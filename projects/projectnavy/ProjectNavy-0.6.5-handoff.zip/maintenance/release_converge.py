from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import json,shutil,subprocess,zipfile,hashlib,sys
from build_converge import ROOT,HERE,VERSION,GAME,SAVE,OLD,PREVIOUS,read,sha,files,readpack,writejson
OUT=ROOT/'outputs/ProjectNavy_梅緹離線擴充MOD_0.6.5'
WHITELIST=['patches/current.pck','patches/current.json']
def file_sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        while b:=f.read(8*1024*1024):h.update(b)
    return h.hexdigest()
def game_snapshot(p):
    return [{'path':q.relative_to(p).as_posix(),'size':q.stat().st_size,'mtime_ns':q.stat().st_mtime_ns,'sha256':file_sha(q)} for q in sorted(p.rglob('*')) if q.is_file()]
def manager(action,game,save,backup,label):
    p=subprocess.run(['powershell.exe','-NoProfile','-ExecutionPolicy','Bypass','-File',str(OUT/'manage_mod.ps1'),'-Action',action,'-GameDir',str(game),'-SaveRoot',str(save),'-BackupRoot',str(backup)],capture_output=True,timeout=90,creationflags=subprocess.CREATE_NO_WINDOW)
    (HERE/(label+'.log')).write_bytes(p.stdout+b'\nSTDERR\n'+p.stderr)
    assert p.returncode==0,(label,p.stderr[-1500:]);d=json.loads(p.stdout.decode('utf-8-sig'));assert d['status']=='PASS' and d['saveUntouched'];return d
def prepare():
    validation=read(HERE/'final_verification.json');assert validation['production_smoke']['pass']
    m=read(HERE/'manifest.json');previous=read(PREVIOUS/'MOD_MANIFEST.json')
    expected={n:previous['original_sha256'][n] for n in ['ProjectNavy.exe','ProjectNavy.pck']}
    expected.update({n:previous['installed'][n]['sha256'] for n in WHITELIST})
    snap=game_snapshot(GAME);assert {r['path']:r['sha256'] for r in snap}==expected
    save=files(SAVE);writejson(HERE/'before_install.json',{'game':snap,'save':save})
    for section in ['payload','original_patch']:(OUT/section/'patches').mkdir(parents=True,exist_ok=True)
    for n in WHITELIST:
        shutil.copy2(PREVIOUS/'payload'/n,OUT/'original_patch'/n)
        shutil.copy2(HERE/'game'/n,OUT/'payload'/n)
        assert file_sha(OUT/'original_patch'/n)==expected[n]
    assert file_sha(OUT/'payload/patches/current.pck')==m['sha256']
    assert read(OUT/'payload/patches/current.json')['sha256']==m['sha256']
    pack=readpack(OUT/'payload/patches/current.pck');assert not any(k.startswith(('boot/','meti/')) for k in pack)
    installed={n:{'size':(OUT/'payload'/n).stat().st_size,'sha256':file_sha(OUT/'payload'/n)} for n in WHITELIST}
    manifest=previous.copy()
    manifest.update(mod_name='梅緹離線擴充：自動火控逐炮管集中',version=VERSION,
        original_version='0.6.16',previous_version='0.6.4',original_sha256=expected,installed=installed,
        cvui_mouse_panel=True,cvui_deck_and_flight_modes=True,cvui_native_air_commands=True,
        cvui_player_offline_carrier_only=True,cvui_auto_preserved=True,cvui_enemy_visibility_respected=True,
        cvui_manual_attack_requires_release_confirmation=True,cvui_gun_panel_switch=True,
        automatic_player_gun_convergence=True,automatic_player_gun_no_random_spread=True,
        individual_turret_aim=True,individual_barrel_horizontal_velocity_correction_max_pct=1,
        in_range_water_coordinate_only=True,manual_and_npc_gunnery_unchanged=True,
        gun_waits_for_turret_to_finish_aiming=True,
        prior_patch_entries_byte_identical=len(m['preserved_previous_entries']),
        profile_schema_unchanged=True,whitelist=WHITELIST,qa_hook_excluded=True,offline_only=True)
    writejson(OUT/'MOD_MANIFEST.json',manifest)
    shutil.copy2(PREVIOUS/'manage_mod.ps1',OUT/'manage_mod.ps1')
    for filename,action in [('重新安裝.cmd','Install'),('還原至0.6.4.cmd','Restore')]:
        (OUT/filename).write_text('@echo off\r\npowershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0manage_mod.ps1" -Action '+action+'\r\npause\r\n',encoding='ascii')
    writejson(OUT/'背景驗證報告.json',validation)
    report_names=['converge','cvui','gunui','enemy','refit','ui','carrier','scene','aim_scene','aim','roles','ammo','features','reload_features','rollback_064','renderconverge1024']
    writejson(OUT/'驗證項目.json',{n:read(HERE/(n+'.json'))['checks'] for n in report_names})
    writejson(OUT/'敵方旗艦清單與驗證.json',read(HERE/'refit.json')['refit_enemy'])
    shutil.copy2(HERE/'changes.diff',OUT/'程式變更.diff')
    shutil.copytree(PREVIOUS/'source',OUT/'source',dirs_exist_ok=True)
    for n in ['shared/sim/sim_ship.gd','shared/sim/meti_convergence.gd','client/battle/meti_aim_preview.gd']:
        shutil.copy2(HERE/'sources'/n,OUT/'source'/Path(n).name)
    (OUT/'screenshots').mkdir(exist_ok=True)
    shutil.copy2(HERE/'converge1024.png',OUT/'screenshots/converge1024.png')
    (OUT/'diagnostics').mkdir(exist_ok=True)
    for n in ['converge.log','cvui.log','gunui.log','enemy.log','refit.log','ui.log','carrier.log','scene.log','aim_scene.log','aim.log','roles.log','ammo.log','features.log','reload_features.log','rollback_064.log','renderconverge1024.stderr.log','renderconverge1024.stdout.log','production_smoke.log']:
        shutil.copy2(HERE/n,OUT/'diagnostics'/n)
    shutil.copy2(PREVIOUS/'安裝與調整說明.txt',OUT/'前版功能說明.txt')
    (OUT/'安裝與調整說明.txt').write_text((HERE/'readme.txt').read_text(encoding='utf-8'),encoding='utf-8-sig')
    writejson(HERE/'prepared.json',{'pass':True,'save_files':len(save),'payload':installed})
    print(json.dumps({'prepared':True,'files':len(save),'payload':installed}))
def probe():
    assert read(HERE/'prepared.json')['pass'];m=read(HERE/'manifest.json');game=Path(m['game']);save=Path(m['save']);before=files(save)
    for n in WHITELIST:shutil.copy2(OUT/'original_patch'/n,game/n)
    results=[]
    for label,action in [('probe_install','Install'),('probe_repeat','Install'),('probe_restore','Restore')]:
        results.append(manager(action,game,save,HERE/'installer_probe_backup',label));assert files(save)==before
    assert results[1]['alreadyDesired']
    assert all(file_sha(game/n)==file_sha(OUT/'original_patch'/n) for n in WHITELIST)
    writejson(HERE/'installer_probe.json',{'pass':True,'save_files_unchanged':len(before),'actions':results})
    print('installer probe PASS')
def install():
    assert read(HERE/'installer_probe.json')['pass'];before=read(HERE/'before_install.json')
    assert game_snapshot(GAME)==before['game'] and files(SAVE)==before['save']
    backup=ROOT/'outputs'/('ProjectNavy_安裝前備份_0.6.5_'+datetime.now(ZoneInfo('Asia/Taipei')).strftime('%Y%m%d_%H%M%S'))
    receipt=manager('Install',GAME,SAVE,backup,'formal_install')
    after=game_snapshot(GAME);old={r['path']:r for r in before['game']};new={r['path']:r for r in after}
    assert set(old)==set(new) and sorted(k for k in old if old[k]!=new[k])==sorted(WHITELIST)
    assert all(new[k]==old[k] for k in ['ProjectNavy.exe','ProjectNavy.pck'])
    assert files(SAVE)==before['save'] and files(backup/'save')==before['save']
    for n in WHITELIST:assert file_sha(GAME/n)==file_sha(OUT/'payload'/n) and file_sha(backup/'game'/n)==old[n]['sha256']
    repeat=manager('Install',GAME,SAVE,backup,'formal_idempotent');assert repeat['alreadyDesired'] and files(SAVE)==before['save']
    verification={'status':'PASS_FORMALLY_INSTALLED','version':VERSION,'previous':'0.6.4','installed_at':datetime.now(ZoneInfo('Asia/Taipei')).isoformat(timespec='seconds'),'backup':str(backup),'changed_only':WHITELIST,'game_files_after':after,'save_files_unchanged':len(before['save']),'save_bytes_size_mtime_unchanged':True,'full_backup_verified':True,'installer_idempotent':True,'game_launched_after_install':False,'computer_use':False,'receipt':receipt}
    writejson(OUT/'正式安裝核對.json',verification)
    writejson(OUT/'套用狀態.json',{'status':'PASS_FORMALLY_INSTALLED','version':VERSION,'backup':str(backup),'installed_at':verification['installed_at']})
    writejson(backup/'備份核對.json',{'previous':'0.6.4','save_files':before['save'],'game_files':before['game'],'backup_verified':True})
    (backup/'備份說明.txt').write_text('安裝0.6.5前的0.6.4補丁及完整存檔。\n退版請優先使用交付包「還原至0.6.4.cmd」，保留遊戲進度。\n請勿單獨覆蓋profile.sav；回復整套備份存檔會失去後續進度。\n',encoding='utf-8-sig')
    inventory={p.relative_to(OUT).as_posix():{'size':p.stat().st_size,'sha256':file_sha(p)} for p in sorted(OUT.rglob('*')) if p.is_file() and p.name!='交付檔案清單.json'}
    writejson(OUT/'交付檔案清單.json',{'version':VERSION,'files':inventory})
    archive=Path(str(OUT)+'.zip')
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in sorted(OUT.rglob('*')):
            if p.is_file():z.write(p,p.relative_to(OUT).as_posix())
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for n,row in inventory.items():assert sha(z.read(n))==row['sha256']
        assert not any('profile.sav' in n or 'ledger.sav' in n or 'stats.bin' in n or '\\' in n for n in z.namelist())
    Path(str(archive)+'.sha256.txt').write_text(file_sha(archive)+'  '+archive.name+'\n',encoding='utf-8')
    writejson(HERE/'completed.json',{'status':'PASS','version':VERSION,'backup':str(backup),'release':str(OUT),'zip':str(archive),'save_files_unchanged':len(before['save']),'installed_pck_sha256':file_sha(GAME/'patches/current.pck')})
    print(json.dumps(read(HERE/'completed.json'),ensure_ascii=True))
if __name__=='__main__':{'prepare':prepare,'probe':probe,'install':install}[sys.argv[1]]()

