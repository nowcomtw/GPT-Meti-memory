from pathlib import Path
HERE=Path(__file__).resolve().parent
def once(s,a,b):
    assert s.count(a)==1,(a,s.count(a))
    return s.replace(a,b)

def sources():
    ship=(HERE/'original_source/sim_ship.gd').read_text(encoding='utf-8-sig')
    ship=once(ship,'extends RefCounted\n','extends RefCounted\nvar meti_convergence_solver: Variant\nvar meti_convergence_tick: int = 0\n')
    anchor='\tfor g: Dictionary in __BJReFJ4ugditvprP9JFCx5S2:\n\t\t__C6pewoIsQqLWcmNf6AFJV9OO(g)\n'
    ship=once(ship,anchor,'\tmeti_convergence_tick += 1\n'+anchor)
    old='\tvar __7QzGUm68_J5mE6QcD29GcSA7: Array[Dictionary] = __a3Qlrip4DI7L5IkLGkgxE5xK.__Uinp0qKlBAx07Wxg3OpdJrIb(g, __SksdldC3RmAB50TlM8qjLTaW, g["elev"], __HIQKIPLb8masbBKrWxn1SFM5.__EaiCL_s7Is8n8XhLMgCmd8bh, __HIQKIPLb8masbBKrWxn1SFM5.__t2UdGLb5AjoD9DJacXSIpDUA, __HIQKIPLb8masbBKrWxn1SFM5.__T3MhJL9nMTQaWMJrYSTIXXqi, __4KgeLYSBHTCVzEvm4t2YLWlw.x, __4KgeLYSBHTCVzEvm4t2YLWlw.y, true, __CQmrJDrlrxQho2i8OkSrVQ1N)\n'
    new=old.replace(', true, __CQmrJDrlrxQho2i8OkSrVQ1N)',', not meti_convergence_active(g), __CQmrJDrlrxQho2i8OkSrVQ1N)')
    ship=once(ship,old,new+'''\tif meti_convergence_active(g) and bool((g["meti_convergence"] as Dictionary).get("in_range", false)):
\t\tvar meti_shell: Dictionary = g["shell"] if int(g["cargo"]) == 0 else g["shell_b"]
\t\t__7QzGUm68_J5mE6QcD29GcSA7 = meti_convergence_solver.align_shots(__7QzGUm68_J5mE6QcD29GcSA7, meti_shell, Vector2i(__k2tNHcrJ7Ubu73oDndNmYPUU, __PnHs8Uffgi24ue5O7EVvelTY))
''')
    old='\tvar __K3bzGozcwIYitknHXJZFzGOX: int = int(g["aim_az"]) if (__P6eCDN63DJlbyMrNKQSMz7jJ and g.has("aim_az")) else __QiHzrKvwrwbVmkkk810kJg1o\n'
    new='''\tvar meti_solution: Dictionary = meti_converge_solution(g) if not __EQCrLhh9pXK6VzYE8riuFeyM else {}
'''+old+'''\tif not meti_solution.is_empty():
\t\t__K3bzGozcwIYitknHXJZFzGOX = posmod(int(meti_solution["az"]) - 900, 3600)
'''
    ship=once(ship,old,new)
    old='\tif absi(d) <= __hcsiwLKVH5CWwqRRJbFcnqkb:\n'
    ship=once(ship,old,'\tif not meti_solution.is_empty():\n\t\t__hcsiwLKVH5CWwqRRJbFcnqkb = 0\n\t\tg["meti_rot_remaining"] = absi(d)\n'+old)
    old='\tvar __5qf09YdieB8GxLvBMQmk9NBp: int = __0dUy3nixZqFUs5DlTiYVzlOT - int(g["elev"])\n'
    ship=once(ship,old,'\tif not meti_solution.is_empty():\n\t\t__0dUy3nixZqFUs5DlTiYVzlOT = int(meti_solution["elev"])\n'+old+'\tif not meti_solution.is_empty():\n\t\tg["meti_elev_remaining"] = absi(__5qf09YdieB8GxLvBMQmk9NBp)\n')
    ship=once(ship,'\tif absi(__5qf09YdieB8GxLvBMQmk9NBp) <= __gJlQ_MAOI1fUZ0lp200xQHBV:\n','\tif absi(__5qf09YdieB8GxLvBMQmk9NBp) <= (0 if not meti_solution.is_empty() else __gJlQ_MAOI1fUZ0lp200xQHBV):\n')
    anchor='\t\tg["angle"] = posmod(int(g["angle"]) + int(g["rot_dir"]) * __5B2g58fxaWxgGDctoUpqKL1h, 3600)\n'
    ship=once(ship,anchor,'\t\tif meti_convergence_active(g):\n\t\t\t__5B2g58fxaWxgGDctoUpqKL1h = mini(__5B2g58fxaWxgGDctoUpqKL1h, int(g.get("meti_rot_remaining", __5B2g58fxaWxgGDctoUpqKL1h)))\n'+anchor)
    anchor='\t\tvar __ndsCdx2W_9IKM6wniG6HA5Pc: int = int(g.get("el_hold", -1))\n'
    ship=once(ship,anchor,'\t\tif meti_convergence_active(g):\n\t\t\t__jY3vFyaCmt6U0_0n10cGLCFA = mini(__jY3vFyaCmt6U0_0n10cGLCFA, int(g.get("meti_elev_remaining", __jY3vFyaCmt6U0_0n10cGLCFA)))\n'+anchor)
    # Do not release a ready selected gun while it is still traversing to the
    # computed convergence. Unsolvable weapons fall back to native behavior.
    old='\treturn bool(__ODOtqe2fVanVALAUFKm2DrFT(__JKsiWcyVLOuGL7Lo1v2kA9kF)["ready"])\n'
    new='''\tvar meti_weapon: Dictionary = __ODOtqe2fVanVALAUFKm2DrFT(__JKsiWcyVLOuGL7Lo1v2kA9kF)
\tif not bool(meti_weapon["ready"]):
\t\treturn false
\tif not bool(__JKsiWcyVLOuGL7Lo1v2kA9kF["launcher"]) and meti_convergence_active(meti_weapon):
\t\tvar meti_solution: Dictionary = meti_weapon["meti_convergence"]
\t\tvar meti_az_error: int = posmod(int(meti_solution["az"]) - 900 - __Rzlu0K6FmW_AJtyGtfyruX3f(meti_weapon) + 1800, 3600) - 1800
\t\treturn absi(meti_az_error) <= 1 and absi(int(meti_solution["elev"]) - int(meti_weapon["elev"])) <= 1
\treturn true
'''
    ship=once(ship,old,new)
    ship+='''\nfunc meti_convergence_active(g: Dictionary) -> bool:
\treturn __ZMgQrrB9zxLXJ4nY9DOrkD1m and __sfrhGgpP8JHW6nvd0GQRC91I and __k2tNHcrJ7Ubu73oDndNmYPUU >= 0 and not g.has("tp_row") and int(g.get("aa", 0)) == 0 and not (g.get("meti_convergence", {}) as Dictionary).is_empty()

func meti_converge_solution(g: Dictionary) -> Dictionary:
\tif not __ZMgQrrB9zxLXJ4nY9DOrkD1m or not __sfrhGgpP8JHW6nvd0GQRC91I or __k2tNHcrJ7Ubu73oDndNmYPUU < 0 or g.has("tp_row") or int(g.get("aa", 0)) != 0:
\t\treturn {}
\tvar shell: Dictionary = g["shell"] if int(g["cargo"]) == 0 else g["shell_b"]
\tvar origin: Vector2i = __oc4DIMhqXqRDsyYDHkfod1e6(g)
\tvar key: Array = [__k2tNHcrJ7Ubu73oDndNmYPUU, __PnHs8Uffgi24ue5O7EVvelTY, int(g["cargo"]), int(shell.get("proj_row", -1)), int(g["V0"]), int(g["max_el"])]
\tif key != g.get("meti_converge_key", []) or (origin != g.get("meti_converge_origin", Vector2i(-1, -1)) and meti_convergence_tick - int(g.get("meti_converge_tick", -100)) >= 10):
\t\tif meti_convergence_solver == null:
\t\t\tmeti_convergence_solver = load("res://shared/sim/meti_convergence.gdc")
\t\tif meti_convergence_solver == null:
\t\t\treturn {}
\t\tvar result: Dictionary = meti_convergence_solver.solve(g, shell, origin, Vector2i(__k2tNHcrJ7Ubu73oDndNmYPUU, __PnHs8Uffgi24ue5O7EVvelTY))
\t\tg["meti_convergence"] = result
\t\tg["meti_converge_key"] = key
\t\tg["meti_converge_origin"] = origin
\t\tg["meti_converge_tick"] = meti_convergence_tick
\treturn g.get("meti_convergence", {})
'''
    preview=(HERE/'original_source/meti_aim_preview.gd').read_text(encoding='utf-8-sig')
    old='var solved = solve(entry["gun"], entry["shell"], entry["az"], int(ship.__CQmrJDrlrxQho2i8OkSrVQ1N))'
    preview=once(preview,old,'''var meti_active: bool = ship.meti_convergence_active(entry["gun"])
\t\t\tvar meti_target = Vector2i(ship.__k2tNHcrJ7Ubu73oDndNmYPUU, ship.__PnHs8Uffgi24ue5O7EVvelTY) - entry["origin"] if meti_active and bool((entry["gun"]["meti_convergence"] as Dictionary).get("in_range", false)) else null
\t\t\tvar solved = solve(entry["gun"], entry["shell"], entry["az"], int(ship.__CQmrJDrlrxQho2i8OkSrVQ1N), meti_active, meti_target)''')
    preview=once(preview,'func solve(g: Dictionary, shell: Dictionary, az: int, accuracy_cap: int = 0) -> Dictionary:', 'func solve(g: Dictionary, shell: Dictionary, az: int, accuracy_cap: int = 0, no_random_spread: bool = false, convergence_target: Variant = null) -> Dictionary:')
    anchor='\tif ideal.is_empty(): return {"valid": false}\n'
    preview=once(preview,anchor,anchor+'''\tif no_random_spread and convergence_target is Vector2i:
\t\tvar meti_solver = load("res://shared/sim/meti_convergence.gdc")
\t\tideal = meti_solver.align_shots(ideal, shell, convergence_target)
''')
    old='\t\tvar fixed: Vector2i = first["fixed"] + Vector2i(int(shot["x"]), int(shot["y"])) - first_start\n'
    preview=once(preview,old,'''\t\tvar fixed: Vector2i
\t\tif no_random_spread and convergence_target is Vector2i:
\t\t\tvar meti_hit = project(shot, shell)
\t\t\tif meti_hit.is_empty(): continue
\t\t\tfixed = meti_hit["fixed"]
\t\telse:
\t\t\tfixed = first["fixed"] + Vector2i(int(shot["x"]), int(shot["y"])) - first_start
''')
    preview=once(preview,'\tfor sample in SAMPLE_COUNT:\n','\tfor sample in (0 if no_random_spread else SAMPLE_COUNT):\n')
    preview=once(preview,'var legend = "艦砲海面預測｜外框為散布樣本估計"','''var legend = "艦砲海面預測｜外框為散布樣本估計"
\tif not entries.is_empty():
\t\tvar meti_active: int = 0
\t\tfor entry in entries:
\t\t\tif ship.meti_convergence_active(entry["gun"]): meti_active += 1
\t\tif meti_active == entries.size(): legend = "自動火控集中｜隨機散布關閉"
\t\telif meti_active > 0: legend = "部分火炮集中｜其他火炮保留散布"''')
    preview=once(preview,'\tif not bool(g.get("ready", false)): return "裝填"\n\treturn "就緒"','\tif not bool(g.get("ready", false)): return "裝填"\n\tif ship.meti_convergence_active(g) and (bool(g.get("rotating", false)) or bool(g.get("elevating", false))): return "瞄準中"\n\treturn "就緒"')
    old='int(g["mount"]), int(g["base"])]'
    preview=once(preview,old,'int(g["mount"]), int(g["base"]), ship.__k2tNHcrJ7Ubu73oDndNmYPUU - ship.__oc4DIMhqXqRDsyYDHkfod1e6(g).x if ship.meti_convergence_active(g) else -1, ship.__PnHs8Uffgi24ue5O7EVvelTY - ship.__oc4DIMhqXqRDsyYDHkfod1e6(g).y if ship.meti_convergence_active(g) else -1]')
    return {'shared/sim/sim_ship.gd':ship,'shared/sim/meti_convergence.gd':(HERE/'meti_convergence.gd').read_text(encoding='utf-8'),'client/battle/meti_aim_preview.gd':preview}
