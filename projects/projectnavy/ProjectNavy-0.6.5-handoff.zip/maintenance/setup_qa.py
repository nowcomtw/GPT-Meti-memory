from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
qa=(ROOT/'work/modcvui/qa.gd').read_text(encoding='utf-8-sig')
qa=qa.replace('20261029_cvui_','20261029_converge_').replace('info["meti_mod_version"]=="0.6.4"','info["meti_mod_version"]=="0.6.5"')
anchor='    if args.has("--qa-cvui"):'
assert qa.count(anchor)==1
qa=qa.replace(anchor,'    if args.has("--qa-converge"):\n        await converge_case(app)\n        finish()\n        return\n'+anchor)
qa+='\n'+(HERE/'converge_qa.gdpart').read_text(encoding='utf-8')
(HERE/'qa.gd').write_text(qa,encoding='utf-8')
