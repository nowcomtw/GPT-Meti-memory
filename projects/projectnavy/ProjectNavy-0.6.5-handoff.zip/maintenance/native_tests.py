from pathlib import Path
import sys,shutil,subprocess,json
from build_converge import ROOT,HERE,tool,read,sha,writejson,once
def hook():
    m=read(HERE/'manifest.json');game=Path(m['game']);assert not (game/'patches/booting').exists()
    mappings={'boot/boot.gdc':ROOT/'work/modretrain/qa_boot.gdc','meti/qa.gd':HERE/'qa.gd'}
    for n in ['prior_aggregate.gdc','prior_assembler.gdc','prior_roster.gdc']:mappings['meti/'+n]=(ROOT/'work/modupdate0616/official_assembler.gdc') if n=='prior_assembler.gdc' else ROOT/'work/modretrain'/n
    for n in ['previous_assembler.gd','previous_gunnery.gd']:mappings['meti/'+n]=(ROOT/'work/modupdate0616'/n) if n=='previous_assembler.gd' else ROOT/'work/modupdate0610'/n
    mappings['meti/roles_previous_assembler.gd']=ROOT/'work/modupdate0616/roles_previous_assembler.gd'
    mappings['meti/official_aggregate.gd']=ROOT/'work/modupdate0616/official_aggregate.gd'
    mappings['meti/previous_battle_scene.gd']=ROOT/'work/modenemy/previous_battle_scene.gd'
    output=HERE/'qa.pck';tool(['--pck-patch='+m['pack'],'--output='+str(output)]+['--patch-file='+str(p)+'=res://'+n for n,p in mappings.items()],'pack_qa')
    shutil.copy2(output,game/'patches/current.pck');meta=read(HERE/'backup/game/patches/current.json');meta.update(sha256=sha(output.read_bytes()),meti_mod_version=m['version']);writejson(game/'patches/current.json',meta)

def run(label):
    m=read(HERE/'manifest.json');game=Path(m['game']);out=HERE/(label+'.json');log=HERE/(label+'.log')
    assert game.resolve()==(HERE/'game').resolve() and m['save'].endswith('ProjectNavy_MetiQA_20261029_converge_001')
    assert not (game/'patches/booting').exists()
    args=[str(game/'ProjectNavy.exe'),'--headless','--','--meti-qa','--no-server','--qa-out',str(out),'--qa-model',str(ROOT/'work/proposal/proposal_parameters_and_model.json')]
    if label=='battle_diag':args+=['--qa-battle-diag']
    if label=='update0616':args+=['--qa-update0616']
    if label=='converge':args+=['--qa-converge']
    if label=='cvui':args+=['--qa-cvui']
    if label=='gunui':args+=['--qa-gunui']
    if label in ['probe','refit','ui']:args+=['--qa-'+label]
    if label=='enemy':args+=['--qa-enemy']
    if label=='roles':args+=['--qa-roles']
    if label=='ammo':args+=['--qa-ammo']
    if label=='transactions':args+=['--qa-transactions']
    if label=='aim':args+=['--qa-aim']
    if label=='aim_scene':args+=['--qa-aim-scene']
    if label=='aim_catalog':args+=['--qa-aim-catalog']
    if label=='aim_ballistics':args+=['--qa-aim-ballistics']
    if label=='dispersion':args+=['--qa-dispersion']
    if label=='carrier':args+=['--qa-carrier']
    if label=='scene':args+=['--qa-carrier-scene']
    if label=='features':args+=['--qa-fleet','--qa-balance','--qa-xp','--qa-update069','--qa-update0610']
    if label.startswith('battle'):args+=['--qa-battle','--qa-xp','--qa-update0610']
    if label=='retrain':args+=['--qa-retrain']
    if label=='persist':args+=['--qa-retrain-reload']
    if out.exists():out.unlink()
    with log.open('wb') as f:
        p=subprocess.Popen(args,cwd=game,stdout=f,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
        try:p.wait(175 if label.startswith('battle') else 120)
        except subprocess.TimeoutExpired:p.kill();p.wait()
    if out.exists():
        d=read(out);print(json.dumps({'label':label,'exit':p.returncode,'pass':d['pass'],'checks':len(d['checks']),'failures':[x for x in d['checks'] if not x['pass']]},ensure_ascii=True),flush=True)
    else:print(log.read_text(encoding='utf-8',errors='replace')[-5000:])
    assert p.returncode==0 and out.exists() and read(out)['pass'],label
    assert 'SCRIPT ERROR:' not in log.read_text(encoding='utf-8',errors='replace'),label
if __name__=='__main__':hook() if sys.argv[1]=='hook' else run(sys.argv[1])
