from pathlib import Path
import sys,json,shutil,subprocess,hashlib,zlib,os,difflib
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'work/modbuild'));from build import readpack,TOOL,ENV,writejson,sha
VERSION='0.6.5';ORIGINAL='0.6.16';GAME=Path('D:/C GAME/ProjectNavy');SAVE=Path.home()/'AppData/Roaming/Godot/app_userdata/Project Navy'
OLD='5845e643054f3c76768e2b78a9c935de30e4347e365ff98e1e85f2975c1c45ba';PREVIOUS=ROOT/'outputs/ProjectNavy_梅緹離線擴充MOD_0.6.4'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def files(p):return [{'path':q.relative_to(p).as_posix(),'size':q.stat().st_size,'mtime_ns':q.stat().st_mtime_ns,'sha256':sha(q.read_bytes())} for q in sorted(p.rglob('*')) if q.is_file()]
def once(s,a,b):
    assert s.count(a)==1,(a,s.count(a));return s.replace(a,b)
def tool(args,label):
    p=subprocess.run([str(TOOL),'--headless']+args,cwd=HERE,env=ENV,capture_output=True,timeout=90,creationflags=subprocess.CREATE_NO_WINDOW)
    (HERE/(label+'.log')).write_bytes(p.stdout+b'\nSTDERR\n'+p.stderr);assert p.returncode==0,(label,p.stderr[-2500:])
from modify_converge import sources

def build():
    assert sha((GAME/'patches/current.pck').read_bytes())==OLD
    backup=HERE/'backup'
    if not backup.exists():
        snap=files(SAVE);(backup/'game/patches').mkdir(parents=True)
        for n in ['current.pck','current.json']:shutil.copy2(GAME/'patches'/n,backup/'game/patches'/n)
        shutil.copytree(SAVE,backup/'save');assert files(SAVE)==snap and files(backup/'save')==snap
        writejson(backup/'snapshot.json',{'patch':OLD,'save_files':snap})
    prior=readpack(backup/'game/patches/current.pck');content={};delta=[]
    for n,s in sources().items():
        src=HERE/'sources'/n;src.parent.mkdir(parents=True,exist_ok=True);src.write_text(s,encoding='utf-8')
        tool(['--compile='+str(src),'--bytecode=ebc36a7','--output='+str(src.parent)],'compile_'+src.stem)
        content[Path(n).with_suffix('.gdc').as_posix()]=src.with_suffix('.gdc').read_bytes()
        base=HERE/'original_source'/Path(n).name
        delta.extend(difflib.unified_diff((base.read_text(encoding='utf-8-sig') if base.exists() else '').splitlines(True),s.splitlines(True),fromfile=n+' (0.6.4)',tofile=n+' (0.6.5)'))
    client=json.loads(prior['assets/data/client_version.json']);client['meti_mod_version']=VERSION;content['assets/data/client_version.json']=(json.dumps(client,ensure_ascii=False,indent=2)+'\n').encode()
    identity=b'MetiOffline/'+VERSION.encode()+b'\0'
    for n,b in sorted({**prior,**content}.items()):
        if n!='assets/data/sim_version.json':identity+=n.encode()+b'\0'+hashlib.sha256(b).digest()
    sim=json.loads(prior['assets/data/sim_version.json']);sim.update(sim_hash=zlib.crc32(identity),meti_mod_version=VERSION);content['assets/data/sim_version.json']=(json.dumps(sim,indent=2)+'\n').encode()
    mappings={}
    for n,b in content.items():
        p=HERE/'overlay'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);mappings[n]=p
    pack=HERE/'converge.pck';tool(['--pck-patch='+str(backup/'game/patches/current.pck'),'--output='+str(pack)]+['--patch-file='+str(p)+'=res://'+n for n,p in mappings.items()],'pack_converge')
    final=readpack(pack);assert final=={**prior,**content} and not any(n.startswith(('boot/','meti/')) for n in final)
    game=HERE/'game';(game/'patches').mkdir(parents=True,exist_ok=True)
    for n in ['ProjectNavy.exe','ProjectNavy.pck']:
        if not (game/n).exists():os.link(ROOT/'work/modupdate069/game'/n,game/n)
    shutil.copy2(pack,game/'patches/current.pck');meta=read(backup/'game/patches/current.json');meta.update(sha256=sha(pack.read_bytes()),meti_mod_version=VERSION);writejson(game/'patches/current.json',meta)
    custom='ProjectNavy_MetiQA_20261029_converge_001';save=Path.home()/'AppData/Roaming'/custom
    (game/'override.cfg').write_text('[application]\nconfig/use_custom_user_dir=true\nconfig/custom_user_dir_name="'+custom+'"\n',encoding='utf-8')
    if not save.exists():shutil.copytree(backup/'save',save)
    writejson(HERE/'manifest.json',{'version':VERSION,'original_version':ORIGINAL,'game':str(game),'save':str(save),'pack':str(pack),'sha256':sha(pack.read_bytes()),'entries':len(final),'changed_or_added':sorted(content),'preserved_previous_entries':[n for n in prior if n not in content],'prior_pck_sha256':OLD,'gun_accuracy_extra_pct':150,'gun_accuracy_total_pct':225,'dispersion_floor_changed':False,'automatic_gun_convergence':True,'auto_player_no_random_spread':True,'cvui_mouse_panel':True,'cvui_native_commands':True,'gunui_mouse_panel':True,'gunui_dynamic_key_labels':True,'elite_enemy_mixed':True,'elite_enemy_pool':[477,478,479,480,481,482,483],'elite_enemy_per_8':1,'elite_enemy_max':3,'elite_enemy_only':True,'original_level_range_for_other_npcs':True,'gun_roles_from_native_hull_flags':True,'gun_storage_schema_unchanged':True,'ammo_bulk_same_model':True,'ammo_bulk_default_off':True,'automatic_aim_preview':True,'preview_default_on':True,'preview_setting_required':False,'default_auto':True,'player_carrier_only':True,'ship_navigation_automated':False,'native_command_recording':True,'profile_schema_unchanged':True,'new_settings_key':'meti_cv_auto'})
    (HERE/'changes.diff').write_text(''.join(delta),encoding='utf-8');print(json.dumps(read(HERE/'manifest.json'),ensure_ascii=True))
if __name__=='__main__':build()
