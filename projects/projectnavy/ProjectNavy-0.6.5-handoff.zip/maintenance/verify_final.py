from pathlib import Path
import os, re, shutil, subprocess
from build_converge import ROOT,HERE,read,writejson,sha,tool,readpack,files,SAVE,GAME,OLD
from native_tests import run

def finish():
    m=read(HERE/'manifest.json');game=Path(m['game'])
    names=['converge','cvui','gunui','carrier','scene','enemy','refit','ui','aim_scene','aim','roles','ammo','features','reload_features']
    reports={n:read(HERE/(n+'.json')) for n in names}
    assert all(d['pass'] for d in reports.values())
    assert reports['reload_features']['roster']==reports['features']['roster_after']
    render=read(HERE/'renderconverge1024.json');assert render['pass']
    render_lines=[]
    for suffix in ['stdout.log','stderr.log']:
        render_lines+=(HERE/('renderconverge1024.'+suffix)).read_text(encoding='utf-8',errors='replace').splitlines()
    render_errors=[x for x in render_lines if 'ERROR:' in x];render_warnings=[x for x in render_lines if 'WARNING:' in x]
    assert not render_errors and not render_warnings and (HERE/'converge1024.png').is_file()
    # Exercise rollback to the exact previous release using its own version-specific QA.
    legacy=HERE/'legacy_qa.pck';legacy_source=HERE/'legacy_qa.gd'
    legacy_source.write_text((ROOT/'work/modcvui/qa.gd').read_text(encoding='utf-8'),encoding='utf-8')
    tool(['--pck-patch='+str(HERE/'backup/game/patches/current.pck'),'--output='+str(legacy),
          '--patch-file='+str(ROOT/'work/modretrain/qa_boot.gdc')+'=res://boot/boot.gdc',
          '--patch-file='+str(legacy_source)+'=res://meti/qa.gd'],'pack_legacy_qa')
    shutil.copy2(legacy,game/'patches/current.pck')
    meta=read(HERE/'backup/game/patches/current.json');meta['sha256']=sha(legacy.read_bytes());writejson(game/'patches/current.json',meta)
    run('rollback_064');rollback=read(HERE/'rollback_064.json')
    assert rollback['pass'] and rollback['roster']==reports['reload_features']['roster_after']
    meta=read(HERE/'backup/game/patches/current.json');shutil.copy2(m['pack'],game/'patches/current.pck')
    meta.update(version=m['original_version'],meti_mod_version=m['version'],sha256=m['sha256']);writejson(game/'patches/current.json',meta)
    # Smoke test only the uninstrumented isolated copy; restore its settings exactly.
    log=HERE/'production_smoke.log';settings=Path(m['save'])/'settings.cfg';old=settings.read_bytes();stamp=settings.stat()
    text=old.decode('utf-8-sig')
    if re.search(r'(?m)^bgm_on=',text):text=re.sub(r'(?m)^bgm_on=.*$','bgm_on=false',text)
    else:text=text.replace('[main]','[main]\nbgm_on=false',1)
    settings.write_text(text,encoding='utf-8')
    try:
        with log.open('wb') as f:
            p=subprocess.run([str(game/'ProjectNavy.exe'),'--headless','--audio-driver','Dummy','--verbose','--quit-after','360'],cwd=game,stdout=f,stderr=subprocess.STDOUT,timeout=30,creationflags=subprocess.CREATE_NO_WINDOW)
    finally:
        settings.write_bytes(old);os.utime(settings,ns=(stamp.st_atime_ns,stamp.st_mtime_ns))
    lines=log.read_text(encoding='utf-8',errors='replace').splitlines()
    errors=[x for x in lines if 'ERROR:' in x];warnings=[x for x in lines if 'WARNING:' in x]
    assert p.returncode==0 and not errors and not warnings,(p.returncode,errors,warnings)
    final=readpack(game/'patches/current.pck');prior=readpack(HERE/'backup/game/patches/current.pck')
    assert len(final)==m['entries'] and all(final[n]==prior[n] for n in m['preserved_previous_entries'])
    assert sorted(n for n in final if prior.get(n)!=final[n])==m['changed_or_added']
    assert not any(n.startswith(('boot/','meti/')) for n in final)
    assert sha((GAME/'patches/current.pck').read_bytes())==OLD
    assert files(SAVE)==read(HERE/'backup/snapshot.json')['save_files']
    counts={n:len(d['checks']) for n,d in reports.items()}
    checks={c['name']:c for c in reports['converge']['checks']}
    underway=checks['converge_underway_reachable_rounds_are_concentrated']['detail']
    impacts=checks['converge_native_projectile_steps_produce_same_water_impact']['detail']
    no_warn=['converge','gunui','carrier','enemy','refit','aim_scene','aim','roles','ammo','reload_features']
    unexpected={n:[line for line in (HERE/(n+'.log')).read_text(encoding='utf-8',errors='replace').splitlines() if 'ERROR:' in line or 'WARNING:' in line] for n in no_warn}
    unexpected={n:v for n,v in unexpected.items() if v}
    assert not unexpected,unexpected
    # These two inherited suites create intentionally uninitialized in-memory
    # ProfileStore fixtures. Their identical prior-version save errors do not
    # represent writes to the copied or formal player profile.
    mock_save_errors={}
    for n in ['ui','features']:
        def diagnostic_bytes(path):return [line for line in path.read_bytes().splitlines() if b'ERROR:' in line or b'WARNING:' in line]
        current=diagnostic_bytes(HERE/(n+'.log'));previous=diagnostic_bytes(ROOT/'work/modcvui'/(n+'.log'))
        assert current==previous and all(line==b'ERROR: '+('存档写入失败：'.encode('utf-8')) for line in current),(n,current[:3])
        mock_save_errors[n]={'count':len(current),'same_as_previous_release':True,'fixture':'uninitialized in-memory ProfileStore'}
    # Older isolated scene teardown has shown an intermittent single-resource
    # warning; retain it as a diagnostic rather than hiding it.
    teardown={n:[line for line in (HERE/(n+'.log')).read_text(encoding='utf-8',errors='replace').splitlines() if 'ERROR:' in line or 'WARNING:' in line] for n in ['scene','cvui']}
    assert all(all('ObjectDB instances leaked at exit' in line or '1 resources still in use at exit' in line for line in lines) for lines in teardown.values())
    validation={'status':'PASS_AUTOMATIC_GUN_CONVERGENCE_SCOPE','version':m['version'],'original_version':m['original_version'],
      'checks':counts,'render_checks':len(render['checks']),'rollback_checks':len(rollback['checks']),
      'total_passed_feature_checks':sum(counts.values())+len(render['checks'])+len(rollback['checks']),
      'prior_patch_entries_byte_identical':len(m['preserved_previous_entries']),'changed_or_added':m['changed_or_added'],
      'underway_reachable_rounds':underway,'native_water_impact_count':len(impacts['splash_points']),
      'copied_save_persistence_exact':True,'rollback_roster_exact':True,'qa_hook_excluded':True,
      'render_errors':render_errors,'render_warnings':render_warnings,'qa_teardown_diagnostics':teardown,'mock_save_errors':mock_save_errors,'other_qa_diagnostics':unexpected,
      'production_smoke':{'pass':True,'exit':p.returncode,'errors':errors,'warnings':warnings,'isolated_music_temporarily_disabled':True,'isolated_settings_restored_exact':settings.read_bytes()==old},
      'formal_save_count':len(files(SAVE)),'formal_save_equals_initial_snapshot':True,'foreground_launch':False,'computer_use':False,'render_parent_hidden':True,
      'validation_limits':['Player automatic fire control only; manual and NPC shots retain their existing dispersion.',
      'Per-barrel horizontal launch velocity correction is capped at one percent of the original horizontal speed; actual collisions are unmodified.',
      'Same integer water coordinate was observed in controlled in-range scenarios; this is not a guarantee of the same impact point in every battle.',
      'Out-of-range, firing arcs, target movement, collision and limited adjustment can prevent convergence.',
      'No full natural campaign battle or visible formal-game acceptance was performed.']}
    writejson(HERE/'final_verification.json',validation)
    print({'pass':True,'checks':validation['total_passed_feature_checks'],'saves':validation['formal_save_count'],'prior_resources_preserved':validation['prior_patch_entries_byte_identical'],'other_qa_diagnostics':unexpected})

if __name__=='__main__':finish()
