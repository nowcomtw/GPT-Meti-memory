import sys
from native_tests import run
for name in sys.argv[1:]:run(name)
