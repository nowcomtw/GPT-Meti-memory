class_name __a3Qlrip4DI7L5IkLGkgxE5xK
const __20d5R79I8KhCsBXP1JpFOLE8: = 50
const __TZzvT81yZO7o4__efCrW8_Ps: = -180
const __n7FJGfy2zn3Ki8n0LQtfSsGs: = __3RMEFseeX7lwG1B9fZj8jUzH.__n7FJGfy2zn3Ki8n0LQtfSsGs
static func __eY2uIcoZhiz2WRqGDlLe85tO(__TtDRmOOrgVDByXFK4vVNipR6: __bzxMmNAcE_RKMny5gklgDglw, __wx25vxQaaOqGJjMikmahm13i: int, __73Csl_vu49UX9nAufky3WoHG: int = 0, __T00UJXPIT22zn5wGoLVvfJGA: int = 0, __P_AswX73K6xO15prBJitgtEr: int = 0) -> Dictionary:
	var __R2aLjvBT7hkbRa0Y_P3TOiP7: int = __TtDRmOOrgVDByXFK4vVNipR6.__Jy2hcMM9emCF3iBBkLMyeUr7("Gunset", __wx25vxQaaOqGJjMikmahm13i, 152)
	var __fHRlAmYSbMLl2R0QdCzM2yjQ: int = __TtDRmOOrgVDByXFK4vVNipR6.__Jy2hcMM9emCF3iBBkLMyeUr7("Gunset", __wx25vxQaaOqGJjMikmahm13i, 154)
	var g: = {"w98": __R2aLjvBT7hkbRa0Y_P3TOiP7, "barrels": __R2aLjvBT7hkbRa0Y_P3TOiP7 & 7, "blen": ((__R2aLjvBT7hkbRa0Y_P3TOiP7 >> 3) & 63) * 100, "bgap": ((__R2aLjvBT7hkbRa0Y_P3TOiP7 >> 9) & 31) * 100, "seat": (__fHRlAmYSbMLl2R0QdCzM2yjQ >> 1) & 7, "max_el": ((__fHRlAmYSbMLl2R0QdCzM2yjQ >> 4) & 127) * 10, "caliber": __TtDRmOOrgVDByXFK4vVNipR6.__Jy2hcMM9emCF3iBBkLMyeUr7("Gunset", __wx25vxQaaOqGJjMikmahm13i, 160), "V0": __TtDRmOOrgVDByXFK4vVNipR6.__Jy2hcMM9emCF3iBBkLMyeUr7("Gunset", __wx25vxQaaOqGJjMikmahm13i, 168), "acc70": __73Csl_vu49UX9nAufky3WoHG, "mount": __T00UJXPIT22zn5wGoLVvfJGA, "base": __P_AswX73K6xO15prBJitgtEr, }
	g["muzzle"] = __clveUzS5EUMaa0neAkHLPAMo(g)
	return g
const __jSHCPDm8k9O9CtctnqkQJ6b2: = 280
const __W_7fSiIVO80l6wn6KwvCuoPH: = __jSHCPDm8k9O9CtctnqkQJ6b2 * 117 / 100
static func __DsPMDiFMjhFuKK6KYj6QVgYN(__K3ED1pbOquXEt7zBb_m6hjVM: int) -> Dictionary:
	if __MD_UopLd02nwgefGRENUlQnd.has(__K3ED1pbOquXEt7zBb_m6hjVM):
		return __MD_UopLd02nwgefGRENUlQnd[__K3ED1pbOquXEt7zBb_m6hjVM]
	var __eITRt5dC9TRureFpiNud6Dei: int = (__K3ED1pbOquXEt7zBb_m6hjVM >> 12) & 7
	__eITRt5dC9TRureFpiNud6Dei += __eITRt5dC9TRureFpiNud6Dei & 1
	var size: int = (__K3ED1pbOquXEt7zBb_m6hjVM >> 3) & 63
	size += size & 1
	var __9Gwzhr4E6VnXf1OFhIPvgRKz: int = size
	var w: int = 2 * __9Gwzhr4E6VnXf1OFhIPvgRKz
	var __hLPULSDbPcvCFdnG6HzaoodK: int = 2 * __eITRt5dC9TRureFpiNud6Dei
	var __yNce5PiDDf2qhHnLWuOYZCZb: = PackedByteArray()
	__yNce5PiDDf2qhHnLWuOYZCZb.resize(w * w)
	var __vWgVWqEgbeRjJSfwNhZC4LV_: int = (w - __hLPULSDbPcvCFdnG6HzaoodK) / 2
	for __HjUqOnkaJC00UBINTcTT9WTp: int in w:
		for __3scKA5ZuEVMBoc5or8Yig4BD: int in __hLPULSDbPcvCFdnG6HzaoodK:
			__yNce5PiDDf2qhHnLWuOYZCZb[w * __HjUqOnkaJC00UBINTcTT9WTp + __3scKA5ZuEVMBoc5or8Yig4BD + __vWgVWqEgbeRjJSfwNhZC4LV_] = 1
	var __Nb4nANXmNzsujRMpAOKgcD0T: Array[PackedByteArray] = []
	for d: int in 36:
		var __Zlcusze7RcZHMYZognf4UTTS: int = d * 100
		var __xqKDQJe_zCEGyW9W8YtUA_ia: int = __TXCdoY85HWzo9E7Qcf9l8raZ.__9nHAKAsjPH38LR2tAezCTqd_[__Zlcusze7RcZHMYZognf4UTTS]
		var s: int = __TXCdoY85HWzo9E7Qcf9l8raZ.__7laIgLr3i8VN0D_tZnYT3p0D[__Zlcusze7RcZHMYZognf4UTTS]
		var __Gemt2_YYVXkJBaX4zJ31ttjp: = PackedByteArray()
		__Gemt2_YYVXkJBaX4zJ31ttjp.resize(w * w)
		for __41tMAYcvVbaML1kDvfBnmjFZ: int in w:
			var __ZwMZWpf3tzAvro767sZgICM3: int = 10 * (__9Gwzhr4E6VnXf1OFhIPvgRKz - __41tMAYcvVbaML1kDvfBnmjFZ)
			for ___z0AGY4cwKDPZTrlGHf9q4OS: int in w:
				if __yNce5PiDDf2qhHnLWuOYZCZb[w * __41tMAYcvVbaML1kDvfBnmjFZ + ___z0AGY4cwKDPZTrlGHf9q4OS] == 0:
					continue
				var __qaUDFsIyQxLYPexkDSRDNf6A: int = 10 * (__9Gwzhr4E6VnXf1OFhIPvgRKz - ___z0AGY4cwKDPZTrlGHf9q4OS)
				var __UIBTSnXQPe5b3ci5HCBoMQqm: int = (__qaUDFsIyQxLYPexkDSRDNf6A * __xqKDQJe_zCEGyW9W8YtUA_ia - __ZwMZWpf3tzAvro767sZgICM3 * s) / 1000
				var __8uXDujXOzHJMYt8vZ0dREXv9: int = (__qaUDFsIyQxLYPexkDSRDNf6A * s + __ZwMZWpf3tzAvro767sZgICM3 * __xqKDQJe_zCEGyW9W8YtUA_ia) / 1000
				var __ewoIjPZuzlBLDe0sU2YSyeAX: int = __9Gwzhr4E6VnXf1OFhIPvgRKz + __UIBTSnXQPe5b3ci5HCBoMQqm / 10
				var __1KnhFbD8WiWxH0Pgz1TWDBch: int = __9Gwzhr4E6VnXf1OFhIPvgRKz - __8uXDujXOzHJMYt8vZ0dREXv9 / 10
				if __ewoIjPZuzlBLDe0sU2YSyeAX >= 0 and __ewoIjPZuzlBLDe0sU2YSyeAX < w and __1KnhFbD8WiWxH0Pgz1TWDBch >= 0 and __1KnhFbD8WiWxH0Pgz1TWDBch < w:
					__Gemt2_YYVXkJBaX4zJ31ttjp[w * __1KnhFbD8WiWxH0Pgz1TWDBch + __ewoIjPZuzlBLDe0sU2YSyeAX] = 1
		for r: int in w:
			for __bVOy7MRct1A5SmK9u3Ae_Fnq: int in range(1, w - 1):
				var __3j_VJqLVbqhnJOBrXuLxn3d1: int = w * r + __bVOy7MRct1A5SmK9u3Ae_Fnq
				if __Gemt2_YYVXkJBaX4zJ31ttjp[__3j_VJqLVbqhnJOBrXuLxn3d1] == 0 and __Gemt2_YYVXkJBaX4zJ31ttjp[__3j_VJqLVbqhnJOBrXuLxn3d1 - 1] == 1 and __Gemt2_YYVXkJBaX4zJ31ttjp[__3j_VJqLVbqhnJOBrXuLxn3d1 + 1] == 1:
					__Gemt2_YYVXkJBaX4zJ31ttjp[__3j_VJqLVbqhnJOBrXuLxn3d1] = 1
		__Nb4nANXmNzsujRMpAOKgcD0T.append(__Gemt2_YYVXkJBaX4zJ31ttjp)
	var __53upfkCDsNqkj6nvujQ0_fqx: = {"W": w, "ebp": __9Gwzhr4E6VnXf1OFhIPvgRKz, "wid": __hLPULSDbPcvCFdnG6HzaoodK, "masks": __Nb4nANXmNzsujRMpAOKgcD0T}
	__MD_UopLd02nwgefGRENUlQnd[__K3ED1pbOquXEt7zBb_m6hjVM] = __53upfkCDsNqkj6nvujQ0_fqx
	return __53upfkCDsNqkj6nvujQ0_fqx
static func hit_test(__ZhWM3MlHDgaKcnote9J3JQMy: Dictionary, __awSr8XQkXXZdutp276_uLIob: int, __Rf_er09NsiWqiCVPpnR100th: int, direction: int, __j9aExjhwVtZEqRtylLY4nMVp: int, __RXIBWrSlaxtoe9ZjC8rQCPoV: int) -> int:
	var __MXtSZ9JqsI9JZI1rDvGriPwL: int = __ZhWM3MlHDgaKcnote9J3JQMy["ebp"]
	var w: int = __ZhWM3MlHDgaKcnote9J3JQMy["W"]
	var __rUqIEGKxFW9syHYbnbfhZtUp: int = (__RXIBWrSlaxtoe9ZjC8rQCPoV - __Rf_er09NsiWqiCVPpnR100th) * 170 / 100 + __Rf_er09NsiWqiCVPpnR100th
	var __Zhg6x0TT2954We2qT9EFAL5z: int = __awSr8XQkXXZdutp276_uLIob - 4 * __MXtSZ9JqsI9JZI1rDvGriPwL
	var __AFLx62rywhRbCPmDjWUbnQ6u: int = __Rf_er09NsiWqiCVPpnR100th - 4 * __MXtSZ9JqsI9JZI1rDvGriPwL
	var __C1cN9AAUUSob_W4cQ0hWcFZP: int = __Zhg6x0TT2954We2qT9EFAL5z + 8 * __MXtSZ9JqsI9JZI1rDvGriPwL
	var __NtGj0GLOwjiwgWzYD10yljVl: int = __AFLx62rywhRbCPmDjWUbnQ6u + 8 * __MXtSZ9JqsI9JZI1rDvGriPwL
	if not (__Zhg6x0TT2954We2qT9EFAL5z < __j9aExjhwVtZEqRtylLY4nMVp and __j9aExjhwVtZEqRtylLY4nMVp < __C1cN9AAUUSob_W4cQ0hWcFZP and __AFLx62rywhRbCPmDjWUbnQ6u < __rUqIEGKxFW9syHYbnbfhZtUp and __rUqIEGKxFW9syHYbnbfhZtUp < __NtGj0GLOwjiwgWzYD10yljVl):
		return 0
	var __dFhiOSTkCcgTLb1ZoB2cg5x7: int = (__rUqIEGKxFW9syHYbnbfhZtUp - __AFLx62rywhRbCPmDjWUbnQ6u) / 4 * w + (__j9aExjhwVtZEqRtylLY4nMVp - __Zhg6x0TT2954We2qT9EFAL5z) / 4
	if __dFhiOSTkCcgTLb1ZoB2cg5x7 >= w * w:
		return 0
	return (__ZhWM3MlHDgaKcnote9J3JQMy["masks"][direction] as PackedByteArray)[__dFhiOSTkCcgTLb1ZoB2cg5x7]
static func __ORqwIwPfsrSDsYgAOm7jWTne(__tRJrkE5O3YDxvx2IdUScdG3T: Dictionary, __g7OhXSd8N0SfL94jqPw6aU98: int, __7hXGNali9bFleIYNvmEr5rz8: int = 0, __vHXsppD3sgZ9iuJDrrbvgN_Q: int = 50000) -> Array:
	var __ZYDX2_VKSQ3OGmwNOap3C0ST: Dictionary = __tRJrkE5O3YDxvx2IdUScdG3T.duplicate()
	for __QqYoBRGHvLjfLwKeYF2nkUj_: int in range(1, __vHXsppD3sgZ9iuJDrrbvgN_Q):
		step(__ZYDX2_VKSQ3OGmwNOap3C0ST, __g7OhXSd8N0SfL94jqPw6aU98, __7hXGNali9bFleIYNvmEr5rz8)
		var h: int = __ZYDX2_VKSQ3OGmwNOap3C0ST["h"]
		var __89V7s9lvLvo5HnLebGMtqEY7: int = __ZYDX2_VKSQ3OGmwNOap3C0ST["vz"]
		var __LsZMxo65J7qVei6tsp7TF0IG: int = h + __89V7s9lvLvo5HnLebGMtqEY7
		if __LsZMxo65J7qVei6tsp7TF0IG < 0:
			var __GoPS5a7cG6zfOSAqMvmJbYNT: int = absi(h * 100 / __89V7s9lvLvo5HnLebGMtqEY7) if __89V7s9lvLvo5HnLebGMtqEY7 != 0 else 0
			return [(int(__ZYDX2_VKSQ3OGmwNOap3C0ST["x"]) + int(__ZYDX2_VKSQ3OGmwNOap3C0ST["vx"]) * __GoPS5a7cG6zfOSAqMvmJbYNT / 100) / __jSHCPDm8k9O9CtctnqkQJ6b2, (int(__ZYDX2_VKSQ3OGmwNOap3C0ST["y"]) + int(__ZYDX2_VKSQ3OGmwNOap3C0ST["vy"]) * __GoPS5a7cG6zfOSAqMvmJbYNT / 100) / __W_7fSiIVO80l6wn6KwvCuoPH, __QqYoBRGHvLjfLwKeYF2nkUj_]
		__ZYDX2_VKSQ3OGmwNOap3C0ST["x"] = int(__ZYDX2_VKSQ3OGmwNOap3C0ST["x"]) + int(__ZYDX2_VKSQ3OGmwNOap3C0ST["vx"])
		__ZYDX2_VKSQ3OGmwNOap3C0ST["y"] = int(__ZYDX2_VKSQ3OGmwNOap3C0ST["y"]) + int(__ZYDX2_VKSQ3OGmwNOap3C0ST["vy"])
		__ZYDX2_VKSQ3OGmwNOap3C0ST["h"] = __LsZMxo65J7qVei6tsp7TF0IG
	return [null, null, __vHXsppD3sgZ9iuJDrrbvgN_Q]
static func __clveUzS5EUMaa0neAkHLPAMo(g: Dictionary) -> PackedInt32Array:
	var __GwQu1bxMvrCmlnqxZ8gd8kZ3: int = g["barrels"]
	var __2uuh_SaHRTfXTFqFw9480H1H: int = g["bgap"]
	var __PHqq9zsqrZGcrECQuWA_gC54: int = g["blen"]
	var __BDs9kow7mjx3X9cTSxub2tG6: int = g["seat"]
	var __i9Z82pglhE2eGC13NAA4zFdP: int = - ((int(g["w98"]) >> 1) & 3) * __2uuh_SaHRTfXTFqFw9480H1H
	if (__GwQu1bxMvrCmlnqxZ8gd8kZ3 & 1) == 0:
		__i9Z82pglhE2eGC13NAA4zFdP += __2uuh_SaHRTfXTFqFw9480H1H / 2
	var step: int = int(g["max_el"]) / 8
	var __7c1OEDxLqmU3qcTg0QHp0H0C: = PackedInt32Array()
	__7c1OEDxLqmU3qcTg0QHp0H0C.resize(8)
	var __VEnOpHJd4MJIfsWblQ6dbFNv: = PackedInt32Array()
	__VEnOpHJd4MJIfsWblQ6dbFNv.resize(__GwQu1bxMvrCmlnqxZ8gd8kZ3 * 8 * 2)
	var __UFdYlJKDOrZMGcCNqzUG1IIs: int = 0
	for __SrB8vubhJd3QCUiQhXi1xjAh: int in 8:
		__7c1OEDxLqmU3qcTg0QHp0H0C[__SrB8vubhJd3QCUiQhXi1xjAh] = __TXCdoY85HWzo9E7Qcf9l8raZ.__7laIgLr3i8VN0D_tZnYT3p0D[__UFdYlJKDOrZMGcCNqzUG1IIs] * __PHqq9zsqrZGcrECQuWA_gC54 / 1000
		var __nTcMngRWMLC80CdzcccLgcGF: int = __TXCdoY85HWzo9E7Qcf9l8raZ.__9nHAKAsjPH38LR2tAezCTqd_[__UFdYlJKDOrZMGcCNqzUG1IIs] * __PHqq9zsqrZGcrECQuWA_gC54 / 1000
		var x: int = __i9Z82pglhE2eGC13NAA4zFdP
		for __jZ0gOQgDii1GirIQBzI7vbLj: int in __GwQu1bxMvrCmlnqxZ8gd8kZ3:
			__VEnOpHJd4MJIfsWblQ6dbFNv[(__jZ0gOQgDii1GirIQBzI7vbLj * 8 + __SrB8vubhJd3QCUiQhXi1xjAh) * 2] = x
			__VEnOpHJd4MJIfsWblQ6dbFNv[(__jZ0gOQgDii1GirIQBzI7vbLj * 8 + __SrB8vubhJd3QCUiQhXi1xjAh) * 2 + 1] = __nTcMngRWMLC80CdzcccLgcGF
			x += __2uuh_SaHRTfXTFqFw9480H1H
		__UFdYlJKDOrZMGcCNqzUG1IIs = (__UFdYlJKDOrZMGcCNqzUG1IIs + step) % 3600
	var __ln0_ibGwZlwpT7KqndZXsR1c: = PackedInt32Array()
	__ln0_ibGwZlwpT7KqndZXsR1c.resize(36 * 8 * __GwQu1bxMvrCmlnqxZ8gd8kZ3 * 2)
	for d: int in 36:
		var __jNiKKBxQlBHm4fY0NBRJ5FMZ: int = d * 100
		var __jsOE_snKIgpZVdT5oFzryO3l: int = __TXCdoY85HWzo9E7Qcf9l8raZ.__9nHAKAsjPH38LR2tAezCTqd_[__jNiKKBxQlBHm4fY0NBRJ5FMZ]
		var s: int = __TXCdoY85HWzo9E7Qcf9l8raZ.__7laIgLr3i8VN0D_tZnYT3p0D[__jNiKKBxQlBHm4fY0NBRJ5FMZ]
		for __LknjOvOU0b2N7XyktYJuj23D: int in __GwQu1bxMvrCmlnqxZ8gd8kZ3:
			for __2XNdECdFGAtDp3xAjOiOXVzu: int in 8:
				var __aXLiQx82qmSrUIuLVD_xVCOg: int = __VEnOpHJd4MJIfsWblQ6dbFNv[(__LknjOvOU0b2N7XyktYJuj23D * 8 + __2XNdECdFGAtDp3xAjOiOXVzu) * 2]
				var __3x9EnKu_pYxFpqe3pRhPzXIE: int = __VEnOpHJd4MJIfsWblQ6dbFNv[(__LknjOvOU0b2N7XyktYJuj23D * 8 + __2XNdECdFGAtDp3xAjOiOXVzu) * 2 + 1]
				var __mPIFh2yLmO2khY62Qfh72FIg: int = ((d * 8 + __2XNdECdFGAtDp3xAjOiOXVzu) * __GwQu1bxMvrCmlnqxZ8gd8kZ3 + __LknjOvOU0b2N7XyktYJuj23D) * 2
				__ln0_ibGwZlwpT7KqndZXsR1c[__mPIFh2yLmO2khY62Qfh72FIg] = (__aXLiQx82qmSrUIuLVD_xVCOg * __jsOE_snKIgpZVdT5oFzryO3l - __3x9EnKu_pYxFpqe3pRhPzXIE * s) / 100000
				__ln0_ibGwZlwpT7KqndZXsR1c[__mPIFh2yLmO2khY62Qfh72FIg + 1] = (__aXLiQx82qmSrUIuLVD_xVCOg * s + __3x9EnKu_pYxFpqe3pRhPzXIE * __jsOE_snKIgpZVdT5oFzryO3l) / 200000 + (__7c1OEDxLqmU3qcTg0QHp0H0C[__2XNdECdFGAtDp3xAjOiOXVzu] + 50) / 200 + __BDs9kow7mjx3X9cTSxub2tG6
	return __ln0_ibGwZlwpT7KqndZXsR1c
static func __My0r70GtKB_51wp2KWwlfoX2(__B7JDyr2dfRCvTrMqFWseRnOK: Dictionary, __WreU5ZAzQtAAJVY5FLAp0j36: int) -> int:
	var a: int = int(__B7JDyr2dfRCvTrMqFWseRnOK["acc70"])
	return mini(a, __WreU5ZAzQtAAJVY5FLAp0j36) if __WreU5ZAzQtAAJVY5FLAp0j36 > 0 else a
static var __MD_UopLd02nwgefGRENUlQnd: Dictionary = {}
static func __Uinp0qKlBAx07Wxg3OpdJrIb(__TAtJXDBCVc28BnMmUqTP8Amr: Dictionary, __w2lSI32p6e8UKvEHMvwvyRiN: int, __WkE0RQ7Jkcms9jzzMtDexcpx: int, __ua93LNzwTA8V8_hlh5jO0vPs: int, __M569gMr1IpPZhbEfD9zQ5Cc0: int, __UaB3tWU3yPVvCA_wY0uGW7Fx: PackedInt32Array, __JuOAgtVoT7f_7RbOg6sFfZ4C: int = 0, __eZsm9LeAl85wVo6ACgb4iae5: int = 0, __5hNZMmXMggc2bLy98WZeFW2l: bool = true, ____2PcPAvAUyj_FUcgcnfkigG: int = 0) -> Array[Dictionary]:
	var __mTC8K1P9Y1nUZsbsx74szOin: int = __ua93LNzwTA8V8_hlh5jO0vPs + __M569gMr1IpPZhbEfD9zQ5Cc0 + int(__TAtJXDBCVc28BnMmUqTP8Amr["mount"])
	var __dU5FtIUfAj2i9fU1yVDxvK4w: int = __TAtJXDBCVc28BnMmUqTP8Amr["max_el"]
	var step: int = __dU5FtIUfAj2i9fU1yVDxvK4w / 8
	var __89y0dxxTQGYG11_A2fUe4gCe: int = mini((__WkE0RQ7Jkcms9jzzMtDexcpx + step / 2) / step, 7) if step != 0 else 0
	var __tGzT9GoEXiR4eFLEycqLPRj9: int = posmod(__w2lSI32p6e8UKvEHMvwvyRiN - 900 + 50, 3600) / 100
	var __sRFoJmhjXpIQvXrMueh68VfG: int = 0
	var __I5mSwjYEiwjfvY97fzXGsyfq: int = 0
	var __5RZzsfD9Orsfa13TBhSmdVHj: int = 0
	var v: int = __TAtJXDBCVc28BnMmUqTP8Amr["V0"]
	var __dUXxL__NoRt5M_0jttUxVvak: int = __TAtJXDBCVc28BnMmUqTP8Amr["barrels"]
	var __tVfbMGD8jeiqTp0WxScvFQQ2: PackedInt32Array = __TAtJXDBCVc28BnMmUqTP8Amr["muzzle"]
	var __a488zVdX7jyFgXno2tVaEPaq: int = __TAtJXDBCVc28BnMmUqTP8Amr["caliber"]
	var __OJ5f_WsPxueyVVD0PSd4mUX6: int = __My0r70GtKB_51wp2KWwlfoX2(__TAtJXDBCVc28BnMmUqTP8Amr, ____2PcPAvAUyj_FUcgcnfkigG)
	var __cH6iQqVZWBFyvt4wBrSKOqPA: Array[Dictionary] = []
	for __itZHMY8t1mMcyjtWMixpzJSK: int in __dUXxL__NoRt5M_0jttUxVvak:
		var s: int = 64 + maxi(__a488zVdX7jyFgXno2tVaEPaq - 200, 0) / 20 + __WkE0RQ7Jkcms9jzzMtDexcpx / 50
		s -= __OJ5f_WsPxueyVVD0PSd4mUX6 * s / 480
		if s <= 0:
			s = 0
		s += int(__TAtJXDBCVc28BnMmUqTP8Amr.get("meti_spread_floor", 8))
		if __5hNZMmXMggc2bLy98WZeFW2l:
			var __VU8cw9ad2TkOEOZOHlMFPDox: int = __UaB3tWU3yPVvCA_wY0uGW7Fx[(__mTC8K1P9Y1nUZsbsx74szOin + __sRFoJmhjXpIQvXrMueh68VfG) % __n7FJGfy2zn3Ki8n0LQtfSsGs] %1000
			__w2lSI32p6e8UKvEHMvwvyRiN = posmod(__w2lSI32p6e8UKvEHMvwvyRiN + (s / 2 - (1000 - __TXCdoY85HWzo9E7Qcf9l8raZ.__O6YJHz7KUETC0vGPOoIPvREQ[__VU8cw9ad2TkOEOZOHlMFPDox]) * s / 1000), 3600)
			__VU8cw9ad2TkOEOZOHlMFPDox = __UaB3tWU3yPVvCA_wY0uGW7Fx[(__mTC8K1P9Y1nUZsbsx74szOin + __I5mSwjYEiwjfvY97fzXGsyfq) % __n7FJGfy2zn3Ki8n0LQtfSsGs] %1000
			__WkE0RQ7Jkcms9jzzMtDexcpx = posmod(__WkE0RQ7Jkcms9jzzMtDexcpx + (s / 2 - (1000 - __TXCdoY85HWzo9E7Qcf9l8raZ.__O6YJHz7KUETC0vGPOoIPvREQ[__VU8cw9ad2TkOEOZOHlMFPDox]) * s / 1000) / 4, 3600)
			__VU8cw9ad2TkOEOZOHlMFPDox = __UaB3tWU3yPVvCA_wY0uGW7Fx[(__mTC8K1P9Y1nUZsbsx74szOin + __5RZzsfD9Orsfa13TBhSmdVHj) % __n7FJGfy2zn3Ki8n0LQtfSsGs] %1000
			v = v + (s / 2 - (1000 - __TXCdoY85HWzo9E7Qcf9l8raZ.__O6YJHz7KUETC0vGPOoIPvREQ[__VU8cw9ad2TkOEOZOHlMFPDox]) * s / 1000) / 3 * v / 1000
		var __H_kBSzSUn4XEV15APySFrky2: int = ((__tGzT9GoEXiR4eFLEycqLPRj9 * 8 + __89y0dxxTQGYG11_A2fUe4gCe) * __dUXxL__NoRt5M_0jttUxVvak + __itZHMY8t1mMcyjtWMixpzJSK) * 2
		var __3eMWQMISYDENFGcbGGBhThFd: int = __tVfbMGD8jeiqTp0WxScvFQQ2[__H_kBSzSUn4XEV15APySFrky2]
		var __S9ldY6gIvjjbHdU0YQwE4RuG: int = __tVfbMGD8jeiqTp0WxScvFQQ2[__H_kBSzSUn4XEV15APySFrky2 + 1]
		var __KpX02HNFbUWF36aXPDfm_bP8: int = __TXCdoY85HWzo9E7Qcf9l8raZ.__9nHAKAsjPH38LR2tAezCTqd_[__WkE0RQ7Jkcms9jzzMtDexcpx] * v / 1000
		__cH6iQqVZWBFyvt4wBrSKOqPA.append({"x": (__JuOAgtVoT7f_7RbOg6sFfZ4C + __3eMWQMISYDENFGcbGGBhThFd) * __jSHCPDm8k9O9CtctnqkQJ6b2, "y": (__eZsm9LeAl85wVo6ACgb4iae5 - __S9ldY6gIvjjbHdU0YQwE4RuG) * __W_7fSiIVO80l6wn6KwvCuoPH, "h": 200, "vx": __TXCdoY85HWzo9E7Qcf9l8raZ.__9nHAKAsjPH38LR2tAezCTqd_[__w2lSI32p6e8UKvEHMvwvyRiN] * __KpX02HNFbUWF36aXPDfm_bP8 / 100, "vy": - (__TXCdoY85HWzo9E7Qcf9l8raZ.__7laIgLr3i8VN0D_tZnYT3p0D[__w2lSI32p6e8UKvEHMvwvyRiN] * __KpX02HNFbUWF36aXPDfm_bP8 / 100), "vz": __TXCdoY85HWzo9E7Qcf9l8raZ.__7laIgLr3i8VN0D_tZnYT3p0D[__WkE0RQ7Jkcms9jzzMtDexcpx] * v / 100 * 2, "az": __w2lSI32p6e8UKvEHMvwvyRiN, "el": __WkE0RQ7Jkcms9jzzMtDexcpx, "V": v, "spawn_x": __3eMWQMISYDENFGcbGGBhThFd, "spawn_y": - __S9ldY6gIvjjbHdU0YQwE4RuG, })
		__sRFoJmhjXpIQvXrMueh68VfG += 32
		__I5mSwjYEiwjfvY97fzXGsyfq += 64
		__5RZzsfD9Orsfa13TBhSmdVHj += 128
	if int(__TAtJXDBCVc28BnMmUqTP8Amr.get("meti_range_pct", 100)) != 100:
		for b: Dictionary in __cH6iQqVZWBFyvt4wBrSKOqPA:
			b["vx"] = int(b["vx"]) * 3 / 2
			b["vy"] = int(b["vy"]) * 3 / 2
	return __cH6iQqVZWBFyvt4wBrSKOqPA
static func __Nq02DWmfwm40QGHNNikwbr_O(__AN2p8wWVvEmXEsC9Ol2E1htv: Array[Dictionary], __JL7a6InYLntudr_6drrqelHa: Dictionary, x: int, y: int) -> Variant:
	var __XzEEiihZ1KgKHbXizMaabZdo: int = x / __UnOvcaypq_4dUki6SIGuiQW7
	var __HadtpokLo508woH7qwdQX_ig: int = y / __W_7fSiIVO80l6wn6KwvCuoPH
	for s: Dictionary in __AN2p8wWVvEmXEsC9Ol2E1htv:
		if int(s["state"]) != 1073741824:
			continue
		if is_same(s, __JL7a6InYLntudr_6drrqelHa):
			continue
		if int(s["depth"]) >= 3:
			continue
		if hit_test(s["hull"], s["x"], s["y"], s["dir"], __XzEEiihZ1KgKHbXizMaabZdo, __HadtpokLo508woH7qwdQX_ig) != 0:
			return s
	return null
static func __JI2WieShJuy_m4l0qRsK5CZT(__LEKf30Hj1UfZFa0l8HBgQZkc: __bzxMmNAcE_RKMny5gklgDglw, __rElBwI1RoY0ByOdFYTX6eRIJ: int) -> int:
	var __WCdWFJCcZ7NxlGKwE59XMq3_: int = __LEKf30Hj1UfZFa0l8HBgQZkc.__Jy2hcMM9emCF3iBBkLMyeUr7("Projectile", __rElBwI1RoY0ByOdFYTX6eRIJ, 160)
	if __WCdWFJCcZ7NxlGKwE59XMq3_ == 0:
		__WCdWFJCcZ7NxlGKwE59XMq3_ = 100
	var __5i4uZD7f8umN4BkgANL8fuQN: int = __LEKf30Hj1UfZFa0l8HBgQZkc.__Jy2hcMM9emCF3iBBkLMyeUr7("Projectile", __rElBwI1RoY0ByOdFYTX6eRIJ, 158)
	var __2_bVtgtW1pJh9GATBOgtD2Ip: int = __LEKf30Hj1UfZFa0l8HBgQZkc.__W6CI0qz_EcizmoUzla_lpyar("Projectile", __rElBwI1RoY0ByOdFYTX6eRIJ, 153)
	return 10000 - (__WCdWFJCcZ7NxlGKwE59XMq3_ * __WCdWFJCcZ7NxlGKwE59XMq3_ / __20d5R79I8KhCsBXP1JpFOLE8 / (__5i4uZD7f8umN4BkgANL8fuQN + 5)) * (100 - __2_bVtgtW1pJh9GATBOgtD2Ip) / 100
static func __feGVgInD4izIDZgdfCqE8YS9(start: Array, end: Array, __eOJI5DtieSRDeQuoIiYYD6_F: Array[Dictionary], __ptey1qdhyPJYsUeFcnSfvzL5: Dictionary, __iwPryeA3omJupextbgoPdiUl: bool = false) -> Variant:
	var __yVOunur9SpwhzwkanlgDj44a: int = int(end[0]) - int(start[0])
	var __icoTmVIhPJHgqw5UkfQZ60GG: int = int(end[1]) - int(start[1])
	var v: int = (__yVOunur9SpwhzwkanlgDj44a / __UnOvcaypq_4dUki6SIGuiQW7) if (absi(__yVOunur9SpwhzwkanlgDj44a) / __UnOvcaypq_4dUki6SIGuiQW7 > absi(__icoTmVIhPJHgqw5UkfQZ60GG) / __W_7fSiIVO80l6wn6KwvCuoPH) else (__icoTmVIhPJHgqw5UkfQZ60GG / __W_7fSiIVO80l6wn6KwvCuoPH)
	var __W89PWwFmdchslK7RF_zj34hu: int = (absi(v) >> 1) + 1
	if __W89PWwFmdchslK7RF_zj34hu <= 0:
		return null
	var __G7vLiIIVat80c9d8jS19L190: int = int(start[0])
	var __CGXbRk3KKwgRH6ZLJrMX2pFC: int = int(start[1])
	var __nOeOBCJ4HZtR07hCfIY6FvtH: int = __G7vLiIIVat80c9d8jS19L190 / __UnOvcaypq_4dUki6SIGuiQW7
	var __6NiaTbTtHnSIpT4Arl7vv6Uz: int = (__G7vLiIIVat80c9d8jS19L190 + __yVOunur9SpwhzwkanlgDj44a) / __UnOvcaypq_4dUki6SIGuiQW7
	var __6tAjugjY26hQw_TFl3tLL6U9: int = __CGXbRk3KKwgRH6ZLJrMX2pFC / __W_7fSiIVO80l6wn6KwvCuoPH
	var __ynKFz0vNfK0rp7Ar2fIbjJV9: int = (__CGXbRk3KKwgRH6ZLJrMX2pFC + __icoTmVIhPJHgqw5UkfQZ60GG) / __W_7fSiIVO80l6wn6KwvCuoPH
	var __kLf7jEsNSnO2Jbdlubwp26DX: int = mini(__nOeOBCJ4HZtR07hCfIY6FvtH, __6NiaTbTtHnSIpT4Arl7vv6Uz)
	var __rBltxFjyEimykXIODfQLqB8T: int = maxi(__nOeOBCJ4HZtR07hCfIY6FvtH, __6NiaTbTtHnSIpT4Arl7vv6Uz)
	var __0fMg9S_u0NUU7ecCjYXALrHf: int = mini(__6tAjugjY26hQw_TFl3tLL6U9, __ynKFz0vNfK0rp7Ar2fIbjJV9)
	var __sFoktrBidzCIvTf73Uunaah2: int = maxi(__6tAjugjY26hQw_TFl3tLL6U9, __ynKFz0vNfK0rp7Ar2fIbjJV9)
	var __43NvgbSOAiWablCS6ybbuCpx: Array[Dictionary] = []
	for ___m_jAEUz5oS4dGKj6Zoa1A_i: Dictionary in __eOJI5DtieSRDeQuoIiYYD6_F:
		if int(___m_jAEUz5oS4dGKj6Zoa1A_i["state"]) != 1073741824 or is_same(___m_jAEUz5oS4dGKj6Zoa1A_i, __ptey1qdhyPJYsUeFcnSfvzL5) or int(___m_jAEUz5oS4dGKj6Zoa1A_i["depth"]) >= 3:
			continue
		var __WQqvOLrlSTgQoog5hrIaTkxY: int = 4 * int((___m_jAEUz5oS4dGKj6Zoa1A_i["hull"] as Dictionary)["ebp"])
		var __dbOSly3rWj8zjW6Eg47_hsf4: int = ___m_jAEUz5oS4dGKj6Zoa1A_i["x"]
		var __oXJ_l_FG9J8V6d6uqP94LB5y: int = ___m_jAEUz5oS4dGKj6Zoa1A_i["y"]
		if __rBltxFjyEimykXIODfQLqB8T <= __dbOSly3rWj8zjW6Eg47_hsf4 - __WQqvOLrlSTgQoog5hrIaTkxY or __kLf7jEsNSnO2Jbdlubwp26DX >= __dbOSly3rWj8zjW6Eg47_hsf4 + __WQqvOLrlSTgQoog5hrIaTkxY:
			continue
		if (__sFoktrBidzCIvTf73Uunaah2 - __oXJ_l_FG9J8V6d6uqP94LB5y) * 170 / 100 + __oXJ_l_FG9J8V6d6uqP94LB5y <= __oXJ_l_FG9J8V6d6uqP94LB5y - __WQqvOLrlSTgQoog5hrIaTkxY or (__0fMg9S_u0NUU7ecCjYXALrHf - __oXJ_l_FG9J8V6d6uqP94LB5y) * 170 / 100 + __oXJ_l_FG9J8V6d6uqP94LB5y >= __oXJ_l_FG9J8V6d6uqP94LB5y + __WQqvOLrlSTgQoog5hrIaTkxY:
			continue
		__43NvgbSOAiWablCS6ybbuCpx.append(___m_jAEUz5oS4dGKj6Zoa1A_i)
	if __43NvgbSOAiWablCS6ybbuCpx.is_empty():
		return null
	var __hJVSecmsW7u7g0wNVBGMv5F7: int = 0
	var __uYQpOmvDVij6oMrLuZCVj46w: int = 0
	for __JWiyaCOTPjIACh22XqGKFq61: int in __W89PWwFmdchslK7RF_zj34hu:
		var __J2Flof0Ab1cA4AYDiROOOQ0F: int = __hJVSecmsW7u7g0wNVBGMv5F7 / __W89PWwFmdchslK7RF_zj34hu + __G7vLiIIVat80c9d8jS19L190
		var __wwVq97QvwmAnRCyGVGPJhNTO: int = __uYQpOmvDVij6oMrLuZCVj46w / __W89PWwFmdchslK7RF_zj34hu + __CGXbRk3KKwgRH6ZLJrMX2pFC
		var __7OeVP7QGFFsN5i9beJY2AbCy: Variant = __Nq02DWmfwm40QGHNNikwbr_O(__43NvgbSOAiWablCS6ybbuCpx, __ptey1qdhyPJYsUeFcnSfvzL5, __J2Flof0Ab1cA4AYDiROOOQ0F, __wwVq97QvwmAnRCyGVGPJhNTO)
		if __7OeVP7QGFFsN5i9beJY2AbCy != null:
			if not (__iwPryeA3omJupextbgoPdiUl and __ptey1qdhyPJYsUeFcnSfvzL5["team"] == __7OeVP7QGFFsN5i9beJY2AbCy["team"]):
				return [__JWiyaCOTPjIACh22XqGKFq61, __7OeVP7QGFFsN5i9beJY2AbCy]
		__hJVSecmsW7u7g0wNVBGMv5F7 += __yVOunur9SpwhzwkanlgDj44a
		__uYQpOmvDVij6oMrLuZCVj46w += __icoTmVIhPJHgqw5UkfQZ60GG
	return null
const __UnOvcaypq_4dUki6SIGuiQW7: = __jSHCPDm8k9O9CtctnqkQJ6b2 * 100 / 100
static func step(__7SeohwNQOw5n6BTjp2ez_mFM: Dictionary, __YuJ_YhVWSUACMvRYl0rcDavZ: int, __V1Wpeyuo20d6A1KCZpL0zKhI: int = 0) -> int:
	var h: int = __7SeohwNQOw5n6BTjp2ez_mFM["h"]
	var __w_ZY89rfoitjFPh6N92m9U6A: int = h / 400 * h / 400
	var __G_cuRW3tp4EJ_6oZkKFFTUvK: int = __YuJ_YhVWSUACMvRYl0rcDavZ + __w_ZY89rfoitjFPh6N92m9U6A * (10000 - __YuJ_YhVWSUACMvRYl0rcDavZ) / 490000
	if __G_cuRW3tp4EJ_6oZkKFFTUvK > 10000:
		__G_cuRW3tp4EJ_6oZkKFFTUvK = 10000
	__7SeohwNQOw5n6BTjp2ez_mFM["vx"] = int(__7SeohwNQOw5n6BTjp2ez_mFM["vx"]) * __G_cuRW3tp4EJ_6oZkKFFTUvK / 10000
	__7SeohwNQOw5n6BTjp2ez_mFM["vy"] = int(__7SeohwNQOw5n6BTjp2ez_mFM["vy"]) * __G_cuRW3tp4EJ_6oZkKFFTUvK / 10000
	if __V1Wpeyuo20d6A1KCZpL0zKhI != 3:
		__7SeohwNQOw5n6BTjp2ez_mFM["vz"] = int(__7SeohwNQOw5n6BTjp2ez_mFM["vz"]) + __TZzvT81yZO7o4__efCrW8_Ps
	if int(__7SeohwNQOw5n6BTjp2ez_mFM["vz"]) >= 0:
		__7SeohwNQOw5n6BTjp2ez_mFM["vz"] = 2 * (__G_cuRW3tp4EJ_6oZkKFFTUvK - 5000) * int(__7SeohwNQOw5n6BTjp2ez_mFM["vz"]) / 10000
	return __G_cuRW3tp4EJ_6oZkKFFTUvK
