extends Node2D

const Guns = preload("res://shared/sim/gunnery.gd")
const RandomTable = preload("res://shared/core/rand_table.gd")
const SAMPLE_COUNT: int = 8
const MAX_FLIGHT_TICKS: int = 5000
const REFRESH_USEC: int = 120000
const COLORS: Array[Color] = [Color("65e5ff"), Color("ffd477"), Color("b4f48c"), Color("f6a9dd"), Color("b6b0ff"), Color("ff9d7e")]

var world: Variant
var ship: Variant
var battle_ref: WeakRef
var solutions: Dictionary = {}
var entries: Array[Dictionary] = []
var private_randoms: PackedInt32Array = RandomTable.generate(1296389193)
var cursor: int = 0
var solve_count: int = 0
var solve_usec_total: int = 0
var solve_usec_max: int = 0
var render_count: int = 0
var font: Font
var label_rects: Array[Rect2] = []

func bind(battle: Node, simulation: Variant, player: Variant) -> void :
	name = "MetiAimPreview"
	battle_ref = weakref(battle) if battle != null else null
	world = simulation
	ship = player
	font = ThemeDB.fallback_font
	z_index = 50
	set_process(true)
	refresh(true)

func allowed() -> bool:
	if world == null or ship == null or not ship.__ZMgQrrB9zxLXJ4nY9DOrkD1m or ship.state != 1073741824:
		return false
	var battle = battle_ref.get_ref() if battle_ref != null else null
	return battle == null or ( not battle.__898CZFX8zI40Huxp297h_lkH and battle.__5zsHBwGhnk5X3Ays_WuwIBnz == null and battle.__rQbCTLm4ikRheIOavyVgPmxH == 0)

func aircraft_selected() -> bool:
	var battle = battle_ref.get_ref() if battle_ref != null else null
	return battle != null and battle.__g7JC3EJmfsOWnIyqLGGB93eB != null and battle.__g7JC3EJmfsOWnIyqLGGB93eB.__PrvZDcSAg2N7M4qrzB5vt2MU()

func signature(g: Dictionary, az: int, shell: Dictionary) -> Array:
	return [az, int(g["elev"]), int(shell.get("proj_row", -1)), int(shell["t0"]), int(shell.get("kind", 0)), int(g["V0"]), int(g["acc70"]), int(g["barrels"]), int(g.get("meti_range_pct", 100)), int(g.get("meti_spread_floor", 8)), int(ship.__CQmrJDrlrxQho2i8OkSrVQ1N), int(g.get("gunset_row", -1)), int(g["caliber"]), int(g["max_el"]), int(g["mount"]), int(g["base"])]

func status(g: Dictionary) -> String:
	if bool(g.get("broken", false)): return "損壞"
	var ammo = "ammo_a" if int(g.get("cargo", 0)) == 0 else "ammo_b"
	if int(g.get(ammo, 0)) <= 0: return "無彈"
	if not bool(g.get("in_arc", true)): return "超射角"
	if not bool(g.get("ready", false)): return "裝填"
	return "就緒"

func _process(_delta: float) -> void :
	refresh()

func refresh(force: bool = false) -> void :
	entries.clear()
	if not allowed() or aircraft_selected():
		queue_redraw()
		return
	var now = Time.get_ticks_usec()
	for index in ship.__BJReFJ4ugditvprP9JFCx5S2.size():
		var g: Dictionary = ship.__BJReFJ4ugditvprP9JFCx5S2[index]
		if int(g.get("seat", 0)) != ship.__1Z7OFhxB6TttwviVl7guTYN5 or not ship.__hQ0Qf6xcbMMYVte0AH7gKSm7(g) or int(g.get("aa", 0)) != 0:
			continue
		var shell: Dictionary = g["shell"] if int(g.get("cargo", 0)) == 0 else g["shell_b"]
		if int(shell.get("proj_row", -1)) < 0 or int(shell.get("kind", 0)) == 1 or int(g.get("barrels", 0)) <= 0 or int(g.get("V0", 0)) <= 0:
			continue
		var az = posmod(ship.__Rzlu0K6FmW_AJtyGtfyruX3f(g) + 900, 3600)
		entries.append({"index": index, "gun": g, "shell": shell, "az": az, "signature": signature(g, az, shell), "origin": ship.__yRuUzjxz_RR_5vyQfUbTx_ec(index), "status": status(g)})
	if not entries.is_empty():

		for offset in entries.size():
			var slot = posmod(cursor + offset, entries.size())
			var entry: Dictionary = entries[slot]
			var previous: Dictionary = solutions.get(entry["index"], {})
			if not force and not previous.is_empty() and (previous["signature"] == entry["signature"] or now - int(previous["updated"]) < REFRESH_USEC):
				continue
			var started = Time.get_ticks_usec()
			var solved = solve(entry["gun"], entry["shell"], entry["az"], int(ship.__CQmrJDrlrxQho2i8OkSrVQ1N))
			var cost = Time.get_ticks_usec() - started
			solve_count += 1;solve_usec_total += cost;solve_usec_max = maxi(solve_usec_max, cost)
			solved["signature"] = entry["signature"]
			solved["updated"] = now
			solutions[entry["index"]] = solved
			cursor = slot + 1
			break
	queue_redraw()

func project(shot: Dictionary, shell: Dictionary) -> Dictionary:


	var b = shot.duplicate()
	for tick in range(1, MAX_FLIGHT_TICKS):
		Guns.step(b, int(shell["t0"]), int(shell.get("kind", 0)))
		var h: int = b["h"]
		var vz: int = b["vz"]
		if h + vz < 0:
			var fraction: int = absi(h * 100 / vz) if vz != 0 else 0
			var fixed = Vector2i(int(b["x"]) + int(b["vx"]) * fraction / 100, int(b["y"]) + int(b["vy"]) * fraction / 100)
			return {"fixed": fixed, "ticks": tick, "native": Vector2i(fixed.x / Guns.__jSHCPDm8k9O9CtctnqkQJ6b2, fixed.y / Guns.__W_7fSiIVO80l6wn6KwvCuoPH)}
		b["x"] = int(b["x"]) + int(b["vx"])
		b["y"] = int(b["y"]) + int(b["vy"])
		b["h"] = h + vz
	return {}

func solve(g: Dictionary, shell: Dictionary, az: int, accuracy_cap: int = 0) -> Dictionary:
	var ideal: Array[Dictionary] = Guns.__Uinp0qKlBAx07Wxg3OpdJrIb(g, az, int(g["elev"]), 0, 0, private_randoms, 0, 0, false, accuracy_cap)
	if ideal.is_empty(): return {"valid": false}
	var first = project(ideal[0], shell)
	if first.is_empty(): return {"valid": false}
	var center = Vector2.ZERO
	var points: Array[Vector2i] = []
	var first_start = Vector2i(int(ideal[0]["x"]), int(ideal[0]["y"]))
	for shot in ideal:
		var fixed: Vector2i = first["fixed"] + Vector2i(int(shot["x"]), int(shot["y"])) - first_start
		center += Vector2(fixed)
		points.append(fixed)
	center /= ideal.size()
	for sample in SAMPLE_COUNT:
		var shots = Guns.__Uinp0qKlBAx07Wxg3OpdJrIb(g, az, int(g["elev"]), 0, sample * 997 + 43, private_randoms, 0, 0, true, accuracy_cap)
		for shot in shots:
			var hit = project(shot, shell)
			if not hit.is_empty(): points.append(hit["fixed"])
	return {"valid": true, "center_fixed": center, "cloud_fixed": points, "ticks": first["ticks"], "seconds": float(first["ticks"]) * 0.04, "samples": points.size(), "az": az, "elevation": int(g["elev"]), "projectile": int(shell["proj_row"]), "ammo": "AP" if int(shell.get("HE_base", 0)) == 0 else "HE"}

func world_point(fixed: Vector2, origin: Vector2i) -> Vector2:
	return Vector2(int((fixed.x + origin.x * Guns.__jSHCPDm8k9O9CtctnqkQJ6b2) / Guns.__jSHCPDm8k9O9CtctnqkQJ6b2), int((fixed.y + origin.y * Guns.__W_7fSiIVO80l6wn6KwvCuoPH) / Guns.__W_7fSiIVO80l6wn6KwvCuoPH))

func envelope(points: PackedVector2Array, center: Vector2) -> PackedVector2Array:
	var xx = 0.0; var yy = 0.0; var xy = 0.0
	for p in points:
		var d = p - center;xx += d.x * d.x;yy += d.y * d.y;xy += d.x * d.y
	var angle = 0.5 * atan2(2.0 * xy, xx - yy)
	var u = Vector2(cos(angle), sin(angle)); var v = Vector2( - u.y, u.x)
	var a = 1.5; var b = 1.5
	for p in points:
		var d = p - center;a = maxf(a, absf(d.dot(u)) * sqrt(2.0));b = maxf(b, absf(d.dot(v)) * sqrt(2.0))
	var ring = PackedVector2Array()
	for i in 49:
		var t = TAU * float(i) / 48.0
		ring.append(center + u * cos(t) * a + v * sin(t) * b)
	return ring

func draw_label(text: String, at: Vector2, color: Color, viewport: Vector2) -> void :
	var width = font.get_string_size(text, HORIZONTAL_ALIGNMENT_LEFT, -1, 13).x
	var p = Vector2(clampf(at.x, 12.0, maxf(12.0, viewport.x - width - 16.0)), clampf(at.y, 146.0, maxf(146.0, viewport.y - 170.0)))
	var preferred = p
	var rectangle = Rect2(p + Vector2(-4, -14), Vector2(width + 8, 20))
	for attempt in 24:
		var overlaps = false
		for occupied in label_rects:
			if rectangle.intersects(occupied.grow(2)): overlaps = true;break
		if not overlaps: break
		var shift = float((attempt / 2 + 1) * 22) * (1.0 if attempt % 2 == 0 else -1.0)
		p.y = clampf(preferred.y + shift, 146.0, maxf(146.0, viewport.y - 170.0))
		rectangle = Rect2(p + Vector2(-4, -14), Vector2(width + 8, 20))
	label_rects.append(rectangle)
	draw_rect(rectangle, Color(0.025, 0.055, 0.08, 0.82))
	draw_string(font, p, text, HORIZONTAL_ALIGNMENT_LEFT, -1, 13, color)

func _draw() -> void :
	if not allowed() or font == null: return
	render_count += 1
	var transform_to_screen = get_global_transform_with_canvas()
	var viewport = get_viewport_rect().size
	draw_set_transform_matrix(transform_to_screen.affine_inverse())
	label_rects.clear()
	var legend = "艦砲海面預測｜外框為散布樣本估計"
	if aircraft_selected(): legend = "艦砲預測｜操作飛機中"
	elif entries.is_empty(): legend = "艦砲預測｜目前未選取一般艦砲"
	var legend_width = font.get_string_size(legend, HORIZONTAL_ALIGNMENT_LEFT, -1, 13).x
	var legend_x = maxf(12.0, (viewport.x - legend_width) * 0.5)
	draw_rect(Rect2(legend_x - 8, 96, legend_width + 16, 26), Color(0.025, 0.055, 0.08, 0.85))
	draw_string(font, Vector2(legend_x, 114), legend, HORIZONTAL_ALIGNMENT_LEFT, -1, 13, Color("ccecf5"))
	if aircraft_selected(): return
	var map_rect = Rect2(Vector2(18, 136), Vector2(maxf(1, viewport.x - 36), maxf(1, viewport.y - 318)))
	var offscreen_drawn = false
	for entry in entries:
		var solution: Dictionary = solutions.get(entry["index"], {})
		if solution.is_empty() or not bool(solution.get("valid", false)): continue
		var center = transform_to_screen * world_point(solution["center_fixed"], entry["origin"])
		var color = COLORS[int(entry["index"]) % COLORS.size()]
		if entry["status"] != "就緒": color = color.lerp(Color("abb5be"), 0.55)
		var updating = solution["signature"] != entry["signature"]
		if updating and int(solution["projectile"]) != int(entry["shell"]["proj_row"]): continue
		if updating: color.a = 0.6
		var text = "砲%d %s · %.1f秒 · %.1f° · %s%s" % [int(entry["index"]) + 1, solution["ammo"], float(solution["seconds"]), float(solution["elevation"]) / 10.0, entry["status"], " · 更新中" if updating else ""]
		if not map_rect.has_point(center):
			if offscreen_drawn: continue
			offscreen_drawn = true
			var edge = Vector2(clampf(center.x, map_rect.position.x, map_rect.end.x), clampf(center.y, map_rect.position.y, map_rect.end.y))
			var direction = (center - edge).normalized()
			var side = Vector2( - direction.y, direction.x)
			draw_line(edge - direction * 10 + side * 5, edge, color, 2, true)
			draw_line(edge - direction * 10 - side * 5, edge, color, 2, true)
			draw_label(text + "（畫面外）", edge + Vector2(12, 20), color, viewport)
			continue
		var points = PackedVector2Array()
		for fixed in solution["cloud_fixed"]: points.append(transform_to_screen * world_point(Vector2(fixed), entry["origin"]))
		var ring = envelope(points, center)
		var fill = color;fill.a = 0.055
		draw_colored_polygon(ring.slice(0, 48), fill)
		draw_polyline(ring, Color(color, 0.5), 1.0, true)
		draw_line(center - Vector2(7, 0), center + Vector2(7, 0), color, 1.5, true)
		draw_line(center - Vector2(0, 7), center + Vector2(0, 7), color, 1.5, true)
		draw_circle(center, 2.0, color)
		draw_label(text, center + Vector2(12, 18), color, viewport)
	draw_set_transform_matrix(Transform2D.IDENTITY)
