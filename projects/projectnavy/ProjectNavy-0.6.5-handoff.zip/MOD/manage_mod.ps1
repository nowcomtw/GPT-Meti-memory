﻿param(
    [ValidateSet('Install','Restore')][string]$Action='Install',
    [string]$GameDir='D:\C GAME\ProjectNavy',
    [string]$SaveRoot=(Join-Path $env:APPDATA 'Godot\app_userdata\Project Navy'),
    [string]$BackupRoot=(Join-Path $PSScriptRoot 'LocalBackups'),
    [switch]$RestoreSave
)
$ErrorActionPreference='Stop'
[Console]::OutputEncoding=New-Object Text.UTF8Encoding($false)
if($RestoreSave){throw '此版快速還原僅還原補丁，保留進度。若要回復整套舊存檔，請另行明確指定。'}
$manifest=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'MOD_MANIFEST.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$gameFull=[IO.Path]::GetFullPath($GameDir).TrimEnd('\')
$saveFull=[IO.Path]::GetFullPath($SaveRoot).TrimEnd('\')
$backupFull=[IO.Path]::GetFullPath($BackupRoot).TrimEnd('\')
function Hash-File([string]$Path) {
    $stream=[IO.File]::OpenRead($Path)
    $algorithm=[Security.Cryptography.SHA256]::Create()
    try { ([BitConverter]::ToString($algorithm.ComputeHash($stream))).Replace('-','').ToLowerInvariant() }
    finally { $algorithm.Dispose(); $stream.Dispose() }
}
function Save-Fingerprints([string]$Folder) {
    if (-not (Test-Path -LiteralPath $Folder)) { return @() }
    @(Get-ChildItem -LiteralPath $Folder -Recurse -File | Sort-Object FullName | ForEach-Object {
        [pscustomobject]@{path=$_.FullName.Substring($Folder.Length+1);size=$_.Length;sha256=(Hash-File $_.FullName)}
    })
}
function Assert-GameClosed {
    foreach($proc in @(Get-CimInstance Win32_Process -Filter "Name = 'ProjectNavy.exe'")) {
        if(-not $proc.ExecutablePath -or ([IO.Path]::GetDirectoryName($proc.ExecutablePath) -ieq $gameFull)) { throw '請先關閉此安裝目錄中的遊戲。' }
    }
}
Assert-GameClosed
foreach($name in @('ProjectNavy.exe','ProjectNavy.pck')) {
    $expected=$manifest.original_sha256.$name
    if((Hash-File (Join-Path $gameFull $name)) -ne $expected) { throw ('遊戲基礎檔案版本不符：'+$name) }
}
foreach($name in @('booting','current.pck.new','current.json.new')) {
    if(Test-Path -LiteralPath (Join-Path $gameFull ('patches\'+$name))) { throw ('偵測到未完成的啟動／更新狀態，先停止：'+$name) }
}
$whitelist=@('patches/current.pck','patches/current.json')
$saveBefore=Save-Fingerprints $saveFull
$alreadyDesired=$true
foreach($relative in $whitelist) {
    $target=[IO.Path]::GetFullPath((Join-Path $gameFull $relative))
    if(-not $target.StartsWith($gameFull+'\',[StringComparison]::OrdinalIgnoreCase)) { throw '目標路徑超出遊戲目錄。' }
    $current=Hash-File $target
    $originalHash=$manifest.original_sha256.$relative
    $modHash=$manifest.installed.$relative.sha256
    if($current -ne $originalHash -and $current -ne $modHash) { throw ('偵測到其他版本或修改，停止覆蓋：'+$relative) }
    $desired=if($Action -eq 'Install'){$modHash}else{$originalHash}
    if($current -ne $desired){$alreadyDesired=$false}
}
if($Action -eq 'Install' -and -not $alreadyDesired) {
    if(Test-Path -LiteralPath $backupFull) { throw '備份目錄已存在；請另選 BackupRoot，避免覆寫舊備份。' }
    [IO.Directory]::CreateDirectory((Join-Path $backupFull 'game/patches')) | Out-Null
    foreach($relative in $whitelist) { Copy-Item -LiteralPath (Join-Path $gameFull $relative) -Destination (Join-Path $backupFull ('game/'+$relative)) }
    if(Test-Path -LiteralPath $saveFull) { Copy-Item -LiteralPath $saveFull -Destination (Join-Path $backupFull 'save') -Recurse }
    $backupSave=Save-Fingerprints (Join-Path $backupFull 'save')
    if(($saveBefore|ConvertTo-Json -Depth 5 -Compress) -cne ($backupSave|ConvertTo-Json -Depth 5 -Compress)) { throw '存檔備份雜湊不一致；未安裝。' }
    [pscustomobject]@{game=$gameFull;save=$saveFull;files=$saveBefore} | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $backupFull 'snapshot.json') -Encoding UTF8
}
Assert-GameClosed
if(-not $alreadyDesired) {
    $section=if($Action -eq 'Install'){'payload'}else{'original_patch'}
    foreach($relative in $whitelist) {
        $source=Join-Path $PSScriptRoot ($section+'/'+$relative)
        $expected=if($Action -eq 'Install'){$manifest.installed.$relative.sha256}else{$manifest.original_sha256.$relative}
        if((Hash-File $source) -ne $expected){throw ('來源校驗失敗：'+$relative)}
        if(Test-Path -LiteralPath ((Join-Path $gameFull $relative)+'.meti-old')){throw '偵測到上一輪暫存備份，先停止。'}
    }
    try {
        foreach($relative in $whitelist) {
            $target=[IO.Path]::GetFullPath((Join-Path $gameFull $relative))
            $stage=$target+'.meti-stage'
            if(Test-Path -LiteralPath $stage){throw ('暫存檔已存在：'+$stage)}
            Copy-Item -LiteralPath (Join-Path $PSScriptRoot ($section+'/'+$relative)) -Destination $stage
            [IO.File]::Replace($stage,$target,$target+'.meti-old')
        }
    } catch {
        foreach($relative in $whitelist) {
            Copy-Item -LiteralPath (Join-Path $PSScriptRoot ('original_patch/'+$relative)) -Destination (Join-Path $gameFull $relative) -Force
            $stage=(Join-Path $gameFull $relative)+'.meti-stage'
            if(Test-Path -LiteralPath $stage){Remove-Item -LiteralPath $stage}
            $old=(Join-Path $gameFull $relative)+'.meti-old'
            if(Test-Path -LiteralPath $old){Remove-Item -LiteralPath $old}
        }
        throw
    }
}
foreach($relative in $whitelist) {
    $expected=if($Action -eq 'Install'){$manifest.installed.$relative.sha256}else{$manifest.original_sha256.$relative}
    if((Hash-File (Join-Path $gameFull $relative)) -ne $expected){throw ('安裝後校驗失敗：'+$relative)}
    $old=(Join-Path $gameFull $relative)+'.meti-old'
    if(Test-Path -LiteralPath $old){Remove-Item -LiteralPath $old}
}
if($RestoreSave) {
    if($Action -ne 'Restore'){throw 'RestoreSave 只供明確要求回復舊進度時使用。'}
    $snapshot=Get-Content -LiteralPath (Join-Path $backupFull 'snapshot.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    $sourceSave=Join-Path $backupFull 'save'
    foreach($item in $snapshot.files) {
        if((Hash-File (Join-Path $sourceSave $item.path)) -ne $item.sha256){throw '舊存檔備份校驗失敗。'}
    }
    $futureBackup=$backupFull+'_before_save_restore_'+(Get-Date -Format 'yyyyMMdd_HHmmss')
    if(Test-Path -LiteralPath $futureBackup){throw '回復前備份目錄已存在。'}
    if(Test-Path -LiteralPath $saveFull){Copy-Item -LiteralPath $saveFull -Destination $futureBackup -Recurse}
    Get-ChildItem -LiteralPath $sourceSave -Force | ForEach-Object { Copy-Item -LiteralPath $_.FullName -Destination $saveFull -Recurse -Force }
}
$saveAfter=Save-Fingerprints $saveFull
if(-not $RestoreSave -and (($saveBefore|ConvertTo-Json -Depth 5 -Compress) -cne ($saveAfter|ConvertTo-Json -Depth 5 -Compress))) {throw '存檔內容於操作期間改變，請檢查。'}
[pscustomobject]@{status='PASS';action=$Action;game=$gameFull;backup=$backupFull;alreadyDesired=$alreadyDesired;saveUntouched=(-not $RestoreSave);savedFiles=$saveAfter.Count} | ConvertTo-Json
