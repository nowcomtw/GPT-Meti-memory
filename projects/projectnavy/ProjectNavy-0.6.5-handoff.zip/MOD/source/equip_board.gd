class_name __vkUw3hIvnFxkI0lKRsW_x52c
extends Control
const __YHAi_l3enYEvgawtDjAQt4ow: = Rect2(4, 41, 466, 16)
var __iDNkCPxPojBek41rxB5M2Fvi: int = -1
func __56uwjo4rut9BrBhaLFRDhess(__6mIRCtdG1kL45cL1n63wTxTh: float, __PKZkOIW8nIuBz0GLfj3fsPM0: float, y: float, s: String, __Eax3STz8ZY2UheRBVNNGgMqH: Color = __pCUi6LToFPukNiGDrBwJ7It8, align: HorizontalAlignment = HORIZONTAL_ALIGNMENT_LEFT, __SUHjjbXWLx1mgLkCBT8bEyoi: int = __g4fWDCu0WZ5Ll3ig3mt3BKrb) -> void :
	var __ILwTeT6ZXjv3WN4r5wOYH3Wg: String = s
	while __ILwTeT6ZXjv3WN4r5wOYH3Wg.length() > 0 and __f6i2N_d8G8VgiRxtr3I3nZPB.__1lKMgy2lackzlIl0Q9F8FxhE(self, __usUoZxqK0tIN0N1IOSl94332, __ILwTeT6ZXjv3WN4r5wOYH3Wg, __SUHjjbXWLx1mgLkCBT8bEyoi) > __PKZkOIW8nIuBz0GLfj3fsPM0 - __6mIRCtdG1kL45cL1n63wTxTh:
		__ILwTeT6ZXjv3WN4r5wOYH3Wg = __ILwTeT6ZXjv3WN4r5wOYH3Wg.substr(0, __ILwTeT6ZXjv3WN4r5wOYH3Wg.length() - 1)
	__f6i2N_d8G8VgiRxtr3I3nZPB.draw(self, __usUoZxqK0tIN0N1IOSl94332, Vector2(__6mIRCtdG1kL45cL1n63wTxTh, y + __SUHjjbXWLx1mgLkCBT8bEyoi - 1), __ILwTeT6ZXjv3WN4r5wOYH3Wg, align, __PKZkOIW8nIuBz0GLfj3fsPM0 - __6mIRCtdG1kL45cL1n63wTxTh if align != HORIZONTAL_ALIGNMENT_LEFT else -1.0, __SUHjjbXWLx1mgLkCBT8bEyoi, __Eax3STz8ZY2UheRBVNNGgMqH)
const __chyDA45DWMDdP8pgE_97A6ZA: = 18
const __jWohe0A1qko0s_BICi5kZE4j: = Color8(255, 220, 90)
func __u8hy3ISjyDmipgX1Q_5CKF_0(h: Dictionary) -> bool:
	match h["id"]:
		"up":
			return __J7Q2zIqKaACRdzLBTlwWCvat > 0
		"down":
			return __J7Q2zIqKaACRdzLBTlwWCvat < __1KK7mLbVDjpqbODCm_jiSHhN()
	return true
var __YJgAymCaLB78BrFx7OQpn545: __s8yZigV26lPAvEmbOWzMbnjE
const __h4vKx0du70Ycl2qhceThLOoS: = Rect2(474, 41, 14, 16)
const __qkI9rzzPHG3olOfJc5DxIE0c: = 494
const __hWaLiMj057VktAgkCeO8MD_U: = 220
signal __5dOpWU_ha4oiYZpAS9KePUB4(__48gFohGTXydGBa1OjDwoapAp: String, index: int)
func _notification(__GbxVJky_46t48pWAiuebG4lr: int) -> void :
	if __GbxVJky_46t48pWAiuebG4lr == NOTIFICATION_MOUSE_EXIT and (__iDNkCPxPojBek41rxB5M2Fvi >= 0 or __kQVpUwZu_9LRJegsKzpzs1LH >= 0):
		__iDNkCPxPojBek41rxB5M2Fvi = -1
		__kQVpUwZu_9LRJegsKzpzs1LH = -1
		queue_redraw()
const __syiXBSXppU6V7Fj0Yweo8e3l: = 6
const __AitoAweg9PP1LgrxqOaqiNUn: = 366
const __0TzCNXqGr_xlfeKYSe0LBQFC: = 37
const __8DH0IlpFmjMCyvkslQ4FdpdO: = 20
var __zFPxZ4x_KsoNDuQiG7QR7qOU: Array[Dictionary] = []
const __kVYXi_NVoyPvuzc3ek8hOGFd: = Color8(140, 160, 180)
var __J7Q2zIqKaACRdzLBTlwWCvat: int = 0
func __jJLKIKFnWd_VHYYReKs_kefk(__Si9anWrCoHNrOnpXR2etRq6x: Vector2) -> int:
	for ___GjTLzJYd9X0vOt24O5IHIW0: int in __zFPxZ4x_KsoNDuQiG7QR7qOU.size():
		var h: Dictionary = __zFPxZ4x_KsoNDuQiG7QR7qOU[___GjTLzJYd9X0vOt24O5IHIW0]
		if (h["rect"] as Rect2).has_point(__Si9anWrCoHNrOnpXR2etRq6x) and __u8hy3ISjyDmipgX1Q_5CKF_0(h):
			return ___GjTLzJYd9X0vOt24O5IHIW0
	return -1
func _gui_input(__5woW_WtBtkXpDqhtuwnbpreh: InputEvent) -> void :
	var __m5myN8HtNk9WmjXVbS1mN_V7: = __5woW_WtBtkXpDqhtuwnbpreh as InputEventMouseMotion
	if __m5myN8HtNk9WmjXVbS1mN_V7 != null:
		var __chjnxpRtjXHRYEU7Jh3A2ljw: int = __jJLKIKFnWd_VHYYReKs_kefk(__m5myN8HtNk9WmjXVbS1mN_V7.position)
		var __vmJ7FHX1vDNbcA9rIfalF1Gr: int = -1
		if Rect2(__YHAi_l3enYEvgawtDjAQt4ow.position.x, __dIlsOx9kBMqLWp6RZD1ZSU_n, __GbCKF83RIWHpg93W6aEOFjt4 - __YHAi_l3enYEvgawtDjAQt4ow.position.x, __O_krrF5upjv1sZYM1ft4t0FV * __bUl3aBV7CjUTIBcbbuUwjAt9).has_point(__m5myN8HtNk9WmjXVbS1mN_V7.position):
			__vmJ7FHX1vDNbcA9rIfalF1Gr = int((__m5myN8HtNk9WmjXVbS1mN_V7.position.y - __dIlsOx9kBMqLWp6RZD1ZSU_n) / __O_krrF5upjv1sZYM1ft4t0FV)
			if __J7Q2zIqKaACRdzLBTlwWCvat + __vmJ7FHX1vDNbcA9rIfalF1Gr >= __g2SE4dHxL_kXsExPdzpyHdoE.size():
				__vmJ7FHX1vDNbcA9rIfalF1Gr = -1
		if __chjnxpRtjXHRYEU7Jh3A2ljw != __iDNkCPxPojBek41rxB5M2Fvi or __vmJ7FHX1vDNbcA9rIfalF1Gr != __kQVpUwZu_9LRJegsKzpzs1LH:
			__iDNkCPxPojBek41rxB5M2Fvi = __chjnxpRtjXHRYEU7Jh3A2ljw
			__kQVpUwZu_9LRJegsKzpzs1LH = __vmJ7FHX1vDNbcA9rIfalF1Gr
			tooltip_text = str(__zFPxZ4x_KsoNDuQiG7QR7qOU[__chjnxpRtjXHRYEU7Jh3A2ljw]["tip"]) if __chjnxpRtjXHRYEU7Jh3A2ljw >= 0 else ""
			queue_redraw()
		return
	var __WjGYOWNkDKwbqfy0xrHHjwQ4: = __5woW_WtBtkXpDqhtuwnbpreh as InputEventMouseButton
	if __WjGYOWNkDKwbqfy0xrHHjwQ4 == null:
		return
	if __WjGYOWNkDKwbqfy0xrHHjwQ4.pressed and __WjGYOWNkDKwbqfy0xrHHjwQ4.button_index == MOUSE_BUTTON_WHEEL_UP:
		__8jHhFIzUAr5Qh3zT3ac5EgAx(-1)
	elif __WjGYOWNkDKwbqfy0xrHHjwQ4.pressed and __WjGYOWNkDKwbqfy0xrHHjwQ4.button_index == MOUSE_BUTTON_WHEEL_DOWN:
		__8jHhFIzUAr5Qh3zT3ac5EgAx(1)
	elif __WjGYOWNkDKwbqfy0xrHHjwQ4.button_index == MOUSE_BUTTON_LEFT:
		if __WjGYOWNkDKwbqfy0xrHHjwQ4.pressed:
			__Eu6qHyivDiwDtCgFQImi4A4K = __jJLKIKFnWd_VHYYReKs_kefk(__WjGYOWNkDKwbqfy0xrHHjwQ4.position)
			if __Eu6qHyivDiwDtCgFQImi4A4K < 0 and __A83meQhKXYN81y2fmwZCvYT4().has_point(__WjGYOWNkDKwbqfy0xrHHjwQ4.position):
				__8jHhFIzUAr5Qh3zT3ac5EgAx(__bUl3aBV7CjUTIBcbbuUwjAt9 if __WjGYOWNkDKwbqfy0xrHHjwQ4.position.y > __oAdr6FVkVftJ_szUC7Z6ZgDK().get_center().y else - __bUl3aBV7CjUTIBcbbuUwjAt9)
			queue_redraw()
		else:
			var h: int = __jJLKIKFnWd_VHYYReKs_kefk(__WjGYOWNkDKwbqfy0xrHHjwQ4.position)
			var __xozofEU_E3mTkuTRotxUS33n: int = __Eu6qHyivDiwDtCgFQImi4A4K
			__Eu6qHyivDiwDtCgFQImi4A4K = -1
			queue_redraw()
			if h >= 0 and h == __xozofEU_E3mTkuTRotxUS33n:
				_activate(__zFPxZ4x_KsoNDuQiG7QR7qOU[h])
const __O_krrF5upjv1sZYM1ft4t0FV: = 12
var __Eu6qHyivDiwDtCgFQImi4A4K: int = -1
var __kQVpUwZu_9LRJegsKzpzs1LH: int = -1
func __BmL75x0AkEn2C8EfwCa5cPw3(x: float, label: String, __yFyeA9Ngof6YXkYzJ7jb3d54: int, ___0PKIzeyJ5InLaUxyjVNimbY: int) -> void :
	var __NN14kQADyXyJmB1VSiVcNOUp: float = __f6i2N_d8G8VgiRxtr3I3nZPB.__1lKMgy2lackzlIl0Q9F8FxhE(self, __usUoZxqK0tIN0N1IOSl94332, label, __g4fWDCu0WZ5Ll3ig3mt3BKrb)
	__56uwjo4rut9BrBhaLFRDhess(x, x + __NN14kQADyXyJmB1VSiVcNOUp + 2, __NRYbWJ3kHhn6dPMXegCnyJO2 + 6, label, __kVYXi_NVoyPvuzc3ek8hOGFd)
	__56uwjo4rut9BrBhaLFRDhess(x + __NN14kQADyXyJmB1VSiVcNOUp + 8, x + 156, __NRYbWJ3kHhn6dPMXegCnyJO2 + 6, "%d / %d" % [__yFyeA9Ngof6YXkYzJ7jb3d54, ___0PKIzeyJ5InLaUxyjVNimbY], Color8(240, 110, 100) if __yFyeA9Ngof6YXkYzJ7jb3d54 > ___0PKIzeyJ5InLaUxyjVNimbY else __pCUi6LToFPukNiGDrBwJ7It8)
func _init() -> void :
	custom_minimum_size = Vector2(__qkI9rzzPHG3olOfJc5DxIE0c, __leD6A5XRn3zKfwhALPi2EQS0)
	size = Vector2(__qkI9rzzPHG3olOfJc5DxIE0c, __leD6A5XRn3zKfwhALPi2EQS0)
	mouse_filter = Control.MOUSE_FILTER_STOP
	__usUoZxqK0tIN0N1IOSl94332 = ThemeDB.fallback_font
const __NRYbWJ3kHhn6dPMXegCnyJO2: = 161
signal closed
func __8jHhFIzUAr5Qh3zT3ac5EgAx(d: int) -> void :
	__J7Q2zIqKaACRdzLBTlwWCvat = clampi(__J7Q2zIqKaACRdzLBTlwWCvat + d, 0, __1KK7mLbVDjpqbODCm_jiSHhN())
	__1H3G3vV5jgEbYMNPrKuiilfM()
	queue_redraw()
var __g2SE4dHxL_kXsExPdzpyHdoE: Array[Dictionary] = []
func __Zs_NRND2aIHjT0QBiS5yVaRm(__58er4OB7eS4bYc7qAQ4gH9JV: __s8yZigV26lPAvEmbOWzMbnjE) -> void :
	__YJgAymCaLB78BrFx7OQpn545 = __58er4OB7eS4bYc7qAQ4gH9JV
	var __eO6codUpcJoNA53eXImZ1E_N: __Se4EsxPBCHX48h1ZS5MexaMl = App.__PtNURh2PaYHMgsPlkLtni90Y()
	__g2SE4dHxL_kXsExPdzpyHdoE.clear()
	var __UdSXsMCbx0tUuvf_Un0KkCNa: PackedInt32Array = __eO6codUpcJoNA53eXImZ1E_N.__RgxkBWnYRjC44wuJnI7BKnV_(__58er4OB7eS4bYc7qAQ4gH9JV)
	var __H5dnWL4Uh6aDGc2irgw6CUWB: int = 1
	for __gpNcxpi3Lnnw3w9W0WX8Drgq: int in __58er4OB7eS4bYc7qAQ4gH9JV.__dOsDavODOasdfPxqce2DEBC3.size():
		if __58er4OB7eS4bYc7qAQ4gH9JV.__dOsDavODOasdfPxqce2DEBC3[__gpNcxpi3Lnnw3w9W0WX8Drgq] < 0:
			continue
		var g: Dictionary = __eO6codUpcJoNA53eXImZ1E_N.__Y7oNU_MxqAazQR74RzaCuaOa(__58er4OB7eS4bYc7qAQ4gH9JV.__dOsDavODOasdfPxqce2DEBC3[__gpNcxpi3Lnnw3w9W0WX8Drgq])
		var __ypXUh_Tbw70UJC2n1M4DmFWR: = {"slot": __H5dnWL4Uh6aDGc2irgw6CUWB, "name": str(g.get("cn", "—")), "w": int(g.get("weight", 0)), "sp": int(g.get("space", 0)), "kind": "gun", "index": __gpNcxpi3Lnnw3w9W0WX8Drgq}
		if __2ZIL9u7_cM4KOmaAUAdneX5d.meti_catalog_main_seat(__eO6codUpcJoNA53eXImZ1E_N,__58er4OB7eS4bYc7qAQ4gH9JV.__WeB9Hi0OxaFBUuwm2WU2qKEH,__gpNcxpi3Lnnw3w9W0WX8Drgq)==1:
			__ypXUh_Tbw70UJC2n1M4DmFWR["name"]="副砲 · "+str(__ypXUh_Tbw70UJC2n1M4DmFWR["name"])
		__TX7WRW286Wp_Mn1nkLDQ1JgL(__ypXUh_Tbw70UJC2n1M4DmFWR, __UdSXsMCbx0tUuvf_Un0KkCNa, __gpNcxpi3Lnnw3w9W0WX8Drgq)
		__g2SE4dHxL_kXsExPdzpyHdoE.append(__ypXUh_Tbw70UJC2n1M4DmFWR)
		__H5dnWL4Uh6aDGc2irgw6CUWB += 1
	var __o5UFgeRaov8Eiv65uIOP3Hfn: PackedInt32Array = __eO6codUpcJoNA53eXImZ1E_N.__PJZemYw0whDwrAt4vbBLpQ7w(__58er4OB7eS4bYc7qAQ4gH9JV)
	var __XgfsxwUvSYvyMbSa4FwhBRhz: PackedInt32Array = __eO6codUpcJoNA53eXImZ1E_N.__Xs0yLUqBQ7TVWSHzfx4EiUAr(__58er4OB7eS4bYc7qAQ4gH9JV)
	for __h6V2iSCZV9uRZ5g9vsyPIxlu: int in __o5UFgeRaov8Eiv65uIOP3Hfn.size():
		if __o5UFgeRaov8Eiv65uIOP3Hfn[__h6V2iSCZV9uRZ5g9vsyPIxlu] < 0:
			continue
		var g: Dictionary = __eO6codUpcJoNA53eXImZ1E_N.__RgEOOq666utGRIIoFV0rRVRX(__o5UFgeRaov8Eiv65uIOP3Hfn[__h6V2iSCZV9uRZ5g9vsyPIxlu])
		var __QOhmDbrPCo9ofjFdk9wR_Qmg: = {"slot": __H5dnWL4Uh6aDGc2irgw6CUWB, "name": str(g.get("cn", "—")), "w": int(g.get("weight", 0)), "sp": int(g.get("space", 0)), "kind": "side", "index": __h6V2iSCZV9uRZ5g9vsyPIxlu}
		__TX7WRW286Wp_Mn1nkLDQ1JgL(__QOhmDbrPCo9ofjFdk9wR_Qmg, __XgfsxwUvSYvyMbSa4FwhBRhz, __h6V2iSCZV9uRZ5g9vsyPIxlu)
		__g2SE4dHxL_kXsExPdzpyHdoE.append(__QOhmDbrPCo9ofjFdk9wR_Qmg)
		__H5dnWL4Uh6aDGc2irgw6CUWB += 1
	var __rQlTE_nzSOdOSVIKoFaS1Dzn: PackedInt32Array = __eO6codUpcJoNA53eXImZ1E_N.__7uBhyRNBJZP4s1InKu8Lo_y7(__58er4OB7eS4bYc7qAQ4gH9JV)
	var __sNCbHiPKIsZLzWO2t3dAIfHg: PackedInt32Array = __eO6codUpcJoNA53eXImZ1E_N.__El7brR86C9a6x0hMgLnIgY3e(__58er4OB7eS4bYc7qAQ4gH9JV)
	for __jNgfRwwiGJhckS03whIlCcn7: int in __rQlTE_nzSOdOSVIKoFaS1Dzn.size():
		if __rQlTE_nzSOdOSVIKoFaS1Dzn[__jNgfRwwiGJhckS03whIlCcn7] < 0:
			continue
		var __lKhAGK4LvPqey8usUEZBWWpm: Dictionary = __eO6codUpcJoNA53eXImZ1E_N.__GP_inhBqbirtrHNQn7xXbKG_(__rQlTE_nzSOdOSVIKoFaS1Dzn[__jNgfRwwiGJhckS03whIlCcn7])
		var __ujUXu94popR9GSeqPRWSmI8J: int = __sNCbHiPKIsZLzWO2t3dAIfHg[2 * __jNgfRwwiGJhckS03whIlCcn7 + 1] if __sNCbHiPKIsZLzWO2t3dAIfHg[2 * __jNgfRwwiGJhckS03whIlCcn7] >= 0 else 0
		__g2SE4dHxL_kXsExPdzpyHdoE.append({"slot": __H5dnWL4Uh6aDGc2irgw6CUWB, "name": str(__lKhAGK4LvPqey8usUEZBWWpm.get("cn", "—")), "w": int(__lKhAGK4LvPqey8usUEZBWWpm.get("weight", 0)), "sp": int(__lKhAGK4LvPqey8usUEZBWWpm.get("space", 0)), "kind": "tp", "index": __jNgfRwwiGJhckS03whIlCcn7, "a": str(__ujUXu94popR9GSeqPRWSmI8J) if __ujUXu94popR9GSeqPRWSmI8J > 0 else tr("UI_SS_NO_TORPEDO"), "b": "", "a_dim": __ujUXu94popR9GSeqPRWSmI8J <= 0, "b_dim": true})
		__H5dnWL4Uh6aDGc2irgw6CUWB += 1
	__J7Q2zIqKaACRdzLBTlwWCvat = clampi(__J7Q2zIqKaACRdzLBTlwWCvat, 0, __1KK7mLbVDjpqbODCm_jiSHhN())
	__1H3G3vV5jgEbYMNPrKuiilfM()
	queue_redraw()
var __usUoZxqK0tIN0N1IOSl94332: Font
const __bUl3aBV7CjUTIBcbbuUwjAt9: = 8
const __dIlsOx9kBMqLWp6RZD1ZSU_n: = 60
const __DIe_SzMbxLsigEfuTaFUx9Kl: = Rect2(474, 60, 14, 96)
func __1H3G3vV5jgEbYMNPrKuiilfM() -> void :
	__zFPxZ4x_KsoNDuQiG7QR7qOU.clear()
	__zFPxZ4x_KsoNDuQiG7QR7qOU.append({"rect": __h4vKx0du70Ycl2qhceThLOoS, "id": "close", "tip": tr("UI_CLOSE")})
	__zFPxZ4x_KsoNDuQiG7QR7qOU.append({"rect": Rect2(__DIe_SzMbxLsigEfuTaFUx9Kl.position, Vector2(__DIe_SzMbxLsigEfuTaFUx9Kl.size.x, 12)), "id": "up", "tip": ""})
	__zFPxZ4x_KsoNDuQiG7QR7qOU.append({"rect": Rect2(__DIe_SzMbxLsigEfuTaFUx9Kl.position.x, __DIe_SzMbxLsigEfuTaFUx9Kl.end.y - 12, __DIe_SzMbxLsigEfuTaFUx9Kl.size.x, 12), "id": "down", "tip": ""})
	for __CpdVUco_GwERbooo28dqGW5S: int in mini(__bUl3aBV7CjUTIBcbbuUwjAt9, __g2SE4dHxL_kXsExPdzpyHdoE.size() - __J7Q2zIqKaACRdzLBTlwWCvat):
		var r: Dictionary = __g2SE4dHxL_kXsExPdzpyHdoE[__J7Q2zIqKaACRdzLBTlwWCvat + __CpdVUco_GwERbooo28dqGW5S]
		var y: float = __dIlsOx9kBMqLWp6RZD1ZSU_n + __O_krrF5upjv1sZYM1ft4t0FV * __CpdVUco_GwERbooo28dqGW5S + 1
		match r["kind"]:
			"gun", "side":
				var __ZKGfwKHc3NpZheyTT4PoeGLW: String = "" if r["kind"] == "gun" else "S"
				__zFPxZ4x_KsoNDuQiG7QR7qOU.append({"rect": Rect2(__Dfdb0r4u5hoULcNSn_vE3gBA, y, __chyDA45DWMDdP8pgE_97A6ZA, __O_krrF5upjv1sZYM1ft4t0FV - 2), "id": "buy", "kind": __ZKGfwKHc3NpZheyTT4PoeGLW + "A", "index": int(r["index"]), "label": tr("UI_EQUIP_BTN_A"), "tip": tr("UI_EQUIP_BUY_SHELL")})
				__zFPxZ4x_KsoNDuQiG7QR7qOU.append({"rect": Rect2(__AitoAweg9PP1LgrxqOaqiNUn, y, __chyDA45DWMDdP8pgE_97A6ZA, __O_krrF5upjv1sZYM1ft4t0FV - 2), "id": "buy", "kind": __ZKGfwKHc3NpZheyTT4PoeGLW + "B", "index": int(r["index"]), "label": tr("UI_EQUIP_BTN_B"), "tip": tr("UI_EQUIP_BUY_SHELL")})
			"tp":
				__zFPxZ4x_KsoNDuQiG7QR7qOU.append({"rect": Rect2(__Dfdb0r4u5hoULcNSn_vE3gBA, y, __chyDA45DWMDdP8pgE_97A6ZA, __O_krrF5upjv1sZYM1ft4t0FV - 2), "id": "buy", "kind": "T", "index": int(r["index"]), "label": tr("UI_EQUIP_BTN_T"), "tip": tr("UI_EQUIP_BUY_TORP")})
	__iDNkCPxPojBek41rxB5M2Fvi = -1
func __1KK7mLbVDjpqbODCm_jiSHhN() -> int:
	return maxi(0, __g2SE4dHxL_kXsExPdzpyHdoE.size() - __bUl3aBV7CjUTIBcbbuUwjAt9)
func __oAdr6FVkVftJ_szUC7Z6ZgDK() -> Rect2:
	var __OAoNzH8xYrH8pxjmfi_Oz1oW: Rect2 = __A83meQhKXYN81y2fmwZCvYT4()
	var __lsNlF8BcLuXkAvdCq9oLHDLY: int = maxi(1, __g2SE4dHxL_kXsExPdzpyHdoE.size())
	var __evdJ1WCYy6AWBFqaJov5WfKg: float = maxf(10.0, __OAoNzH8xYrH8pxjmfi_Oz1oW.size.y * minf(1.0, float(__bUl3aBV7CjUTIBcbbuUwjAt9) / __lsNlF8BcLuXkAvdCq9oLHDLY))
	var y: float = __OAoNzH8xYrH8pxjmfi_Oz1oW.position.y + (__OAoNzH8xYrH8pxjmfi_Oz1oW.size.y - __evdJ1WCYy6AWBFqaJov5WfKg) * (float(__J7Q2zIqKaACRdzLBTlwWCvat) / maxf(1.0, __1KK7mLbVDjpqbODCm_jiSHhN()))
	return Rect2(__OAoNzH8xYrH8pxjmfi_Oz1oW.position.x + 2, y, __OAoNzH8xYrH8pxjmfi_Oz1oW.size.x - 4, __evdJ1WCYy6AWBFqaJov5WfKg)
const __PKDrrYEl88IOD0b5ulkIFMx2: = 260
const __8h2uKVxwyDED2FKi0hoy_nrA: = Color8(156, 184, 212)
const __p21lsufDyKQzV21yJ4KRVEgm: = 179
const __g4fWDCu0WZ5Ll3ig3mt3BKrb: = 10
func __A83meQhKXYN81y2fmwZCvYT4() -> Rect2:
	return Rect2(__DIe_SzMbxLsigEfuTaFUx9Kl.position.x, __DIe_SzMbxLsigEfuTaFUx9Kl.position.y + 13, __DIe_SzMbxLsigEfuTaFUx9Kl.size.x, __DIe_SzMbxLsigEfuTaFUx9Kl.size.y - 26)
const __GbCKF83RIWHpg93W6aEOFjt4: = 468
func __TX7WRW286Wp_Mn1nkLDQ1JgL(__Cl81KK4Jw03RjZyIH1DOT6Bo: Dictionary, __U3fSDIgeMuW3dVR1EDSjZgU7: PackedInt32Array, __Ucfox4XXcmnyXi5DpYf4gP7V: int) -> void :
	var __gpXPdY0TFVC0mqMFhnWuMtdq: __Se4EsxPBCHX48h1ZS5MexaMl = App.__PtNURh2PaYHMgsPlkLtni90Y()
	for __kTPhe_xhdruT6LjEjW86fqm9: int in 2:
		var r: int = __U3fSDIgeMuW3dVR1EDSjZgU7[4 * __Ucfox4XXcmnyXi5DpYf4gP7V + 2 * __kTPhe_xhdruT6LjEjW86fqm9]
		var __dWaCmsNKTpgk6EMrDb0p2GDy: int = __U3fSDIgeMuW3dVR1EDSjZgU7[4 * __Ucfox4XXcmnyXi5DpYf4gP7V + 2 * __kTPhe_xhdruT6LjEjW86fqm9 + 1]
		var __Qs5oyFwfJgGRSFt_h7aQP5Ge: String = tr("UI_EQUIP_NOSHELL")
		if r >= 0 and __dWaCmsNKTpgk6EMrDb0p2GDy > 0:
			var s: Dictionary = __gpXPdY0TFVC0mqMFhnWuMtdq.__Z1n6LQ0e8g_Sv5O7it1HPeiw(r)
			__Qs5oyFwfJgGRSFt_h7aQP5Ge = tr("UI_EQUIP_ROUNDS") % [tr(__Se4EsxPBCHX48h1ZS5MexaMl.__t9BykvPbNOqdOsY2A_MmTW3G.get(int(s["kind"]), "UI_SHELL_HE")), __dWaCmsNKTpgk6EMrDb0p2GDy * int(s["per_box"]), __dWaCmsNKTpgk6EMrDb0p2GDy]
		__Cl81KK4Jw03RjZyIH1DOT6Bo["ab"[__kTPhe_xhdruT6LjEjW86fqm9]] = __Qs5oyFwfJgGRSFt_h7aQP5Ge
		__Cl81KK4Jw03RjZyIH1DOT6Bo["ab"[__kTPhe_xhdruT6LjEjW86fqm9] + "_dim"] = not (r >= 0 and __dWaCmsNKTpgk6EMrDb0p2GDy > 0)
func __w3Qs6BDVZyBjmUqVBKHi22cK(r: Rect2, label: String, __k_h5wE8l1mbMZ6HZpFUaNB7R: int) -> void :
	var __zOUumNQkM9XttkhBSJc8Pn9u: bool = __u8hy3ISjyDmipgX1Q_5CKF_0(__zFPxZ4x_KsoNDuQiG7QR7qOU[__k_h5wE8l1mbMZ6HZpFUaNB7R])
	var fill: Color = Color(0.1, 0.2, 0.32, 1)
	if not __zOUumNQkM9XttkhBSJc8Pn9u:
		fill = Color(0.06, 0.09, 0.13, 1)
	elif __k_h5wE8l1mbMZ6HZpFUaNB7R == __Eu6qHyivDiwDtCgFQImi4A4K and __k_h5wE8l1mbMZ6HZpFUaNB7R == __iDNkCPxPojBek41rxB5M2Fvi:
		fill = Color(0.06, 0.13, 0.22, 1)
	elif __k_h5wE8l1mbMZ6HZpFUaNB7R == __iDNkCPxPojBek41rxB5M2Fvi:
		fill = Color(0.18, 0.34, 0.52, 1)
	draw_rect(r, fill)
	draw_rect(Rect2(r.position + Vector2(0.5, 0.5), r.size - Vector2.ONE), __l0ljxOzuGuAaMAg0E9tYqY8N.__UaQzKGmq2KuW6fOzrZIiSZtk if __zOUumNQkM9XttkhBSJc8Pn9u else __l0ljxOzuGuAaMAg0E9tYqY8N.__IBVvKw1yASSe7F4G5OVPjjdj, false, 1.0)
	__56uwjo4rut9BrBhaLFRDhess(r.position.x, r.end.x, r.position.y + (r.size.y - __g4fWDCu0WZ5Ll3ig3mt3BKrb) / 2.0, label, __pCUi6LToFPukNiGDrBwJ7It8 if __zOUumNQkM9XttkhBSJc8Pn9u else __kVYXi_NVoyPvuzc3ek8hOGFd, HORIZONTAL_ALIGNMENT_CENTER, __g4fWDCu0WZ5Ll3ig3mt3BKrb - 1)
const __Dfdb0r4u5hoULcNSn_vE3gBA: = 264
const __leD6A5XRn3zKfwhALPi2EQS0: = 186
func _activate(h: Dictionary) -> void :
	match h["id"]:
		"close":
			closed.emit()
		"up":
			__8jHhFIzUAr5Qh3zT3ac5EgAx(-1)
		"down":
			__8jHhFIzUAr5Qh3zT3ac5EgAx(1)
		"buy":
			__5dOpWU_ha4oiYZpAS9KePUB4.emit(str(h["kind"]), int(h["index"]))
func _draw() -> void :
	var __cP8qtiSiIu0ISF9w_4StKaEp: = Rect2(0, __0TzCNXqGr_xlfeKYSe0LBQFC, __qkI9rzzPHG3olOfJc5DxIE0c, __leD6A5XRn3zKfwhALPi2EQS0 - __0TzCNXqGr_xlfeKYSe0LBQFC)
	draw_rect(__cP8qtiSiIu0ISF9w_4StKaEp, __l0ljxOzuGuAaMAg0E9tYqY8N.__FZypoysBpi4L67LAu9AxsRfZ)
	draw_rect(Rect2(__cP8qtiSiIu0ISF9w_4StKaEp.position + Vector2(0.5, 0.5), __cP8qtiSiIu0ISF9w_4StKaEp.size - Vector2.ONE), __l0ljxOzuGuAaMAg0E9tYqY8N.__UaQzKGmq2KuW6fOzrZIiSZtk, false, 1.0)
	draw_rect(__YHAi_l3enYEvgawtDjAQt4ow, __l0ljxOzuGuAaMAg0E9tYqY8N.__uM0syOiZSyAoYRI1egXEgPRF)
	draw_rect(Rect2(__YHAi_l3enYEvgawtDjAQt4ow.position.x, __YHAi_l3enYEvgawtDjAQt4ow.end.y, __YHAi_l3enYEvgawtDjAQt4ow.size.x, 1), __l0ljxOzuGuAaMAg0E9tYqY8N.__5BdrvxK7qD5BiVk_0jPZ4czq)
	__56uwjo4rut9BrBhaLFRDhess(__YHAi_l3enYEvgawtDjAQt4ow.position.x, __p21lsufDyKQzV21yJ4KRVEgm, __YHAi_l3enYEvgawtDjAQt4ow.position.y + 2, tr("UI_EQUIP_HEAD_NAME"), __8h2uKVxwyDED2FKi0hoy_nrA, HORIZONTAL_ALIGNMENT_CENTER, 11)
	__56uwjo4rut9BrBhaLFRDhess(__p21lsufDyKQzV21yJ4KRVEgm, __hWaLiMj057VktAgkCeO8MD_U, __YHAi_l3enYEvgawtDjAQt4ow.position.y + 2, tr("UI_EQUIP_HEAD_WEIGHT"), __8h2uKVxwyDED2FKi0hoy_nrA, HORIZONTAL_ALIGNMENT_CENTER, 11)
	__56uwjo4rut9BrBhaLFRDhess(__hWaLiMj057VktAgkCeO8MD_U, __PKDrrYEl88IOD0b5ulkIFMx2, __YHAi_l3enYEvgawtDjAQt4ow.position.y + 2, tr("UI_EQUIP_HEAD_SPACE"), __8h2uKVxwyDED2FKi0hoy_nrA, HORIZONTAL_ALIGNMENT_CENTER, 11)
	__56uwjo4rut9BrBhaLFRDhess(__PKDrrYEl88IOD0b5ulkIFMx2, __YHAi_l3enYEvgawtDjAQt4ow.end.x, __YHAi_l3enYEvgawtDjAQt4ow.position.y + 2, tr("UI_EQUIP_HEAD_DATA"), __8h2uKVxwyDED2FKi0hoy_nrA, HORIZONTAL_ALIGNMENT_CENTER, 11)
	for __vxJRQkVS0o4BRU3ZVzcRKW4v: int in __bUl3aBV7CjUTIBcbbuUwjAt9:
		var y: float = __dIlsOx9kBMqLWp6RZD1ZSU_n + __O_krrF5upjv1sZYM1ft4t0FV * __vxJRQkVS0o4BRU3ZVzcRKW4v
		if __vxJRQkVS0o4BRU3ZVzcRKW4v % 2 == 1:
			draw_rect(Rect2(__YHAi_l3enYEvgawtDjAQt4ow.position.x, y, __GbCKF83RIWHpg93W6aEOFjt4 - __YHAi_l3enYEvgawtDjAQt4ow.position.x, __O_krrF5upjv1sZYM1ft4t0FV), Color(1, 1, 1, 0.035))
		if __vxJRQkVS0o4BRU3ZVzcRKW4v == __kQVpUwZu_9LRJegsKzpzs1LH:
			draw_rect(Rect2(__YHAi_l3enYEvgawtDjAQt4ow.position.x, y, __GbCKF83RIWHpg93W6aEOFjt4 - __YHAi_l3enYEvgawtDjAQt4ow.position.x, __O_krrF5upjv1sZYM1ft4t0FV), Color(0.35, 0.6, 0.9, 0.16))
	for x: int in [__p21lsufDyKQzV21yJ4KRVEgm, __hWaLiMj057VktAgkCeO8MD_U, __PKDrrYEl88IOD0b5ulkIFMx2]:
		draw_rect(Rect2(x, __YHAi_l3enYEvgawtDjAQt4ow.position.y, 1, __dIlsOx9kBMqLWp6RZD1ZSU_n + __O_krrF5upjv1sZYM1ft4t0FV * __bUl3aBV7CjUTIBcbbuUwjAt9 - __YHAi_l3enYEvgawtDjAQt4ow.position.y), __l0ljxOzuGuAaMAg0E9tYqY8N.__IBVvKw1yASSe7F4G5OVPjjdj)
	if __g2SE4dHxL_kXsExPdzpyHdoE.is_empty():
		__56uwjo4rut9BrBhaLFRDhess(__8DH0IlpFmjMCyvkslQ4FdpdO, __p21lsufDyKQzV21yJ4KRVEgm - 4, __dIlsOx9kBMqLWp6RZD1ZSU_n + 1, tr("UI_EQUIP_EMPTY"), __kVYXi_NVoyPvuzc3ek8hOGFd)
	for __mmKcW4fPNVZK638kfFgxVDdv: int in mini(__bUl3aBV7CjUTIBcbbuUwjAt9, __g2SE4dHxL_kXsExPdzpyHdoE.size() - __J7Q2zIqKaACRdzLBTlwWCvat):
		var r: Dictionary = __g2SE4dHxL_kXsExPdzpyHdoE[__J7Q2zIqKaACRdzLBTlwWCvat + __mmKcW4fPNVZK638kfFgxVDdv]
		var y: float = __dIlsOx9kBMqLWp6RZD1ZSU_n + __O_krrF5upjv1sZYM1ft4t0FV * __mmKcW4fPNVZK638kfFgxVDdv + 1
		__56uwjo4rut9BrBhaLFRDhess(__syiXBSXppU6V7Fj0Yweo8e3l, __8DH0IlpFmjMCyvkslQ4FdpdO - 2, y, str(r["slot"]), __jWohe0A1qko0s_BICi5kZE4j)
		__56uwjo4rut9BrBhaLFRDhess(__8DH0IlpFmjMCyvkslQ4FdpdO, __p21lsufDyKQzV21yJ4KRVEgm - 3, y, r["name"], __pCUi6LToFPukNiGDrBwJ7It8)
		__56uwjo4rut9BrBhaLFRDhess(__p21lsufDyKQzV21yJ4KRVEgm + 2, __hWaLiMj057VktAgkCeO8MD_U - 4, y, "%d.%d" % [int(r["w"]) / 1000, int(r["w"]) % 1000 / 100], __pCUi6LToFPukNiGDrBwJ7It8, HORIZONTAL_ALIGNMENT_RIGHT)
		__56uwjo4rut9BrBhaLFRDhess(__hWaLiMj057VktAgkCeO8MD_U + 2, __PKDrrYEl88IOD0b5ulkIFMx2 - 4, y, "%d.%d" % [int(r["sp"]) / 10, int(r["sp"]) % 10], __pCUi6LToFPukNiGDrBwJ7It8, HORIZONTAL_ALIGNMENT_RIGHT)
		var __Aq6dxxMvQIGYGNfJ9SIIIUgR: float = __Dfdb0r4u5hoULcNSn_vE3gBA + __chyDA45DWMDdP8pgE_97A6ZA + 4
		__56uwjo4rut9BrBhaLFRDhess(__Aq6dxxMvQIGYGNfJ9SIIIUgR, __AitoAweg9PP1LgrxqOaqiNUn - 4, y, r["a"], __kVYXi_NVoyPvuzc3ek8hOGFd if r["a_dim"] else __pCUi6LToFPukNiGDrBwJ7It8)
		__56uwjo4rut9BrBhaLFRDhess(__AitoAweg9PP1LgrxqOaqiNUn + __chyDA45DWMDdP8pgE_97A6ZA + 4, __GbCKF83RIWHpg93W6aEOFjt4 - 2, y, r["b"], __kVYXi_NVoyPvuzc3ek8hOGFd if r["b_dim"] else __pCUi6LToFPukNiGDrBwJ7It8)
	for __uX2slyxyEQhm4sbrJHecTEHK: int in __zFPxZ4x_KsoNDuQiG7QR7qOU.size():
		var h: Dictionary = __zFPxZ4x_KsoNDuQiG7QR7qOU[__uX2slyxyEQhm4sbrJHecTEHK]
		match h["id"]:
			"buy":
				__w3Qs6BDVZyBjmUqVBKHi22cK(h["rect"], str(h["label"]), __uX2slyxyEQhm4sbrJHecTEHK)
			"close":
				__w3Qs6BDVZyBjmUqVBKHi22cK(h["rect"], "×", __uX2slyxyEQhm4sbrJHecTEHK)
			"up":
				__w3Qs6BDVZyBjmUqVBKHi22cK(h["rect"], "▲", __uX2slyxyEQhm4sbrJHecTEHK)
			"down":
				__w3Qs6BDVZyBjmUqVBKHi22cK(h["rect"], "▼", __uX2slyxyEQhm4sbrJHecTEHK)
	var __081QPFrnbhYY3h6Yuz6K4Hdw: Rect2 = __A83meQhKXYN81y2fmwZCvYT4()
	draw_rect(__081QPFrnbhYY3h6Yuz6K4Hdw, Color(0.01, 0.03, 0.05, 1))
	draw_rect(Rect2(__081QPFrnbhYY3h6Yuz6K4Hdw.position + Vector2(0.5, 0.5), __081QPFrnbhYY3h6Yuz6K4Hdw.size - Vector2.ONE), __l0ljxOzuGuAaMAg0E9tYqY8N.__IBVvKw1yASSe7F4G5OVPjjdj, false, 1.0)
	if __g2SE4dHxL_kXsExPdzpyHdoE.size() > __bUl3aBV7CjUTIBcbbuUwjAt9:
		draw_rect(__oAdr6FVkVftJ_szUC7Z6ZgDK(), Color(__l0ljxOzuGuAaMAg0E9tYqY8N.__uZsUn6KOOVv_qJLmAUYOaxgm, 0.6))
	draw_rect(Rect2(4, __NRYbWJ3kHhn6dPMXegCnyJO2, __qkI9rzzPHG3olOfJc5DxIE0c - 8, 1), __l0ljxOzuGuAaMAg0E9tYqY8N.__uZsUn6KOOVv_qJLmAUYOaxgm)
	var __QNUFrMzMfsAyhrrkEBEFNIiB: int = 0
	var __i9OPXjG1KWYpRQU1gcgx0p7s: int = 0
	if __YJgAymCaLB78BrFx7OQpn545 != null:
		var __b6atWHi7_08I5AlXkZL5uopQ: __Se4EsxPBCHX48h1ZS5MexaMl = App.__PtNURh2PaYHMgsPlkLtni90Y()
		__QNUFrMzMfsAyhrrkEBEFNIiB = __b6atWHi7_08I5AlXkZL5uopQ.__1CdXpyU1UJ8cmNMTd_g2_0od(__YJgAymCaLB78BrFx7OQpn545)
		__i9OPXjG1KWYpRQU1gcgx0p7s = __b6atWHi7_08I5AlXkZL5uopQ.__eO4VHYjMVObwrueIqrahxQOQ(__YJgAymCaLB78BrFx7OQpn545.__WeB9Hi0OxaFBUuwm2WU2qKEH)
	__BmL75x0AkEn2C8EfwCa5cPw3(8, tr("UI_EQUIP_FOOT_TORP"), __QNUFrMzMfsAyhrrkEBEFNIiB, __i9OPXjG1KWYpRQU1gcgx0p7s)
	__BmL75x0AkEn2C8EfwCa5cPw3(174, tr("UI_EQUIP_FOOT_AIR"), 0, 0)
	__BmL75x0AkEn2C8EfwCa5cPw3(330, tr("UI_EQUIP_FOOT_SCOUT"), 0, 0)
const __pCUi6LToFPukNiGDrBwJ7It8: = Color8(220, 232, 245)
