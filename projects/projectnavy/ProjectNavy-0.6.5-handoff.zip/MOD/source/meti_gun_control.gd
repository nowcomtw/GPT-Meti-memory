extends PanelContainer

const ACTIONS:Dictionary={
    "select_r": __ZHwJr3sB730Xm67xCNPRVjTe.__7p66fpI27Ejh1nHovTpHSGpN.__iP7LN73_xb6x5PKHMlGXbHjn,
    "select_t": __ZHwJr3sB730Xm67xCNPRVjTe.__7p66fpI27Ejh1nHovTpHSGpN.__Bz_D3u8GcSr1fT7dQ3qcayns,
    "select_front": __ZHwJr3sB730Xm67xCNPRVjTe.__7p66fpI27Ejh1nHovTpHSGpN.__nIaVC0RCY5x_ReiW9iy0cfJY,
    "select_rear": __ZHwJr3sB730Xm67xCNPRVjTe.__7p66fpI27Ejh1nHovTpHSGpN.__cSWKSV1e8j41TiOunWHnJFTK,
    "select_both": __ZHwJr3sB730Xm67xCNPRVjTe.__7p66fpI27Ejh1nHovTpHSGpN.__eZFFJSoM0kHSHvp53AhrAgX1,
    "cargo": __ZHwJr3sB730Xm67xCNPRVjTe.__7p66fpI27Ejh1nHovTpHSGpN.__X5iB60ENF15r2NuA81LfX6oo,
}
const TEXT:Dictionary={"select_r":"主砲","select_t":"副砲","select_front":"前組","select_both":"全部","select_rear":"後組","cargo":"切換主／備彈"}
var battle:Node
var ship:Variant
var buttons:Dictionary={}
var body:VBoxContainer
var fold_button:Button
var meti_carrier_button:Button
var meti_carrier_panel:WeakRef
var title_label:Label
var group_status:Array[Label]=[]
var folded:bool=false
var elapsed:float=0.0
var last_bindings:Dictionary={}

func _ready() -> void:
    theme=__Wl_Qw9KUEfRrP_gP8ETPRbl4.get_theme()
    mouse_filter=Control.MOUSE_FILTER_STOP
    set_anchors_preset(Control.PRESET_TOP_RIGHT)
    offset_left=-258;offset_right=-10;offset_top=374;offset_bottom=374
    custom_minimum_size=Vector2(248,0)
    var background=StyleBoxFlat.new()
    background.bg_color=Color(0.035,0.075,0.13,0.93)
    background.border_color=Color(0.39,0.58,0.75,0.9)
    background.set_border_width_all(1)
    background.set_corner_radius_all(4)
    background.content_margin_left=7;background.content_margin_right=7
    background.content_margin_top=5;background.content_margin_bottom=6
    add_theme_stylebox_override("panel",background)
    var outer=VBoxContainer.new()
    outer.add_theme_constant_override("separation",4)
    add_child(outer)
    var heading=HBoxContainer.new();heading.add_theme_constant_override("separation",4);outer.add_child(heading)
    title_label=Label.new();title_label.text="火炮操作";title_label.size_flags_horizontal=Control.SIZE_EXPAND_FILL
    title_label.add_theme_font_size_override("font_size",14);title_label.add_theme_color_override("font_color",Color8(255,214,110));heading.add_child(title_label)
    fold_button=Button.new();fold_button.text="收起";fold_button.focus_mode=Control.FOCUS_NONE
    fold_button.custom_minimum_size=Vector2(52,24);fold_button.add_theme_font_size_override("font_size",11)
    fold_button.pressed.connect(toggle_fold);heading.add_child(fold_button)
    meti_carrier_button=Button.new();meti_carrier_button.text="飛機";meti_carrier_button.focus_mode=Control.FOCUS_NONE
    meti_carrier_button.custom_minimum_size=Vector2(48,24);meti_carrier_button.add_theme_font_size_override("font_size",11)
    meti_carrier_button.pressed.connect(meti_open_carrier);heading.add_child(meti_carrier_button);meti_carrier_button.hide()
    body=VBoxContainer.new();body.add_theme_constant_override("separation",3);outer.add_child(body)
    add_row(["select_r","select_t"])
    add_row(["select_front","select_both","select_rear"])
    add_row(["cargo"])
    for i:int in 2:
        var label=Label.new();label.add_theme_font_size_override("font_size",11)
        label.add_theme_color_override("font_color",Color8(203,223,241));label.mouse_filter=Control.MOUSE_FILTER_IGNORE
        label.clip_text=true;body.add_child(label);group_status.append(label)
    buttons["cargo"].tooltip_text="切換目前選中炮組的主／備彈。若各炮原本槽位不同，會分別切到另一槽。"
    get_viewport().size_changed.connect(update_layout)
    call_deferred("update_layout")
    refresh(true)

func add_row(ids:Array) -> void:
    var row=HBoxContainer.new();row.add_theme_constant_override("separation",3);body.add_child(row)
    for id:String in ids:
        var button=Button.new();button.name="action_"+id
        button.focus_mode=Control.FOCUS_NONE;button.mouse_filter=Control.MOUSE_FILTER_STOP
        button.size_flags_horizontal=Control.SIZE_EXPAND_FILL;button.custom_minimum_size=Vector2(0,27)
        button.add_theme_font_size_override("font_size",11)
        button.toggle_mode=id!="cargo"
        button.pressed.connect(func() -> void: dispatch(id))
        row.add_child(button);buttons[id]=button

func bind(owner_battle:Node,player:Variant) -> void:
    battle=owner_battle;ship=player
    refresh(true)

func dispatch(id:String) -> void:
    if not ACTIONS.has(id) or not is_instance_valid(battle) or ship==null:return
    if battle.__898CZFX8zI40Huxp297h_lkH or battle.__5zsHBwGhnk5X3Ays_WuwIBnz!=null or battle.paused:return
    if ship.state!=__lAo0PsogaUvqHw4muTzPsHiR.__pRO7nOY10o2GAU3KzWQvIvwY:return
    var router=battle.__323DjHVpeKq9qbqbhN5ocoRI
    if is_instance_valid(router):router.__iL4GqZUqVbrDbkYxSpzwsdvm(int(ACTIONS[id]),true,null)
    # The state is confirmed by the simulation on the next tick.

func toggle_fold() -> void:
    folded=not folded
    body.visible=not folded
    fold_button.text="展開" if folded else "收起"
    call_deferred("reset_size")
    call_deferred("update_layout")

func update_layout() -> void:
    var viewport_height:float=get_viewport_rect().size.y
    var panel_height:float=maxf(30.0,get_combined_minimum_size().y)
    # The stock A/B team summaries occupy y=100..363. Keep the controls below
    # them and above the bottom battle HUD on common 720p+ window sizes.
    var fit:float=clampf((viewport_height-170.0-374.0)/panel_height,0.75,1.0)
    scale=Vector2.ONE*fit
    offset_left=-10.0-248.0*fit;offset_right=offset_left+248.0
    var top:float=minf(374.0,maxf(68.0,viewport_height-170.0-panel_height*fit))
    offset_top=top;offset_bottom=top+panel_height

func _process(delta:float) -> void:
    elapsed+=delta
    if elapsed>=0.15:
        elapsed=0.0
        refresh()

func refresh(force:bool=false) -> void:
    if buttons.is_empty():return
    var bindings:Dictionary=__MT3tlqgNpSAar5gPyaxu16Oq.names()
    if force or bindings!=last_bindings:
        last_bindings=bindings.duplicate()
        for id:String in buttons:
            buttons[id].text="%s [%s]" % [TEXT[id],str(bindings.get(id,"—"))]
    if ship==null:return
    var seat:int=int(ship.__1Z7OFhxB6TttwviVl7guTYN5)
    var mask:int=int(ship.__0j_qIrRynBs_5RNxom5Lo_bi)
    title_label.text="火炮操作 · "+("主砲" if seat==0 else "副砲")
    buttons["select_r"].set_pressed_no_signal(seat==0)
    buttons["select_t"].set_pressed_no_signal(seat==1)
    buttons["select_front"].set_pressed_no_signal((mask&48)==16)
    buttons["select_rear"].set_pressed_no_signal((mask&48)==32)
    buttons["select_both"].set_pressed_no_signal((mask&48)==48)
    for group:int in 2:
        group_status[group].text=("● " if (mask & (16 << group))!=0 else "○ ")+status_for_group(seat,group)

func status_for_group(seat:int,group:int) -> String:
    var entries:Dictionary={};var count:int=0;var rounds:int=0
    for gun:Dictionary in ship.__BJReFJ4ugditvprP9JFCx5S2:
        if int(gun.get("seat",0))!=seat or int(gun.get("group",0))!=group:continue
        count+=1
        var backup:bool=int(gun.get("cargo",0))!=0
        var projectile:Dictionary=gun.get("shell_b",{}) if backup else gun.get("shell",{})
        var kind:int=int(projectile.get("kind",-1))
        var type_name:String="高爆" if kind==0 else "防空" if kind==1 else "穿甲" if kind==2 else "其他"
        var label:String=("備" if backup else "主")+" "+type_name
        entries[label]=true
        rounds+=maxi(0,int(gun.get("ammo_b" if backup else "ammo_a",0)))
    var group_name:String="前組" if group==0 else "後組"
    if count==0:return group_name+"：無火砲"
    var active:String=str(entries.keys()[0]) if entries.size()==1 else "混合（各炮各自切換）"
    return "%s：%s｜%d 發" % [group_name,active,rounds]

func meti_bind_carrier(panel:Control) -> void:
    meti_carrier_panel=weakref(panel)
    meti_carrier_button.show()
    call_deferred("reset_size")
    call_deferred("update_layout")

func meti_open_carrier() -> void:
    var panel=meti_carrier_panel.get_ref() if meti_carrier_panel!=null else null
    if is_instance_valid(panel):
        hide()
        panel.show()
        panel.call_deferred("update_layout")
