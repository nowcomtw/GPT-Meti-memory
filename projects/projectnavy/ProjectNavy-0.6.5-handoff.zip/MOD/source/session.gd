extends Node
signal __0B62d3Zf32pWK86ifUjWdVAO(client: __OVAOfLpG8ro21Yx3xp7VhB3r)
static func __ZAzoyXS_Hxv_vfUfIRQ125kE() -> String:
	var __7UqofG7NVDhQ3HxZLsgtkzOf: String = __svCpIOini0lrUqcqp5XK8DO3.__SVYydJFZQaaI80Q8q8_QVkpb()
	return __7UqofG7NVDhQ3HxZLsgtkzOf if __7UqofG7NVDhQ3HxZLsgtkzOf != "" else "127.0.0.1:%d" % __R9QNzROpIBeVhQdDMd60twhq.__MejvtxQk1DW6AN522yF6BG19
var __R7ELz7zJC7hosKgl7dZAW2Qf: __s8yZigV26lPAvEmbOWzMbnjE = null
func __6boYmTBi229EPYhIG1rS9EZs() -> void :
	if client != null:
		client.close()
		client.poll()
	client = null
	__E3paFTADNyc5HASlcvMeifJo = ""
	__vRWRc9t3f6oN0JpbN_TPt2xm = 0
	__R7ELz7zJC7hosKgl7dZAW2Qf = null
	__0B62d3Zf32pWK86ifUjWdVAO.emit(null)
func __foz_YDdkDf3P3Vbb9RWlAuVo(__uFBnga8yuQAzyHv7t1KakIGK: Dictionary, __Q7iLRGAq5K_AgatkuYGCyB5u: int) -> void :
	var __IaFpsRZXNlW1HTMZf_VroxxA: Dictionary = App.__M0ImV248NGNrBFXy9NCs5jwX().__6vukUhU2G_4b_rRHatkEj0ZY(int(__uFBnga8yuQAzyHv7t1KakIGK["total_exp"]), {"credits": int(__uFBnga8yuQAzyHv7t1KakIGK["credits"]), "points": int(__uFBnga8yuQAzyHv7t1KakIGK["points"])}, __Q7iLRGAq5K_AgatkuYGCyB5u, 0, __uFBnga8yuQAzyHv7t1KakIGK)
	UI.__Qyp4Js7J9ejl5FSF4pVpfEi5(tr("UI_RESULT_SETTLED_LATE") % [int(__IaFpsRZXNlW1HTMZf_VroxxA["total"]), __9MFWgnc8oYQpY6kqM0OFfhrH.__T6RXw_rko7c4535cA0DDKIn7(int(__IaFpsRZXNlW1HTMZf_VroxxA["credits_delta"])), __9MFWgnc8oYQpY6kqM0OFfhrH.__T6RXw_rko7c4535cA0DDKIn7(int(__IaFpsRZXNlW1HTMZf_VroxxA["points_delta"]))], 4.0)
var __SVYydJFZQaaI80Q8q8_QVkpb: String = ""
var __vRWRc9t3f6oN0JpbN_TPt2xm: int = 0
var __eUrEV7KZeZb5SFnaL0Wry5AY: __k8pdL_GB8yADpq0vqeDWpz5v
func __sElzfZsQgPUojFHBug4gvaek(__f8xS5TWauyMwNsGm3zz0l_c9: Dictionary, __d6VTHL_H2ZKLA3i8GWlLvGDR: __OVAOfLpG8ro21Yx3xp7VhB3r) -> void :
	if __d6VTHL_H2ZKLA3i8GWlLvGDR != client or __E3paFTADNyc5HASlcvMeifJo == "" or str(__f8xS5TWauyMwNsGm3zz0l_c9.get("id", "")) != __E3paFTADNyc5HASlcvMeifJo:
		return
	if __f8xS5TWauyMwNsGm3zz0l_c9.get("ok") != true:
		__vpLUQnFNf6ZOOEyoVq1KPowy(str(__f8xS5TWauyMwNsGm3zz0l_c9.get("why", "REJECTED")))
		return
	print("[repair] 服务端确认完成：", __E3paFTADNyc5HASlcvMeifJo)
	__eUrEV7KZeZb5SFnaL0Wry5AY = null
	__d6VTHL_H2ZKLA3i8GWlLvGDR.__BQdoTflzacZ5Zx0drR5P5egD = "" if __eXg3hMS7akhCfGmWn242Awpx().is_empty() else __H5G0YcInAz3w9I5gBsEa5PDa.__nwxRqpICDhNdCf6CjHh9vjo5
	UI.__Qyp4Js7J9ejl5FSF4pVpfEi5(tr("UI_REPAIR_DONE"), 4.0)
	__E3paFTADNyc5HASlcvMeifJo = ""
	__vRWRc9t3f6oN0JpbN_TPt2xm = Time.get_ticks_msec() + 15000
	__d6VTHL_H2ZKLA3i8GWlLvGDR.__U8Z30RAkbS6JQ7Q8kwHMNI_D()
const __Fn_eB9YJAdyxGkRYpCBYNAB0: = "node"
func _exit_tree() -> void :
	__O1mRKOPITP5ldy0TJRNfObZZ()
func __2AokRD4QOC79KSjRpI0qITEn(host: String, __kdAtNsgVEvecScKaZueHK5S8: int, __XcjHtM98OQd6tsZTmezAanWj: String) -> __OVAOfLpG8ro21Yx3xp7VhB3r:
	__6boYmTBi229EPYhIG1rS9EZs()
	__R7ELz7zJC7hosKgl7dZAW2Qf = null
	client = __OVAOfLpG8ro21Yx3xp7VhB3r.new()
	client.__P4e34ZpL4re0nm_B3HT_VrxU = OS.get_name().to_lower()
	client.__8FkJfHSvxnbl2cbIJgntGxuA = App.__M0ImV248NGNrBFXy9NCs5jwX().__dFm6DOUISO0GARjmCPdhCxZ0.__8FkJfHSvxnbl2cbIJgntGxuA()
	if not __eXg3hMS7akhCfGmWn242Awpx().is_empty():
		client.__BQdoTflzacZ5Zx0drR5P5egD = __H5G0YcInAz3w9I5gBsEa5PDa.__nwxRqpICDhNdCf6CjHh9vjo5
	client.__ncTq6ojhsWEF20WJ4N7X2hhu = true
	client.__Bhm7zDQX1IkDw6ywQ3emCtM6.connect(__1tiM1GqqZCDCWM_qOQaC1YoM.bind(client))
	client.__o4KBBWItLXhd2sO6a18ttTee.connect(__sElzfZsQgPUojFHBug4gvaek.bind(client))
	client.__2AokRD4QOC79KSjRpI0qITEn(host, __kdAtNsgVEvecScKaZueHK5S8, __XcjHtM98OQd6tsZTmezAanWj)
	client.__3dW_g7wmEQwNmeyAKmyjKIB6.connect(__foz_YDdkDf3P3Vbb9RWlAuVo)
	client.__7yE1jeaT1rRsPdBjEaNcl8ZK.connect(__ViYX4w2ASUw2ZKGRTJpg4UYd.bind(client))
	client.__0jDXnfPFnrhIqsXWFjF7NWAa.connect(__DigKz7rQbLtpKHckK81vVfH7.bind(client))
	__0B62d3Zf32pWK86ifUjWdVAO.emit(client)
	return client
func __SuBZLqI1lyz7kyXBzRhzHZJl(__uCX169lL_25iB0SNhr7vjdb3: String) -> void :
	if client != null and client.__sHeDEjN1uGO_IzL9xSFAvdmE != null and client.__sHeDEjN1uGO_IzL9xSFAvdmE.state != __mCxdlfGh1GIop1wIEIUuf2Sd.State.__GOIZmjSwbJDQRNOS2RaSY7iT:
		return
	var __y8bTlxXqI51pqZcoO5HFKLdD: __OVAOfLpG8ro21Yx3xp7VhB3r = __8T8SD4lKRTek5jmwVIakcgAU(__uCX169lL_25iB0SNhr7vjdb3)
	get_tree().create_timer(__kHOWkyYCrIn8WkmOwap9Zu4k).timeout.connect( func() -> void :
		if client == __y8bTlxXqI51pqZcoO5HFKLdD and __y8bTlxXqI51pqZcoO5HFKLdD.__bEaVqnUpkbc9pnzD2IA0HDfW == null:
			__6boYmTBi229EPYhIG1rS9EZs())
func __jNrYGOeR6xmcA1i8u3s86x7P(__Oc6BCte4nyUc5c58nUeO1w7k: int = 8000) -> bool:
	var __R7vCQVAjUIl00wVmZLbb9coN: int = Time.get_ticks_msec()
	while Time.get_ticks_msec() - __R7vCQVAjUIl00wVmZLbb9coN < __Oc6BCte4nyUc5c58nUeO1w7k:
		if __8NvWict5WXnmrC74DsKlj2Rl <= 0 or not OS.is_process_running(__8NvWict5WXnmrC74DsKlj2Rl):
			__8NvWict5WXnmrC74DsKlj2Rl = -1
			return false
		var __YFEXwbMkVSfyU3r54HgFdoKP: = StreamPeerTCP.new()
		if __YFEXwbMkVSfyU3r54HgFdoKP.connect_to_host("127.0.0.1", __fivu_OTkPp7NZgqi85gOk1Dn) == OK:
			var __8IIjaMWqEGkvRbQnxYBi2Z0E: int = Time.get_ticks_msec()
			while Time.get_ticks_msec() - __8IIjaMWqEGkvRbQnxYBi2Z0E < 300:
				__YFEXwbMkVSfyU3r54HgFdoKP.poll()
				var ___Jnq6If3flocVu0GqZvzq_RV: int = __YFEXwbMkVSfyU3r54HgFdoKP.get_status()
				if ___Jnq6If3flocVu0GqZvzq_RV == StreamPeerTCP.STATUS_CONNECTED:
					__YFEXwbMkVSfyU3r54HgFdoKP.disconnect_from_host()
					return true
				if ___Jnq6If3flocVu0GqZvzq_RV != StreamPeerTCP.STATUS_CONNECTING:
					break
				await get_tree().process_frame
		await get_tree().create_timer(0.05).timeout
	__O1mRKOPITP5ldy0TJRNfObZZ()
	return false
func __eXg3hMS7akhCfGmWn242Awpx() -> Dictionary:
	var __OlTgHKqjI4oUeY_QTD2QKJkz: __k8pdL_GB8yADpq0vqeDWpz5v = App.__M0ImV248NGNrBFXy9NCs5jwX().__dFm6DOUISO0GARjmCPdhCxZ0
	var __zS6Cf0_yy64PCxTMtq0C1wqQ: String = __OlTgHKqjI4oUeY_QTD2QKJkz.__8FkJfHSvxnbl2cbIJgntGxuA()
	if __eUrEV7KZeZb5SFnaL0Wry5AY != __OlTgHKqjI4oUeY_QTD2QKJkz or __dU8vO0vu02XUnMJgCaANOdgm != __zS6Cf0_yy64PCxTMtq0C1wqQ:
		__eUrEV7KZeZb5SFnaL0Wry5AY = __OlTgHKqjI4oUeY_QTD2QKJkz
		__dU8vO0vu02XUnMJgCaANOdgm = __zS6Cf0_yy64PCxTMtq0C1wqQ
		__tMJUXYpXr2OVziGIKtmRywwZ = __H5G0YcInAz3w9I5gBsEa5PDa.scan(__izQSEvpCqMhIwBTLX0qZok3C.__K6wnay3yxWR4lbv3X6wjBiAQ(__OlTgHKqjI4oUeY_QTD2QKJkz.__W6QsuD1d3329_0oIzLomMBJU(), __KrQVlchyjAqFXcac3Kiw77hk.__EQSSy6KHEM37BgV1J4KGqz8Y().__OEOWxLRPlFVV6yS929wFDPht))
		if __OlTgHKqjI4oUeY_QTD2QKJkz.__MN6iqdbpK7uPL7BcyVzilMVE:
			__tMJUXYpXr2OVziGIKtmRywwZ = {"error": "REPAIR_RECOVERY"}
		if not __tMJUXYpXr2OVziGIKtmRywwZ.is_empty():
			print("[clock-history] 单机历史时长存疑，限制多人出击：", JSON.stringify(__tMJUXYpXr2OVziGIKtmRywwZ))
	return __tMJUXYpXr2OVziGIKtmRywwZ.duplicate(true)
var __E3paFTADNyc5HASlcvMeifJo: String = ""
var __dU8vO0vu02XUnMJgCaANOdgm: String = ""
static func __3vm8NY9OCjLSVWrZ38ZNESeA(__lxTpYAvPvuUkev_nLtU7vWx9: String) -> Array:
	var __JNINPghe0ddmy8HCg6olphQD: String = __lxTpYAvPvuUkev_nLtU7vWx9.strip_edges()
	var __jXt2xbulB4Ny3s7Pi1otG7IC: int = __JNINPghe0ddmy8HCg6olphQD.rfind(":")
	if __jXt2xbulB4Ny3s7Pi1otG7IC > 0:
		return [__JNINPghe0ddmy8HCg6olphQD.substr(0, __jXt2xbulB4Ny3s7Pi1otG7IC), int(__JNINPghe0ddmy8HCg6olphQD.substr(__jXt2xbulB4Ny3s7Pi1otG7IC + 1))]
	return [__JNINPghe0ddmy8HCg6olphQD if __JNINPghe0ddmy8HCg6olphQD != "" else "127.0.0.1", __R9QNzROpIBeVhQdDMd60twhq.__MejvtxQk1DW6AN522yF6BG19]
func __DXc0ZNVmozUBOXzV022mptGx() -> bool:
	return __8NvWict5WXnmrC74DsKlj2Rl > 0
func __uB16QuJM6SQy0GQtmWroxfOs(__O4llbRpOxcdWa1C4JYTUeb1j: int, __1r7p0c_nzx7m3sJd8wN4e0Yh: __s8yZigV26lPAvEmbOWzMbnjE, __WnUWgs5QZ2CCxJmrr9NCgx22: String = "", __UYLlNdKs8V3C8OM0BC56DJam: __OVAOfLpG8ro21Yx3xp7VhB3r = null) -> void :
	if __UYLlNdKs8V3C8OM0BC56DJam == null:
		__UYLlNdKs8V3C8OM0BC56DJam = client
	if __UYLlNdKs8V3C8OM0BC56DJam == null or __UYLlNdKs8V3C8OM0BC56DJam.__8FkJfHSvxnbl2cbIJgntGxuA == "" or __UYLlNdKs8V3C8OM0BC56DJam.__xWJJImORZi02koDWaVRreo_F or not __UYLlNdKs8V3C8OM0BC56DJam.__EQuCPPWLxyLUNOZAfxsuqiRH():
		return
	__UYLlNdKs8V3C8OM0BC56DJam.__dtbExf1Y765p0k8XAbww3ih9.connect( func(code: int) -> void :
		print("[report] 问题报告回执 %d" % code)
		if code == 0:
			UI.__Qyp4Js7J9ejl5FSF4pVpfEi5(tr("UI_SB_REPORT_SENT"), 4.0), CONNECT_ONE_SHOT)
	__UYLlNdKs8V3C8OM0BC56DJam.__thcoTymIjrSwJtIjo1oO1Xip(__M4EUBJpfO6DjRiqZXBQAABmM.__YNjSGlrkuU4xu5LIhzsrDpM7(__O4llbRpOxcdWa1C4JYTUeb1j, __1r7p0c_nzx7m3sJd8wN4e0Yh, __UYLlNdKs8V3C8OM0BC56DJam.__P4e34ZpL4re0nm_B3HT_VrxU, __SVYydJFZQaaI80Q8q8_QVkpb, __WnUWgs5QZ2CCxJmrr9NCgx22))
func __ViYX4w2ASUw2ZKGRTJpg4UYd(__eG8kKUFTG0jOeggNyVDvsAyx: __COUNAgr8wnXy9whG6QVnt_di, __pocRfvir08YjdyRhkQFA0hHP: __OVAOfLpG8ro21Yx3xp7VhB3r) -> void :
	if __pocRfvir08YjdyRhkQFA0hHP.__8FkJfHSvxnbl2cbIJgntGxuA == "":
		__pocRfvir08YjdyRhkQFA0hHP.__ncTq6ojhsWEF20WJ4N7X2hhu = false
		__pocRfvir08YjdyRhkQFA0hHP.__epga6CKpeAksfEcGTy1b9aD8.emit()
		return
	__vRWRc9t3f6oN0JpbN_TPt2xm = Time.get_ticks_msec() + 15000
	__pocRfvir08YjdyRhkQFA0hHP.__U8Z30RAkbS6JQ7Q8kwHMNI_D()
	var __5RQxV8ebXq4mHkWBB1pBO8TG: = __KrQVlchyjAqFXcac3Kiw77hk.__EQSSy6KHEM37BgV1J4KGqz8Y()
	var __lYpXBLJocctW2ud2f5zF_CjA: __k8pdL_GB8yADpq0vqeDWpz5v = App.__M0ImV248NGNrBFXy9NCs5jwX().__dFm6DOUISO0GARjmCPdhCxZ0
	var __B7nEVjtKaMB1__k0w1QWy_YB: int = int(Time.get_unix_time_from_system())
	if not __5RQxV8ebXq4mHkWBB1pBO8TG.__UNfIOIqOLvUmBfpVjLLBpgpz(__lYpXBLJocctW2ud2f5zF_CjA.get_value(__KrQVlchyjAqFXcac3Kiw77hk.__6V84o45JRAxAuaIfVTj1nrRM, {}), __B7nEVjtKaMB1__k0w1QWy_YB):
		return
	var __N6fgth2r2aeVKFqVcVfrDowW: int = __5RQxV8ebXq4mHkWBB1pBO8TG.__hi6_FOLysJZrVqVnm_v_19kI()
	__pocRfvir08YjdyRhkQFA0hHP.__7o8enMHtIXhmf_rsTpe2r20d.connect( func(code: int) -> void :
		if code == 0:
			__lYpXBLJocctW2ud2f5zF_CjA.set_value(__KrQVlchyjAqFXcac3Kiw77hk.__6V84o45JRAxAuaIfVTj1nrRM, {"seq": __N6fgth2r2aeVKFqVcVfrDowW, "at": __B7nEVjtKaMB1__k0w1QWy_YB}), CONNECT_ONE_SHOT)
	__pocRfvir08YjdyRhkQFA0hHP.__f7wd6AvvY2Iri1lgi8oqQOm7(__5RQxV8ebXq4mHkWBB1pBO8TG.__jHq7oMuFc6ugPQP2THxrraV9(__eG8kKUFTG0jOeggNyVDvsAyx.name, __pocRfvir08YjdyRhkQFA0hHP.__P4e34ZpL4re0nm_B3HT_VrxU, __svCpIOini0lrUqcqp5XK8DO3.current(), __B7nEVjtKaMB1__k0w1QWy_YB))
const __kHOWkyYCrIn8WkmOwap9Zu4k: = 6.0
var __fivu_OTkPp7NZgqi85gOk1Dn: int = 0
func __JilTMnDE3AFHARdgOWwK84vg(__njiw_517qBY9frBmrKgVrFA7: int, __6_oN18crSzR4Q8_dvtb_Fx63: PackedStringArray = PackedStringArray()) -> Error:
	return ERR_UNAVAILABLE
var client: __OVAOfLpG8ro21Yx3xp7VhB3r
func __vpLUQnFNf6ZOOEyoVq1KPowy(__cHLGlnaG6V9JMutmcCxf5tQG: String) -> void :
	__vRWRc9t3f6oN0JpbN_TPt2xm = 0
	if client != null:
		client.__QK1H52kEMlLjUEygSABosRHc = __cHLGlnaG6V9JMutmcCxf5tQG
		client.__zwLrJgruki6eq_p_kNVIGQGV.emit()
	print("[repair] 修复未完成：", __cHLGlnaG6V9JMutmcCxf5tQG)
	UI.__Qyp4Js7J9ejl5FSF4pVpfEi5(tr("UI_REPAIR_FAILED"), 6.0)
func __1tiM1GqqZCDCWM_qOQaC1YoM(__mM9dFsaPY2vjcXttn74WbzWS: Dictionary, __dhTDiQWt9RG6exRM_G63E4wS: __OVAOfLpG8ro21Yx3xp7VhB3r) -> void :
	if __dhTDiQWt9RG6exRM_G63E4wS != client or not __dhTDiQWt9RG6exRM_G63E4wS.__ncTq6ojhsWEF20WJ4N7X2hhu or __E3paFTADNyc5HASlcvMeifJo != "":
		return
	var __p_55lpA_Qf_gNw7EGtWkWet7: Variant = __mM9dFsaPY2vjcXttn74WbzWS.get("tasks")
	if int(__mM9dFsaPY2vjcXttn74WbzWS.get("version", 0)) != 1 or __mM9dFsaPY2vjcXttn74WbzWS.has("error") or not (__p_55lpA_Qf_gNw7EGtWkWet7 is Array) or __p_55lpA_Qf_gNw7EGtWkWet7.size() > 16:
		__vpLUQnFNf6ZOOEyoVq1KPowy("BAD_LIST")
		return
	if __p_55lpA_Qf_gNw7EGtWkWet7.is_empty():
		__vRWRc9t3f6oN0JpbN_TPt2xm = 0
		__dhTDiQWt9RG6exRM_G63E4wS.__ncTq6ojhsWEF20WJ4N7X2hhu = false
		__dhTDiQWt9RG6exRM_G63E4wS.__epga6CKpeAksfEcGTy1b9aD8.emit()
		return
	if not (__p_55lpA_Qf_gNw7EGtWkWet7[0] is Dictionary):
		__vpLUQnFNf6ZOOEyoVq1KPowy("BAD_TASK")
		return
	var __ud8mhH0A8zRuW7uu8rZA6WSm: Dictionary = __p_55lpA_Qf_gNw7EGtWkWet7[0]
	var __tV4cU36xuKJFbcFuuItviULH: __MxRtF5kMQ2PhDOJRxJ1ej8ie = App.__M0ImV248NGNrBFXy9NCs5jwX()
	var __9UixiofuQ2t3Ae4FoxChZ6wb: Array[__s8yZigV26lPAvEmbOWzMbnjE] = []
	for h: __s8yZigV26lPAvEmbOWzMbnjE in __U7UMfwBewiXSLEeaDnywaCO7.__7GUZ3bU5qeMGglBHenrrrt1p():
		__9UixiofuQ2t3Ae4FoxChZ6wb.append(__U7UMfwBewiXSLEeaDnywaCO7.normalized(h))
	var __vQOzBq9gqx5ubEeYDCbCnBRL: String = __DJubHAbResvPb2i6NZEYPW6D.__htKE4fJ0zQs5MPTznG9YFc13(__ud8mhH0A8zRuW7uu8rZA6WSm, __tV4cU36xuKJFbcFuuItviULH, __9UixiofuQ2t3Ae4FoxChZ6wb)
	if __vQOzBq9gqx5ubEeYDCbCnBRL != "":
		__uB16QuJM6SQy0GQtmWroxfOs(-1, __U7UMfwBewiXSLEeaDnywaCO7.normalized(__U7UMfwBewiXSLEeaDnywaCO7.__V0erSRNWoPFGOr7bG6vGIpsK()), "REPAIR_" + __vQOzBq9gqx5ubEeYDCbCnBRL, __dhTDiQWt9RG6exRM_G63E4wS)
		__vpLUQnFNf6ZOOEyoVq1KPowy(__vQOzBq9gqx5ubEeYDCbCnBRL)
		return
	__E3paFTADNyc5HASlcvMeifJo = str(__ud8mhH0A8zRuW7uu8rZA6WSm["id"])
	__vRWRc9t3f6oN0JpbN_TPt2xm = Time.get_ticks_msec() + 15000
	var __4D69vYtzxzHjn74t5FEXANcX: __s8yZigV26lPAvEmbOWzMbnjE = __U7UMfwBewiXSLEeaDnywaCO7.normalized(__U7UMfwBewiXSLEeaDnywaCO7.__V0erSRNWoPFGOr7bG6vGIpsK())
	__dhTDiQWt9RG6exRM_G63E4wS.__Z2l8LDcTR2NaBOmggfhGionH(__E3paFTADNyc5HASlcvMeifJo, str(__ud8mhH0A8zRuW7uu8rZA6WSm["digest"]), __eGnY2BDCUsXxPxxTyKSWsq6B.__YNjSGlrkuU4xu5LIhzsrDpM7(__tV4cU36xuKJFbcFuuItviULH, __9UixiofuQ2t3Ae4FoxChZ6wb, __4D69vYtzxzHjn74t5FEXANcX, true))
static func __ot1K4jsVlZzx9n2OBPzr3Vt2() -> String:
	var __oHTIqczopxHjWQ4zSIlyLL6b: String = ProjectSettings.globalize_path("res://").path_join("../server/src/main.js").simplify_path()
	return __oHTIqczopxHjWQ4zSIlyLL6b if FileAccess.file_exists(__oHTIqczopxHjWQ4zSIlyLL6b) else ""
var __tMJUXYpXr2OVziGIKtmRywwZ: Dictionary = {}
func __O1mRKOPITP5ldy0TJRNfObZZ() -> void :
	if __8NvWict5WXnmrC74DsKlj2Rl > 0:
		OS.kill(__8NvWict5WXnmrC74DsKlj2Rl)
		__8NvWict5WXnmrC74DsKlj2Rl = -1
func __8T8SD4lKRTek5jmwVIakcgAU(__dW7e9K6TBbY6KA55J3m9aTXR: String) -> __OVAOfLpG8ro21Yx3xp7VhB3r:
	var __c7SyeETKNdmu4NPz0vq1lDu4: Array = __3vm8NY9OCjLSVWrZ38ZNESeA(__SVYydJFZQaaI80Q8q8_QVkpb if __SVYydJFZQaaI80Q8q8_QVkpb != "" else __ZAzoyXS_Hxv_vfUfIRQ125kE())
	return __2AokRD4QOC79KSjRpI0qITEn(str(__c7SyeETKNdmu4NPz0vq1lDu4[0]), int(__c7SyeETKNdmu4NPz0vq1lDu4[1]), __dW7e9K6TBbY6KA55J3m9aTXR)
func _process(__q4gJTKKw5FFjfCw6aIEeXacM: float) -> void :
	if client != null:
		client.poll()
	if __vRWRc9t3f6oN0JpbN_TPt2xm > 0 and Time.get_ticks_msec() >= __vRWRc9t3f6oN0JpbN_TPt2xm:
		__vpLUQnFNf6ZOOEyoVq1KPowy("TIMEOUT")
func __DigKz7rQbLtpKHckK81vVfH7(__2Gu5tbPz3JlJ44yM5tVHSUcR: bool, __FeJb05uBY2Ex6fEMVx1QS8CP: int, __JGjf9WwSvWdfrua5IZPPSFl6: __OVAOfLpG8ro21Yx3xp7VhB3r) -> void :
	if not __2Gu5tbPz3JlJ44yM5tVHSUcR:
		__uB16QuJM6SQy0GQtmWroxfOs(__FeJb05uBY2Ex6fEMVx1QS8CP, __R7ELz7zJC7hosKgl7dZAW2Qf, "", __JGjf9WwSvWdfrua5IZPPSFl6)
var __8NvWict5WXnmrC74DsKlj2Rl: int = -1
