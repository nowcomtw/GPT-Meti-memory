class_name __LlOvNfSW39vQFa_X5z9isu0g
static func __3RsPVXWuItfNan5hKErXmnG7(__rQesPauwAjdp4FiJqvVrffjh: PackedInt32Array, __5mSgE25iYi4QsXkeCqwXq0j0: int, __17KLQCQQ2_Tm4lQ3zeQmDXZQ: int, __LruMsicLIZW30fY5YtU0bou5: int, __iZ4oPqz00M7FfOhxmqVtKWPD: int) -> int:
	var b: int = maxi(__rQesPauwAjdp4FiJqvVrffjh[1], 0)
	var __FUUhuQXA2OTVTP6WHPUApBsc: int = maxi(__rQesPauwAjdp4FiJqvVrffjh[2], 0)
	var s: int = maxi(__rQesPauwAjdp4FiJqvVrffjh[0], 0) + b + __FUUhuQXA2OTVTP6WHPUApBsc
	if s == 0:
		return 0
	var __BMv4b8qmP9d44dcxDwPxpL4O: int
	var __gJjIr29mwk27pIX6b7GCvnfB: int = __gGkWBAOuyNFHxtSLqd7hBdqa(__5mSgE25iYi4QsXkeCqwXq0j0, __17KLQCQQ2_Tm4lQ3zeQmDXZQ)
	if __gJjIr29mwk27pIX6b7GCvnfB == 0 or (__gJjIr29mwk27pIX6b7GCvnfB == 1 and __LruMsicLIZW30fY5YtU0bou5 == 3):
		__BMv4b8qmP9d44dcxDwPxpL4O = __WoL6HY_Ch9Ym4nBhK08TNSWp * b + __43rKih3g6GqyyszRr0BT4M1g * __FUUhuQXA2OTVTP6WHPUApBsc
	elif __gJjIr29mwk27pIX6b7GCvnfB == 1:
		__BMv4b8qmP9d44dcxDwPxpL4O = __6yVZ1LYsSPmfmgUmc_7IcYYX * b
	else:
		__BMv4b8qmP9d44dcxDwPxpL4O = __SKcR9WxP8fbIrGzxSC58Kz50 * b
	return __BMv4b8qmP9d44dcxDwPxpL4O * s / maxi(__iZ4oPqz00M7FfOhxmqVtKWPD, 1)
const __zDry7rZ7DQW97Vg8tONXE42z: = 4800
static func __Dpx9jDDytn7_a6OqJEJM8_hN(__ZIH6hoSqWqJcR176BTP9ZKmX: __CgOl36_UCxYZW5PzufCcS4dS, __dBIZo8LSw3XEJVVihy2RyM0U: Dictionary) -> PackedInt32Array:
	var __sTp5XX9qpPDa1MIaFbSab5_9: int = clampi(__ZIH6hoSqWqJcR176BTP9ZKmX.__zMZVCIoyJu5zkEI6YyKqPDoG, 0, 120)
	var w: = PackedInt32Array([__sTp5XX9qpPDa1MIaFbSab5_9, 0, 0, 0])
	var flags: int = int(__dBIZo8LSw3XEJVVihy2RyM0U.get("flags", 0))
	var a: PackedInt32Array = __ZIH6hoSqWqJcR176BTP9ZKmX.__4ObdBYhtKkHScUayTPgiYzH_
	var __ZOEWXXJZAcRj1p7mHCOOde3L: int = a[__o4BlGoLwjfAD3TYKD8Kt7FzU.__zQFbz4wT5ybXvNTatdPLjuFc.__AuLYcgB557BmcSJZGEBo_8wk]
	if flags & __o4BlGoLwjfAD3TYKD8Kt7FzU.___btcT65aM0RqqRVjfIvf0ftl or __ZIH6hoSqWqJcR176BTP9ZKmX.__q26f3dCYzrR9TyO_pwwz7lre == 0:
		w[1] = 0
		w[2] = __YPQoeMce4Ux_l1KIJiNnBaIy(__ZOEWXXJZAcRj1p7mHCOOde3L)
		w[3] = __YPQoeMce4Ux_l1KIJiNnBaIy(__ZOEWXXJZAcRj1p7mHCOOde3L)
		return w
	if flags & __o4BlGoLwjfAD3TYKD8Kt7FzU.__40fTdyPM4G2D_HmgHAUEDY54:
		w[1] = __YPQoeMce4Ux_l1KIJiNnBaIy(a[__o4BlGoLwjfAD3TYKD8Kt7FzU.__zQFbz4wT5ybXvNTatdPLjuFc.__LPMHrVR9FGgz5Ud7XrAqTMeH])
		w[2] = __YPQoeMce4Ux_l1KIJiNnBaIy(a[__o4BlGoLwjfAD3TYKD8Kt7FzU.__zQFbz4wT5ybXvNTatdPLjuFc.__nW6_3hZwHbYFkKg8ycv696NZ])
		w[3] = __YPQoeMce4Ux_l1KIJiNnBaIy(a[__o4BlGoLwjfAD3TYKD8Kt7FzU.__zQFbz4wT5ybXvNTatdPLjuFc.__jYoHRHR758jqjDxdSi5iCuDY])
		return w
	if flags & __o4BlGoLwjfAD3TYKD8Kt7FzU.__9IQIhwFb14PlEkxMAh0PDYhb == 0:
		return w
	if flags & __o4BlGoLwjfAD3TYKD8Kt7FzU.__zOMNyXAvAPwgEaZwvZS1PeG3:
		if flags & __o4BlGoLwjfAD3TYKD8Kt7FzU.__8lND2qMGsenBIhbZrfEY9ESr:
			w[1] = __YPQoeMce4Ux_l1KIJiNnBaIy(a[__o4BlGoLwjfAD3TYKD8Kt7FzU.__zQFbz4wT5ybXvNTatdPLjuFc.__nflD6fHTDo44p532kCisOVa8])
		if flags & __o4BlGoLwjfAD3TYKD8Kt7FzU.__ubxAO2Z13CVPDiMiBS5HJfHS:
			w[2] = __YPQoeMce4Ux_l1KIJiNnBaIy(a[__o4BlGoLwjfAD3TYKD8Kt7FzU.__zQFbz4wT5ybXvNTatdPLjuFc.__nflD6fHTDo44p532kCisOVa8])
	elif flags & __o4BlGoLwjfAD3TYKD8Kt7FzU.__MbxeaGdaUnfgwiPI9Bv8Iihr:
		w[1] = __YPQoeMce4Ux_l1KIJiNnBaIy(__ZOEWXXJZAcRj1p7mHCOOde3L)
		if flags & __o4BlGoLwjfAD3TYKD8Kt7FzU.__3J8YywWvU5WzI6tm3jXeNLE5:
			w[2] = __YPQoeMce4Ux_l1KIJiNnBaIy(__ZOEWXXJZAcRj1p7mHCOOde3L)
		if flags & __o4BlGoLwjfAD3TYKD8Kt7FzU.__UdAxdN9WPd5dvQ27aM9zGIGV:
			w[3] = __YPQoeMce4Ux_l1KIJiNnBaIy(__ZOEWXXJZAcRj1p7mHCOOde3L)
	elif flags & __o4BlGoLwjfAD3TYKD8Kt7FzU.__9WwFMUR2Am_HK0Jg3AuceL6G:
		w[1] = __YPQoeMce4Ux_l1KIJiNnBaIy(__ZOEWXXJZAcRj1p7mHCOOde3L)
	elif flags & __o4BlGoLwjfAD3TYKD8Kt7FzU.__eSXk7ZzFp2s2NuhvXK7XP9hX:
		w[1] = __YPQoeMce4Ux_l1KIJiNnBaIy(__ZOEWXXJZAcRj1p7mHCOOde3L)
	if flags & __o4BlGoLwjfAD3TYKD8Kt7FzU.__Ho8Gg0bR0oC7o_Z457dOFj9F:
		w[3] = __YPQoeMce4Ux_l1KIJiNnBaIy(__ZOEWXXJZAcRj1p7mHCOOde3L)
	elif flags & __o4BlGoLwjfAD3TYKD8Kt7FzU.__doWxkstT0Zeom2mJ81_tdy0s:
		w[1] = __YPQoeMce4Ux_l1KIJiNnBaIy(__ZOEWXXJZAcRj1p7mHCOOde3L)
	elif flags & __o4BlGoLwjfAD3TYKD8Kt7FzU.__qK3r1tHFgcp6FlfZzG1_VPQy:
		w[1] = __YPQoeMce4Ux_l1KIJiNnBaIy(a[__o4BlGoLwjfAD3TYKD8Kt7FzU.__zQFbz4wT5ybXvNTatdPLjuFc.__u7um5J_9_wiV2qGmW2ufEZc8])
		w[2] = __YPQoeMce4Ux_l1KIJiNnBaIy(a[__o4BlGoLwjfAD3TYKD8Kt7FzU.__zQFbz4wT5ybXvNTatdPLjuFc.__OS_ME7fDxzIQ4pJ4cyI9bVZw])
		w[3] = __YPQoeMce4Ux_l1KIJiNnBaIy(a[__o4BlGoLwjfAD3TYKD8Kt7FzU.__zQFbz4wT5ybXvNTatdPLjuFc.__ylRwgIUMLb9XLwKJSVqPq3ap])
	elif flags & __o4BlGoLwjfAD3TYKD8Kt7FzU.__3J8YywWvU5WzI6tm3jXeNLE5:
		w[2] = __YPQoeMce4Ux_l1KIJiNnBaIy(__ZOEWXXJZAcRj1p7mHCOOde3L)
	return w
const __uLoPuRwbpEdqhRSwYJZkw_Rh: = 55
const __E6hcZaGJxWbQKYv5VEHUm7gT: = 3
const __5YFjWh77O8S8YLPnZLCtFkPu: = 200
static func __zWv_ztXn2aihNeNL01cSh9EQ(__OzEycnAhmvZZ_oDcwKHmfV5m: Array[__CgOl36_UCxYZW5PzufCcS4dS]) -> PackedInt32Array:
	var __fJpkKDnlxvlkDreDtTxyt7ci: = PackedInt32Array()
	__fJpkKDnlxvlkDreDtTxyt7ci.resize(__s8yZigV26lPAvEmbOWzMbnjE.__9ERqgkhcu5lsXP6AozrSOU0q)
	for __RLlRiidMVocRCuTTXQfhYJPb: __CgOl36_UCxYZW5PzufCcS4dS in __OzEycnAhmvZZ_oDcwKHmfV5m:
		if __RLlRiidMVocRCuTTXQfhYJPb.__q26f3dCYzrR9TyO_pwwz7lre >= 0 and __RLlRiidMVocRCuTTXQfhYJPb.__q26f3dCYzrR9TyO_pwwz7lre < __s8yZigV26lPAvEmbOWzMbnjE.__9ERqgkhcu5lsXP6AozrSOU0q:
			__fJpkKDnlxvlkDreDtTxyt7ci[__RLlRiidMVocRCuTTXQfhYJPb.__q26f3dCYzrR9TyO_pwwz7lre] = clampi(__RLlRiidMVocRCuTTXQfhYJPb.__pY661vwzoRY0D6Y5ORWYVaB_[0], 0, 255)
	return __fJpkKDnlxvlkDreDtTxyt7ci
static func __gGkWBAOuyNFHxtSLqd7hBdqa(__2Medm0g_n6khcI3Iny4LmYU2: int, __BaI3hjJDCPGRfw4qW6Ih2ubI: int) -> int:
	if __2Medm0g_n6khcI3Iny4LmYU2 == __BaI3hjJDCPGRfw4qW6Ih2ubI:
		return 0
	if __BaI3hjJDCPGRfw4qW6Ih2ubI < 0 or __BaI3hjJDCPGRfw4qW6Ih2ubI >= __R61B2guhdASf9DyZdvdPLPpH.size() or __2Medm0g_n6khcI3Iny4LmYU2 < 0 or __2Medm0g_n6khcI3Iny4LmYU2 > 8:
		return 2
	return 1 if (int(__R61B2guhdASf9DyZdvdPLPpH[__BaI3hjJDCPGRfw4qW6Ih2ubI]) >> __2Medm0g_n6khcI3Iny4LmYU2) & 1 == 1 else 2
static func fold(w: PackedInt32Array, __kjO3ECU69V6jpEjCWnhyMl3e: int, __e2AcCmzC6RkQnZ6l3fqs3jcO: int) -> PackedInt32Array:
	var __GLpCRl1OzYJqtmcoENGPPOYz: PackedInt32Array = w.duplicate()
	var __ZsQBv4ZhDeKJEnpZjUi4PKmu: Array = __P477wrYt4tUNGQkGkb6fiVE_.get(__e2AcCmzC6RkQnZ6l3fqs3jcO, [0, 0, 0])
	for __EeYYPNY2VME0TZ9KALK_Q7eq: int in 3:
		var d: int = int(__ZsQBv4ZhDeKJEnpZjUi4PKmu[__EeYYPNY2VME0TZ9KALK_Q7eq])
		if d > 0:
			__GLpCRl1OzYJqtmcoENGPPOYz[1 + __EeYYPNY2VME0TZ9KALK_Q7eq] = clampi(w[1 + __EeYYPNY2VME0TZ9KALK_Q7eq] * __kjO3ECU69V6jpEjCWnhyMl3e / d, 0, __5mUmXzFHF3sOKQKf_XcZ1XFe)
		elif d < 0:
			__GLpCRl1OzYJqtmcoENGPPOYz[1 + __EeYYPNY2VME0TZ9KALK_Q7eq] = 0
	return __GLpCRl1OzYJqtmcoENGPPOYz
const __R61B2guhdASf9DyZdvdPLPpH: = [511, 357, 355, 177, 169, 511, 295, 56, 103]
const __AHhH0XXjOXCuMZ8qfF_3BbdX: = 100
static func __76YQlbOoFzFgpPn_qa5fce31(__wNgsbfzWT2OxVzW5p5xbUJ9X: int) -> int:
	return mini(__CcuJfEJlHGrXUgnJDReo2jb7(__wNgsbfzWT2OxVzW5p5xbUJ9X) * __AHhH0XXjOXCuMZ8qfF_3BbdX / 100, __zXkENZuYZ0SNlqZ8ZQ8MNFx3)
static func __YjdecicvdCo7i83L_WSJxXd6(__ELGzr1gl_aX8hvCJxUkgUHq7: Array[__CgOl36_UCxYZW5PzufCcS4dS], __rgNvQy8Y4mdcIaFFDrntABhK: __o4BlGoLwjfAD3TYKD8Kt7FzU, __NFIxx1j13nuAC4ySksgsutvm: int) -> PackedInt32Array:
	var __bRYohmraUwXKxS9N9h6ByUvI: = PackedInt32Array()
	__bRYohmraUwXKxS9N9h6ByUvI.resize(__s8yZigV26lPAvEmbOWzMbnjE.__fEshhZq5p9xbb5P6yBiyZTcz * __s8yZigV26lPAvEmbOWzMbnjE.__3a0fFvXLGqYOQozFEWKSeQw8)
	for __vuP4Hql8rVIZ3qOIR4BXLSfL: __CgOl36_UCxYZW5PzufCcS4dS in __ELGzr1gl_aX8hvCJxUkgUHq7:
		if __vuP4Hql8rVIZ3qOIR4BXLSfL.__q26f3dCYzrR9TyO_pwwz7lre < 0 or __vuP4Hql8rVIZ3qOIR4BXLSfL.__q26f3dCYzrR9TyO_pwwz7lre >= __s8yZigV26lPAvEmbOWzMbnjE.__fEshhZq5p9xbb5P6yBiyZTcz:
			continue
		var b: PackedInt32Array = __XTFDOa7w4OA56v8hsN5UoMeW(__vuP4Hql8rVIZ3qOIR4BXLSfL, __rgNvQy8Y4mdcIaFFDrntABhK.__eKMOY9vZxsK1HnP0cqwVRqgs(__vuP4Hql8rVIZ3qOIR4BXLSfL.__mpLpovabZnp87HNkreW4pWJY), __NFIxx1j13nuAC4ySksgsutvm)
		for __CNbKf2BP7xQeXonO4jH_IJJI: int in __s8yZigV26lPAvEmbOWzMbnjE.__3a0fFvXLGqYOQozFEWKSeQw8:
			__bRYohmraUwXKxS9N9h6ByUvI[__vuP4Hql8rVIZ3qOIR4BXLSfL.__q26f3dCYzrR9TyO_pwwz7lre * __s8yZigV26lPAvEmbOWzMbnjE.__3a0fFvXLGqYOQozFEWKSeQw8 + __CNbKf2BP7xQeXonO4jH_IJJI] = b[__CNbKf2BP7xQeXonO4jH_IJJI]
	return __bRYohmraUwXKxS9N9h6ByUvI
const __6yVZ1LYsSPmfmgUmc_7IcYYX: = 10
const __P8gXSN1evWwyWgR1Y3gmqhXw: = 65535
static func __H0DwMsc8mv6Cogy3GckKi2Fc(__4mnYK2MczgO55hFLBgnVFiJD: Array[__CgOl36_UCxYZW5PzufCcS4dS], __pYaxPfeRJgidpTwpg__1Yyms: __o4BlGoLwjfAD3TYKD8Kt7FzU, __Va63wVyG0BHdNX1txwleidya: int, __0Nj187uIQX5OQxliwNz8YhZr: int) -> PackedInt32Array:
	var __Erv8EtHPHEEYeDd_01dhd7Cx: = PackedInt32Array([0, 0, 0])
	if __0Nj187uIQX5OQxliwNz8YhZr == 64:
		return __Erv8EtHPHEEYeDd_01dhd7Cx
	for __WVwQtBG9CHEyr7TpCFUjayOa: __CgOl36_UCxYZW5PzufCcS4dS in __4mnYK2MczgO55hFLBgnVFiJD:
		if __WVwQtBG9CHEyr7TpCFUjayOa.__q26f3dCYzrR9TyO_pwwz7lre < 0 or __WVwQtBG9CHEyr7TpCFUjayOa.__q26f3dCYzrR9TyO_pwwz7lre >= __s8yZigV26lPAvEmbOWzMbnjE.__9ERqgkhcu5lsXP6AozrSOU0q:
			continue
		if __WVwQtBG9CHEyr7TpCFUjayOa.__q26f3dCYzrR9TyO_pwwz7lre < 5 and not (__WVwQtBG9CHEyr7TpCFUjayOa.__q26f3dCYzrR9TyO_pwwz7lre == 0 and __0Nj187uIQX5OQxliwNz8YhZr == 96):
			continue
		var __tsxla4b7tg0sPA9CjQ_4QCEa: Dictionary = __pYaxPfeRJgidpTwpg__1Yyms.__eKMOY9vZxsK1HnP0cqwVRqgs(__WVwQtBG9CHEyr7TpCFUjayOa.__mpLpovabZnp87HNkreW4pWJY)
		if int(__tsxla4b7tg0sPA9CjQ_4QCEa.get("flags", 0)) & __o4BlGoLwjfAD3TYKD8Kt7FzU.__zOMNyXAvAPwgEaZwvZS1PeG3 == 0:
			continue
		var __n9IGZxcGQxymB0e1T2XqeyZO: int = __3RsPVXWuItfNan5hKErXmnG7(__WVwQtBG9CHEyr7TpCFUjayOa.__pY661vwzoRY0D6Y5ORWYVaB_, int(__tsxla4b7tg0sPA9CjQ_4QCEa.get("nation", 0)), __Va63wVyG0BHdNX1txwleidya, 2, __CcuJfEJlHGrXUgnJDReo2jb7(__WVwQtBG9CHEyr7TpCFUjayOa.__zMZVCIoyJu5zkEI6YyKqPDoG))
		var __AmWGJcthuJonMafCVeCo7kEg: int = mini(__YPQoeMce4Ux_l1KIJiNnBaIy(__WVwQtBG9CHEyr7TpCFUjayOa.__4ObdBYhtKkHScUayTPgiYzH_[__o4BlGoLwjfAD3TYKD8Kt7FzU.__zQFbz4wT5ybXvNTatdPLjuFc.__nflD6fHTDo44p532kCisOVa8]) * __E6hcZaGJxWbQKYv5VEHUm7gT, __5mUmXzFHF3sOKQKf_XcZ1XFe)
		__Erv8EtHPHEEYeDd_01dhd7Cx[0] += 1
		__Erv8EtHPHEEYeDd_01dhd7Cx[1] += (__AmWGJcthuJonMafCVeCo7kEg * __n9IGZxcGQxymB0e1T2XqeyZO / 80000) & 65535
		__Erv8EtHPHEEYeDd_01dhd7Cx[2] += (__AmWGJcthuJonMafCVeCo7kEg * __n9IGZxcGQxymB0e1T2XqeyZO / 20000) & 65535
	return __Erv8EtHPHEEYeDd_01dhd7Cx
const __43rKih3g6GqyyszRr0BT4M1g: = 40
static func __CcuJfEJlHGrXUgnJDReo2jb7(__1dhV9U7fcjPQWrEjYhoVo1WB: int) -> int:
	var __dLp4VtMbze35kKJVmPHWAda3: int = clampi(__1dhV9U7fcjPQWrEjYhoVo1WB, 1, 120)
	return __uLoPuRwbpEdqhRSwYJZkw_Rh + (__dLp4VtMbze35kKJVmPHWAda3 - 1) * (__5YFjWh77O8S8YLPnZLCtFkPu - __uLoPuRwbpEdqhRSwYJZkw_Rh) / 119
const __P477wrYt4tUNGQkGkb6fiVE_: = {
	0: [0, 20000, 20000], 
	1: [30000, 100000, 24000], 
	2: [80000, 20000, -1], 
	3: [36000, 36000, 12000], 
	4: [30000, 30000, 30000], 
	5: [24000, 24000, 24000], 6: [24000, 24000, 24000], 
	9: [24000, 24000, 24000], 10: [24000, 24000, 24000], 
	11: [32000, 32000, 32000], 12: [32000, 32000, 32000], 13: [32000, 32000, 32000], 
	14: [32000, 32000, 32000], 15: [32000, 32000, 32000], 
}
const __5mUmXzFHF3sOKQKf_XcZ1XFe: = 65530
static func __YPQoeMce4Ux_l1KIJiNnBaIy(a: int) -> int:

	return mini(maxi(a, 0) * 6, __5mUmXzFHF3sOKQKf_XcZ1XFe)
const __lswJgRt_OA3nq3MkjOKZ2vqE: = 32
const __zXkENZuYZ0SNlqZ8ZQ8MNFx3: = 200
static func __XTFDOa7w4OA56v8hsN5UoMeW(__dkTzUqJZQorNogPo2ZdGY2Gq: __CgOl36_UCxYZW5PzufCcS4dS, __YjoOLKvajVbA21kDiDwdBP_V: Dictionary, __0bIQnqgeMQLcjz_zI1rBc8A2: int) -> PackedInt32Array:
	var w: PackedInt32Array = __Dpx9jDDytn7_a6OqJEJM8_hN(__dkTzUqJZQorNogPo2ZdGY2Gq, __YjoOLKvajVbA21kDiDwdBP_V)
	for __9A0oh6CaraMdOP5M5gznqvWV: int in 3:
		w[1 + __9A0oh6CaraMdOP5M5gznqvWV] = mini(w[1 + __9A0oh6CaraMdOP5M5gznqvWV] * __E6hcZaGJxWbQKYv5VEHUm7gT, __5mUmXzFHF3sOKQKf_XcZ1XFe)
	var __8YfjdDhCk4SPSKVcl006zJ03: int = __F8Ypmbm0kgYXYY6feT7gvakL(int(__YjoOLKvajVbA21kDiDwdBP_V.get("flags", 0)), __dkTzUqJZQorNogPo2ZdGY2Gq.__q26f3dCYzrR9TyO_pwwz7lre)
	var __QIYpOwKf41_got25mLwQtxp3: int = __3RsPVXWuItfNan5hKErXmnG7(__dkTzUqJZQorNogPo2ZdGY2Gq.__pY661vwzoRY0D6Y5ORWYVaB_, int(__YjoOLKvajVbA21kDiDwdBP_V.get("nation", 0)), __0bIQnqgeMQLcjz_zI1rBc8A2, __8YfjdDhCk4SPSKVcl006zJ03, __CcuJfEJlHGrXUgnJDReo2jb7(__dkTzUqJZQorNogPo2ZdGY2Gq.__zMZVCIoyJu5zkEI6YyKqPDoG))
	return fold(w, __QIYpOwKf41_got25mLwQtxp3, __8YfjdDhCk4SPSKVcl006zJ03)
const __WoL6HY_Ch9Ym4nBhK08TNSWp: = 10
static func __Q83ZAVFR9EzPCKEIptkCFVQ6(__D1V6Sc41HDhsUo2uwR1LCCRM: Array[__CgOl36_UCxYZW5PzufCcS4dS], __itz4vESO0KtHMo3xn39zdI0R: __o4BlGoLwjfAD3TYKD8Kt7FzU, __K4XWc9rt77giaUy_hSHxmXUF: int) -> PackedInt32Array:
	var __yx7Vgh7wjcuV29wPnFkGo4Kt: int = 0
	var __b4gJF547qBg7gZXLnRBukpg7: int = 0
	for __9RM1jPBBGG8u7t9BAVFZt7Ag: __CgOl36_UCxYZW5PzufCcS4dS in __D1V6Sc41HDhsUo2uwR1LCCRM:
		if __9RM1jPBBGG8u7t9BAVFZt7Ag.__q26f3dCYzrR9TyO_pwwz7lre < 0:
			continue
		var __2JTce9flFpyW9VcuYN_w9Ew1: Dictionary = __itz4vESO0KtHMo3xn39zdI0R.__eKMOY9vZxsK1HnP0cqwVRqgs(__9RM1jPBBGG8u7t9BAVFZt7Ag.__mpLpovabZnp87HNkreW4pWJY)
		var __P5Fq8Kq7aIEdB14k5O5oGnn6: int = __F8Ypmbm0kgYXYY6feT7gvakL(int(__2JTce9flFpyW9VcuYN_w9Ew1.get("flags", 0)), __9RM1jPBBGG8u7t9BAVFZt7Ag.__q26f3dCYzrR9TyO_pwwz7lre)
		var __O2jo1Hcx6KrsNI1y6z_WwvTt: int = __3RsPVXWuItfNan5hKErXmnG7(__9RM1jPBBGG8u7t9BAVFZt7Ag.__pY661vwzoRY0D6Y5ORWYVaB_, int(__2JTce9flFpyW9VcuYN_w9Ew1.get("nation", 0)), __K4XWc9rt77giaUy_hSHxmXUF, __P5Fq8Kq7aIEdB14k5O5oGnn6, __CcuJfEJlHGrXUgnJDReo2jb7(__9RM1jPBBGG8u7t9BAVFZt7Ag.__zMZVCIoyJu5zkEI6YyKqPDoG))
		var __Zk3A5_8gjryMLh4nbxe2Ifgd: int = mini(__YPQoeMce4Ux_l1KIJiNnBaIy(__9RM1jPBBGG8u7t9BAVFZt7Ag.__4ObdBYhtKkHScUayTPgiYzH_[__o4BlGoLwjfAD3TYKD8Kt7FzU.__zQFbz4wT5ybXvNTatdPLjuFc.__K212O178LY5gaB0Ety8iE2WE]) * __E6hcZaGJxWbQKYv5VEHUm7gT, __5mUmXzFHF3sOKQKf_XcZ1XFe)
		var __YaygEIDOlyKxGRxQJ5cx0KSp: int = mini(__YPQoeMce4Ux_l1KIJiNnBaIy(__9RM1jPBBGG8u7t9BAVFZt7Ag.__4ObdBYhtKkHScUayTPgiYzH_[__o4BlGoLwjfAD3TYKD8Kt7FzU.__zQFbz4wT5ybXvNTatdPLjuFc.__xbDx6h4ZiR0YEi2vqbPhCjDS]) * __E6hcZaGJxWbQKYv5VEHUm7gT, __5mUmXzFHF3sOKQKf_XcZ1XFe)
		__yx7Vgh7wjcuV29wPnFkGo4Kt = mini(__P8gXSN1evWwyWgR1Y3gmqhXw, __yx7Vgh7wjcuV29wPnFkGo4Kt + mini(__P8gXSN1evWwyWgR1Y3gmqhXw, __Zk3A5_8gjryMLh4nbxe2Ifgd * __O2jo1Hcx6KrsNI1y6z_WwvTt / __zDry7rZ7DQW97Vg8tONXE42z))
		__b4gJF547qBg7gZXLnRBukpg7 = mini(__P8gXSN1evWwyWgR1Y3gmqhXw, __b4gJF547qBg7gZXLnRBukpg7 + mini(__P8gXSN1evWwyWgR1Y3gmqhXw, __YaygEIDOlyKxGRxQJ5cx0KSp * __O2jo1Hcx6KrsNI1y6z_WwvTt / __zDry7rZ7DQW97Vg8tONXE42z))
	return PackedInt32Array([__yx7Vgh7wjcuV29wPnFkGo4Kt / __lswJgRt_OA3nq3MkjOKZ2vqE, __b4gJF547qBg7gZXLnRBukpg7 / __lswJgRt_OA3nq3MkjOKZ2vqE])
const __SKcR9WxP8fbIrGzxSC58Kz50: = 4
static func __F8Ypmbm0kgYXYY6feT7gvakL(flags: int, __j1zOuR7jzkPt2P0KXQzjCeqf: int) -> int:
	if flags & __o4BlGoLwjfAD3TYKD8Kt7FzU.___btcT65aM0RqqRVjfIvf0ftl or __j1zOuR7jzkPt2P0KXQzjCeqf == 0:
		return 0
	if flags & __o4BlGoLwjfAD3TYKD8Kt7FzU.__40fTdyPM4G2D_HmgHAUEDY54:
		return 1
	if flags & __o4BlGoLwjfAD3TYKD8Kt7FzU.__9IQIhwFb14PlEkxMAh0PDYhb == 0:
		return 0
	if flags & __o4BlGoLwjfAD3TYKD8Kt7FzU.__Ho8Gg0bR0oC7o_Z457dOFj9F:
		return 5
	if flags & __o4BlGoLwjfAD3TYKD8Kt7FzU.__doWxkstT0Zeom2mJ81_tdy0s:
		return 6
	if flags & __o4BlGoLwjfAD3TYKD8Kt7FzU.__qK3r1tHFgcp6FlfZzG1_VPQy:
		var __0RIq4VK8fnGOJk1k85x0IRM1: int = 0
		if flags & 2149581824:
			__0RIq4VK8fnGOJk1k85x0IRM1 = 11
		if flags & 2048:
			__0RIq4VK8fnGOJk1k85x0IRM1 = 12
		if flags & 8192:
			__0RIq4VK8fnGOJk1k85x0IRM1 = 13
		if flags & 4096:
			__0RIq4VK8fnGOJk1k85x0IRM1 = 14
		return __0RIq4VK8fnGOJk1k85x0IRM1
	return 3
