class_name __bO69ohbc7qstOVzkOQ46HazE
extends Node2D
var __Mg6jxghXyZs3zgCi_qR1PwSb: bool = false
func __F_jehFX5RJNUEjsCJ2T8nanH() -> void :
	__SgEyrIZJCIKq5tHIvreYIf6z = true
	if __LJD_DLosLmVUkX41Kalx6Ttc:
		__LJD_DLosLmVUkX41Kalx6Ttc = false
		UI.pop()
	__m5TW9MpzzNDZg7II10XZl5MU()
	App.__C1KFt9tOFvmtDu5lhMey47Lc(__c8JJGEKEvrszgBpfNsvw4gM0())
var __5zsHBwGhnk5X3Ays_WuwIBnz: __aTOx5XAvuUIxfTwxoFTG10xf
var __OUrhMiIPovPuCx2oLsoLxFDb: = __lQA2X_Tbdwp3cdBqDfL8XMPe.new()
var __Szndsmt47uTQYpRKJToURNl7: __BM01A0hfXxtKzcEAsrrhw94R
const __oPiraE7TPjWFHkzUnJOVP_f7: = 50
var __90bkbYVvZTOYe0VYY3rj_ZzV: = __lQA2X_Tbdwp3cdBqDfL8XMPe.new()
func __0DRZevprYoqfQvWPztROS7nl(__Isvo1Hcnoap4oFKpkTCcWy3Y: Dictionary) -> void :
	__SgEyrIZJCIKq5tHIvreYIf6z = true
	var path: String = __u8UvjIlM7wFkkXpmjKu2BJUJ("desync")
	await UI.__Dzq5SbxUBHUUe7FLUyy2rI_S(tr("UI_DESYNC"), tr("UI_DESYNC_TEXT") % [int(__Isvo1Hcnoap4oFKpkTCcWy3Y["turn_no"]), ProjectSettings.globalize_path(path)], [tr("UI_BACK_ROOM")])
	App.__MmzTu5Qu8ljNTyzkdxs4GEtt(__iAbDeha6hgeEpDzp_OVLHMcN)
func __ASM9naUc7LGeAbtWSqS9xNTM() -> PackedInt64Array:
	var __qCUz537hX9MDe0bJFg_5vmKC: = PackedInt64Array([0, 0])
	var __voqCaFjAIlbZWabwqN90ax0q: PackedInt32Array = __gLoRe5VNudNaczgnAFQL0Z8x
	for __ZZS3CHdvLYtzy7ToLKLRBhU4: int in __voqCaFjAIlbZWabwqN90ax0q.size():
		var __RS27tKpwOk0kKAWnQtTzbZ3A: int = __Im3kdj312UN9j6s5TpSfKOAs.__LYNzM9N3A8Dmo_1zq54GljKm[__ZZS3CHdvLYtzy7ToLKLRBhU4].__7OKcEzdMfOdabzyMipWdSzWD
		if __RS27tKpwOk0kKAWnQtTzbZ3A >= 0 and __RS27tKpwOk0kKAWnQtTzbZ3A < 2:
			__qCUz537hX9MDe0bJFg_5vmKC[__RS27tKpwOk0kKAWnQtTzbZ3A] += __voqCaFjAIlbZWabwqN90ax0q[__ZZS3CHdvLYtzy7ToLKLRBhU4]
	return __qCUz537hX9MDe0bJFg_5vmKC
var __hfhrNERwZCXjneW2quGcUg2n: = __Eqd4HoZVFfamlNlSeotGOZBp.new()
func __U1hBTDILqY3bitS_L8xpZsMH() -> void :
	if __hDON5_Ak_v4LQsqfesSFUaa2 != null and __wbELGtzJYkGkxW7qLn9ltku7 != null:
		__wbELGtzJYkGkxW7qLn9ltku7.__OnvfPn6EEoHxtfCyCVEmsKKY(__hDON5_Ak_v4LQsqfesSFUaa2)
var __HN2CGq76mPdGF_uuq2VLVMCB: String = ""
var __DL2yNM3BV9Lmjk_IjGgO27dt: int:
	get: return __AkJDLb0dYRECEiyB7JBimGWX.get_value()
	set(v): __AkJDLb0dYRECEiyB7JBimGWX.set_value(v)
const __R2Oz4qX8VyeS84GFoN4sQNcI: = 125
var __nvtHehTtgAm979A1wLl1o1st: = __VOgRTeKsSyRPz8xhXp41enO7.new()
var __qDMGPXum4Wfh1OWpRcTjfrQm: Array[__PvnLOrlcJy1UWxLTLMpWrcWS] = []
var __oGQ4RXn5cKC7Lk331Q81Ys_V: = __lQA2X_Tbdwp3cdBqDfL8XMPe.new()
func __KQZdXu2S1iZ_EaFcA8wgkdsw(x: int, y: int) -> int:
	var __a_eqnlxOzpEpJleM_dGnX40q: int = x - __H_DT0F4P9u3L0d2FERrVmg1j.x()
	var ___XynLnAf_2XG06K9H9PSTA5D: int = y - __H_DT0F4P9u3L0d2FERrVmg1j.y()
	return __Irz9hiGcyslSDsJT8BenfEt2.__f8g2PjfN7nwJbTHn9ePhmeZH(__a_eqnlxOzpEpJleM_dGnX40q * __a_eqnlxOzpEpJleM_dGnX40q + ___XynLnAf_2XG06K9H9PSTA5D * ___XynLnAf_2XG06K9H9PSTA5D)
var __exPMG5hclEJ4GrkuNTp8QecI: String = ""
var __i4WJeJTstISPCnqQAjaX2qhi: bool = false
var __svN_fv5m0UGKw8JIYuTHIUfI: = Vector2i.ZERO
var __gt_3Npy2nSfXotDarWn3jYtq: int = 0
var __0ebdt1P4SN2l7nmmh7JZeojA: CanvasLayer
func __yra4cvXO1zvZcUlEgJXSrg6l(__mQOkK1cfnmqHYnt8ZCGX5wSC: __PvnLOrlcJy1UWxLTLMpWrcWS) -> void :
	var __uQgCj30XKaqyNanB4XHMCHlw: int = Time.get_ticks_msec()
	for __jqNB91xPIbkcevrbbT4R3vP2: __REjpG8i8fp_pDKfx6CV3uyDe in __mQOkK1cfnmqHYnt8ZCGX5wSC.__LYNzM9N3A8Dmo_1zq54GljKm[__H_DT0F4P9u3L0d2FERrVmg1j.index].__TvSfxzgQXaZCIjioVO_AuUCJ:
		for __uRbHD6YfzKutvY2xK53LQu4Y: int in __1lT38LAdcUETU4FP4xOZDWAU.size():
			if __1lT38LAdcUETU4FP4xOZDWAU[__uRbHD6YfzKutvY2xK53LQu4Y].x == __jqNB91xPIbkcevrbbT4R3vP2.code:
				__Nbwq42oyGfXWqpZgReQfjApf.append(__uQgCj30XKaqyNanB4XHMCHlw - __1lT38LAdcUETU4FP4xOZDWAU[__uRbHD6YfzKutvY2xK53LQu4Y].y + __jqNB91xPIbkcevrbbT4R3vP2.__t2UdGLb5AjoD9DJacXSIpDUA * __lAo0PsogaUvqHw4muTzPsHiR.__qYP_YAvOQ8TvQJjfN6xGqOuz)
				__1lT38LAdcUETU4FP4xOZDWAU.remove_at(__uRbHD6YfzKutvY2xK53LQu4Y)
				break
	while __Nbwq42oyGfXWqpZgReQfjApf.size() > __MR04C36GQwmWStVvnym2GOW6:
		__Nbwq42oyGfXWqpZgReQfjApf.pop_front()
	if not __Nbwq42oyGfXWqpZgReQfjApf.is_empty():
		var __myb_mlD4TTtpi1qNFOI1T9EM: int = 0
		for v: int in __Nbwq42oyGfXWqpZgReQfjApf:
			__myb_mlD4TTtpi1qNFOI1T9EM += v
		__YVwrEYU5N0dWOswYhyLAhgF6 = __myb_mlD4TTtpi1qNFOI1T9EM / __Nbwq42oyGfXWqpZgReQfjApf.size()
const __8OfkYKKKoPZGOE4lCzGLW94p: = {"aa": 1, "aa_no": 2, "he": 4, "he_no": 5, "tp": 7, "tp_no": 8}
func __G2zYsJx5HRFiDZUAlfwnf1IN(__f5Jln0PUG1YeFc99qTONojSR: String) -> void :
	var __lgq_LifB6v8vkqz0UhAgiEjr: int = Time.get_ticks_msec()
	if __lgq_LifB6v8vkqz0UhAgiEjr - __FucjOm7PB7VBmsuC6Qq0btzH > 2000:
		UI.__Qyp4Js7J9ejl5FSF4pVpfEi5(tr(__f5Jln0PUG1YeFc99qTONojSR))
		__FucjOm7PB7VBmsuC6Qq0btzH = __lgq_LifB6v8vkqz0UhAgiEjr
var __AQ1E4IB2xjKUZDj84PMq7p0n: __CnHLFuemzEF6fvMpwe7EnocH
func __c8JJGEKEvrszgBpfNsvw4gM0() -> Dictionary:
	var __24ayykMsWy198l8obikyhhcf: Array[int] = [0, 0]
	for s: __YdhZSn3k6BLtSITi5naOCb7n in __Im3kdj312UN9j6s5TpSfKOAs.__LYNzM9N3A8Dmo_1zq54GljKm:
		if s.state == __lAo0PsogaUvqHw4muTzPsHiR.__pRO7nOY10o2GAU3KzWQvIvwY:
			__24ayykMsWy198l8obikyhhcf[s.__7OKcEzdMfOdabzyMipWdSzWD] += 1
	var __LGUEKwyCsWvAbJHZsVU0w3oh: Dictionary = __vAo65UE0pQLvxGOA_O1YS4a8()
	var __n4cHQScuI7tM8XE___xQYlxD: Dictionary = {"outcome": __rQbCTLm4ikRheIOavyVgPmxH, "hits": __zFPxZ4x_KsoNDuQiG7QR7qOU, "damage": __ntcYuQ5_xrJQSz3m7gFyPFYC, "kills": __k4tAH6rGNdvYl6lno95PF0x0, "alive_a": __24ayykMsWy198l8obikyhhcf[0], "alive_b": __24ayykMsWy198l8obikyhhcf[1], "side": __H_DT0F4P9u3L0d2FERrVmg1j.__7OKcEzdMfOdabzyMipWdSzWD, "ticks": __Im3kdj312UN9j6s5TpSfKOAs.__u0nkAKG5lGiEsenIJI6PFvMF, "crew": __LGUEKwyCsWvAbJHZsVU0w3oh}.merged(__xUtrAmQCt6WLEaRP0KW1kETe())
	if not __EB62kdWxBmEB2Xlff4o0XGma.is_empty():
		__n4cHQScuI7tM8XE___xQYlxD["alive_a"] = int(__EB62kdWxBmEB2Xlff4o0XGma["alive"][0])
		__n4cHQScuI7tM8XE___xQYlxD["alive_b"] = int(__EB62kdWxBmEB2Xlff4o0XGma["alive"][1])
		__n4cHQScuI7tM8XE___xQYlxD["ticks"] = int(__EB62kdWxBmEB2Xlff4o0XGma["end"])
	if __898CZFX8zI40Huxp297h_lkH:
		var __LSW7Wrd2shueyB5pPuggCrNI: Dictionary = __iAbDeha6hgeEpDzp_OVLHMcN.duplicate()
		__LSW7Wrd2shueyB5pPuggCrNI["rounds"] = int(__LSW7Wrd2shueyB5pPuggCrNI.get("rounds", 1)) - 1
		__n4cHQScuI7tM8XE___xQYlxD["room_params"] = __LSW7Wrd2shueyB5pPuggCrNI
		__n4cHQScuI7tM8XE___xQYlxD["auto_back"] = bool(__iAbDeha6hgeEpDzp_OVLHMcN.get("auto_back", false)) and int(__LSW7Wrd2shueyB5pPuggCrNI["rounds"]) > 0
		__n4cHQScuI7tM8XE___xQYlxD["settle_note"] = __LGUEKwyCsWvAbJHZsVU0w3oh.is_empty() and __vUjiLF8Y8Ck6mD07UbSjsQ8I < 0 and __XfimwY75BPlAiCDQbPD1LH9R()
	else:
		__n4cHQScuI7tM8XE___xQYlxD["offline_key"] = str(__iAbDeha6hgeEpDzp_OVLHMcN.get("offline_key", ""))
	return __n4cHQScuI7tM8XE___xQYlxD
func __wPxLRTgsWINZJN0shOfbxuiZ() -> void :
	if __1GEiijgEuP6kQplREzdJ_7E0 or __rQbCTLm4ikRheIOavyVgPmxH != 0 or __Mg6jxghXyZs3zgCi_qR1PwSb or __SgEyrIZJCIKq5tHIvreYIf6z or __H_DT0F4P9u3L0d2FERrVmg1j.state == __lAo0PsogaUvqHw4muTzPsHiR.__pRO7nOY10o2GAU3KzWQvIvwY:
		return
	if __5zsHBwGhnk5X3Ays_WuwIBnz != null or int(__iAbDeha6hgeEpDzp_OVLHMcN.get("shot", 0)) > 0 or bool(__iAbDeha6hgeEpDzp_OVLHMcN.get("auto_back", false)):
		return
	if __Im3kdj312UN9j6s5TpSfKOAs.__u0nkAKG5lGiEsenIJI6PFvMF - __H_DT0F4P9u3L0d2FERrVmg1j.__l9VibzAjJA8MnBH74WNhUJZL < __R2Oz4qX8VyeS84GFoN4sQNcI:
		return
	__1GEiijgEuP6kQplREzdJ_7E0 = true
	__LJD_DLosLmVUkX41Kalx6Ttc = true
	__F8HZCw7buuEBi0A0Mf6znYAe.get_parent().visible = false
	var __9NZzDaxbktgrCfsZHY1SeYZg: Dictionary = __c8JJGEKEvrszgBpfNsvw4gM0()
	__9NZzDaxbktgrCfsZHY1SeYZg["pending"] = __XfimwY75BPlAiCDQbPD1LH9R()
	__9NZzDaxbktgrCfsZHY1SeYZg["on_back"] = __RfdK3qu26jslGOFyRhJNbrz6
	__9NZzDaxbktgrCfsZHY1SeYZg["on_watch"] = __XkTmIcupKCOz_0RuPpASvUVm
	UI.__EdWX1D1SE7QOmjDer1HHnYqo("result", __9NZzDaxbktgrCfsZHY1SeYZg)
func _ready() -> void :
	App.__W489J4Gtntjtp_hMofn_wpkk = self
	__o5d4_jO9yZhivIzUiP0l8tys(Chat.__G5qb1fBWYxMBs5l8SDtIdhdl, __TU3KAtFI6UhHcRL5nuMhjxJJ)
	__ny0DWNynYxcUApZV6IS26JNR = int(Time.get_unix_time_from_system())
	var __fibBsZBj98GsAss2tQmJfWV4: Dictionary = App.__qCPTUUg6F8JnpOzFBXJFg8nU()
	if bool(__fibBsZBj98GsAss2tQmJfWV4.get("lobby", false)):
		__vCaHebXeTSk5ki_sJbb3gGEn = true
		__kN6myDrSvB160g5C80XDP_oe = not (__fibBsZBj98GsAss2tQmJfWV4.get("room", {}) as Dictionary).has("offline")
		UI.replace("room", __fibBsZBj98GsAss2tQmJfWV4.get("room", {}))
		return
	begin(__fibBsZBj98GsAss2tQmJfWV4)
var __WZkZ6Z7lN40BIDwB5zpEaYYg: Dictionary = {}
func _unhandled_input(__ChSy0eAh_tqokNrfXiEgeQ7j: InputEvent) -> void :
	if not __vCaHebXeTSk5ki_sJbb3gGEn or __NqcLKvQgaJD_pE3JD6vSe71E == null or camera == null:
		return
	var __flSRALMSANIiE81VJxw5TMZH: = __ChSy0eAh_tqokNrfXiEgeQ7j as InputEventMouseButton
	if __flSRALMSANIiE81VJxw5TMZH == null or not __flSRALMSANIiE81VJxw5TMZH.pressed or __flSRALMSANIiE81VJxw5TMZH.button_index != MOUSE_BUTTON_LEFT:
		return
	var __Du6Ycp3fTEgPYH5508Klv2Ds: int = __NqcLKvQgaJD_pE3JD6vSe71E.__OYUuWbn8L_KwgOgZesEfmkAP(camera.__ozvIRbROi2ytRE660_lBLW16(__flSRALMSANIiE81VJxw5TMZH.position))
	if __Du6Ycp3fTEgPYH5508Klv2Ds < 0:
		return
	get_viewport().set_input_as_handled()
	__o4IaqmP0oQSmDbqK58CnsRon(__Du6Ycp3fTEgPYH5508Klv2Ds)
	var v: Vector2 = camera.__7Q1u13W5jsLs8HPva7eP0p0P()
	var __rphyA_D8okv17kWdz9hrnPh4: = Rect2(Vector2(__cETMzqV9c70NaZRcXAs6n0Lf, __cETMzqV9c70NaZRcXAs6n0Lf), v - Vector2(2 * __cETMzqV9c70NaZRcXAs6n0Lf, __cETMzqV9c70NaZRcXAs6n0Lf + __UNRSz2MGXfIN8eyp8xYLBhT1.__VDgomB4zTZRkEYQ7hbHKnVMI))
	if not __rphyA_D8okv17kWdz9hrnPh4.has_point(__flSRALMSANIiE81VJxw5TMZH.position):
		camera.__8NF_uQgwrK0pZjB7yAvmXr4x(Vector2(__NqcLKvQgaJD_pE3JD6vSe71E.__h98tny9lVz8ZP5QoYrItiS6K[__Du6Ycp3fTEgPYH5508Klv2Ds]))
func __RfdK3qu26jslGOFyRhJNbrz6() -> void :
	if __SgEyrIZJCIKq5tHIvreYIf6z:
		return
	if __898CZFX8zI40Huxp297h_lkH:
		if __H_DT0F4P9u3L0d2FERrVmg1j.state != __lAo0PsogaUvqHw4muTzPsHiR.__pRO7nOY10o2GAU3KzWQvIvwY and __XfimwY75BPlAiCDQbPD1LH9R():
			__vAo65UE0pQLvxGOA_O1YS4a8()
			if (__D6DZnkEZuvO5Z8roRMmWk2nt as Dictionary).is_empty() and __vUjiLF8Y8Ck6mD07UbSjsQ8I < 0:
				await __IlUC_NC3OXFZTLC0kCLklDzm()
				return
			if (__D6DZnkEZuvO5Z8roRMmWk2nt as Dictionary).is_empty():
				client.__rHPjM22WErQ5NFazByygkf9U(__Uvzp2Nhc4YbduKNpA08hrEu5.__wMfg3dVnjdqMi7KUhLZ61Mhk, __H_DT0F4P9u3L0d2FERrVmg1j.__WeB9Hi0OxaFBUuwm2WU2qKEH)
		client.__UcctewY14V2ZY6pcHXj4WVQT()
	elif __5zsHBwGhnk5X3Ays_WuwIBnz == null and __XfimwY75BPlAiCDQbPD1LH9R() and __D6DZnkEZuvO5Z8roRMmWk2nt == null and (__rQbCTLm4ikRheIOavyVgPmxH != 0 or __H_DT0F4P9u3L0d2FERrVmg1j.state != __lAo0PsogaUvqHw4muTzPsHiR.__pRO7nOY10o2GAU3KzWQvIvwY):
		__SgEyrIZJCIKq5tHIvreYIf6z = true
		if __rQbCTLm4ikRheIOavyVgPmxH == 0:
			__EB62kdWxBmEB2Xlff4o0XGma = __hfhrNERwZCXjneW2quGcUg2n.__KrFZgdVa7_BjlbTjJDWvdEAc(__Im3kdj312UN9j6s5TpSfKOAs, __ASM9naUc7LGeAbtWSqS9xNTM(), __k4tJVsMbRmcRrzVGv3Bdb2bj)
			__rQbCTLm4ikRheIOavyVgPmxH = __4kuWb3XCQlF_JVzFT1aeoeA4(int(__EB62kdWxBmEB2Xlff4o0XGma["outcome"]))
			__rtep__1NaeBRnIaPLRs7keNF = int(__EB62kdWxBmEB2Xlff4o0XGma["end"])
		__m5TW9MpzzNDZg7II10XZl5MU()
		App.__C1KFt9tOFvmtDu5lhMey47Lc(__c8JJGEKEvrszgBpfNsvw4gM0())
		return
	__D38wuayWXzdzHovfPrGdL14l()
func __jPl56qRp4FciYYHXDmLtD2k2() -> void :
	if __DW5u_PxmVzx39MAyJaNAZ9No != null:
		__DW5u_PxmVzx39MAyJaNAZ9No.__ct8qKYCzBoe8obGKLLgvCtKo()
	if __NqcLKvQgaJD_pE3JD6vSe71E != null:
		remove_child(__NqcLKvQgaJD_pE3JD6vSe71E)
		__NqcLKvQgaJD_pE3JD6vSe71E.queue_free()
	__NqcLKvQgaJD_pE3JD6vSe71E = __ExHo5kjSvjunkYmWDgdJUGHm.new()
	__NqcLKvQgaJD_pE3JD6vSe71E.name = "BattleView"
	__g7JC3EJmfsOWnIyqLGGB93eB = __c5hyhliCGxS3qW31tQfksxJC.new(__Im3kdj312UN9j6s5TpSfKOAs, __H_DT0F4P9u3L0d2FERrVmg1j) if __H_DT0F4P9u3L0d2FERrVmg1j.__g7JC3EJmfsOWnIyqLGGB93eB != null else null
	if __g7JC3EJmfsOWnIyqLGGB93eB != null:
		__g7JC3EJmfsOWnIyqLGGB93eB.__opR4fKhG5cmcetfWMxSAxkbZ = __0HyQkKSIPfVuTPxYFxdIU3Cq
	__NqcLKvQgaJD_pE3JD6vSe71E.__g7JC3EJmfsOWnIyqLGGB93eB = __g7JC3EJmfsOWnIyqLGGB93eB
	__NqcLKvQgaJD_pE3JD6vSe71E.__wYzhleVaJC9SeB0bEr8PU0Nv = tr("UI_GROUNDED")
	add_child(__NqcLKvQgaJD_pE3JD6vSe71E)
	move_child(__NqcLKvQgaJD_pE3JD6vSe71E, 0)
	__NqcLKvQgaJD_pE3JD6vSe71E.setup(__Im3kdj312UN9j6s5TpSfKOAs, __H_DT0F4P9u3L0d2FERrVmg1j, App.__PtNURh2PaYHMgsPlkLtni90Y(), __fFoBwMT_TKrtEb91FCnVA4CQ)
	if __g7JC3EJmfsOWnIyqLGGB93eB != null:
		__g7JC3EJmfsOWnIyqLGGB93eB.__ei9nl__2_7NlD_vcHu11Nu7h = func(__5ZTfJmdKpQeSvgG9O8V1sfjb: Vector2i) -> __YdhZSn3k6BLtSITi5naOCb7n: return __NqcLKvQgaJD_pE3JD6vSe71E.__37RsK6AWr9ZdZGkqXMQ2XF8b(__5ZTfJmdKpQeSvgG9O8V1sfjb, true, __H_DT0F4P9u3L0d2FERrVmg1j.__7OKcEzdMfOdabzyMipWdSzWD)
	__NqcLKvQgaJD_pE3JD6vSe71E.__CR2jpqZ6wQv1sbgGfFwtARRJ.__pVZ1rgxXYv28k7A0SkDmbXvW = func(name: String, __HRppAn3uMiEAzQjB37r82c_q: Vector2) -> void :
		if __DW5u_PxmVzx39MAyJaNAZ9No != null and camera != null:
			__DW5u_PxmVzx39MAyJaNAZ9No.__3B0DYyBJbTNY6VyTGBYYxYT4(name, __HRppAn3uMiEAzQjB37r82c_q, Rect2(camera.position, camera.__7Q1u13W5jsLs8HPva7eP0p0P()))
	if camera == null:
		camera = __UNRSz2MGXfIN8eyp8xYLBhT1.new()
		camera.name = "Camera"
		add_child(camera)
		camera.__kPB6WrEOPKVp2mDZNM_ZEE0m = false
		__0ebdt1P4SN2l7nmmh7JZeojA = CanvasLayer.new()
		__0ebdt1P4SN2l7nmmh7JZeojA.layer = 10
		__0ebdt1P4SN2l7nmmh7JZeojA.visible = not __vCaHebXeTSk5ki_sJbb3gGEn
		add_child(__0ebdt1P4SN2l7nmmh7JZeojA)
		__wbELGtzJYkGkxW7qLn9ltku7 = __Qw7y3OnRnHxfWbHNtT6nnAUS.new()
		__0ebdt1P4SN2l7nmmh7JZeojA.add_child(__wbELGtzJYkGkxW7qLn9ltku7)
		__hDON5_Ak_v4LQsqfesSFUaa2 = __tALbI77Bj72RNkUjx1rJalbI.new()
		__hDON5_Ak_v4LQsqfesSFUaa2.__pBBZs7_ktaMaPnY0Ge7BL3C4 = false
		__hDON5_Ak_v4LQsqfesSFUaa2.__dbCUdY63qvJon3thvsV0K35A = true
		__0ebdt1P4SN2l7nmmh7JZeojA.add_child(__hDON5_Ak_v4LQsqfesSFUaa2)
		__wbELGtzJYkGkxW7qLn9ltku7.resized.connect(__U1hBTDILqY3bitS_L8xpZsMH)
		__hDON5_Ak_v4LQsqfesSFUaa2.__hjwdkOcfz3xI6m0cgps8MGo7.connect( func(__E3TDgQiJbUTwlaPhJCrnP9aS: Rect2) -> void : __U1hBTDILqY3bitS_L8xpZsMH.call_deferred())
		__U1hBTDILqY3bitS_L8xpZsMH.call_deferred()
		camera.__6E0LnAXodPRnDLQeGQADQ8wD = Vector2(__Im3kdj312UN9j6s5TpSfKOAs.terrain.__9Zy5NwQKLR2WXbpStDOauEMz, __Im3kdj312UN9j6s5TpSfKOAs.terrain.__0xMwoIVfT_j6GZoLP_HkB6nE)
		camera.__ygQpjlnLTsRv_t24LnuR1ohD(Vector2(__H_DT0F4P9u3L0d2FERrVmg1j.x(), __H_DT0F4P9u3L0d2FERrVmg1j.y()))
	camera.__6E0LnAXodPRnDLQeGQADQ8wD = Vector2(__Im3kdj312UN9j6s5TpSfKOAs.terrain.__9Zy5NwQKLR2WXbpStDOauEMz, __Im3kdj312UN9j6s5TpSfKOAs.terrain.__0xMwoIVfT_j6GZoLP_HkB6nE)
	__wbELGtzJYkGkxW7qLn9ltku7.__aWkYw_ILTtySHgVTtX3gmlyw.camera = camera
	if __g7JC3EJmfsOWnIyqLGGB93eB != null:
		__g7JC3EJmfsOWnIyqLGGB93eB.camera = camera
	__wbELGtzJYkGkxW7qLn9ltku7.bind(__Im3kdj312UN9j6s5TpSfKOAs, __H_DT0F4P9u3L0d2FERrVmg1j, __g7JC3EJmfsOWnIyqLGGB93eB, __0HyQkKSIPfVuTPxYFxdIU3Cq, __iMall8mB5R0iCf4lBncKqddf)

	var meti_old_gun_controls = __wbELGtzJYkGkxW7qLn9ltku7.get_node_or_null("MetiGunControls")
	if meti_old_gun_controls != null:
		__wbELGtzJYkGkxW7qLn9ltku7.remove_child(meti_old_gun_controls)
		meti_old_gun_controls.queue_free()
	if not __898CZFX8zI40Huxp297h_lkH and __5zsHBwGhnk5X3Ays_WuwIBnz == null and __H_DT0F4P9u3L0d2FERrVmg1j.__ZMgQrrB9zxLXJ4nY9DOrkD1m and not __H_DT0F4P9u3L0d2FERrVmg1j.__BJReFJ4ugditvprP9JFCx5S2.is_empty():
		var meti_gun_controls = load("res://client/battle/meti_gun_control.gdc").new()
		meti_gun_controls.name = "MetiGunControls"
		__wbELGtzJYkGkxW7qLn9ltku7.add_child(meti_gun_controls)
		meti_gun_controls.bind(self, __H_DT0F4P9u3L0d2FERrVmg1j)
	# Offline player carriers get a dedicated flight-control view.
	var meti_old_carrier_controls = __wbELGtzJYkGkxW7qLn9ltku7.get_node_or_null("MetiCarrierControls")
	if meti_old_carrier_controls != null:
		__wbELGtzJYkGkxW7qLn9ltku7.remove_child(meti_old_carrier_controls)
		meti_old_carrier_controls.queue_free()
	if not __898CZFX8zI40Huxp297h_lkH and __5zsHBwGhnk5X3Ays_WuwIBnz == null and __H_DT0F4P9u3L0d2FERrVmg1j.__ZMgQrrB9zxLXJ4nY9DOrkD1m and __g7JC3EJmfsOWnIyqLGGB93eB != null and __wbELGtzJYkGkxW7qLn9ltku7.__t3y1cnuny6w_2nwErOwdsvQP != null and __wbELGtzJYkGkxW7qLn9ltku7.__t3y1cnuny6w_2nwErOwdsvQP.meti_auto_available():
		var meti_carrier_controls = load("res://client/battle/meti_carrier_control.gdc").new()
		meti_carrier_controls.name = "MetiCarrierControls"
		__wbELGtzJYkGkxW7qLn9ltku7.add_child(meti_carrier_controls)
		var meti_gun_for_carrier = __wbELGtzJYkGkxW7qLn9ltku7.get_node_or_null("MetiGunControls")
		meti_carrier_controls.bind(self, __H_DT0F4P9u3L0d2FERrVmg1j, __g7JC3EJmfsOWnIyqLGGB93eB, __wbELGtzJYkGkxW7qLn9ltku7.__t3y1cnuny6w_2nwErOwdsvQP, meti_gun_for_carrier)
		if meti_gun_for_carrier != null:
			meti_gun_for_carrier.meti_bind_carrier(meti_carrier_controls)
			meti_gun_for_carrier.hide()
	__wbELGtzJYkGkxW7qLn9ltku7.__l9f8vnMOnlJhQwWYruaBlIAK = __NqcLKvQgaJD_pE3JD6vSe71E.__l9f8vnMOnlJhQwWYruaBlIAK
	__NqcLKvQgaJD_pE3JD6vSe71E.__5asHp4YxjoVtjNPsWMIuoRZR([])
	if not __898CZFX8zI40Huxp297h_lkH and __5zsHBwGhnk5X3Ays_WuwIBnz == null and __H_DT0F4P9u3L0d2FERrVmg1j.__ZMgQrrB9zxLXJ4nY9DOrkD1m:
		var meti_preview = load("res://client/battle/meti_aim_preview.gdc").new()
		__NqcLKvQgaJD_pE3JD6vSe71E.add_child(meti_preview)
		meti_preview.bind(self, __Im3kdj312UN9j6s5TpSfKOAs, __H_DT0F4P9u3L0d2FERrVmg1j)
const __cETMzqV9c70NaZRcXAs6n0Lf: = 140
var __YVwrEYU5N0dWOswYhyLAhgF6: int = -1
var __RrqNTQv04kVmefPIEe7GJtI6: int = 0
var setup: Dictionary = {}
var __p0VcvihgtXhiKjC_wbNpnF4q: = __5N6awaIMq5qNkafjTDM69PIs.new()
var __kN6myDrSvB160g5C80XDP_oe: bool = false
const __ie1fCh72Dme_5IXLGrTsILmx: Array[int] = __U7UMfwBewiXSLEeaDnywaCO7.__0idCwE67dWrlgVz7VpRZRO9s
func __mT8Bp2SMqz7JpPTq617FmdMN(__0t8bnl0GDQyrRTMZcegm31OO: int) -> void :
	__vUjiLF8Y8Ck6mD07UbSjsQ8I = __0t8bnl0GDQyrRTMZcegm31OO
	__u8UvjIlM7wFkkXpmjKu2BJUJ("end")
	if __rQbCTLm4ikRheIOavyVgPmxH == 0:
		__rQbCTLm4ikRheIOavyVgPmxH = __4kuWb3XCQlF_JVzFT1aeoeA4(__0t8bnl0GDQyrRTMZcegm31OO)
		__rtep__1NaeBRnIaPLRs7keNF = __Im3kdj312UN9j6s5TpSfKOAs.__u0nkAKG5lGiEsenIJI6PFvMF
var __1lT38LAdcUETU4FP4xOZDWAU: Array[Vector2i] = []
var __qlFicdtBAIg_rNEpMlXK2S0o: Dictionary = {}
var __D6DZnkEZuvO5Z8roRMmWk2nt: Variant = null
var __EiZRF1NnMPMecKiwh_R_ucyi: float = 0.0
var __898CZFX8zI40Huxp297h_lkH: bool = false
func __O7tQVHvLjLwc5CBGir5xcQGO(__4WwW86IdwezvuCCl0inwxzU7: int) -> void :
	var __Twx6Hd1dT0C2xXMoTEodQT79: __8GTw5uMzf0oxhrK8dEroB4bz = UI.__fXAqPJcjPkBlY5zLmcPc3Z0E()
	if __Twx6Hd1dT0C2xXMoTEodQT79 != null and __Twx6Hd1dT0C2xXMoTEodQT79.has_method("set_pending_progress"):
		__Twx6Hd1dT0C2xXMoTEodQT79.call("set_pending_progress", __4WwW86IdwezvuCCl0inwxzU7)
var __mmFfxzFJBSbDwmcmgECiPiAR: = __4ADc5imRmZoHoEXtbVeZyH16.new()
func __AY9VuPCIn6Gi801H6R1FBMz0(__Je1oIZmKGGCzeL7DJHalea3K: int) -> int:
	if __eRoQ6QawJdKmQoEOmdz1CInO.has(__Je1oIZmKGGCzeL7DJHalea3K):
		return __eRoQ6QawJdKmQoEOmdz1CInO[__Je1oIZmKGGCzeL7DJHalea3K]
	var r: int = 0
	for __jFjdHT4JlVKGwUMJu56XuYB_: int in __H_DT0F4P9u3L0d2FERrVmg1j.__BJReFJ4ugditvprP9JFCx5S2.size():
		if int(__H_DT0F4P9u3L0d2FERrVmg1j.__BJReFJ4ugditvprP9JFCx5S2[__jFjdHT4JlVKGwUMJu56XuYB_].get("seat", 0)) == __Je1oIZmKGGCzeL7DJHalea3K:
			for __5YVq1gftul1KiG18V4El93s9: Vector3i in __FbfcZh7zipvK02thKpA13yoN.__hORONTOnKoUlBZe2vvywVoHY(__H_DT0F4P9u3L0d2FERrVmg1j, __jFjdHT4JlVKGwUMJu56XuYB_):
				r = maxi(r, __5YVq1gftul1KiG18V4El93s9.y)
	if r == 0:
		for __Of7s2c6OOm0sZ4UsBG5Ih5_E: Dictionary in __H_DT0F4P9u3L0d2FERrVmg1j.__bFJ1csmbpVraScDCZhw1ETZ5:
			if int(__Of7s2c6OOm0sZ4UsBG5Ih5_E["seat"]) == __Je1oIZmKGGCzeL7DJHalea3K:
				r = maxi(r, maxi(int(__Of7s2c6OOm0sZ4UsBG5Ih5_E["r_slow"]), int(__Of7s2c6OOm0sZ4UsBG5Ih5_E["r_fast"])))
	__eRoQ6QawJdKmQoEOmdz1CInO[__Je1oIZmKGGCzeL7DJHalea3K] = r
	return r
func __m5TW9MpzzNDZg7II10XZl5MU() -> void :
	if __5zsHBwGhnk5X3Ays_WuwIBnz != null or __Im3kdj312UN9j6s5TpSfKOAs == null or __898CZFX8zI40Huxp297h_lkH:
		return
	var __Igof2M9n4pgA0WinRTIYc9gz: Dictionary = __Szndsmt47uTQYpRKJToURNl7.__O7XWrHjG1GCET_VeupnKFYjJ(setup, __2mQ2BJsmPe4GT6uaSdCAvxsA.size(), __B03hDgmIU4O8q341eLf_67xq, __2mQ2BJsmPe4GT6uaSdCAvxsA)
	var __4rjTn8WsI8WSKpgsaQwT7zPW: FileAccess = FileAccess.open(App.__C70SHOw_Dud5j_o4PUukTYjz, FileAccess.WRITE)
	if __4rjTn8WsI8WSKpgsaQwT7zPW != null:
		__4rjTn8WsI8WSKpgsaQwT7zPW.store_string(JSON.stringify(__Igof2M9n4pgA0WinRTIYc9gz))
func __fXj045rwdfjWIfF_Xd9YYADm(__DAcRjrrgiKguUenTK_19LMmP: Vector2i) -> void :
	if __g7JC3EJmfsOWnIyqLGGB93eB != null and __5zsHBwGhnk5X3Ays_WuwIBnz == null and __H_DT0F4P9u3L0d2FERrVmg1j != null and __H_DT0F4P9u3L0d2FERrVmg1j.state == __lAo0PsogaUvqHw4muTzPsHiR.__pRO7nOY10o2GAU3KzWQvIvwY:
		__g7JC3EJmfsOWnIyqLGGB93eB.__W23QfliEsPoPcB14rd8Qc3Dv(__DAcRjrrgiKguUenTK_19LMmP, true)
func __mRR1SQWSm4CqOo8liJnegLye() -> void :
	if __LJD_DLosLmVUkX41Kalx6Ttc or __c9HSVk0U4goH9I0e212o2UAu or __SgEyrIZJCIKq5tHIvreYIf6z:
		return
	__c9HSVk0U4goH9I0e212o2UAu = true
	var title: String = tr("UI_LEAVE_WATCH_CONFIRM" if __H_DT0F4P9u3L0d2FERrVmg1j.state != __lAo0PsogaUvqHw4muTzPsHiR.__pRO7nOY10o2GAU3KzWQvIvwY else "UI_LEAVE_CONFIRM")
	var __c7LlJh96goUDjPtn__9PvodG: int = await UI.__Dzq5SbxUBHUUe7FLUyy2rI_S(title, "", [tr("UI_YES"), tr("UI_NO")])
	__c9HSVk0U4goH9I0e212o2UAu = false
	if __c7LlJh96goUDjPtn__9PvodG == 0 and not __SgEyrIZJCIKq5tHIvreYIf6z and is_inside_tree():
		__RfdK3qu26jslGOFyRhJNbrz6()
var __2omsALYMZSn3ijkiFbTa0YhU: Dictionary = {}
var __Nbwq42oyGfXWqpZgReQfjApf: Array[int] = []
var __ZiG9DqFDEiEyq21OsrGR3LI9: = __PGym0Ggx0gP39qJnLFTmTzF3.new()
var __vUjiLF8Y8Ck6mD07UbSjsQ8I: int = -1
var __B03hDgmIU4O8q341eLf_67xq: int = 0
func __XAO6JKg0PQn3g5ui6hTmZuKg() -> void :
	var __PK5O5OlI1_kOF0sLDY7L1Ycq: String = ""
	if __g7JC3EJmfsOWnIyqLGGB93eB != null and __g7JC3EJmfsOWnIyqLGGB93eB.__PrvZDcSAg2N7M4qrzB5vt2MU():
		__PK5O5OlI1_kOF0sLDY7L1Ycq = "air"
	elif __H_DT0F4P9u3L0d2FERrVmg1j.__sfrhGgpP8JHW6nvd0GQRC91I and __H_DT0F4P9u3L0d2FERrVmg1j.state == __lAo0PsogaUvqHw4muTzPsHiR.__pRO7nOY10o2GAU3KzWQvIvwY and __5zsHBwGhnk5X3Ays_WuwIBnz == null:
		var __w_Hk3QturOBcEEINy0iBUmf8: Vector2 = get_viewport().get_mouse_position()
		if not __wbELGtzJYkGkxW7qLn9ltku7.__OIYqDJXDDzt5rLpfnxCGBKRN(__w_Hk3QturOBcEEINy0iBUmf8):
			var __GTLlF1ZGO71kSoFOXmIUFiIN: String = "tp"
			var __PI79hIyTN5BEQtxt5dJfh1cZ: int = __H_DT0F4P9u3L0d2FERrVmg1j.__7aPSjzsiug8Scbil7Xy9VkQ1(__H_DT0F4P9u3L0d2FERrVmg1j.__1Z7OFhxB6TttwviVl7guTYN5)
			if __PI79hIyTN5BEQtxt5dJfh1cZ >= 0:
				__GTLlF1ZGO71kSoFOXmIUFiIN = "aa" if __ExHo5kjSvjunkYmWDgdJUGHm.__7_uztVc7mDtrHY3HgRMD8s1F(__H_DT0F4P9u3L0d2FERrVmg1j) == 10 else "he"
			var __DqjQd1rN6z0BWpUO1nDN6mxG: Vector2i = camera.__ozvIRbROi2ytRE660_lBLW16(__w_Hk3QturOBcEEINy0iBUmf8)
			var d: int = __Irz9hiGcyslSDsJT8BenfEt2.__f8g2PjfN7nwJbTHn9ePhmeZH((__DqjQd1rN6z0BWpUO1nDN6mxG.x - __H_DT0F4P9u3L0d2FERrVmg1j.x()) * (__DqjQd1rN6z0BWpUO1nDN6mxG.x - __H_DT0F4P9u3L0d2FERrVmg1j.x()) + (__DqjQd1rN6z0BWpUO1nDN6mxG.y - __H_DT0F4P9u3L0d2FERrVmg1j.y()) * (__DqjQd1rN6z0BWpUO1nDN6mxG.y - __H_DT0F4P9u3L0d2FERrVmg1j.y()))
			__PK5O5OlI1_kOF0sLDY7L1Ycq = __GTLlF1ZGO71kSoFOXmIUFiIN + ("_no" if d > __AY9VuPCIn6Gi801H6R1FBMz0(__H_DT0F4P9u3L0d2FERrVmg1j.__1Z7OFhxB6TttwviVl7guTYN5) else "")
	if __PK5O5OlI1_kOF0sLDY7L1Ycq == __GuP_w3N6IPD6F4EDt99FrC8q:
		return
	__GuP_w3N6IPD6F4EDt99FrC8q = __PK5O5OlI1_kOF0sLDY7L1Ycq
	var __7S9y0sU0b8ovI1eF61NO4xbY: Texture2D = null
	var __bFW5IN9XBG2VPyDYEvA_NzX6: Vector2 = Vector2.ZERO
	if __PK5O5OlI1_kOF0sLDY7L1Ycq == "air" and Assets.__QiUGArjHDhwcrWbH3BB0K8c5("Cursor", 12):
		var frame: __cBjn_l7I8v2A2mo4oxWc1Hx5 = Assets.__MUCguPydNQwl8ZRXUX2ciJ44("Cursor", 12).frame(0)
		if frame.__9GUNq0RC3I2wtF6RyGyGCuST != null:
			var __xwkUm3THspDyRdS_bfD1bMRt: Image = frame.__9GUNq0RC3I2wtF6RyGyGCuST.get_image()
			if __xwkUm3THspDyRdS_bfD1bMRt.is_compressed():
				__xwkUm3THspDyRdS_bfD1bMRt.decompress()
			__xwkUm3THspDyRdS_bfD1bMRt.convert(Image.FORMAT_RGBA8)
			var canvas: Image = Image.create(frame.size.x, frame.size.y, false, Image.FORMAT_RGBA8)
			canvas.blit_rect(__xwkUm3THspDyRdS_bfD1bMRt, Rect2i(Vector2i.ZERO, __xwkUm3THspDyRdS_bfD1bMRt.get_size()), frame.__0qOEymYSM0v6_xaX4s5nNVDN)
			__7S9y0sU0b8ovI1eF61NO4xbY = ImageTexture.create_from_image(canvas)
			__bFW5IN9XBG2VPyDYEvA_NzX6 = Vector2(23, 21)
	elif __8OfkYKKKoPZGOE4lCzGLW94p.has(__PK5O5OlI1_kOF0sLDY7L1Ycq) and Assets.__QiUGArjHDhwcrWbH3BB0K8c5("Cursor2", __8OfkYKKKoPZGOE4lCzGLW94p[__PK5O5OlI1_kOF0sLDY7L1Ycq]):
		__7S9y0sU0b8ovI1eF61NO4xbY = Assets.__MUCguPydNQwl8ZRXUX2ciJ44("Cursor2", __8OfkYKKKoPZGOE4lCzGLW94p[__PK5O5OlI1_kOF0sLDY7L1Ycq]).frame(0).__9GUNq0RC3I2wtF6RyGyGCuST
	Input.set_custom_mouse_cursor(__7S9y0sU0b8ovI1eF61NO4xbY, Input.CURSOR_ARROW, __bFW5IN9XBG2VPyDYEvA_NzX6)
func __yS_eFWQpHQh4Iwo2AO9wcsbL(__6vvu1VoVSWONxyMviT4Y8bg3: int, pressed: bool, data: Variant) -> bool:
	if __g7JC3EJmfsOWnIyqLGGB93eB == null or __5zsHBwGhnk5X3Ays_WuwIBnz != null:
		return false
	return __g7JC3EJmfsOWnIyqLGGB93eB.__NhyzmUA9yvICs3BYE9vRlcqw(__6vvu1VoVSWONxyMviT4Y8bg3, pressed, data, __wbELGtzJYkGkxW7qLn9ltku7.__t3y1cnuny6w_2nwErOwdsvQP if __wbELGtzJYkGkxW7qLn9ltku7 != null else null)
var __vCaHebXeTSk5ki_sJbb3gGEn: bool = false
func __8zeRLqvwZ9Oswm0rTuSnPick(__uTzBgujYIQlr1CvmLqiPIiFd: __PvnLOrlcJy1UWxLTLMpWrcWS) -> void :
	queue.__EdWX1D1SE7QOmjDer1HHnYqo(__uTzBgujYIQlr1CvmLqiPIiFd)
	__qDMGPXum4Wfh1OWpRcTjfrQm.append(__uTzBgujYIQlr1CvmLqiPIiFd)
func __o4IaqmP0oQSmDbqK58CnsRon(__yKAD7nwBghXkE0mkeo7JOher: int) -> void :
	if not __vCaHebXeTSk5ki_sJbb3gGEn or __NqcLKvQgaJD_pE3JD6vSe71E == null or __yKAD7nwBghXkE0mkeo7JOher < 0 or __yKAD7nwBghXkE0mkeo7JOher >= __Ti__RyaVjFAbq0eWKyiulRtX.__SC0yVVB4FXWyqXqfTR1JmRLW or __yKAD7nwBghXkE0mkeo7JOher == __NqcLKvQgaJD_pE3JD6vSe71E.__brZUfFe36MKriDlq0TIetwbS:
		return
	if __kN6myDrSvB160g5C80XDP_oe:
		Session.client.set_slot(__yKAD7nwBghXkE0mkeo7JOher)
	else:
		__JmicKnMOUqYWokzP32Q2v9RX = __yKAD7nwBghXkE0mkeo7JOher
		__fJyTMvijFRPTnM5LvyNVeHLa(__HN2CGq76mPdGF_uuq2VLVMCB)
func __9im0usQslI7QC1gjJqA79Guj(__zAPgrp9SB6w8AB9OQDEG7H_X: Vector2i) -> bool:
	__NqcLKvQgaJD_pE3JD6vSe71E.target = __NqcLKvQgaJD_pE3JD6vSe71E.__37RsK6AWr9ZdZGkqXMQ2XF8b(__zAPgrp9SB6w8AB9OQDEG7H_X)
	return __NqcLKvQgaJD_pE3JD6vSe71E.target != null
var __GuP_w3N6IPD6F4EDt99FrC8q: String = ""
var client: __OVAOfLpG8ro21Yx3xp7VhB3r
var __BiQoQGi6zNoff3oBH5w2ocqb: int = -1
func __TU3KAtFI6UhHcRL5nuMhjxJJ(__bMuXXaLgsGsQJEjeeepsvLhD: __CFABd68UPPkXfz30m555bw3p) -> void :
	if __vCaHebXeTSk5ki_sJbb3gGEn or __NqcLKvQgaJD_pE3JD6vSe71E == null or __Im3kdj312UN9j6s5TpSfKOAs == null or __5zsHBwGhnk5X3Ays_WuwIBnz != null or __bMuXXaLgsGsQJEjeeepsvLhD.__rz0b1JWIGUp0RMuSBya_Sl5N() or __bMuXXaLgsGsQJEjeeepsvLhD.__WGEyCfWpyvUvMNc11zQw82Tr <= 0:
		return
	if __898CZFX8zI40Huxp297h_lkH:
		var index: int = __Uvzp2Nhc4YbduKNpA08hrEu5.__9X3lUNXcQD5jKQrJ56a0JZ82(__bMuXXaLgsGsQJEjeeepsvLhD.__WGEyCfWpyvUvMNc11zQw82Tr)
		__NqcLKvQgaJD_pE3JD6vSe71E.__5tXUiDlk76eGCKG6jGJ9N2hz(index, __bMuXXaLgsGsQJEjeeepsvLhD.text)
	elif Session.client != null and Session.client.__bEaVqnUpkbc9pnzD2IA0HDfW != null:
		if __bMuXXaLgsGsQJEjeeepsvLhD.__WGEyCfWpyvUvMNc11zQw82Tr == Session.client.__bEaVqnUpkbc9pnzD2IA0HDfW.__WGEyCfWpyvUvMNc11zQw82Tr:
			__NqcLKvQgaJD_pE3JD6vSe71E.__5tXUiDlk76eGCKG6jGJ9N2hz(__H_DT0F4P9u3L0d2FERrVmg1j.index, __bMuXXaLgsGsQJEjeeepsvLhD.text)
func __PDz2BjB1mbrZMzHiimUkaczG() -> void :
	__H1kWP_uRU_4T8c7RAuJRJSNi = __H_DT0F4P9u3L0d2FERrVmg1j.__TUveEYNBcdzuJiqL7lNZR8jT
	if __5zsHBwGhnk5X3Ays_WuwIBnz != null:
		return
	var __N9_1eyJJEf8ANMfW_EQ54cJi: int = clampi(int(Settings.get_value("fire_mode", __YdhZSn3k6BLtSITi5naOCb7n.__PqwHiMCiEKMg9bL_3LrzgjVT.__Df7mxkznfLfIj2iCD1v2Tzl8)), 0, 2)
	var __lfuyivliE4TmpBO1CPnapFQ8: int = (__N9_1eyJJEf8ANMfW_EQ54cJi - __H_DT0F4P9u3L0d2FERrVmg1j.__TUveEYNBcdzuJiqL7lNZR8jT + 3) % 3
	__H1kWP_uRU_4T8c7RAuJRJSNi = __N9_1eyJJEf8ANMfW_EQ54cJi
	for __GGGhev0aPCKGxsgUD1IqpkbO: int in __lfuyivliE4TmpBO1CPnapFQ8:
		__CjmY96ucMnR54d8UC0PF7fMV(__lAo0PsogaUvqHw4muTzPsHiR.__sKP2pX8KjRdyhsUnZlBoy8m7, PackedByteArray())
var __doKOKtoKy3i4SBlfmjnARw4_: __s_qOeBtjnb9HkxVxzl6YMKdK
func __z5sslWfZOq0V_PbBTItlWglS(events: Array[__QzfA1_MgHwBGTTBizdgA8rkk]) -> void :
	if __XcEBuZmYff2OSNt7_4huxaTI != null:
		__XcEBuZmYff2OSNt7_4huxaTI.__gzKqptXdbfWsDhOy3FQZmyZz(__Im3kdj312UN9j6s5TpSfKOAs, events)
	for __bpnL2CgM8dYMGdiLGPdVjhmQ: __QzfA1_MgHwBGTTBizdgA8rkk in events:
		if __bpnL2CgM8dYMGdiLGPdVjhmQ.__RZSGss6vMJxzvS6fmWkQMma8 == __QzfA1_MgHwBGTTBizdgA8rkk.__FSW4WCXpupwYSF0KaHCFCNKb.__QECI9RHRtVBcNl93XhYVIrYe:
			if not __pu08ep8gFB8kGVBlMsMmPfl_:
				__DW5u_PxmVzx39MAyJaNAZ9No.__iLUTtdlJz90LVGliQf9aQ68R(__bpnL2CgM8dYMGdiLGPdVjhmQ, __Im3kdj312UN9j6s5TpSfKOAs.__LYNzM9N3A8Dmo_1zq54GljKm, __H_DT0F4P9u3L0d2FERrVmg1j, Rect2(camera.position, camera.__7Q1u13W5jsLs8HPva7eP0p0P()))
			var owner: int = __bpnL2CgM8dYMGdiLGPdVjhmQ.__145YNBYj4PTDAeaaNu9tNnKg[6]
			__791Ac4ziZrNNSMrxTb_I3Kp7[__bpnL2CgM8dYMGdiLGPdVjhmQ.__o3MhRIns6p6L9ICgdCGUOTuE] = owner
			if owner == __H_DT0F4P9u3L0d2FERrVmg1j.index:
				__zFPxZ4x_KsoNDuQiG7QR7qOU += 1
				__ntcYuQ5_xrJQSz3m7gFyPFYC += __bpnL2CgM8dYMGdiLGPdVjhmQ.value
			if owner >= 0 and owner < __Im3kdj312UN9j6s5TpSfKOAs.__LYNzM9N3A8Dmo_1zq54GljKm.size() and __Im3kdj312UN9j6s5TpSfKOAs.__LYNzM9N3A8Dmo_1zq54GljKm[owner].__7OKcEzdMfOdabzyMipWdSzWD == __H_DT0F4P9u3L0d2FERrVmg1j.__7OKcEzdMfOdabzyMipWdSzWD:
				__QK4Tkf7mTL3ljYx9WnGAAW_W += __bpnL2CgM8dYMGdiLGPdVjhmQ.value
			if owner >= 0 and owner < __gLoRe5VNudNaczgnAFQL0Z8x.size() and __Im3kdj312UN9j6s5TpSfKOAs.__LYNzM9N3A8Dmo_1zq54GljKm[owner].__7OKcEzdMfOdabzyMipWdSzWD != __Im3kdj312UN9j6s5TpSfKOAs.__LYNzM9N3A8Dmo_1zq54GljKm[__bpnL2CgM8dYMGdiLGPdVjhmQ.__o3MhRIns6p6L9ICgdCGUOTuE].__7OKcEzdMfOdabzyMipWdSzWD:
				__gLoRe5VNudNaczgnAFQL0Z8x[owner] += __bpnL2CgM8dYMGdiLGPdVjhmQ.value
		elif __bpnL2CgM8dYMGdiLGPdVjhmQ.__RZSGss6vMJxzvS6fmWkQMma8 == __QzfA1_MgHwBGTTBizdgA8rkk.__FSW4WCXpupwYSF0KaHCFCNKb.__aO41k8gx8LZFJAoRdHhDtndC:
			if __bpnL2CgM8dYMGdiLGPdVjhmQ.__o3MhRIns6p6L9ICgdCGUOTuE == __H_DT0F4P9u3L0d2FERrVmg1j.index and (__bpnL2CgM8dYMGdiLGPdVjhmQ.__145YNBYj4PTDAeaaNu9tNnKg.size() < 9 or __bpnL2CgM8dYMGdiLGPdVjhmQ.__145YNBYj4PTDAeaaNu9tNnKg[8] == 0):
				__IRvSrr33dhN97m8w8a2ZI1lE += 1
		elif __bpnL2CgM8dYMGdiLGPdVjhmQ.__RZSGss6vMJxzvS6fmWkQMma8 == __QzfA1_MgHwBGTTBizdgA8rkk.__FSW4WCXpupwYSF0KaHCFCNKb.__ib7uB05JH2a_eoqGxv3it3Um:
			__DW5u_PxmVzx39MAyJaNAZ9No.__p4BfRGGYcGsflWTqyV1NyITt(__bpnL2CgM8dYMGdiLGPdVjhmQ, __H_DT0F4P9u3L0d2FERrVmg1j)
		elif __bpnL2CgM8dYMGdiLGPdVjhmQ.__RZSGss6vMJxzvS6fmWkQMma8 == __QzfA1_MgHwBGTTBizdgA8rkk.__FSW4WCXpupwYSF0KaHCFCNKb.__tsbqIr5ld5OPHHXy4mMiC8xs:
			if int(__791Ac4ziZrNNSMrxTb_I3Kp7.get(__bpnL2CgM8dYMGdiLGPdVjhmQ.__o3MhRIns6p6L9ICgdCGUOTuE, -1)) == __H_DT0F4P9u3L0d2FERrVmg1j.index and __Im3kdj312UN9j6s5TpSfKOAs.__LYNzM9N3A8Dmo_1zq54GljKm[__bpnL2CgM8dYMGdiLGPdVjhmQ.__o3MhRIns6p6L9ICgdCGUOTuE].__7OKcEzdMfOdabzyMipWdSzWD != __H_DT0F4P9u3L0d2FERrVmg1j.__7OKcEzdMfOdabzyMipWdSzWD:
				__k4tAH6rGNdvYl6lno95PF0x0 += 1
		elif __bpnL2CgM8dYMGdiLGPdVjhmQ.__RZSGss6vMJxzvS6fmWkQMma8 == __QzfA1_MgHwBGTTBizdgA8rkk.__FSW4WCXpupwYSF0KaHCFCNKb.__Z4zb38Z0p0n5agncEYj9TLFK and __bpnL2CgM8dYMGdiLGPdVjhmQ.value == 0 and __bpnL2CgM8dYMGdiLGPdVjhmQ.__145YNBYj4PTDAeaaNu9tNnKg.size() >= 6 and __H_DT0F4P9u3L0d2FERrVmg1j != null:
			var __qztkvvUNQevgoVm4uKcHL4f5: int = __bpnL2CgM8dYMGdiLGPdVjhmQ.__145YNBYj4PTDAeaaNu9tNnKg[4]
			var owner: int = __bpnL2CgM8dYMGdiLGPdVjhmQ.__145YNBYj4PTDAeaaNu9tNnKg[1]
			if __qztkvvUNQevgoVm4uKcHL4f5 == __H_DT0F4P9u3L0d2FERrVmg1j.index and owner >= 0 and owner < __Im3kdj312UN9j6s5TpSfKOAs.__LYNzM9N3A8Dmo_1zq54GljKm.size() and __Im3kdj312UN9j6s5TpSfKOAs.__LYNzM9N3A8Dmo_1zq54GljKm[owner].__7OKcEzdMfOdabzyMipWdSzWD != __H_DT0F4P9u3L0d2FERrVmg1j.__7OKcEzdMfOdabzyMipWdSzWD:
				__bGkdz3KvT6NvE2AmieSpxtUI += 1
				var __qGJT4C4nU7c86YlmGesE0VdU: int = __9MFWgnc8oYQpY6kqM0OFfhrH.__0202i1SvVujzDqjo_evMz9XF(__bpnL2CgM8dYMGdiLGPdVjhmQ.__145YNBYj4PTDAeaaNu9tNnKg[5])
				__DL2yNM3BV9Lmjk_IjGgO27dt += __qGJT4C4nU7c86YlmGesE0VdU
				if __wbELGtzJYkGkxW7qLn9ltku7 != null and not __pu08ep8gFB8kGVBlMsMmPfl_:
					__wbELGtzJYkGkxW7qLn9ltku7.__NVOfAa1QO8p2fVaQ4QsEZ0Py(tr("UI_BATTLE_AA_CREDIT") % [__bGkdz3KvT6NvE2AmieSpxtUI, __DL2yNM3BV9Lmjk_IjGgO27dt])
	if __wbELGtzJYkGkxW7qLn9ltku7 != null and not __pu08ep8gFB8kGVBlMsMmPfl_:
		var __GGs2nNHlhKYun2FH2NQjyY_2: int = __IRvSrr33dhN97m8w8a2ZI1lE
		__wbELGtzJYkGkxW7qLn9ltku7.__ZfAwU28TKgl1cUKyviqtHaSq(__QK4Tkf7mTL3ljYx9WnGAAW_W, mini(__zFPxZ4x_KsoNDuQiG7QR7qOU, __GGs2nNHlhKYun2FH2NQjyY_2) * 100 / __GGs2nNHlhKYun2FH2NQjyY_2 if __GGs2nNHlhKYun2FH2NQjyY_2 > 0 else 0, __ntcYuQ5_xrJQSz3m7gFyPFYC, __DL2yNM3BV9Lmjk_IjGgO27dt)
func __vAo65UE0pQLvxGOA_O1YS4a8() -> Dictionary:
	if not __898CZFX8zI40Huxp297h_lkH and __rQbCTLm4ikRheIOavyVgPmxH == 0:
		return {}
	if __D6DZnkEZuvO5Z8roRMmWk2nt == null or (__898CZFX8zI40Huxp297h_lkH and (__D6DZnkEZuvO5Z8roRMmWk2nt as Dictionary).is_empty()):
		__D6DZnkEZuvO5Z8roRMmWk2nt = __NaSa_ZIwL9DjG6MZ6yNHvnkr()
	return __D6DZnkEZuvO5Z8roRMmWk2nt
var __zuKfjKUwqReKh1GZj_9rbBYO: int = __lAo0PsogaUvqHw4muTzPsHiR.__nbNt7X55zG6_WZmrWTE7nXlh
var __xdF6xz9WJIAyCFIlMNF3msY1: String = ""
var __W0AIX5_s5ZmzSZEuijQKMEky: = __w6jggbpJmrltNJbzpG2SdrDf.new()
var __gxRURc4MFvkf691WMIX_PoIT: String = ""
func __zdpRVN2_7VlxgfFr07a8dj8X() -> Dictionary:
	var __8wXoNAkxbMvJgDwcrChUX2_I: PackedInt64Array = __EB62kdWxBmEB2Xlff4o0XGma["dmg"] if not __EB62kdWxBmEB2Xlff4o0XGma.is_empty() else __ASM9naUc7LGeAbtWSqS9xNTM()
	var __Xo3sO0DqTXLdWzotrefymuvv: int = int(__EB62kdWxBmEB2Xlff4o0XGma["pool"][__H_DT0F4P9u3L0d2FERrVmg1j.__7OKcEzdMfOdabzyMipWdSzWD]) if not __EB62kdWxBmEB2Xlff4o0XGma.is_empty() else __Im3kdj312UN9j6s5TpSfKOAs.__J7C_o18LIGdZ9b2iqkKpR5o0[__H_DT0F4P9u3L0d2FERrVmg1j.__7OKcEzdMfOdabzyMipWdSzWD]
	var __MyItYRvPyNRAzOH4RvVGTHg0: int = int(__EB62kdWxBmEB2Xlff4o0XGma["end"]) if not __EB62kdWxBmEB2Xlff4o0XGma.is_empty() else __Im3kdj312UN9j6s5TpSfKOAs.__u0nkAKG5lGiEsenIJI6PFvMF
	var __A_WyW2OpjaiY2N6zS2zDnXG8: int = __8wXoNAkxbMvJgDwcrChUX2_I[__H_DT0F4P9u3L0d2FERrVmg1j.__7OKcEzdMfOdabzyMipWdSzWD]
	var __VjvDhi7gqP1C_nNpAhpFg4Jv: int = maxi(__8wXoNAkxbMvJgDwcrChUX2_I[0], __8wXoNAkxbMvJgDwcrChUX2_I[1])
	var __hDyOghj3NwJFbA7enUk4s8aq: int = __MxRtF5kMQ2PhDOJRxJ1ej8ie.__6eO7PI5bMzEA5GZJb78SZ1LV(__Xo3sO0DqTXLdWzotrefymuvv, __Im3kdj312UN9j6s5TpSfKOAs.__B6EBQXlVU15lz9jEUjjfdaw4[__H_DT0F4P9u3L0d2FERrVmg1j.__7OKcEzdMfOdabzyMipWdSzWD], __2ZIL9u7_cM4KOmaAUAdneX5d.meti_reward_hp(__H_DT0F4P9u3L0d2FERrVmg1j), __H_DT0F4P9u3L0d2FERrVmg1j.__RZSGss6vMJxzvS6fmWkQMma8, __A_WyW2OpjaiY2N6zS2zDnXG8, __VjvDhi7gqP1C_nNpAhpFg4Jv, __A_WyW2OpjaiY2N6zS2zDnXG8 > 0 and __A_WyW2OpjaiY2N6zS2zDnXG8 == __VjvDhi7gqP1C_nNpAhpFg4Jv)
	var __ucn9xZfbHpx7RU04RFWmUKRf: int = __H_DT0F4P9u3L0d2FERrVmg1j.__l9VibzAjJA8MnBH74WNhUJZL if __H_DT0F4P9u3L0d2FERrVmg1j.state != __lAo0PsogaUvqHw4muTzPsHiR.__pRO7nOY10o2GAU3KzWQvIvwY and __H_DT0F4P9u3L0d2FERrVmg1j.__F41ZT8z_0zKKqYDFwqS1WGTs <= 0 else __Im3kdj312UN9j6s5TpSfKOAs.__u0nkAKG5lGiEsenIJI6PFvMF
	__hDyOghj3NwJFbA7enUk4s8aq = __MxRtF5kMQ2PhDOJRxJ1ej8ie.__6U088MxIMDA0KhiJnEzHmwiX(__hDyOghj3NwJFbA7enUk4s8aq, __ucn9xZfbHpx7RU04RFWmUKRf, __MyItYRvPyNRAzOH4RvVGTHg0)
	var __eGRRNLFBeQJRnEF3rNmrT3ui: Dictionary = __9MFWgnc8oYQpY6kqM0OFfhrH.__tZYUt1RRgRihT31KMBcK3URJ(__Im3kdj312UN9j6s5TpSfKOAs.__bLc0ZDHxlrSL7QCGVI55zc6I[__H_DT0F4P9u3L0d2FERrVmg1j.index], __rQbCTLm4ikRheIOavyVgPmxH, __MyItYRvPyNRAzOH4RvVGTHg0, __H_DT0F4P9u3L0d2FERrVmg1j.__RZSGss6vMJxzvS6fmWkQMma8)
	return {"ticks": __MyItYRvPyNRAzOH4RvVGTHg0, "stay": mini(__ucn9xZfbHpx7RU04RFWmUKRf, __MyItYRvPyNRAzOH4RvVGTHg0), "mine": __A_WyW2OpjaiY2N6zS2zDnXG8, "best": __VjvDhi7gqP1C_nNpAhpFg4Jv, "exp_raw": __MxRtF5kMQ2PhDOJRxJ1ej8ie.__jFwqhnqGTT88GyqAXfNQgMwD(__hDyOghj3NwJFbA7enUk4s8aq), "cr_raw": int(__eGRRNLFBeQJRnEF3rNmrT3ui["credits"]) + __DL2yNM3BV9Lmjk_IjGgO27dt, "pt_raw": int(__eGRRNLFBeQJRnEF3rNmrT3ui["points"])}
var __0xHkB1yFA97H0R_xTBmMKg67: = __lQA2X_Tbdwp3cdBqDfL8XMPe.new()
var __HwMxXlaf4xpBSYy3rK4yRWvY: Dictionary = {}
var __k4tAH6rGNdvYl6lno95PF0x0: int:
	get: return __0xHkB1yFA97H0R_xTBmMKg67.get_value()
	set(v): __0xHkB1yFA97H0R_xTBmMKg67.set_value(v)
func __D38wuayWXzdzHovfPrGdL14l() -> void :
	__SgEyrIZJCIKq5tHIvreYIf6z = true
	if __898CZFX8zI40Huxp297h_lkH:
		client.__nzYih8Dwbv8gsF4_OC9WyZVf = null
	else:
		__m5TW9MpzzNDZg7II10XZl5MU()
	App.__VyWx49mpJs7424hYJ22diA_s()
func __of00oxcoTvym0dJG2Fz6nIiM(__ajtXRk0nJkiQBo6IQf4GThKI: Dictionary, __NIirYp6Lxc7wjnJPHClW7Pe2: int, __c0d1bgFblSVsoxXbVgWpfy54: int, __lm4tRBY7RGmttmwBqvBuX73U: int, __7ZxJQ_f2AwBqFmJFet1e79mV: Dictionary) -> void :
	var __hTFTYzUjUa0_Nz6tgzRwnL4n: Array = __7ZxJQ_f2AwBqFmJFet1e79mV.get("rows", [])
	var __2LYFJoIbGdDa8O6Z9k6SnHvM: int = 0
	var __govuGw8olaHu7mrKtwEmY4Tn: int = 0
	var __45CKHZlVsPYkyokCIDiib3Ps: int = 0
	for __oztlMbc7HGs96MclnSvSGCrS: Dictionary in __hTFTYzUjUa0_Nz6tgzRwnL4n:
		__2LYFJoIbGdDa8O6Z9k6SnHvM += int(__oztlMbc7HGs96MclnSvSGCrS["lv0"])
		__govuGw8olaHu7mrKtwEmY4Tn += int(__oztlMbc7HGs96MclnSvSGCrS["lv1"]) - int(__oztlMbc7HGs96MclnSvSGCrS["lv0"])
		__45CKHZlVsPYkyokCIDiib3Ps += maxi(0, int(__oztlMbc7HGs96MclnSvSGCrS["need"]) - int(__oztlMbc7HGs96MclnSvSGCrS["exp"]))
	var __wu2h9KTwk4PXdPXHW4Kz5Sgm: int = 0
	var __toOE6pA7asEfj3l5J72jJHni: int = 0
	for s: __YdhZSn3k6BLtSITi5naOCb7n in __Im3kdj312UN9j6s5TpSfKOAs.__LYNzM9N3A8Dmo_1zq54GljKm:
		if s.__7OKcEzdMfOdabzyMipWdSzWD != __H_DT0F4P9u3L0d2FERrVmg1j.__7OKcEzdMfOdabzyMipWdSzWD:
			__wu2h9KTwk4PXdPXHW4Kz5Sgm += 1
			__toOE6pA7asEfj3l5J72jJHni += s.__zMZVCIoyJu5zkEI6YyKqPDoG
	var flags: int = (__KrQVlchyjAqFXcac3Kiw77hk.__wNzCDn9TBUE4DBGX1MgqjvUS if not __EB62kdWxBmEB2Xlff4o0XGma.is_empty() else 0) | (__KrQVlchyjAqFXcac3Kiw77hk.__iy1RC1XM1JEHrJQ8fUJHTi6b if __NIirYp6Lxc7wjnJPHClW7Pe2 < int(__ajtXRk0nJkiQBo6IQf4GThKI["exp_raw"]) or __c0d1bgFblSVsoxXbVgWpfy54 < int(__ajtXRk0nJkiQBo6IQf4GThKI["cr_raw"]) or __lm4tRBY7RGmttmwBqvBuX73U < int(__ajtXRk0nJkiQBo6IQf4GThKI["pt_raw"]) else 0)
	var __VV7w4E5lNv09Pq6znDw235ZO: int = int(__7ZxJQ_f2AwBqFmJFet1e79mV.get("clock_flags", 0))
	if __VV7w4E5lNv09Pq6znDw235ZO & __5N6awaIMq5qNkafjTDM69PIs.Flag.__hSweOGeAehf1dT7yq39zFMMT: flags |= __KrQVlchyjAqFXcac3Kiw77hk.__RyELFK4DyigjNjyiwF22YaRU
	if __VV7w4E5lNv09Pq6znDw235ZO & __5N6awaIMq5qNkafjTDM69PIs.Flag.__PJBeiMZaF_5nyghh0H03V7ln: flags |= __KrQVlchyjAqFXcac3Kiw77hk.__OX6Y5BpPcNpvquZhYnts0qiy
	if __VV7w4E5lNv09Pq6znDw235ZO & __5N6awaIMq5qNkafjTDM69PIs.Flag.__3IxPaHZDtb_exwBOHwDP9sVm: flags |= __KrQVlchyjAqFXcac3Kiw77hk.__sFIDO9hf5G0lSQodjvsznwGM
	var __gPYfQOpEQudyst8FfPaYzjvL: Dictionary = __W0AIX5_s5ZmzSZEuijQKMEky.__50Wjs3O3Xiqibj0r9hRW2DIU() if not __898CZFX8zI40Huxp297h_lkH else {}
	__gPYfQOpEQudyst8FfPaYzjvL["clock_sim_ms"] = int(__7ZxJQ_f2AwBqFmJFet1e79mV.get("clock_sim_ms", 0))
	__gPYfQOpEQudyst8FfPaYzjvL["clock_wall_ms"] = int(__7ZxJQ_f2AwBqFmJFet1e79mV.get("clock_wall_ms", 0))
	__gPYfQOpEQudyst8FfPaYzjvL["clock_samples"] = int(__7ZxJQ_f2AwBqFmJFet1e79mV.get("clock_samples", 0))
	__gPYfQOpEQudyst8FfPaYzjvL["clock_flags"] = __VV7w4E5lNv09Pq6znDw235ZO
	__KrQVlchyjAqFXcac3Kiw77hk.__EQSSy6KHEM37BgV1J4KGqz8Y().append({"mode": 1 if __898CZFX8zI40Huxp297h_lkH else 0, "outcome": __rQbCTLm4ikRheIOavyVgPmxH, "rules_ver": int(__9MFWgnc8oYQpY6kqM0OFfhrH.__qyvbOrjVYs2zGM2jUVQYSgGR().get("version", 0)), "frame_row": __H_DT0F4P9u3L0d2FERrVmg1j.__WeB9Hi0OxaFBUuwm2WU2qKEH, "kind": __H_DT0F4P9u3L0d2FERrVmg1j.__RZSGss6vMJxzvS6fmWkQMma8, "level": __H_DT0F4P9u3L0d2FERrVmg1j.__zMZVCIoyJu5zkEI6YyKqPDoG, "ticks_total": int(__ajtXRk0nJkiQBo6IQf4GThKI["ticks"]), "ticks_stay": int(__ajtXRk0nJkiQBo6IQf4GThKI["stay"]), "sunk": 1 if __H_DT0F4P9u3L0d2FERrVmg1j.__F41ZT8z_0zKKqYDFwqS1WGTs <= 0 else 0, "mvp": 1 if int(__ajtXRk0nJkiQBo6IQf4GThKI["mine"]) > 0 and int(__ajtXRk0nJkiQBo6IQf4GThKI["mine"]) == int(__ajtXRk0nJkiQBo6IQf4GThKI["best"]) else 0, "map_id": __Uvzp2Nhc4YbduKNpA08hrEu5.__lZ8vjU390FVMnZ8cocVoR8mr if __898CZFX8zI40Huxp297h_lkH and __Uvzp2Nhc4YbduKNpA08hrEu5 != null else int(setup.get("map_id", 0)), "dmg_mine": __gLoRe5VNudNaczgnAFQL0Z8x[__H_DT0F4P9u3L0d2FERrVmg1j.index] if __H_DT0F4P9u3L0d2FERrVmg1j.index < __gLoRe5VNudNaczgnAFQL0Z8x.size() else __ntcYuQ5_xrJQSz3m7gFyPFYC, "dmg_best": int(__ajtXRk0nJkiQBo6IQf4GThKI["best"]), "hit_credit": __Im3kdj312UN9j6s5TpSfKOAs.__bLc0ZDHxlrSL7QCGVI55zc6I[__H_DT0F4P9u3L0d2FERrVmg1j.index], "air_kills": __bGkdz3KvT6NvE2AmieSpxtUI, "air_credit": __DL2yNM3BV9Lmjk_IjGgO27dt, "exp_raw": int(__ajtXRk0nJkiQBo6IQf4GThKI["exp_raw"]), "exp_got": __NIirYp6Lxc7wjnJPHClW7Pe2, "exp_knee": __9MFWgnc8oYQpY6kqM0OFfhrH.__VXHR8_PK6BdTYDw2QpZIqbI8(__H_DT0F4P9u3L0d2FERrVmg1j.__zMZVCIoyJu5zkEI6YyKqPDoG), "cr_raw": int(__ajtXRk0nJkiQBo6IQf4GThKI["cr_raw"]), "cr_got": __c0d1bgFblSVsoxXbVgWpfy54, "pt_raw": int(__ajtXRk0nJkiQBo6IQf4GThKI["pt_raw"]), "pt_got": __lm4tRBY7RGmttmwBqvBuX73U, "cr_knee": __9MFWgnc8oYQpY6kqM0OFfhrH.__rFs4lEQBnf7Box5_CDGsnZ5B(__H_DT0F4P9u3L0d2FERrVmg1j.__zMZVCIoyJu5zkEI6YyKqPDoG), "crew_n": __hTFTYzUjUa0_Nz6tgzRwnL4n.size(), "crew_avg_lv": __2LYFJoIbGdDa8O6Z9k6SnHvM / __hTFTYzUjUa0_Nz6tgzRwnL4n.size() if __hTFTYzUjUa0_Nz6tgzRwnL4n.size() > 0 else 0, "crew_lvups": __govuGw8olaHu7mrKtwEmY4Tn, "enemy_avg_lv": __toOE6pA7asEfj3l5J72jJHni / __wu2h9KTwk4PXdPXHW4Kz5Sgm if __wu2h9KTwk4PXdPXHW4Kz5Sgm > 0 else 0, "crew_to_next": __45CKHZlVsPYkyokCIDiib3Ps / __hTFTYzUjUa0_Nz6tgzRwnL4n.size() if __hTFTYzUjUa0_Nz6tgzRwnL4n.size() > 0 else 0, "flags": flags, "difficulty": __Im3kdj312UN9j6s5TpSfKOAs.__f8I9gUlf4vPw6xR4KNFvw66k, }.merged(__gPYfQOpEQudyst8FfPaYzjvL))
var __hDON5_Ak_v4LQsqfesSFUaa2: __tALbI77Bj72RNkUjx1rJalbI
func __0HyQkKSIPfVuTPxYFxdIU3Cq(code: int, __HVOlGcC60mOYCRBVwutS_vHM: PackedByteArray) -> void :
	if __5zsHBwGhnk5X3Ays_WuwIBnz != null or __H_DT0F4P9u3L0d2FERrVmg1j.state != __lAo0PsogaUvqHw4muTzPsHiR.__pRO7nOY10o2GAU3KzWQvIvwY:
		return
	if code == __lAo0PsogaUvqHw4muTzPsHiR.__K1NW_qnIvknoGGkxaf24lsNr:
		var __mg6FAhHD9URlHwoR__nvDIFx: String = __jH2InQdnict_gW0jdXgBh2Ns.__VbyuzGrRF0hms07Qs5WTCSLz(__H_DT0F4P9u3L0d2FERrVmg1j)
		if __mg6FAhHD9URlHwoR__nvDIFx != "":
			__G2zYsJx5HRFiDZUAlfwnf1IN(__mg6FAhHD9URlHwoR__nvDIFx)
	elif code == __lAo0PsogaUvqHw4muTzPsHiR.__sKP2pX8KjRdyhsUnZlBoy8m7:
		__H1kWP_uRU_4T8c7RAuJRJSNi = (__H1kWP_uRU_4T8c7RAuJRJSNi + 1) % 3
		Settings.set_value("fire_mode", __H1kWP_uRU_4T8c7RAuJRJSNi)
		UI.__Qyp4Js7J9ejl5FSF4pVpfEi5(__YdhZSn3k6BLtSITi5naOCb7n.__GZTWhWj5KdYoklE6k3RT7Hp2(__H1kWP_uRU_4T8c7RAuJRJSNi))
	__CjmY96ucMnR54d8UC0PF7fMV(code, __HVOlGcC60mOYCRBVwutS_vHM)
var __zFPxZ4x_KsoNDuQiG7QR7qOU: int:
	get: return __oGQ4RXn5cKC7Lk331Q81Ys_V.get_value()
	set(v): __oGQ4RXn5cKC7Lk331Q81Ys_V.set_value(v)
var __791Ac4ziZrNNSMrxTb_I3Kp7: Dictionary = {}
func __mQCDAUi7FzMVng4v3rDeuucj(events: Array[__QzfA1_MgHwBGTTBizdgA8rkk]) -> void :
	if __g7JC3EJmfsOWnIyqLGGB93eB == null:
		return
	if __wbELGtzJYkGkxW7qLn9ltku7.__t3y1cnuny6w_2nwErOwdsvQP != null:
		__wbELGtzJYkGkxW7qLn9ltku7.__t3y1cnuny6w_2nwErOwdsvQP.__CvD5tKr35VYLv9Cz25Ct38zL(events)
	if __5zsHBwGhnk5X3Ays_WuwIBnz == null and __H_DT0F4P9u3L0d2FERrVmg1j.state == __lAo0PsogaUvqHw4muTzPsHiR.__pRO7nOY10o2GAU3KzWQvIvwY:
		__g7JC3EJmfsOWnIyqLGGB93eB.__kC6zD903kIOB35eRqjx8Rhn6()
	for __Ad7ljoskPfuON6j3z5evMPJL: __QzfA1_MgHwBGTTBizdgA8rkk in events:
		if __Ad7ljoskPfuON6j3z5evMPJL.__RZSGss6vMJxzvS6fmWkQMma8 == __QzfA1_MgHwBGTTBizdgA8rkk.__FSW4WCXpupwYSF0KaHCFCNKb.__7u4clDqtCMcaEbPT4aWekmiB and __Ad7ljoskPfuON6j3z5evMPJL.__o3MhRIns6p6L9ICgdCGUOTuE == __H_DT0F4P9u3L0d2FERrVmg1j.index:
			var __WjRbJgaQXtG9mFpgUTFeX3Tz: int = Time.get_ticks_msec()
			if __WjRbJgaQXtG9mFpgUTFeX3Tz - __gt_3Npy2nSfXotDarWn3jYtq > 2000:
				UI.__Qyp4Js7J9ejl5FSF4pVpfEi5(tr("UI_AIR_MSG_DIVE_ALT"))
			__gt_3Npy2nSfXotDarWn3jYtq = __WjRbJgaQXtG9mFpgUTFeX3Tz
var __gLoRe5VNudNaczgnAFQL0Z8x: PackedInt32Array:
	get: return __mmFfxzFJBSbDwmcmgECiPiAR.__2XdtP7H_Faf9mNAEdtZxWBKN()
	set(v): __mmFfxzFJBSbDwmcmgECiPiAR.__CIhyJB18Fzv4dVyq3m7Of8SS(v)
var __7sOR9PIY6lXhjjgKSq9t0fJL: = __lQA2X_Tbdwp3cdBqDfL8XMPe.new()
func __bx57LdWnJinT2XHAnsga12wK() -> void :
	if __rQbCTLm4ikRheIOavyVgPmxH == 0:
		var __BijcijPsTCrMaF7ASeabnmCS: int = __Im3kdj312UN9j6s5TpSfKOAs.__6UoHldZawwvQeZTuLJQHRrnw()
		if __BijcijPsTCrMaF7ASeabnmCS == 0 and not __898CZFX8zI40Huxp297h_lkH and __Im3kdj312UN9j6s5TpSfKOAs.__u0nkAKG5lGiEsenIJI6PFvMF >= __k4tJVsMbRmcRrzVGv3Bdb2bj:
			__BijcijPsTCrMaF7ASeabnmCS = __TbAkFifAS33uxKcFDf16mKl5.__p_p1Wx3sVcyN02NXv70x3uDv.__cQ_gfQ2gW5LHIZ6LdqbCvVTF
		if __BijcijPsTCrMaF7ASeabnmCS == 0:
			return
		__rQbCTLm4ikRheIOavyVgPmxH = __4kuWb3XCQlF_JVzFT1aeoeA4(__BijcijPsTCrMaF7ASeabnmCS)
		__rtep__1NaeBRnIaPLRs7keNF = __Im3kdj312UN9j6s5TpSfKOAs.__u0nkAKG5lGiEsenIJI6PFvMF
	elif not __Mg6jxghXyZs3zgCi_qR1PwSb and not __898CZFX8zI40Huxp297h_lkH and not __LJD_DLosLmVUkX41Kalx6Ttc and __Im3kdj312UN9j6s5TpSfKOAs.__u0nkAKG5lGiEsenIJI6PFvMF - __rtep__1NaeBRnIaPLRs7keNF >= __jopGolxuYOytI1kIbVUR0Abj:
		__Mg6jxghXyZs3zgCi_qR1PwSb = true
		__F_jehFX5RJNUEjsCJ2T8nanH()
var __1GEiijgEuP6kQplREzdJ_7E0: bool = false
var __ntcYuQ5_xrJQSz3m7gFyPFYC: int:
	get: return __7sOR9PIY6lXhjjgKSq9t0fJL.get_value()
	set(v): __7sOR9PIY6lXhjjgKSq9t0fJL.set_value(v)
func __iMall8mB5R0iCf4lBncKqddf(__SFc9MOh_6YKVE0ZEPQhCeYDW: int) -> void :
	if __5zsHBwGhnk5X3Ays_WuwIBnz != null or __H_DT0F4P9u3L0d2FERrVmg1j == null:
		return
	var r: int = __jH2InQdnict_gW0jdXgBh2Ns.__jLwbnooSantJgACMn465LGnL(__H_DT0F4P9u3L0d2FERrVmg1j, __SFc9MOh_6YKVE0ZEPQhCeYDW == __ZHwJr3sB730Xm67xCNPRVjTe.__7p66fpI27Ejh1nHovTpHSGpN.__zkQ5054TYL04Pmzq9fdL45rm)
	if r >= 0:
		__0HyQkKSIPfVuTPxYFxdIU3Cq(__lAo0PsogaUvqHw4muTzPsHiR.__6Z410v1VboT0hLD2rdNAdHy8, __qUuRE3qEzIGmcU0ysMMtWssY.__It3Y2BjKAtGZJyez5KMqb_lE(r))
	elif __jH2InQdnict_gW0jdXgBh2Ns.__Tr70y0k3PKrcMaN5NkLJaz7a.has(r):
		__G2zYsJx5HRFiDZUAlfwnf1IN(__jH2InQdnict_gW0jdXgBh2Ns.__Tr70y0k3PKrcMaN5NkLJaz7a[r])
const __wqyG4SbwP5c4W0bx6ivd1v5u: = 30000
func begin(__HGFctJZ3jbhWQPJgM0ldfI3o: Dictionary) -> void :
	__vCaHebXeTSk5ki_sJbb3gGEn = false
	__W0AIX5_s5ZmzSZEuijQKMEky = __w6jggbpJmrltNJbzpG2SdrDf.new()
	paused = false
	UI.clear()
	__iAbDeha6hgeEpDzp_OVLHMcN = __HGFctJZ3jbhWQPJgM0ldfI3o
	__zuKfjKUwqReKh1GZj_9rbBYO = clampi(int(__HGFctJZ3jbhWQPJgM0ldfI3o.get("difficulty", __zuKfjKUwqReKh1GZj_9rbBYO)), __lAo0PsogaUvqHw4muTzPsHiR.___2WtfK17HDU4ZlLEJlLUcifm, __lAo0PsogaUvqHw4muTzPsHiR.__nbNt7X55zG6_WZmrWTE7nXlh)
	__2CEP4kl7Sdh3BZ1WciRGEAL0 = int(__HGFctJZ3jbhWQPJgM0ldfI3o.get("shot", 0))
	__xdF6xz9WJIAyCFIlMNF3msY1 = str(__HGFctJZ3jbhWQPJgM0ldfI3o.get("out", "user://shot.png"))
	__gxRURc4MFvkf691WMIX_PoIT = str(__HGFctJZ3jbhWQPJgM0ldfI3o.get("shot_stall", ""))
	__898CZFX8zI40Huxp297h_lkH = str(__HGFctJZ3jbhWQPJgM0ldfI3o.get("mode", "")) == "net"
	if __898CZFX8zI40Huxp297h_lkH:
		client = Session.client
		__Uvzp2Nhc4YbduKNpA08hrEu5 = client.setup
		setup = __Ti__RyaVjFAbq0eWKyiulRtX.__eC2Gef0hq8YlwrdVcs2tTLeg(__Uvzp2Nhc4YbduKNpA08hrEu5)
		__Im3kdj312UN9j6s5TpSfKOAs = __Ti__RyaVjFAbq0eWKyiulRtX.__YNjSGlrkuU4xu5LIhzsrDpM7(App.___qFCN2viGM2bPW1uGV9qys9h(), setup)
		__H_DT0F4P9u3L0d2FERrVmg1j = __Im3kdj312UN9j6s5TpSfKOAs.__LYNzM9N3A8Dmo_1zq54GljKm[maxi(0, __Uvzp2Nhc4YbduKNpA08hrEu5.__9X3lUNXcQD5jKQrJ56a0JZ82(client.__bEaVqnUpkbc9pnzD2IA0HDfW.__WGEyCfWpyvUvMNc11zQw82Tr))]
		__BNtiAVKkxXLbNTzY2JctenZq = __dt7myedK5AYqgRX_SVD2qUee.new(__Im3kdj312UN9j6s5TpSfKOAs, queue, __ZiG9DqFDEiEyq21OsrGR3LI9, client.__LiG2Xr3oChzrk_Rq0co9_rk8)
		__BNtiAVKkxXLbNTzY2JctenZq.__npo0EpGkICEhr8bUFTlkSz8a.connect(__fo_QixeS5zCMq9jlAC8dEJNj)
		__BNtiAVKkxXLbNTzY2JctenZq.__tBbsjYZzbJIEG2_JqkxHzbwu.connect(__yra4cvXO1zvZcUlEgJXSrg6l)
		__BNtiAVKkxXLbNTzY2JctenZq.__7lkHIpUt1zX9l9oLqhZ44PdT.connect( func(__icdiV7V4IVJeaSmNszuOiqOX: int) -> void : __s8T5oktgGgD34cS5bqLx7M4q += __icdiV7V4IVJeaSmNszuOiqOX)
		__o5d4_jO9yZhivIzUiP0l8tys(client.__oXaicmZpxo_JMCyK5dWoEXIA, __8zeRLqvwZ9Oswm0rTuSnPick)
		__o5d4_jO9yZhivIzUiP0l8tys(client.__sxaBD88khnoRWZUGP03waIa4, __mT8Bp2SMqz7JpPTq617FmdMN)
		__o5d4_jO9yZhivIzUiP0l8tys(client.__BfFq33l_d1cInDuN38j9MWNm, __0DRZevprYoqfQvWPztROS7nl)
		__o5d4_jO9yZhivIzUiP0l8tys(client.__teLr9rAmE_GGYekTJ8KXyCxW, __bFGIFOjLp4DCAQz2pYRzWdbG)
		__o5d4_jO9yZhivIzUiP0l8tys(client.__I5g6Fr7xEyzSD804XpZWkkpy, func(__62elgsoCZ1UnusVWyN84aGLv: int) -> void : __BiQoQGi6zNoff3oBH5w2ocqb = __62elgsoCZ1UnusVWyN84aGLv)
	else:
		var __g0ZCp4imarQlxpZ7mAbth3by: __aTOx5XAvuUIxfTwxoFTG10xf = __aTOx5XAvuUIxfTwxoFTG10xf.__x4dRhV0emeOXyfnjujX6iOAP(str(__HGFctJZ3jbhWQPJgM0ldfI3o.get("scenario", App.__zKZrf1ciyEFELFgvd_rF5hzx)))
		if __g0ZCp4imarQlxpZ7mAbth3by == null:
			push_error("场景文件读不了：%s" % __HGFctJZ3jbhWQPJgM0ldfI3o.get("scenario"))
			App.__XA31hlcqDbRgIKg3l91mYJVw()
			return
		if bool(__HGFctJZ3jbhWQPJgM0ldfI3o.get("replay", false)):
			setup = __g0ZCp4imarQlxpZ7mAbth3by.__LUz19fCayjoohhRWMm88VWzt
			__5zsHBwGhnk5X3Ays_WuwIBnz = __g0ZCp4imarQlxpZ7mAbth3by
			__Im3kdj312UN9j6s5TpSfKOAs = __g0ZCp4imarQlxpZ7mAbth3by.__Lm8m8Y33Qa0_kR8B57PWf2CO(App.___qFCN2viGM2bPW1uGV9qys9h())
		else:
			setup = __SkAl4wMOrSNj22qH2dKbbJM3(__HGFctJZ3jbhWQPJgM0ldfI3o)
			print("单机布阵：世界 %d×%d 格" % [int(setup["world"]["cols"]), int(setup["world"]["rows"])])
			__Im3kdj312UN9j6s5TpSfKOAs = __Ti__RyaVjFAbq0eWKyiulRtX.__YNjSGlrkuU4xu5LIhzsrDpM7(App.___qFCN2viGM2bPW1uGV9qys9h(), setup)
		__H_DT0F4P9u3L0d2FERrVmg1j = __emgjXOD_icqI4OOSMXeVRZez()
		__Szndsmt47uTQYpRKJToURNl7 = __BM01A0hfXxtKzcEAsrrhw94R.new()
		__Szndsmt47uTQYpRKJToURNl7.__EHNWWW800rvwE6H3J121RKc9 = true
	__B03hDgmIU4O8q341eLf_67xq = __Im3kdj312UN9j6s5TpSfKOAs.__EeaM5brz45Ll1madYIYSP5pp()
	__PDz2BjB1mbrZMzHiimUkaczG()
	var z: = PackedInt32Array()
	z.resize(__Im3kdj312UN9j6s5TpSfKOAs.__LYNzM9N3A8Dmo_1zq54GljKm.size())
	__gLoRe5VNudNaczgnAFQL0Z8x = z
	__XcEBuZmYff2OSNt7_4huxaTI = __hOFKwxC8l_wy2rZeDG2LnkV_.new(__Im3kdj312UN9j6s5TpSfKOAs.__LYNzM9N3A8Dmo_1zq54GljKm.size())
	if __H_DT0F4P9u3L0d2FERrVmg1j.__g7JC3EJmfsOWnIyqLGGB93eB != null:
		for __uSp4LWdvwRtWcJ8oUXr_Q6Ln: int in __H_DT0F4P9u3L0d2FERrVmg1j.__g7JC3EJmfsOWnIyqLGGB93eB.__xYLJ4HxXNYIH9o2lodd303ua.size():
			__2omsALYMZSn3ijkiFbTa0YhU[__uSp4LWdvwRtWcJ8oUXr_Q6Ln] = int(__H_DT0F4P9u3L0d2FERrVmg1j.__g7JC3EJmfsOWnIyqLGGB93eB.__ovmWIjR9MK5E3k8GPT1QWt_B[int((__H_DT0F4P9u3L0d2FERrVmg1j.__g7JC3EJmfsOWnIyqLGGB93eB.__xYLJ4HxXNYIH9o2lodd303ua[__uSp4LWdvwRtWcJ8oUXr_Q6Ln] as Dictionary)["type"])])
	__jPl56qRp4FciYYHXDmLtD2k2()
	__0ebdt1P4SN2l7nmmh7JZeojA.visible = true
	camera.__kPB6WrEOPKVp2mDZNM_ZEE0m = true
	camera.__ygQpjlnLTsRv_t24LnuR1ohD(Vector2(__H_DT0F4P9u3L0d2FERrVmg1j.x(), __H_DT0F4P9u3L0d2FERrVmg1j.y()))
	var __BF6qpwSbYGFviWXa629QDx13: = CanvasLayer.new()
	__BF6qpwSbYGFviWXa629QDx13.layer = 50
	add_child(__BF6qpwSbYGFviWXa629QDx13)
	__F8HZCw7buuEBi0A0Mf6znYAe = __tvt9CszM3uusC1HqCxL1X84m.new()
	__BF6qpwSbYGFviWXa629QDx13.add_child(__F8HZCw7buuEBi0A0Mf6znYAe)
	__doKOKtoKy3i4SBlfmjnARw4_ = __s_qOeBtjnb9HkxVxzl6YMKdK.new()
	__BF6qpwSbYGFviWXa629QDx13.add_child(__doKOKtoKy3i4SBlfmjnARw4_)
	__323DjHVpeKq9qbqbhN5ocoRI = __jjKPQ5KMtbz3utndERcEBisR.new()
	__323DjHVpeKq9qbqbhN5ocoRI.name = "Input"
	add_child(__323DjHVpeKq9qbqbhN5ocoRI)
	__323DjHVpeKq9qbqbhN5ocoRI.camera = camera
	__323DjHVpeKq9qbqbhN5ocoRI.__opR4fKhG5cmcetfWMxSAxkbZ = __0HyQkKSIPfVuTPxYFxdIU3Cq
	__323DjHVpeKq9qbqbhN5ocoRI.__gqeoroAmXF13AaG6h7gFLP0E = __9im0usQslI7QC1gjJqA79Guj
	__323DjHVpeKq9qbqbhN5ocoRI.__dzAhuh1v1A8DpllGMZIzXIbq.connect(__SMEvAsLM6A8YhavSCs8EA7QU)
	__323DjHVpeKq9qbqbhN5ocoRI.__BhbJ641mrCWayIW9JYZPJ1uz = __yS_eFWQpHQh4Iwo2AO9wcsbL
	__323DjHVpeKq9qbqbhN5ocoRI.__k5hx6NeOCo7HA2masbk8ussz = __iMall8mB5R0iCf4lBncKqddf
	__323DjHVpeKq9qbqbhN5ocoRI.__87z_B4EW4nnoCc_qmKuMvE3C = func() -> bool: return __H_DT0F4P9u3L0d2FERrVmg1j != null and __H_DT0F4P9u3L0d2FERrVmg1j.__sfrhGgpP8JHW6nvd0GQRC91I
	__323DjHVpeKq9qbqbhN5ocoRI.__ldHxpzoGBjj2QUkNJBoWYG1X = func() -> bool: return __H_DT0F4P9u3L0d2FERrVmg1j != null and __H_DT0F4P9u3L0d2FERrVmg1j.__MpnqF3TEucSJpg5SlIfA6pFP()
	__323DjHVpeKq9qbqbhN5ocoRI.__z0uZ3nExJNxZuJq9NXCcBWM8 = func() -> int: return __H_DT0F4P9u3L0d2FERrVmg1j.__7pjg1aLmopfQC2fotNH01Sr1() if __H_DT0F4P9u3L0d2FERrVmg1j != null else 0
	__AQ1E4IB2xjKUZDj84PMq7p0n = __CnHLFuemzEF6fvMpwe7EnocH.new()
	__AQ1E4IB2xjKUZDj84PMq7p0n.__ozvIRbROi2ytRE660_lBLW16 = camera.__ozvIRbROi2ytRE660_lBLW16
	__AQ1E4IB2xjKUZDj84PMq7p0n.__OIYqDJXDDzt5rLpfnxCGBKRN = __wbELGtzJYkGkxW7qLn9ltku7.__OIYqDJXDDzt5rLpfnxCGBKRN
	__323DjHVpeKq9qbqbhN5ocoRI.add_source(__AQ1E4IB2xjKUZDj84PMq7p0n)
	__wbELGtzJYkGkxW7qLn9ltku7.__aWkYw_ILTtySHgVTtX3gmlyw.__amjSAeMkwW6bdBnodHztyRRa.connect(__fXj045rwdfjWIfF_Xd9YYADm)
	camera.__x1ZWrZVHvyyZBJfyHEWtJRnW = func() -> bool: return __AQ1E4IB2xjKUZDj84PMq7p0n.__x1ZWrZVHvyyZBJfyHEWtJRnW() or __wbELGtzJYkGkxW7qLn9ltku7.__aWkYw_ILTtySHgVTtX3gmlyw.__LsepUUfGjjOgFIDcKvHfvVNm
	if bool(__HGFctJZ3jbhWQPJgM0ldfI3o.get("autopilot", false)):
		__pb0UqI8FdD0J1iBIy_gOmQuA = __5VyZOcBPX5I8DadXDQn6ZnrI.new()
		__pb0UqI8FdD0J1iBIy_gOmQuA.bind(__Im3kdj312UN9j6s5TpSfKOAs, __H_DT0F4P9u3L0d2FERrVmg1j)
		__pb0UqI8FdD0J1iBIy_gOmQuA.__g7JC3EJmfsOWnIyqLGGB93eB = __g7JC3EJmfsOWnIyqLGGB93eB
		__pb0UqI8FdD0J1iBIy_gOmQuA.__WclRKgCObOC2XzFVu8lJjpfR = __wbELGtzJYkGkxW7qLn9ltku7.__t3y1cnuny6w_2nwErOwdsvQP
		__323DjHVpeKq9qbqbhN5ocoRI.add_source(__pb0UqI8FdD0J1iBIy_gOmQuA)
	__DW5u_PxmVzx39MAyJaNAZ9No = __wwV6ocUMzL2wx2wFAgrr7A7T.new()
	__DW5u_PxmVzx39MAyJaNAZ9No.name = "Audio"
	add_child(__DW5u_PxmVzx39MAyJaNAZ9No)
	__nvtHehTtgAm979A1wLl1o1st.start()
	if not __898CZFX8zI40Huxp297h_lkH and __5zsHBwGhnk5X3Ays_WuwIBnz == null:
		__p0VcvihgtXhiKjC_wbNpnF4q.start(__Im3kdj312UN9j6s5TpSfKOAs.__u0nkAKG5lGiEsenIJI6PFvMF)
	if __898CZFX8zI40Huxp297h_lkH:
		client.__B3kna7_kYTjyK6PQoZb3eb5m()
func __SkAl4wMOrSNj22qH2dKbbJM3(__C0TTMukFfOR0CUEr81Yc06ed: Dictionary) -> Dictionary:
	var __lFYEQYh6XzGXUN9gTbjvUjv4: __aTOx5XAvuUIxfTwxoFTG10xf = __aTOx5XAvuUIxfTwxoFTG10xf.__x4dRhV0emeOXyfnjujX6iOAP(str(__C0TTMukFfOR0CUEr81Yc06ed.get("scenario", App.__zKZrf1ciyEFELFgvd_rF5hzx)))
	if __lFYEQYh6XzGXUN9gTbjvUjv4 == null:
		return {}
	var s: Dictionary = __U7UMfwBewiXSLEeaDnywaCO7.__tQ0BmdJ0bbPzsZhkncHnyjT7(__lFYEQYh6XzGXUN9gTbjvUjv4.__LUz19fCayjoohhRWMm88VWzt, __83TSym9czt1PBDgaopjy6rEQ)
	var __8rYl9x1MOym88niWHpLRIaU7: Vector2i = __C0TTMukFfOR0CUEr81Yc06ed.get("npc_level_range", __svN_fv5m0UGKw8JIYuTHIUfI)
	if __8rYl9x1MOym88niWHpLRIaU7 != Vector2i.ZERO:
		s = __U7UMfwBewiXSLEeaDnywaCO7.__mTW0cLqTcwX9tidha0dPCkgy(s, __ny0DWNynYxcUApZV6IS26JNR, __8rYl9x1MOym88niWHpLRIaU7)
	if __C0TTMukFfOR0CUEr81Yc06ed.get("player_ship") is __s8yZigV26lPAvEmbOWzMbnjE:
		s = __U7UMfwBewiXSLEeaDnywaCO7.__I2But7PKh2zTXo5HkI75Gs7k(s, __C0TTMukFfOR0CUEr81Yc06ed["player_ship"])
	s = __U7UMfwBewiXSLEeaDnywaCO7.__0Hf_29iZ7PzZlTirdeU0dHdI(s, __ny0DWNynYxcUApZV6IS26JNR, __8rYl9x1MOym88niWHpLRIaU7)
	s = __U7UMfwBewiXSLEeaDnywaCO7.__zZNA1WJf2IOBjuzxgNSRAA6B(s, __ny0DWNynYxcUApZV6IS26JNR, __JmicKnMOUqYWokzP32Q2v9RX)
	s = __U7UMfwBewiXSLEeaDnywaCO7.__oFO7bplEnBWVpM9dvH2aRbaI(s, __ny0DWNynYxcUApZV6IS26JNR)
	s = __U7UMfwBewiXSLEeaDnywaCO7.__NKM5L0xChll3cOZcEXnavPlj(s, __ny0DWNynYxcUApZV6IS26JNR)
	s = __U7UMfwBewiXSLEeaDnywaCO7.__EAS0DpTiSLR0ok88UEwWqG5z(s)
	if not __898CZFX8zI40Huxp297h_lkH and not bool(__C0TTMukFfOR0CUEr81Yc06ed.get("replay", false)):
		s = load("res://client/offline/meti_elite_enemy.gdc").apply(s, __ny0DWNynYxcUApZV6IS26JNR)
	s["world"]["difficulty"] = __zuKfjKUwqReKh1GZj_9rbBYO
	s = __Ti__RyaVjFAbq0eWKyiulRtX.__seS0s7G0_4jIjhaag7fncTHn(s)
	var spread: Array = __U7UMfwBewiXSLEeaDnywaCO7.spread(App.___qFCN2viGM2bPW1uGV9qys9h(), s)
	__FqDMuIQZqiEvYVSmnPHhjSMa = spread[3]
	return spread[0]
func __CjmY96ucMnR54d8UC0PF7fMV(code: int, __G1YvH7hDnrzje_ddoQE2LUBL: PackedByteArray) -> void :
	if __898CZFX8zI40Huxp297h_lkH:
		__ZiG9DqFDEiEyq21OsrGR3LI9.__EHNWWW800rvwE6H3J121RKc9(code, __G1YvH7hDnrzje_ddoQE2LUBL, __Im3kdj312UN9j6s5TpSfKOAs.__t2UdGLb5AjoD9DJacXSIpDUA)
		__1lT38LAdcUETU4FP4xOZDWAU.append(Vector2i(code, Time.get_ticks_msec()))
		var __LSupD7UxD8yNherQS_6yHJBC: __kES0xf2B9McTZ5j15H1qFgN9 = __ZiG9DqFDEiEyq21OsrGR3LI9.__CADYmOuCQOfWhLmSXLFzKn73()
		if __LSupD7UxD8yNherQS_6yHJBC != null:
			client.__LiG2Xr3oChzrk_Rq0co9_rk8(__LSupD7UxD8yNherQS_6yHJBC)
	else:
		__Szndsmt47uTQYpRKJToURNl7.__aGBBEQYWc8Up7HiqcfOKNODR(__Im3kdj312UN9j6s5TpSfKOAs, __H_DT0F4P9u3L0d2FERrVmg1j.index, code, __G1YvH7hDnrzje_ddoQE2LUBL)
func __XkTmIcupKCOz_0RuPpASvUVm() -> void :
	if not __LJD_DLosLmVUkX41Kalx6Ttc:
		return
	__LJD_DLosLmVUkX41Kalx6Ttc = false
	__F8HZCw7buuEBi0A0Mf6znYAe.get_parent().visible = true
	UI.pop()
	Music.play(__nvtHehTtgAm979A1wLl1o1st.current)
var queue: = __ozeAqkdv9EkRJrUncrrQmESF.new()
func __Osq6zMWpMqS1sxxVc5GLMDPW() -> void :
	if __H_DT0F4P9u3L0d2FERrVmg1j.__7OKcEzdMfOdabzyMipWdSzWD != __Air1kJDZlSYUxsBJoK_dKO_V:
		__Air1kJDZlSYUxsBJoK_dKO_V = __H_DT0F4P9u3L0d2FERrVmg1j.__7OKcEzdMfOdabzyMipWdSzWD
		camera.__ygQpjlnLTsRv_t24LnuR1ohD(Vector2(__H_DT0F4P9u3L0d2FERrVmg1j.x(), __H_DT0F4P9u3L0d2FERrVmg1j.y()))
var __AkJDLb0dYRECEiyB7JBimGWX: = __lQA2X_Tbdwp3cdBqDfL8XMPe.new()
var __wbELGtzJYkGkxW7qLn9ltku7: __Qw7y3OnRnHxfWbHNtT6nnAUS
const __jopGolxuYOytI1kIbVUR0Abj: = 40
func __GWBHusWTnOdv5VVjDgHyqNAz(path: String) -> void :
	await RenderingServer.frame_post_draw
	get_viewport().get_texture().get_image().save_png(path)
	print("冻结截图 -> %s（tick %d，队列 %d）" % [ProjectSettings.globalize_path(path), __Im3kdj312UN9j6s5TpSfKOAs.__u0nkAKG5lGiEsenIJI6PFvMF, queue.size()])
func __ZJVxgBx4xBnmYo2Vg5lkensA() -> Dictionary:
	var __OE_Fw0w3bE9Jscp1QdUplK2n: Dictionary = client.__MA0pk1UxJ_4TGlBUteCxt2gY if client != null else {}
	if __OE_Fw0w3bE9Jscp1QdUplK2n.is_empty() or int(__OE_Fw0w3bE9Jscp1QdUplK2n.get("match_id", -1)) != __Uvzp2Nhc4YbduKNpA08hrEu5.__wMfg3dVnjdqMi7KUhLZ61Mhk:
		return {}
	var __VaIyERkLhBwBIZAeidExvmpc: Dictionary = App.__M0ImV248NGNrBFXy9NCs5jwX().__6vukUhU2G_4b_rRHatkEj0ZY(int(__OE_Fw0w3bE9Jscp1QdUplK2n["total_exp"]), {"credits": int(__OE_Fw0w3bE9Jscp1QdUplK2n["credits"]), "points": int(__OE_Fw0w3bE9Jscp1QdUplK2n["points"])}, __H_DT0F4P9u3L0d2FERrVmg1j.__WeB9Hi0OxaFBUuwm2WU2qKEH, __Im3kdj312UN9j6s5TpSfKOAs.__u0nkAKG5lGiEsenIJI6PFvMF, __OE_Fw0w3bE9Jscp1QdUplK2n, __H_DT0F4P9u3L0d2FERrVmg1j.__c15rG2tC96oGc8kXqdQ_1wyL)
	client.__MA0pk1UxJ_4TGlBUteCxt2gY = {}
	__VaIyERkLhBwBIZAeidExvmpc["air_kills"] = __bGkdz3KvT6NvE2AmieSpxtUI
	__VaIyERkLhBwBIZAeidExvmpc["air_credit"] = __DL2yNM3BV9Lmjk_IjGgO27dt
	__of00oxcoTvym0dJG2Fz6nIiM(__zdpRVN2_7VlxgfFr07a8dj8X(), int(__OE_Fw0w3bE9Jscp1QdUplK2n["total_exp"]), int(__OE_Fw0w3bE9Jscp1QdUplK2n["credits"]), int(__OE_Fw0w3bE9Jscp1QdUplK2n["points"]), __VaIyERkLhBwBIZAeidExvmpc)
	return __VaIyERkLhBwBIZAeidExvmpc
func __FFPs26VmLnmU3HSkrPP43at_(__zs6fGJVhddl5EZSinoDuCxD2: int) -> void :
	if not __vCaHebXeTSk5ki_sJbb3gGEn or __kN6myDrSvB160g5C80XDP_oe or __zs6fGJVhddl5EZSinoDuCxD2 == __83TSym9czt1PBDgaopjy6rEQ:
		return
	__83TSym9czt1PBDgaopjy6rEQ = __zs6fGJVhddl5EZSinoDuCxD2
	__fJyTMvijFRPTnM5LvyNVeHLa(__HN2CGq76mPdGF_uuq2VLVMCB)
var __EB62kdWxBmEB2Xlff4o0XGma: Dictionary = {}
var paused: bool = false:
	set(value):
		paused = value
		if __W0AIX5_s5ZmzSZEuijQKMEky != null:
			__W0AIX5_s5ZmzSZEuijQKMEky.set_paused(value)
func __fJyTMvijFRPTnM5LvyNVeHLa(scenario: String) -> void :
	if not __vCaHebXeTSk5ki_sJbb3gGEn:
		return
	__HN2CGq76mPdGF_uuq2VLVMCB = scenario
	var s: Dictionary = __SkAl4wMOrSNj22qH2dKbbJM3({"scenario": scenario, "player_ship": App.__M0ImV248NGNrBFXy9NCs5jwX().__nfaBZ_xIiHIPY3GkBUUjEEyF(__U7UMfwBewiXSLEeaDnywaCO7.__V0erSRNWoPFGOr7bG6vGIpsK())})
	if s.is_empty():
		return
	setup = s
	__Im3kdj312UN9j6s5TpSfKOAs = __Ti__RyaVjFAbq0eWKyiulRtX.__YNjSGlrkuU4xu5LIhzsrDpM7(App.___qFCN2viGM2bPW1uGV9qys9h(), setup)
	__H_DT0F4P9u3L0d2FERrVmg1j = __emgjXOD_icqI4OOSMXeVRZez()
	__jPl56qRp4FciYYHXDmLtD2k2()
	__Osq6zMWpMqS1sxxVc5GLMDPW()
	var __OIyTxcIIWV40A5AL4JAH21eb: Array[Vector2i] = []
	for __7cMZc8L09HYMMNkJjHi9g4O7: Vector2 in __FqDMuIQZqiEvYVSmnPHhjSMa[__H_DT0F4P9u3L0d2FERrVmg1j.__7OKcEzdMfOdabzyMipWdSzWD]:
		__OIyTxcIIWV40A5AL4JAH21eb.append(Vector2i(__7cMZc8L09HYMMNkJjHi9g4O7))
	__NqcLKvQgaJD_pE3JD6vSe71E.__FTxG0Uiu0IV20KQQrCO2pmp1(__OIyTxcIIWV40A5AL4JAH21eb, __JmicKnMOUqYWokzP32Q2v9RX, App.__PtNURh2PaYHMgsPlkLtni90Y())
var __IRvSrr33dhN97m8w8a2ZI1lE: int:
	get: return __OUrhMiIPovPuCx2oLsoLxFDb.get_value()
	set(v): __OUrhMiIPovPuCx2oLsoLxFDb.set_value(v)
func __emgjXOD_icqI4OOSMXeVRZez() -> __YdhZSn3k6BLtSITi5naOCb7n:
	for s: __YdhZSn3k6BLtSITi5naOCb7n in __Im3kdj312UN9j6s5TpSfKOAs.__LYNzM9N3A8Dmo_1zq54GljKm:
		if s.__ZMgQrrB9zxLXJ4nY9DOrkD1m:
			return s
	return __Im3kdj312UN9j6s5TpSfKOAs.__LYNzM9N3A8Dmo_1zq54GljKm[0]
const __k4tJVsMbRmcRrzVGv3Bdb2bj: = 22500
var __SgEyrIZJCIKq5tHIvreYIf6z: bool = false
func __o5d4_jO9yZhivIzUiP0l8tys(__RohjRgWWnbxRvNqi_CsY95Ie: Signal, __VcWGYolaxO3HmX9y8mDzekou: Callable) -> void :
	__RohjRgWWnbxRvNqi_CsY95Ie.connect(__VcWGYolaxO3HmX9y8mDzekou)
	__b95gXqxW8FiQQJ0Bzm9HPgWO.append([__RohjRgWWnbxRvNqi_CsY95Ie, __VcWGYolaxO3HmX9y8mDzekou])
func __XfimwY75BPlAiCDQbPD1LH9R() -> bool:
	return __H_DT0F4P9u3L0d2FERrVmg1j != null and ((setup["ships"] as Array)[__H_DT0F4P9u3L0d2FERrVmg1j.index] as Dictionary).has("crew")
func __fFoBwMT_TKrtEb91FCnVA4CQ(__wyk0gze3JJ0CqS01g0pErK9U: int, __X_CEUmQUeR9UvtveKw_MJzn9: int, __9NNqDUpAG2rKeiL565Q5vcJB: int, __VLOkW9P0XUEtR8Q2kV90crM7: int, __gXfgggTr3vXor7mhF3fmpy3s: Vector2) -> void :
	if __DW5u_PxmVzx39MAyJaNAZ9No != null and camera != null:
		__DW5u_PxmVzx39MAyJaNAZ9No.__Uinp0qKlBAx07Wxg3OpdJrIb(__wyk0gze3JJ0CqS01g0pErK9U, __X_CEUmQUeR9UvtveKw_MJzn9, __9NNqDUpAG2rKeiL565Q5vcJB, __VLOkW9P0XUEtR8Q2kV90crM7, __gXfgggTr3vXor7mhF3fmpy3s, Rect2(camera.position, camera.__7Q1u13W5jsLs8HPva7eP0p0P()))
var __s8T5oktgGgD34cS5bqLx7M4q: int = 0
func __BPel0E_ScloYu6bbCc0sNmYu(events: Array[__QzfA1_MgHwBGTTBizdgA8rkk]) -> void :
	if __wbELGtzJYkGkxW7qLn9ltku7 != null and __wbELGtzJYkGkxW7qLn9ltku7.__5p26PjGwGjkCxqrXKb5tRnmm != null:
		__wbELGtzJYkGkxW7qLn9ltku7.__5p26PjGwGjkCxqrXKb5tRnmm.__CvD5tKr35VYLv9Cz25Ct38zL(events)
	for __G9vrQN7hEfsOQ0yoI9PLYVCu: __QzfA1_MgHwBGTTBizdgA8rkk in events:
		if __G9vrQN7hEfsOQ0yoI9PLYVCu.__RZSGss6vMJxzvS6fmWkQMma8 == __QzfA1_MgHwBGTTBizdgA8rkk.__FSW4WCXpupwYSF0KaHCFCNKb.__PbaJd7abiSk0NwFQGB9iKA0a and __G9vrQN7hEfsOQ0yoI9PLYVCu.__o3MhRIns6p6L9ICgdCGUOTuE == __H_DT0F4P9u3L0d2FERrVmg1j.index:
			__G2zYsJx5HRFiDZUAlfwnf1IN("UI_SUB_MSG_GUN" if __G9vrQN7hEfsOQ0yoI9PLYVCu.value == 0 else "UI_SUB_MSG_TORP")
	if __DW5u_PxmVzx39MAyJaNAZ9No == null:
		return
	var __dxUCu_nJ9lMseKnzURXA5WVP: bool = false
	if __H_DT0F4P9u3L0d2FERrVmg1j.state == __lAo0PsogaUvqHw4muTzPsHiR.__pRO7nOY10o2GAU3KzWQvIvwY and __H_DT0F4P9u3L0d2FERrVmg1j.__ZhyiLCIyqHoRZeY0UaFeTs3e > 0:
		for s: __YdhZSn3k6BLtSITi5naOCb7n in __Im3kdj312UN9j6s5TpSfKOAs.__LYNzM9N3A8Dmo_1zq54GljKm:
			if s.__7OKcEzdMfOdabzyMipWdSzWD != __H_DT0F4P9u3L0d2FERrVmg1j.__7OKcEzdMfOdabzyMipWdSzWD and s.state == __lAo0PsogaUvqHw4muTzPsHiR.__pRO7nOY10o2GAU3KzWQvIvwY and s.__5M2Kw9tr4U856gth8pKR0sL6() >= __qUuRE3qEzIGmcU0ysMMtWssY.__hyGIR4DJfnQtW3RWkaPipovP and s.__5M2Kw9tr4U856gth8pKR0sL6() != __qUuRE3qEzIGmcU0ysMMtWssY.__F_jqEWMCiinD78WMy2CvF0Vb and __qUuRE3qEzIGmcU0ysMMtWssY.__kVVlo4D_74EUz3bKqIXgsYa9(__H_DT0F4P9u3L0d2FERrVmg1j, s):
				__dxUCu_nJ9lMseKnzURXA5WVP = true
				break
	__DW5u_PxmVzx39MAyJaNAZ9No.__zUFQvXXNi9Bxhj12Vo3fYmCf(__dxUCu_nJ9lMseKnzURXA5WVP, __H_DT0F4P9u3L0d2FERrVmg1j)
	var __H41JiwS86XalshhQ5UOHvTTj: bool = not __H_DT0F4P9u3L0d2FERrVmg1j.__AReCBHrBYt7dD7H_WiK9Tklz.is_empty() and (__H_DT0F4P9u3L0d2FERrVmg1j.__5M2Kw9tr4U856gth8pKR0sL6() == __qUuRE3qEzIGmcU0ysMMtWssY.__yE5sEoML5GmEJShAjPz9ooKN or __H_DT0F4P9u3L0d2FERrVmg1j.__5M2Kw9tr4U856gth8pKR0sL6() == __qUuRE3qEzIGmcU0ysMMtWssY.__F_jqEWMCiinD78WMy2CvF0Vb) and int(__H_DT0F4P9u3L0d2FERrVmg1j.__AReCBHrBYt7dD7H_WiK9Tklz["crit_o2"]) != 0
	__DW5u_PxmVzx39MAyJaNAZ9No.__dGJIHlETbgfrRpf1HcgiwIPA(__H41JiwS86XalshhQ5UOHvTTj, __H_DT0F4P9u3L0d2FERrVmg1j)
func __0CTHMP3iB93HB9WarvaiR4Ge() -> void :
	if __H_DT0F4P9u3L0d2FERrVmg1j.state != __lAo0PsogaUvqHw4muTzPsHiR.__pRO7nOY10o2GAU3KzWQvIvwY or __vCaHebXeTSk5ki_sJbb3gGEn:
		return
	var __F0Ny5GUEY4hbWnMAYcRxW_48: int = -1
	for s: __YdhZSn3k6BLtSITi5naOCb7n in __Im3kdj312UN9j6s5TpSfKOAs.__LYNzM9N3A8Dmo_1zq54GljKm:
		if s.__7OKcEzdMfOdabzyMipWdSzWD == __H_DT0F4P9u3L0d2FERrVmg1j.__7OKcEzdMfOdabzyMipWdSzWD:
			continue
		var near: bool = s.state == __lAo0PsogaUvqHw4muTzPsHiR.__pRO7nOY10o2GAU3KzWQvIvwY and __KQZdXu2S1iZ_EaFcA8wgkdsw(s.x(), s.y()) <= __H_DT0F4P9u3L0d2FERrVmg1j.__lp5nMIOUyaTDuOPtUm4IpHRu and __osOG1KsSfr5d06WoVaC5BGTs.__FQri6v1CmjNVPzOMYn976Cs8(__Im3kdj312UN9j6s5TpSfKOAs, s, __H_DT0F4P9u3L0d2FERrVmg1j.__7OKcEzdMfOdabzyMipWdSzWD)
		if near and not __KsofSZfpiiffy8tf0gzvABbm.has(s.index):
			__KsofSZfpiiffy8tf0gzvABbm[s.index] = true
			if __F0Ny5GUEY4hbWnMAYcRxW_48 < 0:
				__F0Ny5GUEY4hbWnMAYcRxW_48 = s.index
		elif not near and s.state == __lAo0PsogaUvqHw4muTzPsHiR.__pRO7nOY10o2GAU3KzWQvIvwY and __KQZdXu2S1iZ_EaFcA8wgkdsw(s.x(), s.y()) > __H_DT0F4P9u3L0d2FERrVmg1j.__lp5nMIOUyaTDuOPtUm4IpHRu:
			__KsofSZfpiiffy8tf0gzvABbm.erase(s.index)
	if __F0Ny5GUEY4hbWnMAYcRxW_48 >= 0:
		UI.__Qyp4Js7J9ejl5FSF4pVpfEi5(tr("UI_ENEMY_SPOTTED") % __NqcLKvQgaJD_pE3JD6vSe71E.__SZmQoweNiN70kTdeGPRFwWUK(__F0Ny5GUEY4hbWnMAYcRxW_48))
		if __DW5u_PxmVzx39MAyJaNAZ9No != null:
			__DW5u_PxmVzx39MAyJaNAZ9No.__S5LpTBqa5gWY5qoxu6fQRqlW()
	var __L2ZCJA694N2P9pBxtBdyBiGX: bool = false
	var __aEHDu8P2VZOq13lL8GQ21dQR: Dictionary = {}
	for a: __YCYnibBjVPRhMDf3YPwizbkN in __Im3kdj312UN9j6s5TpSfKOAs.__gobxGwIVlftvCfJ1fsNzSlj7:
		if a.__7OKcEzdMfOdabzyMipWdSzWD == __H_DT0F4P9u3L0d2FERrVmg1j.__7OKcEzdMfOdabzyMipWdSzWD or not a.active or not a.__dRotcb2ldVZQLm2YDYWTTU9J or a.__jKXPrtchy4v7fjo9Z9kJG9SX:
			continue
		__aEHDu8P2VZOq13lL8GQ21dQR[a.id] = true
		var d: int = __KQZdXu2S1iZ_EaFcA8wgkdsw(a.__EsOQaggwtLEnMAHn6g7H_r7O(), a.__KrKPdZs_d6uEOIuRq3UQy1fb())
		if d <= __H_DT0F4P9u3L0d2FERrVmg1j.__lp5nMIOUyaTDuOPtUm4IpHRu:
			__HwMxXlaf4xpBSYy3rK4yRWvY[a.id] = true
		if d <= __H_DT0F4P9u3L0d2FERrVmg1j.__z0cWmVEHlOSDFrPoyOKsE_Uz and not __WZkZ6Z7lN40BIDwB5zpEaYYg.has(a.id):
			__WZkZ6Z7lN40BIDwB5zpEaYYg[a.id] = true
			__L2ZCJA694N2P9pBxtBdyBiGX = true
		if d > __H_DT0F4P9u3L0d2FERrVmg1j.__lp5nMIOUyaTDuOPtUm4IpHRu and __HwMxXlaf4xpBSYy3rK4yRWvY.has(a.id):
			__HwMxXlaf4xpBSYy3rK4yRWvY.erase(a.id)
			__WZkZ6Z7lN40BIDwB5zpEaYYg.erase(a.id)
	for id: int in __WZkZ6Z7lN40BIDwB5zpEaYYg.keys():
		if not __aEHDu8P2VZOq13lL8GQ21dQR.has(id):
			__WZkZ6Z7lN40BIDwB5zpEaYYg.erase(id)
	for id: int in __HwMxXlaf4xpBSYy3rK4yRWvY.keys():
		if not __aEHDu8P2VZOq13lL8GQ21dQR.has(id):
			__HwMxXlaf4xpBSYy3rK4yRWvY.erase(id)
	if __L2ZCJA694N2P9pBxtBdyBiGX:
		UI.__Qyp4Js7J9ejl5FSF4pVpfEi5(tr("UI_ENEMY_AIR_NEAR"), 2.0, Color.WHITE, "enemy_air_near")
		if __DW5u_PxmVzx39MAyJaNAZ9No != null:
			__DW5u_PxmVzx39MAyJaNAZ9No.__W70A9OaVqgNBBwQIaIu3qIQk()
var camera: __UNRSz2MGXfIN8eyp8xYLBhT1
var __H_DT0F4P9u3L0d2FERrVmg1j: __YdhZSn3k6BLtSITi5naOCb7n
var __c9HSVk0U4goH9I0e212o2UAu: bool = false
var __2mQ2BJsmPe4GT6uaSdCAvxsA: PackedInt64Array = PackedInt64Array()
var __JmicKnMOUqYWokzP32Q2v9RX: int = __U7UMfwBewiXSLEeaDnywaCO7.__cBKQKa3mkITwb0e5Od1VI06x
var __NqcLKvQgaJD_pE3JD6vSe71E: __ExHo5kjSvjunkYmWDgdJUGHm
var __pb0UqI8FdD0J1iBIy_gOmQuA: __5VyZOcBPX5I8DadXDQn6ZnrI
var __DW5u_PxmVzx39MAyJaNAZ9No: __wwV6ocUMzL2wx2wFAgrr7A7T
func __u8UvjIlM7wFkkXpmjKu2BJUJ(suffix: String) -> String:
	if not __898CZFX8zI40Huxp297h_lkH:
		return ""
	var __3hZ0aCdaYo21QIPihHKgknWy: int = 0
	for __aUt0s8n_knTg4sjo9OJE0ZUH: int in __qlFicdtBAIg_rNEpMlXK2S0o:
		__3hZ0aCdaYo21QIPihHKgknWy = maxi(__3hZ0aCdaYo21QIPihHKgknWy, __aUt0s8n_knTg4sjo9OJE0ZUH)
	var __cBxHHTJ3WFQNBTwB0nAeRPom: Dictionary = __qlFicdtBAIg_rNEpMlXK2S0o.duplicate()
	__cBxHHTJ3WFQNBTwB0nAeRPom[0] = __B03hDgmIU4O8q341eLf_67xq
	var __658Kb3wOZI0LuGwK8T9DtP9e: Dictionary = __7Vy8vFx5Xo19gaoA5vqzjRgW.__CLe64LCedzT90CC44_jrq52U(setup, __qDMGPXum4Wfh1OWpRcTjfrQm, __3hZ0aCdaYo21QIPihHKgknWy * __lAo0PsogaUvqHw4muTzPsHiR.__BvjYOp5V9D51FL_PzBjk4Wlf, __B03hDgmIU4O8q341eLf_67xq, PackedInt64Array(), __cBxHHTJ3WFQNBTwB0nAeRPom)
	var path: String = "user://net_match%d_p%d_%s.json" % [__Uvzp2Nhc4YbduKNpA08hrEu5.__wMfg3dVnjdqMi7KUhLZ61Mhk, client.__bEaVqnUpkbc9pnzD2IA0HDfW.__WGEyCfWpyvUvMNc11zQw82Tr, suffix]
	var __HZc7e19FK7IqanL4da4zwUqG: FileAccess = FileAccess.open(path, FileAccess.WRITE)
	if __HZc7e19FK7IqanL4da4zwUqG != null:
		__HZc7e19FK7IqanL4da4zwUqG.store_string(JSON.stringify(__658Kb3wOZI0LuGwK8T9DtP9e))
	return path
var __ny0DWNynYxcUApZV6IS26JNR: int = 0
const __GhEMP6WVBg2EtZjFpXq9U0fw: = 5
const __1GH3EU9THQuSRbfXN1ZL9x5i: = 5000
const __PZOQ1Qvd6XN8QPigmGN5RqqA: = __lAo0PsogaUvqHw4muTzPsHiR.__qYP_YAvOQ8TvQJjfN6xGqOuz / 1000.0
var __FucjOm7PB7VBmsuC6Qq0btzH: int = 0
var __rQbCTLm4ikRheIOavyVgPmxH: int = 0
var __eRoQ6QawJdKmQoEOmdz1CInO: Dictionary = {}
var __QK4Tkf7mTL3ljYx9WnGAAW_W: int:
	get: return __kBqy45AI3C7dTuXhcOic75in.get_value()
	set(v): __kBqy45AI3C7dTuXhcOic75in.set_value(v)
func __4kuWb3XCQlF_JVzFT1aeoeA4(__poiZ_Vis82WNSJmuiZGidDzQ: int) -> int:
	if __poiZ_Vis82WNSJmuiZGidDzQ == __TbAkFifAS33uxKcFDf16mKl5.__p_p1Wx3sVcyN02NXv70x3uDv.__cQ_gfQ2gW5LHIZ6LdqbCvVTF:
		return 3
	var __xNzFMwuOFF1xqoEgJ1zXw5Ap: bool = __poiZ_Vis82WNSJmuiZGidDzQ == __TbAkFifAS33uxKcFDf16mKl5.__p_p1Wx3sVcyN02NXv70x3uDv.__0E_5QdZBBggJMDOV1NiTvepv
	return 1 if __xNzFMwuOFF1xqoEgJ1zXw5Ap == (__H_DT0F4P9u3L0d2FERrVmg1j.__7OKcEzdMfOdabzyMipWdSzWD == 0) else 2
var __Uvzp2Nhc4YbduKNpA08hrEu5: __XY42sSBYwWAYSKuMIziPcxY_
var __2CEP4kl7Sdh3BZ1WciRGEAL0: int = 0
func __rqiIxD66l_NPRNaQOEkhH4mW() -> void :
	var __NBzztXCeMrp6IW_NslbwFm0h: int = __NqcLKvQgaJD_pE3JD6vSe71E.__Mf9wp9Xig2PCnnzLv0DyXzQO
	var __UUH9K4wIpHCG4afbgzvvKqRF: int = 1 - __H_DT0F4P9u3L0d2FERrVmg1j.__7OKcEzdMfOdabzyMipWdSzWD if __NBzztXCeMrp6IW_NslbwFm0h == __H_DT0F4P9u3L0d2FERrVmg1j.__7OKcEzdMfOdabzyMipWdSzWD else (-1 if __NBzztXCeMrp6IW_NslbwFm0h >= 0 else __H_DT0F4P9u3L0d2FERrVmg1j.__7OKcEzdMfOdabzyMipWdSzWD)
	__J5MTDwc6HJsswvlehhkBjcaO(__UUH9K4wIpHCG4afbgzvvKqRF)
	UI.__Qyp4Js7J9ejl5FSF4pVpfEi5(tr("UI_FOG_VIEW_ALL") if __UUH9K4wIpHCG4afbgzvvKqRF < 0 else (tr("UI_FOG_VIEW_OWN") if __UUH9K4wIpHCG4afbgzvvKqRF == __H_DT0F4P9u3L0d2FERrVmg1j.__7OKcEzdMfOdabzyMipWdSzWD else tr("UI_FOG_VIEW_FOE")))
func __61O1SiBTuzE1h0PoCRgl2kZd(__qb2mO4CPPhvocJl_tSVxiztP: __eqBnxkZN0QaSRKoNyvaUGVo1, __N3pjeGg4ud8AXmqNGXuLVubl: int) -> void :
	if not __vCaHebXeTSk5ki_sJbb3gGEn or __qb2mO4CPPhvocJl_tSVxiztP == null:
		return
	var __XeMYr7qyBau9ElyaeEt21iH4: = __XY42sSBYwWAYSKuMIziPcxY_.new()
	__XeMYr7qyBau9ElyaeEt21iH4.__lZ8vjU390FVMnZ8cocVoR8mr = __qb2mO4CPPhvocJl_tSVxiztP.__lZ8vjU390FVMnZ8cocVoR8mr
	var ___JQNjr2yglWYaCpt3VElzQ2s: String = "%d" % __qb2mO4CPPhvocJl_tSVxiztP.__lZ8vjU390FVMnZ8cocVoR8mr
	var __pIMPOscPB0MwvZjkTYyNwKCn: __Se4EsxPBCHX48h1ZS5MexaMl = App.__PtNURh2PaYHMgsPlkLtni90Y()
	for __8EWwRp3jATPPEFO6k4G3LYdv: __ePth2qEwX_Pgp08FFrxSlcLr in __qb2mO4CPPhvocJl_tSVxiztP.__zIF9v7_0wMMhvSzdUeP1IIN3:
		var __m2Unn1FKm54BAmIk1f4uiPah: = __rhxwC76k0CGcO3Ps90EGUa5M.new()
		__m2Unn1FKm54BAmIk1f4uiPah.__WGEyCfWpyvUvMNc11zQw82Tr = __8EWwRp3jATPPEFO6k4G3LYdv.__WGEyCfWpyvUvMNc11zQw82Tr
		__m2Unn1FKm54BAmIk1f4uiPah.name = __8EWwRp3jATPPEFO6k4G3LYdv.name
		__m2Unn1FKm54BAmIk1f4uiPah.__D_bua5LYiw2NWQUHMrFegHMC = __8EWwRp3jATPPEFO6k4G3LYdv.__D_bua5LYiw2NWQUHMrFegHMC
		__m2Unn1FKm54BAmIk1f4uiPah.__q26f3dCYzrR9TyO_pwwz7lre = __8EWwRp3jATPPEFO6k4G3LYdv.__q26f3dCYzrR9TyO_pwwz7lre
		__m2Unn1FKm54BAmIk1f4uiPah.__0mdvQQYQTP5aSMpaYbwwysVj = __ie1fCh72Dme_5IXLGrTsILmx[clampi(__8EWwRp3jATPPEFO6k4G3LYdv.__D_bua5LYiw2NWQUHMrFegHMC, 0, 1)]
		__m2Unn1FKm54BAmIk1f4uiPah.__ofKSCLcCg7jWtqacDa153ehk = __8EWwRp3jATPPEFO6k4G3LYdv.__ofKSCLcCg7jWtqacDa153ehk if __pIMPOscPB0MwvZjkTYyNwKCn.__S427rIy8YAPI_7NTPBneiPZH(__8EWwRp3jATPPEFO6k4G3LYdv.__ofKSCLcCg7jWtqacDa153ehk.__WeB9Hi0OxaFBUuwm2WU2qKEH) else __pIMPOscPB0MwvZjkTYyNwKCn.__vTRMq3igRP2hTt2npyhiJ5UU(__U7UMfwBewiXSLEeaDnywaCO7.__0UjVSEDwyOGHq1aUx6ieU1IJ)
		__XeMYr7qyBau9ElyaeEt21iH4.__M0ImV248NGNrBFXy9NCs5jwX.append(__m2Unn1FKm54BAmIk1f4uiPah)
		___JQNjr2yglWYaCpt3VElzQ2s += "|%d.%d.%d.%d.%s" % [__m2Unn1FKm54BAmIk1f4uiPah.__D_bua5LYiw2NWQUHMrFegHMC, __m2Unn1FKm54BAmIk1f4uiPah.__q26f3dCYzrR9TyO_pwwz7lre, __m2Unn1FKm54BAmIk1f4uiPah.__WGEyCfWpyvUvMNc11zQw82Tr, __m2Unn1FKm54BAmIk1f4uiPah.__ofKSCLcCg7jWtqacDa153ehk.__WeB9Hi0OxaFBUuwm2WU2qKEH, str(__m2Unn1FKm54BAmIk1f4uiPah.__ofKSCLcCg7jWtqacDa153ehk.__dOsDavODOasdfPxqce2DEBC3)]
	if ___JQNjr2yglWYaCpt3VElzQ2s == __exPMG5hclEJ4GrkuNTp8QecI or __XeMYr7qyBau9ElyaeEt21iH4.__M0ImV248NGNrBFXy9NCs5jwX.is_empty():
		return
	__exPMG5hclEJ4GrkuNTp8QecI = ___JQNjr2yglWYaCpt3VElzQ2s
	setup = __Ti__RyaVjFAbq0eWKyiulRtX.__eC2Gef0hq8YlwrdVcs2tTLeg(__XeMYr7qyBau9ElyaeEt21iH4)
	__Im3kdj312UN9j6s5TpSfKOAs = __Ti__RyaVjFAbq0eWKyiulRtX.__YNjSGlrkuU4xu5LIhzsrDpM7(App.___qFCN2viGM2bPW1uGV9qys9h(), setup)
	__H_DT0F4P9u3L0d2FERrVmg1j = __Im3kdj312UN9j6s5TpSfKOAs.__LYNzM9N3A8Dmo_1zq54GljKm[maxi(0, __XeMYr7qyBau9ElyaeEt21iH4.__9X3lUNXcQD5jKQrJ56a0JZ82(__N3pjeGg4ud8AXmqNGXuLVubl))]
	__jPl56qRp4FciYYHXDmLtD2k2()
	__Osq6zMWpMqS1sxxVc5GLMDPW()
	var __EXVGRQRDFxpYe1qIInx7MOxo: __ePth2qEwX_Pgp08FFrxSlcLr = __qb2mO4CPPhvocJl_tSVxiztP.__WnNXJF4tovsq5AqDAdbQcMNw(__N3pjeGg4ud8AXmqNGXuLVubl)
	var map: __nXsG18rT7dnXSEzKPMnVejeY = __Ti__RyaVjFAbq0eWKyiulRtX.__f0Ir4Kzsoc1oSeQ15W2jjpe2(__XeMYr7qyBau9ElyaeEt21iH4.__lZ8vjU390FVMnZ8cocVoR8mr)
	__FqDMuIQZqiEvYVSmnPHhjSMa.clear()
	for __qAjzFX6SJxehaOfW2NqyIZrG: int in 2:
		var points: = PackedVector2Array()
		for __ijeGdl61364b4dr_PQcZYlXH: int in __Ti__RyaVjFAbq0eWKyiulRtX.__SC0yVVB4FXWyqXqfTR1JmRLW:
			points.append(Vector2(__Ti__RyaVjFAbq0eWKyiulRtX.__HXZYP0P0gEqGcS9OsTHW6wJQ(map, __qAjzFX6SJxehaOfW2NqyIZrG, __ijeGdl61364b4dr_PQcZYlXH)))
		__FqDMuIQZqiEvYVSmnPHhjSMa.append(points)
	var __qJXG6Tp5JaHT13TmKVYrvcU7: Array[Vector2i] = []
	for __kYgB_U_pXwgeZsMOyGMJSGvD: Vector2 in __FqDMuIQZqiEvYVSmnPHhjSMa[__H_DT0F4P9u3L0d2FERrVmg1j.__7OKcEzdMfOdabzyMipWdSzWD]:
		__qJXG6Tp5JaHT13TmKVYrvcU7.append(Vector2i(__kYgB_U_pXwgeZsMOyGMJSGvD))
	__NqcLKvQgaJD_pE3JD6vSe71E.__FTxG0Uiu0IV20KQQrCO2pmp1(__qJXG6Tp5JaHT13TmKVYrvcU7, __EXVGRQRDFxpYe1qIInx7MOxo.__q26f3dCYzrR9TyO_pwwz7lre if __EXVGRQRDFxpYe1qIInx7MOxo != null else -1, __pIMPOscPB0MwvZjkTYyNwKCn)
var __FqDMuIQZqiEvYVSmnPHhjSMa: Array[PackedVector2Array] = []
var __pu08ep8gFB8kGVBlMsMmPfl_: bool = false
var __H1kWP_uRU_4T8c7RAuJRJSNi: int = __YdhZSn3k6BLtSITi5naOCb7n.__PqwHiMCiEKMg9bL_3LrzgjVT.__Df7mxkznfLfIj2iCD1v2Tzl8
var __rtep__1NaeBRnIaPLRs7keNF: int = 0
func __vqV0DBV7txhHLAOtjfgkKZtk(events: Array[__QzfA1_MgHwBGTTBizdgA8rkk]) -> void :
	for __N60U26wil5VKZjMqIzJr8q_a: __QzfA1_MgHwBGTTBizdgA8rkk in events:
		if __N60U26wil5VKZjMqIzJr8q_a.__RZSGss6vMJxzvS6fmWkQMma8 == __QzfA1_MgHwBGTTBizdgA8rkk.__FSW4WCXpupwYSF0KaHCFCNKb.__o4UgLmyYvgr3J9nBpaLdFkqq and __N60U26wil5VKZjMqIzJr8q_a.__o3MhRIns6p6L9ICgdCGUOTuE == __H_DT0F4P9u3L0d2FERrVmg1j.index:
			__323DjHVpeKq9qbqbhN5ocoRI.__CeAyoJlL6GjfxVmVg12mRTWq = false
			__wbELGtzJYkGkxW7qLn9ltku7.__6nrrgeS8d1JuWOoOxCdK6GHv(false)
			UI.__Qyp4Js7J9ejl5FSF4pVpfEi5(tr("UI_BATTLE_FAST_AIM_DOWN") % __N60U26wil5VKZjMqIzJr8q_a.value)
	__XAO6JKg0PQn3g5ui6hTmZuKg()
var __b95gXqxW8FiQQJ0Bzm9HPgWO: Array[Array] = []
var __Im3kdj312UN9j6s5TpSfKOAs: __aDswGCE4WWdmypkp3eC7rExn
func __M5hm13Px4Kpp6gsbeWHBfYWI() -> void :
	var __XDH_Wzc7YIJY3lAxMs2TBf7b: PackedStringArray = str(__iAbDeha6hgeEpDzp_OVLHMcN.get("shot_cam", "")).split(",")
	if __XDH_Wzc7YIJY3lAxMs2TBf7b.size() == 1 and __XDH_Wzc7YIJY3lAxMs2TBf7b[0] == "me":
		__XDH_Wzc7YIJY3lAxMs2TBf7b = PackedStringArray([str(__H_DT0F4P9u3L0d2FERrVmg1j.x()), str(__H_DT0F4P9u3L0d2FERrVmg1j.y())])
	if __XDH_Wzc7YIJY3lAxMs2TBf7b.size() == 2:
		camera.__kPB6WrEOPKVp2mDZNM_ZEE0m = false
		camera.__ygQpjlnLTsRv_t24LnuR1ohD(Vector2(float(__XDH_Wzc7YIJY3lAxMs2TBf7b[0]), float(__XDH_Wzc7YIJY3lAxMs2TBf7b[1])))
		await RenderingServer.frame_post_draw
	if DisplayServer.get_name() == "headless":
		await get_tree().process_frame
	else:
		await RenderingServer.frame_post_draw
		get_viewport().get_texture().get_image().save_png(__xdF6xz9WJIAyCFIlMNF3msY1)
	var __wwBsrfxaxu85CeNqPY6Jf8kr: int = 0
	for s: __YdhZSn3k6BLtSITi5naOCb7n in __Im3kdj312UN9j6s5TpSfKOAs.__LYNzM9N3A8Dmo_1zq54GljKm:
		if s.state != __lAo0PsogaUvqHw4muTzPsHiR.__pRO7nOY10o2GAU3KzWQvIvwY:
			__wwBsrfxaxu85CeNqPY6Jf8kr += 1
	print("截图 -> %s（tick %d，帧率 %d，炮弹 %d，沉没 %d 艘，本舰 hp %d，输入延迟 %d ms，追帧 %d turn，RTT %d ms）" % [ProjectSettings.globalize_path(__xdF6xz9WJIAyCFIlMNF3msY1), __Im3kdj312UN9j6s5TpSfKOAs.__u0nkAKG5lGiEsenIJI6PFvMF, Engine.get_frames_per_second(), __Im3kdj312UN9j6s5TpSfKOAs.___1qGksmzNRubFckXIU7Ogyjh.size(), __wwBsrfxaxu85CeNqPY6Jf8kr, __H_DT0F4P9u3L0d2FERrVmg1j.__F41ZT8z_0zKKqYDFwqS1WGTs, __YVwrEYU5N0dWOswYhyLAhgF6, __s8T5oktgGgD34cS5bqLx7M4q, client.__a0zgONyRSfH3PH_q63ZuaGhg if client else -1])
	if __898CZFX8zI40Huxp297h_lkH:
		print("联机录像 -> %s" % ProjectSettings.globalize_path(__u8UvjIlM7wFkkXpmjKu2BJUJ("shot")))
		client.close()
	else:
		__m5TW9MpzzNDZg7II10XZl5MU()
	get_tree().quit(0)
func _exit_tree() -> void :
	if __GuP_w3N6IPD6F4EDt99FrC8q != "":
		Input.set_custom_mouse_cursor(null)
	if App.__W489J4Gtntjtp_hMofn_wpkk == self:
		App.__W489J4Gtntjtp_hMofn_wpkk = null
	for __9bgq5CtKcxGyI1rAUlhi0PC4: Array in __b95gXqxW8FiQQJ0Bzm9HPgWO:
		var __uwWmzphV_SJ9oa1lN8vSTW0A: Signal = __9bgq5CtKcxGyI1rAUlhi0PC4[0]
		if __uwWmzphV_SJ9oa1lN8vSTW0A.is_connected(__9bgq5CtKcxGyI1rAUlhi0PC4[1]):
			__uwWmzphV_SJ9oa1lN8vSTW0A.disconnect(__9bgq5CtKcxGyI1rAUlhi0PC4[1])
	__b95gXqxW8FiQQJ0Bzm9HPgWO.clear()
var __tJnc4IYOEg_SuNVvwdktpsXn: float = 0.0
var __BNtiAVKkxXLbNTzY2JctenZq: __dt7myedK5AYqgRX_SVD2qUee
const __MR04C36GQwmWStVvnym2GOW6: = 20
func _tick() -> void :
	camera.__BcAiwNhsZO9jge7QHyhNOboP(Vector2(__H_DT0F4P9u3L0d2FERrVmg1j.x(), __H_DT0F4P9u3L0d2FERrVmg1j.y()))
	__nvtHehTtgAm979A1wLl1o1st.update(__gLoRe5VNudNaczgnAFQL0Z8x[__H_DT0F4P9u3L0d2FERrVmg1j.index], __H_DT0F4P9u3L0d2FERrVmg1j.__F41ZT8z_0zKKqYDFwqS1WGTs, __H_DT0F4P9u3L0d2FERrVmg1j.__EnRnlPve0Y145ZsCmTA3iWUI)
	__DW5u_PxmVzx39MAyJaNAZ9No.__kC6zD903kIOB35eRqjx8Rhn6(__H_DT0F4P9u3L0d2FERrVmg1j)
	if __898CZFX8zI40Huxp297h_lkH:
		if __SgEyrIZJCIKq5tHIvreYIf6z:
			return
		var __kiVMQC3Vr5imB440fEyorhiR: int = __BNtiAVKkxXLbNTzY2JctenZq.frame()
		if __kiVMQC3Vr5imB440fEyorhiR == 0:
			if __gxRURc4MFvkf691WMIX_PoIT != "" and __BNtiAVKkxXLbNTzY2JctenZq.__g9CDA5obHWnFvXSFXx1g3rGa == 12:
				__GWBHusWTnOdv5VVjDgHyqNAz(__gxRURc4MFvkf691WMIX_PoIT)
				__gxRURc4MFvkf691WMIX_PoIT = ""
			return
	else:
		if paused:
			return
		if __5zsHBwGhnk5X3Ays_WuwIBnz == null:
			__W0AIX5_s5ZmzSZEuijQKMEky.start()
		if __Im3kdj312UN9j6s5TpSfKOAs.__t2UdGLb5AjoD9DJacXSIpDUA == 0:
			if __5zsHBwGhnk5X3Ays_WuwIBnz != null:
				__Im3kdj312UN9j6s5TpSfKOAs.__FNSSrZjYm1kMWB8ZA1h6htpt(__5zsHBwGhnk5X3Ays_WuwIBnz.__wys3iTL1w04VMo0jqdn8SoC5(__RrqNTQv04kVmefPIEe7GJtI6, __Im3kdj312UN9j6s5TpSfKOAs))
				__RrqNTQv04kVmefPIEe7GJtI6 += 1
			else:
				__Im3kdj312UN9j6s5TpSfKOAs.__FNSSrZjYm1kMWB8ZA1h6htpt(__Szndsmt47uTQYpRKJToURNl7.__IqNOZrnYqSfY2dD_XnzKyAUS(__Im3kdj312UN9j6s5TpSfKOAs))
		__Im3kdj312UN9j6s5TpSfKOAs.step(true)
		if __5zsHBwGhnk5X3Ays_WuwIBnz == null and __H_DT0F4P9u3L0d2FERrVmg1j.state != __lAo0PsogaUvqHw4muTzPsHiR.__pRO7nOY10o2GAU3KzWQvIvwY and __H_DT0F4P9u3L0d2FERrVmg1j.__F41ZT8z_0zKKqYDFwqS1WGTs <= 0:
			__W0AIX5_s5ZmzSZEuijQKMEky.finish()
		__2mQ2BJsmPe4GT6uaSdCAvxsA.append(__Im3kdj312UN9j6s5TpSfKOAs.__EeaM5brz45Ll1madYIYSP5pp())
		if __5zsHBwGhnk5X3Ays_WuwIBnz == null:
			__p0VcvihgtXhiKjC_wbNpnF4q.sample(__Im3kdj312UN9j6s5TpSfKOAs.__u0nkAKG5lGiEsenIJI6PFvMF)
	if __pb0UqI8FdD0J1iBIy_gOmQuA != null:
		__pb0UqI8FdD0J1iBIy_gOmQuA.update()
	var events: Array[__QzfA1_MgHwBGTTBizdgA8rkk] = __Im3kdj312UN9j6s5TpSfKOAs.__JW6kWzl9mmLENz2OGP5I1qGI()
	__z5sslWfZOq0V_PbBTItlWglS(events)
	__mQCDAUi7FzMVng4v3rDeuucj(events)
	__BPel0E_ScloYu6bbCc0sNmYu(events)
	__0CTHMP3iB93HB9WarvaiR4Ge()
	__vqV0DBV7txhHLAOtjfgkKZtk(events)
	__NqcLKvQgaJD_pE3JD6vSe71E.__5asHp4YxjoVtjNPsWMIuoRZR(events)
	__wbELGtzJYkGkxW7qLn9ltku7.__8kIGIVFwX0coMLN70rkRYwsc = __NqcLKvQgaJD_pE3JD6vSe71E.__mqCFY5LfObCtHgRHsBFoYUnE.__GZgY4cwRcIm1i_NUzlYW4fdo
	if __DW5u_PxmVzx39MAyJaNAZ9No != null:
		__DW5u_PxmVzx39MAyJaNAZ9No.__BoP41zv7wsOsmFM8oWrKetGR(__NqcLKvQgaJD_pE3JD6vSe71E.__mqCFY5LfObCtHgRHsBFoYUnE.alert, __H_DT0F4P9u3L0d2FERrVmg1j)
	__wbELGtzJYkGkxW7qLn9ltku7.__5asHp4YxjoVtjNPsWMIuoRZR()
	if not __898CZFX8zI40Huxp297h_lkH and __5zsHBwGhnk5X3Ays_WuwIBnz == null and __rQbCTLm4ikRheIOavyVgPmxH == 0 and __g7JC3EJmfsOWnIyqLGGB93eB != null and __wbELGtzJYkGkxW7qLn9ltku7.__t3y1cnuny6w_2nwErOwdsvQP != null:
		__g7JC3EJmfsOWnIyqLGGB93eB.meti_auto_tick(__wbELGtzJYkGkxW7qLn9ltku7.__t3y1cnuny6w_2nwErOwdsvQP)
	__bx57LdWnJinT2XHAnsga12wK()
	__wPxLRTgsWINZJN0shOfbxuiZ()
	if not __898CZFX8zI40Huxp297h_lkH and __5zsHBwGhnk5X3Ays_WuwIBnz == null and __Im3kdj312UN9j6s5TpSfKOAs.__u0nkAKG5lGiEsenIJI6PFvMF % __Eqd4HoZVFfamlNlSeotGOZBp.__a2JvgqHgCEtYP5sdzNxgIun2 == 0:
		__hfhrNERwZCXjneW2quGcUg2n.__EHNWWW800rvwE6H3J121RKc9(__Im3kdj312UN9j6s5TpSfKOAs, __ASM9naUc7LGeAbtWSqS9xNTM())
	if __2CEP4kl7Sdh3BZ1WciRGEAL0 > 0 and __Im3kdj312UN9j6s5TpSfKOAs.__u0nkAKG5lGiEsenIJI6PFvMF >= __2CEP4kl7Sdh3BZ1WciRGEAL0:
		__2CEP4kl7Sdh3BZ1WciRGEAL0 = 0
		__M5hm13Px4Kpp6gsbeWHBfYWI()
var __g7JC3EJmfsOWnIyqLGGB93eB: __c5hyhliCGxS3qW31tQfksxJC
func __SMEvAsLM6A8YhavSCs8EA7QU(___bUrq2GdM2Yqoe7HU6yanDzB: int, pressed: bool) -> void :
	if not pressed:
		return
	match ___bUrq2GdM2Yqoe7HU6yanDzB:
		__ZHwJr3sB730Xm67xCNPRVjTe.__7p66fpI27Ejh1nHovTpHSGpN.__8BSsElRXUMblSRd97jFHUh8y:
			if camera != null and __H_DT0F4P9u3L0d2FERrVmg1j != null and __NqcLKvQgaJD_pE3JD6vSe71E != null and __NqcLKvQgaJD_pE3JD6vSe71E.__CR2jpqZ6wQv1sbgGfFwtARRJ != null:
				camera.__mdFtTZH7brM7Vsjq6TcZfSlo(Vector2(__H_DT0F4P9u3L0d2FERrVmg1j.x(), __H_DT0F4P9u3L0d2FERrVmg1j.y()), __NqcLKvQgaJD_pE3JD6vSe71E.__CR2jpqZ6wQv1sbgGfFwtARRJ.__q75FXs6__XF7hbQp5HDrJQo0, bool(Settings.get_value("GKey_HitPoint", true)))
		__ZHwJr3sB730Xm67xCNPRVjTe.__7p66fpI27Ejh1nHovTpHSGpN.__jGtNELhfIk3YpOnlNDUY4Hkc:
			if not __898CZFX8zI40Huxp297h_lkH:
				paused = not paused
		__ZHwJr3sB730Xm67xCNPRVjTe.__7p66fpI27Ejh1nHovTpHSGpN.__u_a9xsF7Rg6Q8OJScOf3B5Lk:
			__F8HZCw7buuEBi0A0Mf6znYAe.__spR18K2mM9dXz_Qs6R48El0s = not __F8HZCw7buuEBi0A0Mf6znYAe.__spR18K2mM9dXz_Qs6R48El0s
		__ZHwJr3sB730Xm67xCNPRVjTe.__7p66fpI27Ejh1nHovTpHSGpN.__lAIY_eoZYCPRhMbdQFPC2LfO:
			if __ZRS6lZJh1TuB38TS82wWLE09.enabled():
				__NqcLKvQgaJD_pE3JD6vSe71E.___BHlfQUrK3iRAtJUbKzSEZ0Q = not __NqcLKvQgaJD_pE3JD6vSe71E.___BHlfQUrK3iRAtJUbKzSEZ0Q
		__ZHwJr3sB730Xm67xCNPRVjTe.__7p66fpI27Ejh1nHovTpHSGpN.__qyu1UYSBRqdn9HtZztdulaSR:
			__wbELGtzJYkGkxW7qLn9ltku7.show_grid = not __wbELGtzJYkGkxW7qLn9ltku7.show_grid
		__ZHwJr3sB730Xm67xCNPRVjTe.__7p66fpI27Ejh1nHovTpHSGpN.__uNBs15Q_tWtpSGM62dLBXO66:
			__wbELGtzJYkGkxW7qLn9ltku7.__vefOvmmvR8DsOl7v8DF_4Rj5()
		__ZHwJr3sB730Xm67xCNPRVjTe.__7p66fpI27Ejh1nHovTpHSGpN.__Hgg9pOQGC84lqWJXgg7QiaBh:
			__NqcLKvQgaJD_pE3JD6vSe71E.__Yc180FEWWobqHvFluqj2GQud()
		__ZHwJr3sB730Xm67xCNPRVjTe.__7p66fpI27Ejh1nHovTpHSGpN.__vsyowjIvrgsEe7ScLL6SabYF:
			if not __898CZFX8zI40Huxp297h_lkH or __5zsHBwGhnk5X3Ays_WuwIBnz != null or __ZRS6lZJh1TuB38TS82wWLE09.enabled():
				__rqiIxD66l_NPRNaQOEkhH4mW()
		__ZHwJr3sB730Xm67xCNPRVjTe.__7p66fpI27Ejh1nHovTpHSGpN.__RtUF7Cb3ai4zF44EbvYfOeMQ:
			__mRR1SQWSm4CqOo8liJnegLye()
func __NaSa_ZIwL9DjG6MZ6yNHvnkr() -> Dictionary:
	if __5zsHBwGhnk5X3Ays_WuwIBnz != null or not __XfimwY75BPlAiCDQbPD1LH9R():
		return {}
	if __898CZFX8zI40Huxp297h_lkH:
		return __ZJVxgBx4xBnmYo2Vg5lkensA()
	__W0AIX5_s5ZmzSZEuijQKMEky.finish()
	var __OmKVLOjvFlPm8OJBjTFnkiry: Dictionary = __zdpRVN2_7VlxgfFr07a8dj8X()
	var __6SIf1S2uSmVcHglZgse0rqmn: int = int(__OmKVLOjvFlPm8OJBjTFnkiry["exp_raw"])
	var __OTZr8z508PZJxnQ0z3ipNQpf: Dictionary = {"credits": int(__OmKVLOjvFlPm8OJBjTFnkiry["cr_raw"]), "points": int(__OmKVLOjvFlPm8OJBjTFnkiry["pt_raw"])}
	var __bza1ZXDR2IYp3dNpmw9uzSAp: int = int(__OmKVLOjvFlPm8OJBjTFnkiry["cr_raw"])
	var __wsdWBTBBixfca9Jx9H4qhjrP: int = int(__OmKVLOjvFlPm8OJBjTFnkiry["pt_raw"])
	var __XJA_3lCLpDBdhGYWVDMeuFKk: int = int(__OmKVLOjvFlPm8OJBjTFnkiry["ticks"])
	var __gT31LCm_2h8kRdHE_GIRYyJr: int = int(__OmKVLOjvFlPm8OJBjTFnkiry["mine"])
	var __7mfybqs_jEzBr4_m4vgx967I: int = int(__OmKVLOjvFlPm8OJBjTFnkiry["best"])

	var gain: int = clampi(__9MFWgnc8oYQpY6kqM0OFfhrH.__1o3RNeLtx00ko1HSgZEl_0Xi(__6SIf1S2uSmVcHglZgse0rqmn, __9MFWgnc8oYQpY6kqM0OFfhrH.__VXHR8_PK6BdTYDw2QpZIqbI8(__H_DT0F4P9u3L0d2FERrVmg1j.__zMZVCIoyJu5zkEI6YyKqPDoG)), 0, 4294967295)
	__OTZr8z508PZJxnQ0z3ipNQpf["credits"] = __9MFWgnc8oYQpY6kqM0OFfhrH.__1o3RNeLtx00ko1HSgZEl_0Xi(__bza1ZXDR2IYp3dNpmw9uzSAp, __9MFWgnc8oYQpY6kqM0OFfhrH.__rFs4lEQBnf7Box5_CDGsnZ5B(__H_DT0F4P9u3L0d2FERrVmg1j.__zMZVCIoyJu5zkEI6YyKqPDoG))
	__OTZr8z508PZJxnQ0z3ipNQpf["points"] = __9MFWgnc8oYQpY6kqM0OFfhrH.__1o3RNeLtx00ko1HSgZEl_0Xi(__wsdWBTBBixfca9Jx9H4qhjrP, __9MFWgnc8oYQpY6kqM0OFfhrH.__rFs4lEQBnf7Box5_CDGsnZ5B(__H_DT0F4P9u3L0d2FERrVmg1j.__zMZVCIoyJu5zkEI6YyKqPDoG))
	var __QgPI5zV1YQy3oYjDwMLboTBs: Dictionary = __p0VcvihgtXhiKjC_wbNpnF4q.finish()
	var __wi8mCT8hKX5VFlCKk5TfH3ue: int = int(__QgPI5zV1YQy3oYjDwMLboTBs["flags"])
	var ratio: float = float(__QgPI5zV1YQy3oYjDwMLboTBs["ratio"])
	if __wi8mCT8hKX5VFlCKk5TfH3ue & (__5N6awaIMq5qNkafjTDM69PIs.Flag.__hSweOGeAehf1dT7yq39zFMMT | __5N6awaIMq5qNkafjTDM69PIs.Flag.__PJBeiMZaF_5nyghh0H03V7ln):
		gain = floori(gain * ratio)
		__OTZr8z508PZJxnQ0z3ipNQpf["credits"] = floori(int(__OTZr8z508PZJxnQ0z3ipNQpf["credits"]) * ratio)
		__OTZr8z508PZJxnQ0z3ipNQpf["points"] = floori(int(__OTZr8z508PZJxnQ0z3ipNQpf["points"]) * ratio)
	var meti_before_bonus: Dictionary = __OTZr8z508PZJxnQ0z3ipNQpf.duplicate()
	var meti_capped: bool = gain < __6SIf1S2uSmVcHglZgse0rqmn or int(meti_before_bonus["credits"]) < __bza1ZXDR2IYp3dNpmw9uzSAp or int(meti_before_bonus["points"]) < __wsdWBTBBixfca9Jx9H4qhjrP
	var meti_pct: int = int((__9MFWgnc8oYQpY6kqM0OFfhrH.__qyvbOrjVYs2zGM2jUVQYSgGR().get("battle", {}) as Dictionary).get("meti_income_mult_pct", 100))
	for meti_currency in ["credits", "points"]:
		__OTZr8z508PZJxnQ0z3ipNQpf[meti_currency] = meti_income_after_bonus(int(__OTZr8z508PZJxnQ0z3ipNQpf[meti_currency]))
	var __5UEVXMb1xArZH0er6oyQkUQl: Dictionary = App.__M0ImV248NGNrBFXy9NCs5jwX().__6vukUhU2G_4b_rRHatkEj0ZY(gain, __OTZr8z508PZJxnQ0z3ipNQpf, __H_DT0F4P9u3L0d2FERrVmg1j.__WeB9Hi0OxaFBUuwm2WU2qKEH, __XJA_3lCLpDBdhGYWVDMeuFKk, {}, __H_DT0F4P9u3L0d2FERrVmg1j.__c15rG2tC96oGc8kXqdQ_1wyL)
	__5UEVXMb1xArZH0er6oyQkUQl["capped"] = meti_capped
	__5UEVXMb1xArZH0er6oyQkUQl["meti_before_bonus"] = meti_before_bonus
	__5UEVXMb1xArZH0er6oyQkUQl["meti_income_mult_pct"] = meti_pct
	__5UEVXMb1xArZH0er6oyQkUQl["mvp"] = __gT31LCm_2h8kRdHE_GIRYyJr > 0 and __gT31LCm_2h8kRdHE_GIRYyJr == __7mfybqs_jEzBr4_m4vgx967I
	__5UEVXMb1xArZH0er6oyQkUQl["air_kills"] = __bGkdz3KvT6NvE2AmieSpxtUI
	__5UEVXMb1xArZH0er6oyQkUQl["air_credit"] = __DL2yNM3BV9Lmjk_IjGgO27dt
	__5UEVXMb1xArZH0er6oyQkUQl["clock_flags"] = __wi8mCT8hKX5VFlCKk5TfH3ue
	__5UEVXMb1xArZH0er6oyQkUQl["clock_ratio"] = ratio
	__5UEVXMb1xArZH0er6oyQkUQl["clock_sim_ms"] = int(__QgPI5zV1YQy3oYjDwMLboTBs["sim_ms"])
	__5UEVXMb1xArZH0er6oyQkUQl["clock_wall_ms"] = int(__QgPI5zV1YQy3oYjDwMLboTBs["wall_ms"])
	__5UEVXMb1xArZH0er6oyQkUQl["clock_samples"] = int(__QgPI5zV1YQy3oYjDwMLboTBs["samples"])
	__of00oxcoTvym0dJG2Fz6nIiM(__OmKVLOjvFlPm8OJBjTFnkiry, gain, int(__OTZr8z508PZJxnQ0z3ipNQpf["credits"]), int(__OTZr8z508PZJxnQ0z3ipNQpf["points"]), __5UEVXMb1xArZH0er6oyQkUQl)
	return __5UEVXMb1xArZH0er6oyQkUQl
func __fo_QixeS5zCMq9jlAC8dEJNj(__0bgIrSMjdfGAxzAStTxQIRbr: int, h: int) -> void :
	__qlFicdtBAIg_rNEpMlXK2S0o[__0bgIrSMjdfGAxzAStTxQIRbr] = h
	if __i4WJeJTstISPCnqQAjaX2qhi:
		return
	var __tObNJGmOYMuvGXiUzSI6SSXv: int = __Im3kdj312UN9j6s5TpSfKOAs.__6UoHldZawwvQeZTuLJQHRrnw()
	if __tObNJGmOYMuvGXiUzSI6SSXv == 0 and __Im3kdj312UN9j6s5TpSfKOAs.__u0nkAKG5lGiEsenIJI6PFvMF >= __Uvzp2Nhc4YbduKNpA08hrEu5.__QskceNkdSrDq0Xkq06KZzb5y:
		__tObNJGmOYMuvGXiUzSI6SSXv = __TbAkFifAS33uxKcFDf16mKl5.__p_p1Wx3sVcyN02NXv70x3uDv.__cQ_gfQ2gW5LHIZ6LdqbCvVTF
	if __tObNJGmOYMuvGXiUzSI6SSXv == 0 and int(__iAbDeha6hgeEpDzp_OVLHMcN.get("ticks_limit", 0)) > 0 and __Im3kdj312UN9j6s5TpSfKOAs.__u0nkAKG5lGiEsenIJI6PFvMF >= int(__iAbDeha6hgeEpDzp_OVLHMcN["ticks_limit"]):
		__tObNJGmOYMuvGXiUzSI6SSXv = __TbAkFifAS33uxKcFDf16mKl5.__p_p1Wx3sVcyN02NXv70x3uDv.__cQ_gfQ2gW5LHIZ6LdqbCvVTF
	if __tObNJGmOYMuvGXiUzSI6SSXv != 0:
		__i4WJeJTstISPCnqQAjaX2qhi = true
		client.__rk6oft8gojs3V91eRKT5EUUS(__0bgIrSMjdfGAxzAStTxQIRbr, __tObNJGmOYMuvGXiUzSI6SSXv, h, __XcEBuZmYff2OSNt7_4huxaTI.__dRx4y0ZKvOQAyUgaQEQEOHJX(__Im3kdj312UN9j6s5TpSfKOAs) if __XcEBuZmYff2OSNt7_4huxaTI != null else PackedInt32Array())
var __iAbDeha6hgeEpDzp_OVLHMcN: Dictionary = {}
var __XcEBuZmYff2OSNt7_4huxaTI: __hOFKwxC8l_wy2rZeDG2LnkV_
func __xUtrAmQCt6WLEaRP0KW1kETe() -> Dictionary:
	if __H_DT0F4P9u3L0d2FERrVmg1j == null or __H_DT0F4P9u3L0d2FERrVmg1j.__g7JC3EJmfsOWnIyqLGGB93eB == null:
		return {}
	var __rurP1QfdWAsKA8EdLed7e9jv: int = 0
	for __46go_RxpEJqGkVEPAxHFkKWc: int in __H_DT0F4P9u3L0d2FERrVmg1j.__g7JC3EJmfsOWnIyqLGGB93eB.__xYLJ4HxXNYIH9o2lodd303ua.size():
		var __ui70IjLR1QZ2gan5aGniImhQ: Dictionary = __H_DT0F4P9u3L0d2FERrVmg1j.__g7JC3EJmfsOWnIyqLGGB93eB.__xYLJ4HxXNYIH9o2lodd303ua[__46go_RxpEJqGkVEPAxHFkKWc]
		__rurP1QfdWAsKA8EdLed7e9jv += __2omsALYMZSn3ijkiFbTa0YhU.get(__46go_RxpEJqGkVEPAxHFkKWc, 0) - int(__H_DT0F4P9u3L0d2FERrVmg1j.__g7JC3EJmfsOWnIyqLGGB93eB.__ovmWIjR9MK5E3k8GPT1QWt_B[int(__ui70IjLR1QZ2gan5aGniImhQ["type"])])
	return {"air_lost": maxi(0, __rurP1QfdWAsKA8EdLed7e9jv)}
var __kBqy45AI3C7dTuXhcOic75in: = __lQA2X_Tbdwp3cdBqDfL8XMPe.new()
var __KsofSZfpiiffy8tf0gzvABbm: Dictionary = {}
var __bGkdz3KvT6NvE2AmieSpxtUI: int:
	get: return __90bkbYVvZTOYe0VYY3rj_ZzV.get_value()
	set(v): __90bkbYVvZTOYe0VYY3rj_ZzV.set_value(v)
func _process(delta: float) -> void :
	if __Im3kdj312UN9j6s5TpSfKOAs == null:
		return
	__tJnc4IYOEg_SuNVvwdktpsXn = minf(__tJnc4IYOEg_SuNVvwdktpsXn + delta, __PZOQ1Qvd6XN8QPigmGN5RqqA * __GhEMP6WVBg2EtZjFpXq9U0fw)
	if __vCaHebXeTSk5ki_sJbb3gGEn:
		if __DW5u_PxmVzx39MAyJaNAZ9No != null:
			__DW5u_PxmVzx39MAyJaNAZ9No.__ct8qKYCzBoe8obGKLLgvCtKo()
		while __tJnc4IYOEg_SuNVvwdktpsXn >= __PZOQ1Qvd6XN8QPigmGN5RqqA:
			__tJnc4IYOEg_SuNVvwdktpsXn -= __PZOQ1Qvd6XN8QPigmGN5RqqA
			camera.__BcAiwNhsZO9jge7QHyhNOboP(Vector2(__H_DT0F4P9u3L0d2FERrVmg1j.x(), __H_DT0F4P9u3L0d2FERrVmg1j.y()))
			__NqcLKvQgaJD_pE3JD6vSe71E.__Lk1HMNJSPSOM7Y1ZkWxvaQCC()
		return
	while __tJnc4IYOEg_SuNVvwdktpsXn >= __PZOQ1Qvd6XN8QPigmGN5RqqA:
		__tJnc4IYOEg_SuNVvwdktpsXn -= __PZOQ1Qvd6XN8QPigmGN5RqqA
		_tick()
	__DW5u_PxmVzx39MAyJaNAZ9No.__TxUbCpkLLLUkvCEI2sqCGoPl(__Im3kdj312UN9j6s5TpSfKOAs.__gobxGwIVlftvCfJ1fsNzSlj7, Rect2(camera.position, camera.__7Q1u13W5jsLs8HPva7eP0p0P()), __aAsznirtmGYBj3M14TNZD1Cc.__1rVCG23BUdvthQ9LLlypabtj())
	if __898CZFX8zI40Huxp297h_lkH and __vUjiLF8Y8Ck6mD07UbSjsQ8I >= 0 and not __Mg6jxghXyZs3zgCi_qR1PwSb and not __LJD_DLosLmVUkX41Kalx6Ttc:
		__EiZRF1NnMPMecKiwh_R_ucyi += delta
		if __EiZRF1NnMPMecKiwh_R_ucyi >= __jopGolxuYOytI1kIbVUR0Abj * __PZOQ1Qvd6XN8QPigmGN5RqqA:
			__Mg6jxghXyZs3zgCi_qR1PwSb = true
			__F_jehFX5RJNUEjsCJ2T8nanH()
	__F8HZCw7buuEBi0A0Mf6znYAe.__Qa9GbnhM8GDjcw4fKszR0Ftz(self)
	if __doKOKtoKy3i4SBlfmjnARw4_ != null:
		__doKOKtoKy3i4SBlfmjnARw4_.__Qa9GbnhM8GDjcw4fKszR0Ftz(self)
var __83TSym9czt1PBDgaopjy6rEQ: int = -1
func __bFGIFOjLp4DCAQz2pYRzWdbG(__pzvOIlSi1mUw8Giw3Cj11pAU: String) -> void :
	if __SgEyrIZJCIKq5tHIvreYIf6z:
		return
	__SgEyrIZJCIKq5tHIvreYIf6z = true
	__u8UvjIlM7wFkkXpmjKu2BJUJ("lost")
	await UI.__Dzq5SbxUBHUUe7FLUyy2rI_S(tr("UI_LOST"), __pzvOIlSi1mUw8Giw3Cj11pAU, [tr("UI_BACK_HARBOR")])
	Session.__6boYmTBi229EPYhIG1rS9EZs()
	App.__VyWx49mpJs7424hYJ22diA_s()
func __J5MTDwc6HJsswvlehhkBjcaO(__tfXyKVgRqUD9acJHK62va4ga: int) -> void :
	__NqcLKvQgaJD_pE3JD6vSe71E.__Mf9wp9Xig2PCnnzLv0DyXzQO = __tfXyKVgRqUD9acJHK62va4ga
	__wbELGtzJYkGkxW7qLn9ltku7.__Mf9wp9Xig2PCnnzLv0DyXzQO = __tfXyKVgRqUD9acJHK62va4ga
	__NqcLKvQgaJD_pE3JD6vSe71E.__5asHp4YxjoVtjNPsWMIuoRZR([])
var __F8HZCw7buuEBi0A0Mf6znYAe: __tvt9CszM3uusC1HqCxL1X84m
var __Air1kJDZlSYUxsBJoK_dKO_V: int = -1
func __Ii95nGUq1VfgfQ5PYYCpsZZA() -> void :
	__pu08ep8gFB8kGVBlMsMmPfl_ = true
	__O7tQVHvLjLwc5CBGir5xcQGO(0)
	var __XDMfhC7Ccrlhu9smNMt952lY: int = maxi(__Uvzp2Nhc4YbduKNpA08hrEu5.__QskceNkdSrDq0Xkq06KZzb5y / __lAo0PsogaUvqHw4muTzPsHiR.__BvjYOp5V9D51FL_PzBjk4Wlf, 1)
	var __LwubKSgM42qPqll7eBgHoxyU: int = Time.get_ticks_msec()
	var __RG8s7kHAQnUAplnfT8_ysBq1: int = __LwubKSgM42qPqll7eBgHoxyU
	while not __i4WJeJTstISPCnqQAjaX2qhi and client.__EQuCPPWLxyLUNOZAfxsuqiRH() and is_inside_tree():
		var __2RAZPZO5bdPaeNSbtB3hi85A: bool = __BNtiAVKkxXLbNTzY2JctenZq.__cggSzXhOb5Ebo_SpXcitI9aZ()
		__z5sslWfZOq0V_PbBTItlWglS(__Im3kdj312UN9j6s5TpSfKOAs.__JW6kWzl9mmLENz2OGP5I1qGI())
		var __7lbFv5RyalodRlYLiQHSINcg: int = Time.get_ticks_msec()
		if __2RAZPZO5bdPaeNSbtB3hi85A:
			__RG8s7kHAQnUAplnfT8_ysBq1 = __7lbFv5RyalodRlYLiQHSINcg
		elif __7lbFv5RyalodRlYLiQHSINcg - __RG8s7kHAQnUAplnfT8_ysBq1 > __wqyG4SbwP5c4W0bx6ivd1v5u:
			break
		if not __2RAZPZO5bdPaeNSbtB3hi85A or __7lbFv5RyalodRlYLiQHSINcg - __LwubKSgM42qPqll7eBgHoxyU >= __oPiraE7TPjWFHkzUnJOVP_f7:
			__O7tQVHvLjLwc5CBGir5xcQGO(mini(__Im3kdj312UN9j6s5TpSfKOAs.__EaiCL_s7Is8n8XhLMgCmd8bh * 100 / __XDMfhC7Ccrlhu9smNMt952lY, 99))
			await get_tree().process_frame
			__LwubKSgM42qPqll7eBgHoxyU = Time.get_ticks_msec()
	var __Uzb7cnubrLHGoxaF6c9vBUoV: int = Time.get_ticks_msec()
	while __vUjiLF8Y8Ck6mD07UbSjsQ8I < 0 and client.__EQuCPPWLxyLUNOZAfxsuqiRH() and is_inside_tree() and Time.get_ticks_msec() - __Uzb7cnubrLHGoxaF6c9vBUoV < __wqyG4SbwP5c4W0bx6ivd1v5u:
		await get_tree().process_frame
	__pu08ep8gFB8kGVBlMsMmPfl_ = false
var __LJD_DLosLmVUkX41Kalx6Ttc: bool = false
func __IlUC_NC3OXFZTLC0kCLklDzm() -> void :
	__SgEyrIZJCIKq5tHIvreYIf6z = true
	__BiQoQGi6zNoff3oBH5w2ocqb = -1
	client.__UcctewY14V2ZY6pcHXj4WVQT(true)
	var __GdlZBWGhG_R0zFuAyV3fcFfL: int = Time.get_ticks_msec()
	while __BiQoQGi6zNoff3oBH5w2ocqb < 0 and client.__EQuCPPWLxyLUNOZAfxsuqiRH() and Time.get_ticks_msec() - __GdlZBWGhG_R0zFuAyV3fcFfL < __1GH3EU9THQuSRbfXN1ZL9x5i:
		await get_tree().process_frame
	if __BiQoQGi6zNoff3oBH5w2ocqb == 1:
		await __Ii95nGUq1VfgfQ5PYYCpsZZA()
		client.__nzYih8Dwbv8gsF4_OC9WyZVf = null
		if is_inside_tree():
			App.__C1KFt9tOFvmtDu5lhMey47Lc(__c8JJGEKEvrszgBpfNsvw4gM0())
		return
	client.__rHPjM22WErQ5NFazByygkf9U(__Uvzp2Nhc4YbduKNpA08hrEu5.__wMfg3dVnjdqMi7KUhLZ61Mhk, __H_DT0F4P9u3L0d2FERrVmg1j.__WeB9Hi0OxaFBUuwm2WU2qKEH)
	__D38wuayWXzdzHovfPrGdL14l()
var __323DjHVpeKq9qbqbhN5ocoRI: __jjKPQ5KMtbz3utndERcEBisR

static func meti_income_after_bonus(amount: int) -> int:

	return mini(clampi(amount, 0, 2147483647) * int((__9MFWgnc8oYQpY6kqM0OFfhrH.__qyvbOrjVYs2zGM2jUVQYSgGR().get("battle", {}) as Dictionary).get("meti_income_mult_pct", 100)) / 100, 2147483647)
