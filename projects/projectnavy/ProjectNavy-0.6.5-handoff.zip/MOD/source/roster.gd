class_name __MxRtF5kMQ2PhDOJRxJ1ej8ie
extends RefCounted
func __ZLLtGKDi74Tq9_nkqzjM8m28(amount: int) -> void :
	if not __ZRS6lZJh1TuB38TS82wWLE09.enabled():
		return
	__hN4a7punGT3ktCMQCiR5zjz7(amount, 0, __Bsl33jE0VgUtGf0ZDYkuZAkg.__SqQACpn7NvvJhPhBxGiVO55D)
func __UtIa9_8uhk7_1ITiksMpL89m(__Nk7ccGrtrENpNHfWkWdhACFy: __CgOl36_UCxYZW5PzufCcS4dS) -> String:
	if __Nk7ccGrtrENpNHfWkWdhACFy.__JMsr0yCjBlwnkO_7FV9gE93o():
		return "UI_CREW_ERR_ON_SHIP"
	__qpoG34O1fgw9L8TB5rO8XCfq.erase(__Nk7ccGrtrENpNHfWkWdhACFy)
	__jx52K0fsGItWa4CN83U1DY2k.__S_zUpUe6M5yTK0i0FISsyql8(__Nk7ccGrtrENpNHfWkWdhACFy.id)
	save()
	return ""
var ___FfBuNdLnmIikyyvatNDz628: __o4BlGoLwjfAD3TYKD8Kt7FzU
func __JbaCbud_kxBsreb0a_BflnIo() -> Dictionary:
	var __FOu43ae3_9wNDPbLslpb5s_N: Array = []
	for __Qlp5Hw4E26w1MgJiDaUrrqPJ: __CgOl36_UCxYZW5PzufCcS4dS in __qpoG34O1fgw9L8TB5rO8XCfq:
		__FOu43ae3_9wNDPbLslpb5s_N.append(__Qlp5Hw4E26w1MgJiDaUrrqPJ.__JbaCbud_kxBsreb0a_BflnIo())
	return {"version": __MF6yPnp9nwb3D9beyLm_G7qr, "points": points, "credits": __ktyxvkLP8cTjwSfnZb3DAVcL, "next_id": __GeYr1koKZu4yf18L5fqj_M1U, "ship_row": __3pHTyYQlMesWCy5zSJELYO80, "ship_guns": Array(__n49srIn8KerL_HEIiCdNmOxf), "ship_side": Array(__4SUknJBgHUaV9w15IdBVFhd5), "ship_torp": Array(__9tVQSDzDk22f49xhH1zXYlPe), "ship_torp_ammo": Array(__6jT8KoopEZhRFiDaeOpZK1bT), "ship_gun_ammo": Array(__da10PLrO3b92oiJTS9g3Vfve), "ship_air": Array(__a_utLkfvPV74XmpUxv0T2jqV), "ship_side_ammo": Array(__WkXP3BSGyqCbt6VAuFzmJWsZ), "ship_fcs": __DbuthnnVI6mcaRxkjF633v6v, "ship_armor": Array(__RqhcyeP1iDTNK0TaIVLeMfUM), "ship_engine": __cYNPT_ygRY3o9ufvyN3FSzFH, "members": __FOu43ae3_9wNDPbLslpb5s_N}
var __da10PLrO3b92oiJTS9g3Vfve: = PackedInt32Array()
var __GeYr1koKZu4yf18L5fqj_M1U: int = 1
func __8gf1LRFmWIu4atdcX2YYGtf5(source: int, __1C4QbpOvLZEiPxTb2MLKKNrP: int, __RpYJgmcosmHh4_TK77Y720Fg: int, __18GRqbz1cJosFptBrv74hmfO: int) -> void :
	var __r1p6MFTV2LdW9njMB2Johbol: int = __ktyxvkLP8cTjwSfnZb3DAVcL
	var __ADYEKU2vgEzI52MAWBuy31h2: int = points
	var __RCyTL5dtzG8Ro_kzHUx0oJm1: bool = source == __Bsl33jE0VgUtGf0ZDYkuZAkg.__sYsLt_iqlSFqM8rk1xUCFz2O
	var __SJrKhzDw4o5ldKO3a9nszRbz: int = 2147483647 if source == __Bsl33jE0VgUtGf0ZDYkuZAkg.__EsH2TfqGPeBfLiPNtFoEY8mb else __9MFWgnc8oYQpY6kqM0OFfhrH.__k3IF1okbwpM8SFe5Xeos8cd1()
	__ktyxvkLP8cTjwSfnZb3DAVcL = clampi(__ktyxvkLP8cTjwSfnZb3DAVcL + __1C4QbpOvLZEiPxTb2MLKKNrP, -2147483647 if __RCyTL5dtzG8Ro_kzHUx0oJm1 else mini(__r1p6MFTV2LdW9njMB2Johbol, 0), __SJrKhzDw4o5ldKO3a9nszRbz)

	points = clampi(points + __RpYJgmcosmHh4_TK77Y720Fg, -2147483647 if __RCyTL5dtzG8Ro_kzHUx0oJm1 else mini(__ADYEKU2vgEzI52MAWBuy31h2, 0), 2147483647)
	__jx52K0fsGItWa4CN83U1DY2k.__0p9bxVkwi7sidVOHmnpVNAjJ(__Bsl33jE0VgUtGf0ZDYkuZAkg.__jx52K0fsGItWa4CN83U1DY2k(source, __ktyxvkLP8cTjwSfnZb3DAVcL - __r1p6MFTV2LdW9njMB2Johbol, points - __ADYEKU2vgEzI52MAWBuy31h2, __18GRqbz1cJosFptBrv74hmfO))
func __YdmCDD1xIu3pkuWfqNIok5yI() -> int:
	return int(__qyvbOrjVYs2zGM2jUVQYSgGR.get("roster_max", 100))
func __7uYhXLkOUAfh6nv5PwanpntJ(__I5zRae4qwqEL3nar3ijrWTH2: __CgOl36_UCxYZW5PzufCcS4dS, __6BsKmEBCfGgOxRp5kAoDrynE: __CgOl36_UCxYZW5PzufCcS4dS = null) -> void :
	if __6BsKmEBCfGgOxRp5kAoDrynE == __I5zRae4qwqEL3nar3ijrWTH2 or not __qpoG34O1fgw9L8TB5rO8XCfq.has(__I5zRae4qwqEL3nar3ijrWTH2):
		return
	__qpoG34O1fgw9L8TB5rO8XCfq.erase(__I5zRae4qwqEL3nar3ijrWTH2)
	var __XxOdvBmsvAoHrLmIGk7hWbff: int = __qpoG34O1fgw9L8TB5rO8XCfq.find(__6BsKmEBCfGgOxRp5kAoDrynE) if __6BsKmEBCfGgOxRp5kAoDrynE != null else -1
	if __XxOdvBmsvAoHrLmIGk7hWbff < 0:
		__qpoG34O1fgw9L8TB5rO8XCfq.append(__I5zRae4qwqEL3nar3ijrWTH2)
	else:
		__qpoG34O1fgw9L8TB5rO8XCfq.insert(__XxOdvBmsvAoHrLmIGk7hWbff, __I5zRae4qwqEL3nar3ijrWTH2)
	save()
func __wu4mV2iA1GlGvuVZXD0a1FwK(__u2z9aG9Gq96QEjPweEJeDXVo: __CgOl36_UCxYZW5PzufCcS4dS, __DlzY3ChjbiubnLE3OsHIaI6Z: String) -> String:
	var meti_error: String = meti_recruit_validate(__u2z9aG9Gq96QEjPweEJeDXVo, __u2z9aG9Gq96QEjPweEJeDXVo.__wC11jxHS1J5bzkNesfKgNncZ)
	if meti_error != "":
		return meti_error
	var meti_hire_cost: int = __R8eeLnrHRznQldyBPlLJbDHQ(__u2z9aG9Gq96QEjPweEJeDXVo)
	if __qpoG34O1fgw9L8TB5rO8XCfq.size() >= __YdmCDD1xIu3pkuWfqNIok5yI():
		return "UI_CREW_ERR_ROSTER_FULL"
	var __zcXYyUdbHu5tVf2aedC5q1Bf: String = __jNPgEYKDT9jO3SpFHUZ8HJAM(__DlzY3ChjbiubnLE3OsHIaI6Z)
	if __zcXYyUdbHu5tVf2aedC5q1Bf != "":
		return __zcXYyUdbHu5tVf2aedC5q1Bf
	if points < meti_hire_cost:
		return "UI_CREW_ERR_POINTS"
	__u2z9aG9Gq96QEjPweEJeDXVo.name = __DlzY3ChjbiubnLE3OsHIaI6Z.strip_edges()
	__u2z9aG9Gq96QEjPweEJeDXVo.id = __GeYr1koKZu4yf18L5fqj_M1U
	__GeYr1koKZu4yf18L5fqj_M1U += 1
	__u2z9aG9Gq96QEjPweEJeDXVo.__q26f3dCYzrR9TyO_pwwz7lre = -1
	__8gf1LRFmWIu4atdcX2YYGtf5(__Bsl33jE0VgUtGf0ZDYkuZAkg.__NHGmOa6wEbOnfJHXuBNjmrw3, 0, - meti_hire_cost, __u2z9aG9Gq96QEjPweEJeDXVo.id)
	__qpoG34O1fgw9L8TB5rO8XCfq.append(__u2z9aG9Gq96QEjPweEJeDXVo)
	__jx52K0fsGItWa4CN83U1DY2k.__uXq7lesweQwPVFt806V2gCAg(__u2z9aG9Gq96QEjPweEJeDXVo.id, __Bsl33jE0VgUtGf0ZDYkuZAkg.__4Ru6nQhfQM3V8TFwZzShiQgn(__u2z9aG9Gq96QEjPweEJeDXVo))
	save()
	return ""
func __8je_IJ9qXhG3jZ1HE7jMMTAq() -> int:
	return int((__qyvbOrjVYs2zGM2jUVQYSgGR.get("recruit", {}) as Dictionary).get("reroll_cost", 0))
func __79b_vcAxjv7xWNoFe55ubkhE(__ArEDT4Tq4FUMRmUX2LeFuZYO: __CgOl36_UCxYZW5PzufCcS4dS, __8h6ICuLGk_rrLrhBgm8Sd6X4: int) -> int:
	if not __ZRS6lZJh1TuB38TS82wWLE09.enabled():
		return 0
	var __33kRFFgD7toCxEljpBFPuePt: int = - __ArEDT4Tq4FUMRmUX2LeFuZYO.exp
	for __eUWBSGmr1GBc5OdlmlaNhn5I: int in __8h6ICuLGk_rrLrhBgm8Sd6X4:
		if __ArEDT4Tq4FUMRmUX2LeFuZYO.__zMZVCIoyJu5zkEI6YyKqPDoG + __eUWBSGmr1GBc5OdlmlaNhn5I >= __ZEf8MUQNZMeLjokl2rCxl51Z():
			break
		__33kRFFgD7toCxEljpBFPuePt += __pRmI0Gva0OZ3_r554GsEvNGr(__ArEDT4Tq4FUMRmUX2LeFuZYO.__zMZVCIoyJu5zkEI6YyKqPDoG + __eUWBSGmr1GBc5OdlmlaNhn5I)
	__33kRFFgD7toCxEljpBFPuePt = maxi(__33kRFFgD7toCxEljpBFPuePt, 0)
	__eEzZAN_Zxk5bFAPUikmHkYlB(__ArEDT4Tq4FUMRmUX2LeFuZYO, __33kRFFgD7toCxEljpBFPuePt)
	return __33kRFFgD7toCxEljpBFPuePt
func __aGKFFuWZttAOryPti7pfE3iP(__HnQ12Xl56T4w3hIDhCV_aiLE: int) -> bool:
	if __HnQ12Xl56T4w3hIDhCV_aiLE == 0:
		return true
	for __R_XAbYIw8CinO4xjb8v_FACd: __CgOl36_UCxYZW5PzufCcS4dS in __qpoG34O1fgw9L8TB5rO8XCfq:
		var __MxstsDnvErVB2yQ227DqcnJK: Dictionary = __LVCMU4xMBMMHO5bxpAYeHYWt(__R_XAbYIw8CinO4xjb8v_FACd)
		if __o4BlGoLwjfAD3TYKD8Kt7FzU.__jImD0sut02cad96nddoNN3be(__MxstsDnvErVB2yQ227DqcnJK) and int(__MxstsDnvErVB2yQ227DqcnJK.get("nation", 0)) == __HnQ12Xl56T4w3hIDhCV_aiLE:
			return true
	return false
func __2dlO_ydjjaq3W473KRjPZyHh(__l6PzJR3YindJY8sM11NORLP1: __s8yZigV26lPAvEmbOWzMbnjE) -> PackedInt32Array:
	var __XnaOgs0glceAB4zGlqANHozA: = PackedInt32Array()
	var __QNy3h6l7pDQzMfIr9f30yYy_: __2eoTFZc6WxKKaBxTkxeRtmOZ = __EhjJRLjwGbixjchwHoi91WQb(__l6PzJR3YindJY8sM11NORLP1.__WeB9Hi0OxaFBUuwm2WU2qKEH)
	if __QNy3h6l7pDQzMfIr9f30yYy_ == null:
		return __XnaOgs0glceAB4zGlqANHozA
	var __C7NYQN5n9vGrtZXV3bYqUYOs: Dictionary = {}
	for __wUq35pvGO1gYFe3GjlrRgnos: __CgOl36_UCxYZW5PzufCcS4dS in __cQ9sPbueMGXZt2aYRGhozxDp(__l6PzJR3YindJY8sM11NORLP1.__WeB9Hi0OxaFBUuwm2WU2qKEH):
		if not __QNy3h6l7pDQzMfIr9f30yYy_.__ykzgAs0XCiNBCa5N91GVfvLY(__wUq35pvGO1gYFe3GjlrRgnos.__q26f3dCYzrR9TyO_pwwz7lre):
			continue
		var __nACD7loHQdB1y2po4bHEtZLw: Dictionary = __LVCMU4xMBMMHO5bxpAYeHYWt(__wUq35pvGO1gYFe3GjlrRgnos)
		var flags: int = int(__nACD7loHQdB1y2po4bHEtZLw.get("flags", 0))
		var __PO97VCpo6e9sG2KqrYRSUt3o: int = -1
		if flags & __o4BlGoLwjfAD3TYKD8Kt7FzU.__MVMauSX35xohYDjgjfANHN_6:
			__PO97VCpo6e9sG2KqrYRSUt3o = __Se4EsxPBCHX48h1ZS5MexaMl.__dN_6FWGwZykmxR1WpfFXTqiU
		elif flags & __o4BlGoLwjfAD3TYKD8Kt7FzU.__PXsU2k9jg56fnHWMOimCGNv3:
			__PO97VCpo6e9sG2KqrYRSUt3o = __Se4EsxPBCHX48h1ZS5MexaMl.__XRYGrwULxM1MOAxBrhLtVDBO
		if __PO97VCpo6e9sG2KqrYRSUt3o < 0:
			continue
		var __DjNYs6AZ_X3WilflLTytoXxF: int = __LlOvNfSW39vQFa_X5z9isu0g.__YPQoeMce4Ux_l1KIJiNnBaIy(__wUq35pvGO1gYFe3GjlrRgnos.__4ObdBYhtKkHScUayTPgiYzH_[__o4BlGoLwjfAD3TYKD8Kt7FzU.__zQFbz4wT5ybXvNTatdPLjuFc.__AuLYcgB557BmcSJZGEBo_8wk])
		if not __C7NYQN5n9vGrtZXV3bYqUYOs.has(__PO97VCpo6e9sG2KqrYRSUt3o) or __DjNYs6AZ_X3WilflLTytoXxF > int(__C7NYQN5n9vGrtZXV3bYqUYOs[__PO97VCpo6e9sG2KqrYRSUt3o][0]):
			__C7NYQN5n9vGrtZXV3bYqUYOs[__PO97VCpo6e9sG2KqrYRSUt3o] = [__DjNYs6AZ_X3WilflLTytoXxF, clampi(__wUq35pvGO1gYFe3GjlrRgnos.__zMZVCIoyJu5zkEI6YyKqPDoG, 1, 120), clampi(int(__nACD7loHQdB1y2po4bHEtZLw.get("nation", 0)), 0, 8)]
	for __V9pYXI6c1qKoRnZzIQ4tBR_s: int in [__Se4EsxPBCHX48h1ZS5MexaMl.__XRYGrwULxM1MOAxBrhLtVDBO, __Se4EsxPBCHX48h1ZS5MexaMl.__dN_6FWGwZykmxR1WpfFXTqiU]:
		if __C7NYQN5n9vGrtZXV3bYqUYOs.has(__V9pYXI6c1qKoRnZzIQ4tBR_s):
			__XnaOgs0glceAB4zGlqANHozA.append_array([__V9pYXI6c1qKoRnZzIQ4tBR_s, int(__C7NYQN5n9vGrtZXV3bYqUYOs[__V9pYXI6c1qKoRnZzIQ4tBR_s][1]), int(__C7NYQN5n9vGrtZXV3bYqUYOs[__V9pYXI6c1qKoRnZzIQ4tBR_s][0]), int(__C7NYQN5n9vGrtZXV3bYqUYOs[__V9pYXI6c1qKoRnZzIQ4tBR_s][2])])
	return __XnaOgs0glceAB4zGlqANHozA
var __qyvbOrjVYs2zGM2jUVQYSgGR: Dictionary = {}
static func __6U088MxIMDA0KhiJnEzHmwiX(__JQ6jREVj2ZA5H4b2bCJ8jkYS: int, __nlw5l3T33eYi8RNOluWYekda: int, end: int) -> int:
	if end <= 0 or __nlw5l3T33eYi8RNOluWYekda >= end:
		return __JQ6jREVj2ZA5H4b2bCJ8jkYS
	return __JQ6jREVj2ZA5H4b2bCJ8jkYS * maxi(__nlw5l3T33eYi8RNOluWYekda, end * __CK83XjuJnreQUu2blQSJAB0t / 100) / end
func ___NcBFFeS8VOtaADppynFhzPW() -> void :
	var __vb4d9ay6nbWfjHp4nmftUnAj: Array[__CgOl36_UCxYZW5PzufCcS4dS] = __ppcxPlgo8rFGMVWibpznKVCQ()
	__vb4d9ay6nbWfjHp4nmftUnAj.sort_custom( func(a: __CgOl36_UCxYZW5PzufCcS4dS, b: __CgOl36_UCxYZW5PzufCcS4dS) -> bool:
		return __o4BlGoLwjfAD3TYKD8Kt7FzU.__jImD0sut02cad96nddoNN3be(__LVCMU4xMBMMHO5bxpAYeHYWt(a)) and not __o4BlGoLwjfAD3TYKD8Kt7FzU.__jImD0sut02cad96nddoNN3be(__LVCMU4xMBMMHO5bxpAYeHYWt(b)))
	for ___jk0Y1xYAdfeLeT5dORnGNXL: __CgOl36_UCxYZW5PzufCcS4dS in __vb4d9ay6nbWfjHp4nmftUnAj:
		if not ___jk0Y1xYAdfeLeT5dORnGNXL.__JMsr0yCjBlwnkO_7FV9gE93o():
			__sdlPqoZlTuS5DkBvS_mnTzdQ(___jk0Y1xYAdfeLeT5dORnGNXL)
var __3pHTyYQlMesWCy5zSJELYO80: int = -1
func __s9NjLberCgHxlhUKnUjnPOjq(__V7ak1DWengcZ2w2ltuPpc9W2: __CgOl36_UCxYZW5PzufCcS4dS, __YluqqNQBvKdlBknXXCJsxj16: int, __NfpUGLZJKyqxQlVxk0Fq9DFV: __2eoTFZc6WxKKaBxTkxeRtmOZ) -> bool:
	if __NfpUGLZJKyqxQlVxk0Fq9DFV.__LilkEL6lVyhI4ysup5O5wZQF:
		return true
	if __tA3YJLknlQFRzbdlkSywAVMu.__ODueSvGeVnWggM8WyoKBoh4p(__NfpUGLZJKyqxQlVxk0Fq9DFV.__4ZkPKa8dk6pXR1groh01Zac6):
		return (__YluqqNQBvKdlBknXXCJsxj16 == __NfpUGLZJKyqxQlVxk0Fq9DFV.__V9nPx6hwHXTjiZSit4R51eP0 and __V7ak1DWengcZ2w2ltuPpc9W2.__hJTRC1qsUs9T0VQkseYzTT2f == __NfpUGLZJKyqxQlVxk0Fq9DFV.__4ZkPKa8dk6pXR1groh01Zac6) or __V7ak1DWengcZ2w2ltuPpc9W2.__1U0d7dXiK8nppclbz5xhDxaz.has(__NfpUGLZJKyqxQlVxk0Fq9DFV.__4ZkPKa8dk6pXR1groh01Zac6)
	return true
func __IuDP9w3LX3PDa0VZR_faHzyc(__oNiV3Odrt_LHGaCzKeuXUAf2: __CgOl36_UCxYZW5PzufCcS4dS, __TyW2BFD77bqgJEp7kUfjr7dh: int) -> String:
	var __MSKBca6CysXBGUUTZ72ARfzr: __2eoTFZc6WxKKaBxTkxeRtmOZ = __ofKSCLcCg7jWtqacDa153ehk()
	if __MSKBca6CysXBGUUTZ72ARfzr == null or not __MSKBca6CysXBGUUTZ72ARfzr.__XlyecKoUZWL4KyL0Lkce70AI(__TyW2BFD77bqgJEp7kUfjr7dh):
		return "UI_CREW_ERR_NO_SEAT"
	var __w70lxQdIGsOkmkjihuKvrOCg: Dictionary = __LVCMU4xMBMMHO5bxpAYeHYWt(__oNiV3Odrt_LHGaCzKeuXUAf2)
	var __b4_nQBC3Y8dRwDJVbmOsueCV: __CgOl36_UCxYZW5PzufCcS4dS = __ifUAqOmtFvNZXIqHYuzi470Y(__TyW2BFD77bqgJEp7kUfjr7dh)
	if __b4_nQBC3Y8dRwDJVbmOsueCV != null and __b4_nQBC3Y8dRwDJVbmOsueCV != __oNiV3Odrt_LHGaCzKeuXUAf2 and __o4BlGoLwjfAD3TYKD8Kt7FzU.__jImD0sut02cad96nddoNN3be(__LVCMU4xMBMMHO5bxpAYeHYWt(__b4_nQBC3Y8dRwDJVbmOsueCV)):
		return "UI_CREW_ERR_NO_SEAT"
	var load: int = __VbZUWaBQx57NXvzCmbgibMgO() + __RuEf8sDpDtu0ArTJYzf6W0JG(__oNiV3Odrt_LHGaCzKeuXUAf2) + __oNiV3Odrt_LHGaCzKeuXUAf2.__Ln9avrueTbF2AkgyV87ZgBiF(__w70lxQdIGsOkmkjihuKvrOCg, __MSKBca6CysXBGUUTZ72ARfzr.__JzUUCYNEpRcSKSi9X3gAiTQK())
	if __b4_nQBC3Y8dRwDJVbmOsueCV != null and __b4_nQBC3Y8dRwDJVbmOsueCV != __oNiV3Odrt_LHGaCzKeuXUAf2:
		load -= __b4_nQBC3Y8dRwDJVbmOsueCV.__Ln9avrueTbF2AkgyV87ZgBiF(__LVCMU4xMBMMHO5bxpAYeHYWt(__b4_nQBC3Y8dRwDJVbmOsueCV), __MSKBca6CysXBGUUTZ72ARfzr.__JzUUCYNEpRcSKSi9X3gAiTQK())
	if load > __MSKBca6CysXBGUUTZ72ARfzr.__ISyWU6MieRONO0Y_61I5cH44:
		return "UI_CREW_ERR_WEIGHT"
	var __5YDHjQFG5QXTpGxF3xK71fvz: bool = __o4BlGoLwjfAD3TYKD8Kt7FzU.__jImD0sut02cad96nddoNN3be(__w70lxQdIGsOkmkjihuKvrOCg)
	var __BwiLmNvEjoxeYxSfGvtAWO9w: int = int(__w70lxQdIGsOkmkjihuKvrOCg.get("nation", 0))
	if not __g1fieNYIazuBRAy4BIxDTBLm(__BwiLmNvEjoxeYxSfGvtAWO9w, __MSKBca6CysXBGUUTZ72ARfzr.__V9nPx6hwHXTjiZSit4R51eP0):
		return "UI_CREW_ERR_NATION"
	if __TyW2BFD77bqgJEp7kUfjr7dh == 0:
		if __MSKBca6CysXBGUUTZ72ARfzr.__AiCl3NzuKkSgTyTHfA28XSX1:
			if not __5YDHjQFG5QXTpGxF3xK71fvz:
				return "UI_CREW_ERR_NOT_CAPTAIN"
			if __oNiV3Odrt_LHGaCzKeuXUAf2.__zMZVCIoyJu5zkEI6YyKqPDoG < __MSKBca6CysXBGUUTZ72ARfzr.__zMZVCIoyJu5zkEI6YyKqPDoG:
				return "UI_CREW_ERR_CAPTAIN_LEVEL"
			if not __s9NjLberCgHxlhUKnUjnPOjq(__oNiV3Odrt_LHGaCzKeuXUAf2, __BwiLmNvEjoxeYxSfGvtAWO9w, __MSKBca6CysXBGUUTZ72ARfzr):
				return "UI_CREW_ERR_CHANGE_CAPTAIN"
		else:
			if __oNiV3Odrt_LHGaCzKeuXUAf2.__zMZVCIoyJu5zkEI6YyKqPDoG < __MSKBca6CysXBGUUTZ72ARfzr.__zMZVCIoyJu5zkEI6YyKqPDoG:
				return "UI_CREW_ERR_CAPTAIN_LEVEL"
		return ""
	if __5YDHjQFG5QXTpGxF3xK71fvz:
		return "UI_CREW_ERR_BRIDGE_ONLY"
	if __MSKBca6CysXBGUUTZ72ARfzr.__ykzgAs0XCiNBCa5N91GVfvLY(__TyW2BFD77bqgJEp7kUfjr7dh) and __MSKBca6CysXBGUUTZ72ARfzr.__RZSGss6vMJxzvS6fmWkQMma8 == __2eoTFZc6WxKKaBxTkxeRtmOZ.__UdurGu7NlLw_5NC5J7D7nIXj and __o4BlGoLwjfAD3TYKD8Kt7FzU.__2X3IZe5CzNDNYOs5LbrywSPN(__w70lxQdIGsOkmkjihuKvrOCg) and __MSKBca6CysXBGUUTZ72ARfzr.__zMZVCIoyJu5zkEI6YyKqPDoG >= __oNiV3Odrt_LHGaCzKeuXUAf2.__zMZVCIoyJu5zkEI6YyKqPDoG + 15:
		return "UI_CREW_ERR_PILOT_LEVEL"
	return ""
func _load() -> bool:
	var v: Variant = __dFm6DOUISO0GARjmCPdhCxZ0.__FOgjvlUGfoVixz4D2RuLsiii("crew")
	__dFm6DOUISO0GARjmCPdhCxZ0.bind("crew", __JbaCbud_kxBsreb0a_BflnIo)
	if not (v is Dictionary) or int((v as Dictionary).get("version", 0)) != __MF6yPnp9nwb3D9beyLm_G7qr:
		return false
	var d: Dictionary = v
	points = int(d.get("points", 0))
	__ktyxvkLP8cTjwSfnZb3DAVcL = int(d.get("credits", __9MFWgnc8oYQpY6kqM0OFfhrH.__smzfG1UnW0vxTjXlKlUHVrKa()))
	__GeYr1koKZu4yf18L5fqj_M1U = int(d.get("next_id", 1))
	__3pHTyYQlMesWCy5zSJELYO80 = int(d.get("ship_row", -1))
	__n49srIn8KerL_HEIiCdNmOxf = PackedInt32Array()
	for g: Variant in d.get("ship_guns", []):
		__n49srIn8KerL_HEIiCdNmOxf.append(int(g))
	__4SUknJBgHUaV9w15IdBVFhd5 = PackedInt32Array()
	for g: Variant in d.get("ship_side", []):
		__4SUknJBgHUaV9w15IdBVFhd5.append(int(g))
	__9tVQSDzDk22f49xhH1zXYlPe = PackedInt32Array()
	for g: Variant in d.get("ship_torp", []):
		__9tVQSDzDk22f49xhH1zXYlPe.append(int(g))
	__6jT8KoopEZhRFiDaeOpZK1bT = PackedInt32Array()
	for g: Variant in d.get("ship_torp_ammo", []):
		__6jT8KoopEZhRFiDaeOpZK1bT.append(int(g))
	__da10PLrO3b92oiJTS9g3Vfve = PackedInt32Array()
	for g: Variant in d.get("ship_gun_ammo", []):
		__da10PLrO3b92oiJTS9g3Vfve.append(int(g))
	__a_utLkfvPV74XmpUxv0T2jqV = PackedInt32Array()
	for g: Variant in d.get("ship_air", []):
		__a_utLkfvPV74XmpUxv0T2jqV.append(int(g))
	__WkXP3BSGyqCbt6VAuFzmJWsZ = PackedInt32Array()
	for g: Variant in d.get("ship_side_ammo", []):
		__WkXP3BSGyqCbt6VAuFzmJWsZ.append(int(g))
	__DbuthnnVI6mcaRxkjF633v6v = int(d.get("ship_fcs", __s8yZigV26lPAvEmbOWzMbnjE.__VWd1Gfr1VadwmHRrVFdTi1VT))
	__cYNPT_ygRY3o9ufvyN3FSzFH = int(d.get("ship_engine", __s8yZigV26lPAvEmbOWzMbnjE.__gzDclDFgoL3uDH5vfZQtcFjr))
	__RqhcyeP1iDTNK0TaIVLeMfUM = PackedInt32Array()
	for g: Variant in d.get("ship_armor", []):
		__RqhcyeP1iDTNK0TaIVLeMfUM.append(int(g))
	__qpoG34O1fgw9L8TB5rO8XCfq.clear()
	for __u8P9ZDrLZ29ceXbCSY3O48b1: Variant in d.get("members", []):
		if __u8P9ZDrLZ29ceXbCSY3O48b1 is Dictionary:
			var __5CEcaMV6e4DJm9eGszrcgVv8: __CgOl36_UCxYZW5PzufCcS4dS = __CgOl36_UCxYZW5PzufCcS4dS.__ebQ0WafxO2YLU6eTaq0eHAEc(__u8P9ZDrLZ29ceXbCSY3O48b1)
			__5CEcaMV6e4DJm9eGszrcgVv8.name = __ThKAxtrVk_ROrnDyOUbAWswZ.get(__5CEcaMV6e4DJm9eGszrcgVv8.name, __5CEcaMV6e4DJm9eGszrcgVv8.name)
			if __o4BlGoLwjfAD3TYKD8Kt7FzU.__FLBcWdmSyKhlCkG_2_FUG10K(___FfBuNdLnmIikyyvatNDz628.__eKMOY9vZxsK1HnP0cqwVRqgs(__5CEcaMV6e4DJm9eGszrcgVv8.__mpLpovabZnp87HNkreW4pWJY)):
				__qpoG34O1fgw9L8TB5rO8XCfq.append(__5CEcaMV6e4DJm9eGszrcgVv8)
				if __5CEcaMV6e4DJm9eGszrcgVv8.__q26f3dCYzrR9TyO_pwwz7lre >= 0 and __5CEcaMV6e4DJm9eGszrcgVv8.__ofKSCLcCg7jWtqacDa153ehk < 0:
					__5CEcaMV6e4DJm9eGszrcgVv8.__ofKSCLcCg7jWtqacDa153ehk = __3pHTyYQlMesWCy5zSJELYO80
				if not (__u8P9ZDrLZ29ceXbCSY3O48b1 as Dictionary).has("growth"):
					__5CEcaMV6e4DJm9eGszrcgVv8.__wC11jxHS1J5bzkNesfKgNncZ = __geUHcewBqVa9L7LKcQ8q2MXR(__LVCMU4xMBMMHO5bxpAYeHYWt(__5CEcaMV6e4DJm9eGszrcgVv8))
				if not (__u8P9ZDrLZ29ceXbCSY3O48b1 as Dictionary).has("route_node") and __5CEcaMV6e4DJm9eGszrcgVv8.__q26f3dCYzrR9TyO_pwwz7lre == 0 and __o4BlGoLwjfAD3TYKD8Kt7FzU.__jImD0sut02cad96nddoNN3be(__LVCMU4xMBMMHO5bxpAYeHYWt(__5CEcaMV6e4DJm9eGszrcgVv8)):
					__zWR20uspUQuHgajid8HBmEnj(__5CEcaMV6e4DJm9eGszrcgVv8, __tA3YJLknlQFRzbdlkSywAVMu.__egBhFKhVbnr7KydxNtWKHc9D(__3pHTyYQlMesWCy5zSJELYO80))
	return true
func __IlwOWmYpiy_XUpD8gVj6YoPh(__WYewSOCyFX4Emyyg47CQ9p0H: __CgOl36_UCxYZW5PzufCcS4dS, id: int) -> String:
	if not __o4BlGoLwjfAD3TYKD8Kt7FzU.__jImD0sut02cad96nddoNN3be(__LVCMU4xMBMMHO5bxpAYeHYWt(__WYewSOCyFX4Emyyg47CQ9p0H)):
		return "UI_TREE_ERR_NOT_CAPTAIN"
	if __WYewSOCyFX4Emyyg47CQ9p0H.__JMsr0yCjBlwnkO_7FV9gE93o():
		return "UI_TREE_ERR_ON_SHIP"
	if not __Sn0Tcqw1tUdVUvraDQFCbHi2(__WYewSOCyFX4Emyyg47CQ9p0H).has(id):
		return "UI_TREE_ERR_NOT_NEXT"
	if __WYewSOCyFX4Emyyg47CQ9p0H.__zMZVCIoyJu5zkEI6YyKqPDoG < __tA3YJLknlQFRzbdlkSywAVMu.__zMZVCIoyJu5zkEI6YyKqPDoG(id):
		return "UI_TREE_ERR_LEVEL"
	return ""
func __ezmCKdWm9cDeYJ_774xlKddx(__IANsMcRF4sFipQ0qNx88syrJ: __CgOl36_UCxYZW5PzufCcS4dS, __TLWm_iOpfYLt0glA6vXMKAX1: int) -> int:
	var a: int = __IANsMcRF4sFipQ0qNx88syrJ.__pY661vwzoRY0D6Y5ORWYVaB_[0]
	var __OMZ1W1Rjcp6T4iacXVev6Ltu: int = mini(__caiJN7usYIEMNh51fTf1ETV8.__DdjO7licqxMK90434TaAU1qH, a)
	var __LmhrS2sx7dCcioLM5lN5jYAQ: int = clampi(__TLWm_iOpfYLt0glA6vXMKAX1, 0, __OMZ1W1Rjcp6T4iacXVev6Ltu)
	if __IANsMcRF4sFipQ0qNx88syrJ.__q26f3dCYzrR9TyO_pwwz7lre >= 0 and __IANsMcRF4sFipQ0qNx88syrJ.__q26f3dCYzrR9TyO_pwwz7lre < __s8yZigV26lPAvEmbOWzMbnjE.__9ERqgkhcu5lsXP6AozrSOU0q and __LmhrS2sx7dCcioLM5lN5jYAQ < __OMZ1W1Rjcp6T4iacXVev6Ltu:
		var __cjFHZVV3CzX9Auan7PrwSrR0: int = 0
		var rest: int = a
		var __MHWMEjOgJmPuyzQr4wSIhk2g: int = __OFvzEBmSOaaka_xG3IPSAJTS()
		while rest > 0:
			var __mtNxvYNlHG15tBL1sc3tCcw3: int = mini(rest, 50)
			if __FOzOkL_5wngFw83WISq0FbBm.randi_range(0, 999) < __mtNxvYNlHG15tBL1sc3tCcw3 * __MHWMEjOgJmPuyzQr4wSIhk2g:
				__cjFHZVV3CzX9Auan7PrwSrR0 += 1
			rest -= 50
		__LmhrS2sx7dCcioLM5lN5jYAQ = mini(__LmhrS2sx7dCcioLM5lN5jYAQ + mini(__cjFHZVV3CzX9Auan7PrwSrR0, 3), __OMZ1W1Rjcp6T4iacXVev6Ltu)
	if __LmhrS2sx7dCcioLM5lN5jYAQ <= 0:
		return 0

	__LmhrS2sx7dCcioLM5lN5jYAQ = mini(a, __LmhrS2sx7dCcioLM5lN5jYAQ * maxi(1, int((__qyvbOrjVYs2zGM2jUVQYSgGR.get("battle", {}) as Dictionary).get("meti_training_mult", 1))))
	__IANsMcRF4sFipQ0qNx88syrJ.__pY661vwzoRY0D6Y5ORWYVaB_[0] -= __LmhrS2sx7dCcioLM5lN5jYAQ
	__IANsMcRF4sFipQ0qNx88syrJ.__pY661vwzoRY0D6Y5ORWYVaB_[1] += __LmhrS2sx7dCcioLM5lN5jYAQ
	__jx52K0fsGItWa4CN83U1DY2k.__uXq7lesweQwPVFt806V2gCAg(__IANsMcRF4sFipQ0qNx88syrJ.id, __Bsl33jE0VgUtGf0ZDYkuZAkg.__pY661vwzoRY0D6Y5ORWYVaB_( - __LmhrS2sx7dCcioLM5lN5jYAQ, __LmhrS2sx7dCcioLM5lN5jYAQ, 0))
	return __LmhrS2sx7dCcioLM5lN5jYAQ
func ___HvqiRmS3LxFNwDWQwWYBoXa(__xbCZ21LigO_casjpTMO0hVzd: __CgOl36_UCxYZW5PzufCcS4dS) -> Array[Dictionary]:
	var __Ls8wVwtkfAvhzCTUInFLLDnH: int = int(__LVCMU4xMBMMHO5bxpAYeHYWt(__xbCZ21LigO_casjpTMO0hVzd).get("nation", 0))
	var __RYqjOpjqauQ2zj54SSp0MWhm: Array[Dictionary] = []
	for __tLViiR51RlumC13WLT2JVuWE: Dictionary in ___FfBuNdLnmIikyyvatNDz628.__ub1YxTiOmN7pfRXO5aM4nha0(__LVCMU4xMBMMHO5bxpAYeHYWt(__xbCZ21LigO_casjpTMO0hVzd)):
		if not __Se4EsxPBCHX48h1ZS5MexaMl.__G8VgBybQlmXf2sdRasT3PwJT(int(__tLViiR51RlumC13WLT2JVuWE["nation"])) or int(__tLViiR51RlumC13WLT2JVuWE["nation"]) == __Ls8wVwtkfAvhzCTUInFLLDnH:
			__RYqjOpjqauQ2zj54SSp0MWhm.append(__tLViiR51RlumC13WLT2JVuWE)
	return __RYqjOpjqauQ2zj54SSp0MWhm
func __cy8MlQEbWMnDn0W8brML_OIf() -> int:
	return int((__qyvbOrjVYs2zGM2jUVQYSgGR.get("route", {}) as Dictionary).get("reset_cost", 0))
static func __6eO7PI5bMzEA5GZJb78SZ1LV(__YImV_Qr9WWT8D4h40_Fa8LWd: int, __awDm8ONdjue8FyiO81ZDGTTi: int, __ivuZTjJjQHL0SaGjoB4SUbuI: int, __S6QWcr1iCcXMpP_PgdtiaSip: int, __3OkGgLgEz5iadG4Su_m_D_Z0: int, __1mm7gaYqRsGvzHAXATMlOHkQ: int, __dwlitdgnYYicLqgVowFeN7hr: bool) -> int:
	if __YImV_Qr9WWT8D4h40_Fa8LWd <= 0 or __awDm8ONdjue8FyiO81ZDGTTi <= 0:
		return 0
	var __depSeovfO0iIrxEZujCBSqMr: float = 1.0

	var __DKlr8jnz4H0uWBS2HyKFJ6TM: int = int(float(__YImV_Qr9WWT8D4h40_Fa8LWd) / float(__awDm8ONdjue8FyiO81ZDGTTi) * float(__ivuZTjJjQHL0SaGjoB4SUbuI) * __depSeovfO0iIrxEZujCBSqMr)
	var __QVcqmfJF1pzGeUUVCH8DLPDR: int = __DKlr8jnz4H0uWBS2HyKFJ6TM * (100 if __dwlitdgnYYicLqgVowFeN7hr else 85) / 10000
	if __1mm7gaYqRsGvzHAXATMlOHkQ > 0:
		__QVcqmfJF1pzGeUUVCH8DLPDR = __QVcqmfJF1pzGeUUVCH8DLPDR * (60 + __3OkGgLgEz5iadG4Su_m_D_Z0 * 40 / __1mm7gaYqRsGvzHAXATMlOHkQ) / 100
	__QVcqmfJF1pzGeUUVCH8DLPDR = __QVcqmfJF1pzGeUUVCH8DLPDR * 12 / 10
	return maxi(__QVcqmfJF1pzGeUUVCH8DLPDR, 0)
func __qcnliMKio6fmDg5_jGjLaiay(__6A7yCZoQwuWkSWbeUSjoufZh: __CgOl36_UCxYZW5PzufCcS4dS, id: int) -> String:
	var __tTrz8XsbwyiLb1yCCaVqrbd0: String = __IlwOWmYpiy_XUpD8gVj6YoPh(__6A7yCZoQwuWkSWbeUSjoufZh, id)
	if __tTrz8XsbwyiLb1yCCaVqrbd0 != "":
		return __tTrz8XsbwyiLb1yCCaVqrbd0
	if not __6A7yCZoQwuWkSWbeUSjoufZh.__1U0d7dXiK8nppclbz5xhDxaz.has(__6A7yCZoQwuWkSWbeUSjoufZh.__hJTRC1qsUs9T0VQkseYzTT2f) and __6A7yCZoQwuWkSWbeUSjoufZh.__1U0d7dXiK8nppclbz5xhDxaz.size() < __1OkQgYNA0NkvkBligBeQgZWC.__3fKBPF8xIVn7LnRIBUmAHIz6:
		__6A7yCZoQwuWkSWbeUSjoufZh.__1U0d7dXiK8nppclbz5xhDxaz.append(__6A7yCZoQwuWkSWbeUSjoufZh.__hJTRC1qsUs9T0VQkseYzTT2f)
	__6A7yCZoQwuWkSWbeUSjoufZh.__hJTRC1qsUs9T0VQkseYzTT2f = id
	__jx52K0fsGItWa4CN83U1DY2k.__uXq7lesweQwPVFt806V2gCAg(__6A7yCZoQwuWkSWbeUSjoufZh.id, __Bsl33jE0VgUtGf0ZDYkuZAkg.__ulOyzeridQn9EcS2r8quda4K(id))
	save()
	return ""
func __EhjJRLjwGbixjchwHoi91WQb(__UXbQXH7TVhHmifnfsniC8bsE: int) -> __2eoTFZc6WxKKaBxTkxeRtmOZ:
	if __UXbQXH7TVhHmifnfsniC8bsE == __3pHTyYQlMesWCy5zSJELYO80:
		return __ofKSCLcCg7jWtqacDa153ehk()
	return __2eoTFZc6WxKKaBxTkxeRtmOZ.__oFei_mJKJtpqZ6QxLSm5LZdV(__NZtxVGdhytJuFkBWqJKzc9o4, __Z1L5javwTdjxkGCkHOIHLDVI, __UXbQXH7TVhHmifnfsniC8bsE) if __UXbQXH7TVhHmifnfsniC8bsE >= 0 and __Z1L5javwTdjxkGCkHOIHLDVI.__S427rIy8YAPI_7NTPBneiPZH(__UXbQXH7TVhHmifnfsniC8bsE) else null
var __V4HMBvKJ0ZkFXfFel313zhG5: __2eoTFZc6WxKKaBxTkxeRtmOZ
var __RqhcyeP1iDTNK0TaIVLeMfUM: = PackedInt32Array()
var __NYy2YToEB4fxxEoFuo45AarQ: = __lQA2X_Tbdwp3cdBqDfL8XMPe.new()
func __ofKSCLcCg7jWtqacDa153ehk() -> __2eoTFZc6WxKKaBxTkxeRtmOZ:
	if __V4HMBvKJ0ZkFXfFel313zhG5 == null or __V4HMBvKJ0ZkFXfFel313zhG5.__WeB9Hi0OxaFBUuwm2WU2qKEH != __3pHTyYQlMesWCy5zSJELYO80:
		__V4HMBvKJ0ZkFXfFel313zhG5 = __2eoTFZc6WxKKaBxTkxeRtmOZ.__oFei_mJKJtpqZ6QxLSm5LZdV(__NZtxVGdhytJuFkBWqJKzc9o4, __Z1L5javwTdjxkGCkHOIHLDVI, __3pHTyYQlMesWCy5zSJELYO80) if __3pHTyYQlMesWCy5zSJELYO80 >= 0 and __Z1L5javwTdjxkGCkHOIHLDVI.__S427rIy8YAPI_7NTPBneiPZH(__3pHTyYQlMesWCy5zSJELYO80) else null
	return __V4HMBvKJ0ZkFXfFel313zhG5
func __CwpKXs02n6e7mZnAMz9VvPw1(__UYIrgFpaGja3jG0aKE7WCSVE: int, __XtfvvlV0LniBzfrEP0lu0WB4: int, source: int = __Bsl33jE0VgUtGf0ZDYkuZAkg.__sHonv71pRuEn82ajAXfAug6Z, __ZPEPXUJZI7wk1BUEPIypqmxC: int = 0) -> String:
	if __UYIrgFpaGja3jG0aKE7WCSVE > 0 and __ktyxvkLP8cTjwSfnZb3DAVcL < __UYIrgFpaGja3jG0aKE7WCSVE:
		return "UI_ERR_NOTENOUGHT_CREDIT"
	if __XtfvvlV0LniBzfrEP0lu0WB4 > 0 and points < __XtfvvlV0LniBzfrEP0lu0WB4:
		return "UI_CREW_ERR_POINTS"
	__8gf1LRFmWIu4atdcX2YYGtf5(source, - __UYIrgFpaGja3jG0aKE7WCSVE, - __XtfvvlV0LniBzfrEP0lu0WB4, __ZPEPXUJZI7wk1BUEPIypqmxC)
	save()
	return ""
var points: int:
	get: return __vkknSGjjhXgPnF0lq0pScRPK.get_value()
	set(v): __vkknSGjjhXgPnF0lq0pScRPK.set_value(v)
func __sdlPqoZlTuS5DkBvS_mnTzdQ(__BKdJHpNnOrgDXrmIQeuWhMiU: __CgOl36_UCxYZW5PzufCcS4dS) -> String:
	if __BKdJHpNnOrgDXrmIQeuWhMiU.__JMsr0yCjBlwnkO_7FV9gE93o():
		if __BKdJHpNnOrgDXrmIQeuWhMiU.__ofKSCLcCg7jWtqacDa153ehk != __3pHTyYQlMesWCy5zSJELYO80:
			return "UI_CREW_ERR_OTHER_SHIP"
		__PAKIM19pbIBfCQgBDhV5DbBM(__BKdJHpNnOrgDXrmIQeuWhMiU)
		return ""
	var __AMIQkwco0q_fh_n7qcM_nd55: __2eoTFZc6WxKKaBxTkxeRtmOZ = __ofKSCLcCg7jWtqacDa153ehk()
	if __AMIQkwco0q_fh_n7qcM_nd55 == null:
		return "UI_CREW_ERR_NO_SEAT"
	var __2ekHZGG3zagDdVDtfCnGkWGo: Dictionary = __LVCMU4xMBMMHO5bxpAYeHYWt(__BKdJHpNnOrgDXrmIQeuWhMiU)
	var __dYOURFecjrFTaSC_q2safzzN: Array[int] = []
	for s: int in __AMIQkwco0q_fh_n7qcM_nd55.__zIF9v7_0wMMhvSzdUeP1IIN3():
		if __AMIQkwco0q_fh_n7qcM_nd55.__ykzgAs0XCiNBCa5N91GVfvLY(s):
			__dYOURFecjrFTaSC_q2safzzN.append(s)
	var __M0cE4ZOtWeERWDCYuYGSZGb_: Array[int] = []
	if int(__2ekHZGG3zagDdVDtfCnGkWGo.get("cls", -1)) == __o4BlGoLwjfAD3TYKD8Kt7FzU.__oraNV6a0pihFo8XG6RkR7VVE and __AMIQkwco0q_fh_n7qcM_nd55.__V9nPx6hwHXTjiZSit4R51eP0 == 0:
		__M0cE4ZOtWeERWDCYuYGSZGb_ = __AMIQkwco0q_fh_n7qcM_nd55.__zIF9v7_0wMMhvSzdUeP1IIN3()
	elif __o4BlGoLwjfAD3TYKD8Kt7FzU.__jImD0sut02cad96nddoNN3be(__2ekHZGG3zagDdVDtfCnGkWGo):
		__M0cE4ZOtWeERWDCYuYGSZGb_ = [0]
	elif __o4BlGoLwjfAD3TYKD8Kt7FzU.__rXj_JHJKrlgJikuqEaMcy6px(__2ekHZGG3zagDdVDtfCnGkWGo):
		__M0cE4ZOtWeERWDCYuYGSZGb_ = [3, 4, 1, 2]
		__M0cE4ZOtWeERWDCYuYGSZGb_.append_array(__dYOURFecjrFTaSC_q2safzzN)
	elif __o4BlGoLwjfAD3TYKD8Kt7FzU.__Uj4RkkOmRCcs7YE0kCwFf3D4(__2ekHZGG3zagDdVDtfCnGkWGo):
		__M0cE4ZOtWeERWDCYuYGSZGb_ = [1, 2, 3, 4]
		__M0cE4ZOtWeERWDCYuYGSZGb_.append_array(__dYOURFecjrFTaSC_q2safzzN)
	else:
		__M0cE4ZOtWeERWDCYuYGSZGb_ = __dYOURFecjrFTaSC_q2safzzN.duplicate()
		__M0cE4ZOtWeERWDCYuYGSZGb_.append_array([3, 4])
	for s: int in __M0cE4ZOtWeERWDCYuYGSZGb_:
		if __AMIQkwco0q_fh_n7qcM_nd55.__XlyecKoUZWL4KyL0Lkce70AI(s) and __ifUAqOmtFvNZXIqHYuzi470Y(s) == null and __IuDP9w3LX3PDa0VZR_faHzyc(__BKdJHpNnOrgDXrmIQeuWhMiU, s) == "":
			__BKdJHpNnOrgDXrmIQeuWhMiU.__q26f3dCYzrR9TyO_pwwz7lre = s
			__BKdJHpNnOrgDXrmIQeuWhMiU.__ofKSCLcCg7jWtqacDa153ehk = __3pHTyYQlMesWCy5zSJELYO80
			save()
			return ""
	return "UI_CREW_ERR_NO_SEAT"
func __rq_chOHOjEfHcgxVh53u7ecD(__Gxzlsg5UZRqdtSMCe5dhGqfF: __s8yZigV26lPAvEmbOWzMbnjE) -> PackedInt32Array:
	var __51rcF6xrWm3XIg5BiLfCvGBD: = PackedInt32Array()
	var __l9R5HIWVpfEU0jbLm3Rvg9fB: PackedInt32Array = __Z1L5javwTdjxkGCkHOIHLDVI.__mgdM7ycmi3DNHzWo0uObSaPX(__Gxzlsg5UZRqdtSMCe5dhGqfF)
	if __l9R5HIWVpfEU0jbLm3Rvg9fB.is_empty():
		return __51rcF6xrWm3XIg5BiLfCvGBD
	var __14TGF_mz4ZtlKp4CWT8I0lZ4: Array[__CgOl36_UCxYZW5PzufCcS4dS] = __cQ9sPbueMGXZt2aYRGhozxDp(__Gxzlsg5UZRqdtSMCe5dhGqfF.__WeB9Hi0OxaFBUuwm2WU2qKEH)
	__14TGF_mz4ZtlKp4CWT8I0lZ4.sort_custom( func(a: __CgOl36_UCxYZW5PzufCcS4dS, b: __CgOl36_UCxYZW5PzufCcS4dS) -> bool: return a.__q26f3dCYzrR9TyO_pwwz7lre < b.__q26f3dCYzrR9TyO_pwwz7lre)
	var __RLGzBdOLY2XwZ7tmear74qX3: __2eoTFZc6WxKKaBxTkxeRtmOZ = __EhjJRLjwGbixjchwHoi91WQb(__Gxzlsg5UZRqdtSMCe5dhGqfF.__WeB9Hi0OxaFBUuwm2WU2qKEH)
	for __KHc_qcGFsIbKzWfomtgM_vSl: __CgOl36_UCxYZW5PzufCcS4dS in __14TGF_mz4ZtlKp4CWT8I0lZ4:
		if __RLGzBdOLY2XwZ7tmear74qX3 == null or not __RLGzBdOLY2XwZ7tmear74qX3.__ykzgAs0XCiNBCa5N91GVfvLY(__KHc_qcGFsIbKzWfomtgM_vSl.__q26f3dCYzrR9TyO_pwwz7lre):
			continue
		var __em9Xz9faFC2YIYWkqDsLATL4: Dictionary = __LVCMU4xMBMMHO5bxpAYeHYWt(__KHc_qcGFsIbKzWfomtgM_vSl)
		var flags: int = int(__em9Xz9faFC2YIYWkqDsLATL4.get("flags", 0))
		var __jCFnBZza4ohHWoF5v1HCaVxI: int = __gMVsR2m9YSKpVTBiU_rKodWS(flags)
		if __jCFnBZza4ohHWoF5v1HCaVxI < 0:
			continue
		var __6X12Grw_oMHbY1vLD1309Naj: int = __Se4EsxPBCHX48h1ZS5MexaMl.__Uv7vWKACrD3IoOv6puOgq1PA.find(__jCFnBZza4ohHWoF5v1HCaVxI + 17)
		var __JnTE5k0Ydmy23cJmID55FwNN: int = __l9R5HIWVpfEU0jbLm3Rvg9fB[__Se4EsxPBCHX48h1ZS5MexaMl.__7H3uQhAdVTbh0QLkQVDDP1bw * __6X12Grw_oMHbY1vLD1309Naj]
		if __JnTE5k0Ydmy23cJmID55FwNN < 0:
			continue
		var __ja8nvjWTPw3dnBhEHHWsxeQK: Dictionary = __Z1L5javwTdjxkGCkHOIHLDVI.__gobxGwIVlftvCfJ1fsNzSlj7(__JnTE5k0Ydmy23cJmID55FwNN)
		var __tvQVRCUbk4lCLy15gIyr19ut: int = int(__em9Xz9faFC2YIYWkqDsLATL4.get("nation", 0))
		if __KHc_qcGFsIbKzWfomtgM_vSl.__zMZVCIoyJu5zkEI6YyKqPDoG < int(__ja8nvjWTPw3dnBhEHHWsxeQK["lv"]) or (int(__ja8nvjWTPw3dnBhEHHWsxeQK["mask"]) & flags) == 0:
			continue
		if __tvQVRCUbk4lCLy15gIyr19ut != int(__ja8nvjWTPw3dnBhEHHWsxeQK["nat"]) and not __o4BlGoLwjfAD3TYKD8Kt7FzU.__QLNaDYF6pxwRb1StnFnp2s1W(int(__ja8nvjWTPw3dnBhEHHWsxeQK["nat"]), __o4BlGoLwjfAD3TYKD8Kt7FzU.__JORN5FXBCkzYH48_dmuEi61V(__tvQVRCUbk4lCLy15gIyr19ut)):
			continue
		var __hNtFOjRtYYpidVQjJhYV3ftB: int = __KHc_qcGFsIbKzWfomtgM_vSl.__4ObdBYhtKkHScUayTPgiYzH_[__o4BlGoLwjfAD3TYKD8Kt7FzU.__zQFbz4wT5ybXvNTatdPLjuFc.__ylRwgIUMLb9XLwKJSVqPq3ap] if __jCFnBZza4ohHWoF5v1HCaVxI == 11 else (__KHc_qcGFsIbKzWfomtgM_vSl.__4ObdBYhtKkHScUayTPgiYzH_[__o4BlGoLwjfAD3TYKD8Kt7FzU.__zQFbz4wT5ybXvNTatdPLjuFc.__u7um5J_9_wiV2qGmW2ufEZc8] if __jCFnBZza4ohHWoF5v1HCaVxI == 12
			else __KHc_qcGFsIbKzWfomtgM_vSl.__4ObdBYhtKkHScUayTPgiYzH_[__o4BlGoLwjfAD3TYKD8Kt7FzU.__zQFbz4wT5ybXvNTatdPLjuFc.__OS_ME7fDxzIQ4pJ4cyI9bVZw])
		__51rcF6xrWm3XIg5BiLfCvGBD.append_array([__jCFnBZza4ohHWoF5v1HCaVxI, clampi(__KHc_qcGFsIbKzWfomtgM_vSl.__zMZVCIoyJu5zkEI6YyKqPDoG, 0, 120), __LlOvNfSW39vQFa_X5z9isu0g.__YPQoeMce4Ux_l1KIJiNnBaIy(__hNtFOjRtYYpidVQjJhYV3ftB), clampi(__KHc_qcGFsIbKzWfomtgM_vSl.__pY661vwzoRY0D6Y5ORWYVaB_[1] + __KHc_qcGFsIbKzWfomtgM_vSl.__pY661vwzoRY0D6Y5ORWYVaB_[2], 0, 255)])
		if __51rcF6xrWm3XIg5BiLfCvGBD.size() / __Se4EsxPBCHX48h1ZS5MexaMl.__pH0Kwuhkz0OOYzv6GDerVvwv >= __Se4EsxPBCHX48h1ZS5MexaMl.__fW1AFDKAoKUVI60gMEjiNu7w:
			break
	return __51rcF6xrWm3XIg5BiLfCvGBD
func __jzYnT2qz6bxMyJubqlRmPdDW(__yaT7PgemZFTH7Pbk1P9bqCtK: int) -> float:
	var __ba4GmBmNINVjFDonNrgDeHu0: Dictionary = __qyvbOrjVYs2zGM2jUVQYSgGR.get("promote", {})
	var __64i_pm8MgfS4Cm0CGf2eGjl9: float = float(__ba4GmBmNINVjFDonNrgDeHu0.get("base_success_pct", 30.0))
	var __t8zebeVLpsmWUz3KRcZv4ti1: float = float(__ba4GmBmNINVjFDonNrgDeHu0.get("success_multiplier", 2.0))
	var __w9UbF_8YSoFtP4Q8q8cjriaI: float = float(__ba4GmBmNINVjFDonNrgDeHu0.get("success_decay_per_tech", 0.98))
	return clampf(__64i_pm8MgfS4Cm0CGf2eGjl9 * __t8zebeVLpsmWUz3KRcZv4ti1 * pow(__w9UbF_8YSoFtP4Q8q8cjriaI, maxi(__yaT7PgemZFTH7Pbk1P9bqCtK, 0)), 0.0, 100.0)
var __DbuthnnVI6mcaRxkjF633v6v: int = __s8yZigV26lPAvEmbOWzMbnjE.__VWd1Gfr1VadwmHRrVFdTi1VT
func __RuEf8sDpDtu0ArTJYzf6W0JG(__GsRoikFkQwHPOS6IRnXZQNzB: __CgOl36_UCxYZW5PzufCcS4dS = null) -> int:
	var __D2JVUPW75Un_CWUoUNPC1RXm: __2eoTFZc6WxKKaBxTkxeRtmOZ = __ofKSCLcCg7jWtqacDa153ehk()
	var w: int = 0
	for ___rvRx_tkiXXEbqnmWrEf76uE: __CgOl36_UCxYZW5PzufCcS4dS in __JMsr0yCjBlwnkO_7FV9gE93o():
		if ___rvRx_tkiXXEbqnmWrEf76uE != __GsRoikFkQwHPOS6IRnXZQNzB:
			w += ___rvRx_tkiXXEbqnmWrEf76uE.__Ln9avrueTbF2AkgyV87ZgBiF(__LVCMU4xMBMMHO5bxpAYeHYWt(___rvRx_tkiXXEbqnmWrEf76uE), __D2JVUPW75Un_CWUoUNPC1RXm != null and __D2JVUPW75Un_CWUoUNPC1RXm.__JzUUCYNEpRcSKSi9X3gAiTQK())
	return w
func __eEzZAN_Zxk5bFAPUikmHkYlB(__D2GvwLphkJ4O2RLtxj1h5QL0: __CgOl36_UCxYZW5PzufCcS4dS, amount: int) -> int:
	if not __ZRS6lZJh1TuB38TS82wWLE09.enabled():
		return 0
	var __NeXnst1WsJPH0zYsPeAawVgB: int = __D2GvwLphkJ4O2RLtxj1h5QL0.__zMZVCIoyJu5zkEI6YyKqPDoG
	var __v8d75TfNB7h603L27PTHTX7S: int = __D2GvwLphkJ4O2RLtxj1h5QL0.exp
	__jKjv1tq5RRmN4J8UhZ1oGLwE(__D2GvwLphkJ4O2RLtxj1h5QL0, amount)
	__jx52K0fsGItWa4CN83U1DY2k.__uXq7lesweQwPVFt806V2gCAg(__D2GvwLphkJ4O2RLtxj1h5QL0.id, __Bsl33jE0VgUtGf0ZDYkuZAkg.__pxT2tKjeuXkgu_c5zstK_k3d(__D2GvwLphkJ4O2RLtxj1h5QL0.exp - __v8d75TfNB7h603L27PTHTX7S))
	save()
	return __D2GvwLphkJ4O2RLtxj1h5QL0.__zMZVCIoyJu5zkEI6YyKqPDoG - __NeXnst1WsJPH0zYsPeAawVgB
func __6PFrcId2T_VUOlJQ2HU0rfRp() -> __CgOl36_UCxYZW5PzufCcS4dS:
	var __gopYMlNsGH2k85yLx1CZ6KP8: Dictionary = __qyvbOrjVYs2zGM2jUVQYSgGR.get("recruit", {})
	var __qkKnDJH70_w1KQXHSJFkTnmS: Dictionary = __qyvbOrjVYs2zGM2jUVQYSgGR.get("men", {})
	var __3Amv5V_BwdxyZn13evrpg3Z1: = __CgOl36_UCxYZW5PzufCcS4dS.new()
	__3Amv5V_BwdxyZn13evrpg3Z1.__mpLpovabZnp87HNkreW4pWJY = int(__gopYMlNsGH2k85yLx1CZ6KP8.get("class_row", 0))
	__3Amv5V_BwdxyZn13evrpg3Z1.__wC11jxHS1J5bzkNesfKgNncZ = __geUHcewBqVa9L7LKcQ8q2MXR(__LVCMU4xMBMMHO5bxpAYeHYWt(__3Amv5V_BwdxyZn13evrpg3Z1))
	__3Amv5V_BwdxyZn13evrpg3Z1.__zMZVCIoyJu5zkEI6YyKqPDoG = 1
	var __lchRZMSXQOSiT8qOBLhuYViZ: int = int(__gopYMlNsGH2k85yLx1CZ6KP8.get("ability_max", 10))
	for __TYnY3GI7bf1TQ0_fKH1UeUw4: int in __o4BlGoLwjfAD3TYKD8Kt7FzU.__yJKOGHp90JmK10a2SV3ahPUB:
		__3Amv5V_BwdxyZn13evrpg3Z1.__4ObdBYhtKkHScUayTPgiYzH_[__TYnY3GI7bf1TQ0_fKH1UeUw4] = __FOzOkL_5wngFw83WISq0FbBm.randi_range(0, __lchRZMSXQOSiT8qOBLhuYViZ)
	var g: PackedInt32Array = __rOp4mnR3hdtXTfVHeKqxRGI9()
	for __UeglYk7LyJMbuaE3NKNHNWWB: int in __o4BlGoLwjfAD3TYKD8Kt7FzU.__yJKOGHp90JmK10a2SV3ahPUB:
		__3Amv5V_BwdxyZn13evrpg3Z1.__wC11jxHS1J5bzkNesfKgNncZ[__UeglYk7LyJMbuaE3NKNHNWWB] += g[__UeglYk7LyJMbuaE3NKNHNWWB]
	__3Amv5V_BwdxyZn13evrpg3Z1.__pY661vwzoRY0D6Y5ORWYVaB_ = PackedInt32Array([int(__qkKnDJH70_w1KQXHSJFkTnmS.get("recruit", __LlOvNfSW39vQFa_X5z9isu0g.__uLoPuRwbpEdqhRSwYJZkw_Rh)), 0, 0])
	__3Amv5V_BwdxyZn13evrpg3Z1.set_meta("meti_original_growth", __3Amv5V_BwdxyZn13evrpg3Z1.__wC11jxHS1J5bzkNesfKgNncZ.duplicate())
	__3Amv5V_BwdxyZn13evrpg3Z1.set_meta("meti_base_growth", __geUHcewBqVa9L7LKcQ8q2MXR(__LVCMU4xMBMMHO5bxpAYeHYWt(__3Amv5V_BwdxyZn13evrpg3Z1)))
	return __3Amv5V_BwdxyZn13evrpg3Z1
var __4SUknJBgHUaV9w15IdBVFhd5: = PackedInt32Array()
var __qpoG34O1fgw9L8TB5rO8XCfq: Array[__CgOl36_UCxYZW5PzufCcS4dS] = []
func __ifUAqOmtFvNZXIqHYuzi470Y(__Tn5mSTwjN_uDXnuoHyRy4e62: int) -> __CgOl36_UCxYZW5PzufCcS4dS:
	for __483QBColbUsLBou2TF0F3NCC: __CgOl36_UCxYZW5PzufCcS4dS in __qpoG34O1fgw9L8TB5rO8XCfq:
		if __483QBColbUsLBou2TF0F3NCC.__q26f3dCYzrR9TyO_pwwz7lre == __Tn5mSTwjN_uDXnuoHyRy4e62 and __483QBColbUsLBou2TF0F3NCC.__ofKSCLcCg7jWtqacDa153ehk == __3pHTyYQlMesWCy5zSJELYO80:
			return __483QBColbUsLBou2TF0F3NCC
	return null
func __xUdVQnSQPkxPs4_Ls3mOD1xu() -> void :
	var __KKz3AlH1JobOpXDmIHDSv9ll: __2eoTFZc6WxKKaBxTkxeRtmOZ = __ofKSCLcCg7jWtqacDa153ehk()
	var __2LmcNBIR0jfS8GYTr2kkiCGg: Array[__CgOl36_UCxYZW5PzufCcS4dS] = __JMsr0yCjBlwnkO_7FV9gE93o()
	__2LmcNBIR0jfS8GYTr2kkiCGg.sort_custom( func(a: __CgOl36_UCxYZW5PzufCcS4dS, b: __CgOl36_UCxYZW5PzufCcS4dS) -> bool: return a.__q26f3dCYzrR9TyO_pwwz7lre < b.__q26f3dCYzrR9TyO_pwwz7lre)
	var __yahqYFHbn7BRvWfteyluXUPy: Dictionary = {}
	for __36rftaazykfkDHd42nIjQi8_: __CgOl36_UCxYZW5PzufCcS4dS in __2LmcNBIR0jfS8GYTr2kkiCGg:
		__yahqYFHbn7BRvWfteyluXUPy[__36rftaazykfkDHd42nIjQi8_] = __36rftaazykfkDHd42nIjQi8_.__q26f3dCYzrR9TyO_pwwz7lre
		__36rftaazykfkDHd42nIjQi8_.__q26f3dCYzrR9TyO_pwwz7lre = -1
		__36rftaazykfkDHd42nIjQi8_.__ofKSCLcCg7jWtqacDa153ehk = -1
	for __5WNa3ATkgIvOnK7rCYCGTzZn: __CgOl36_UCxYZW5PzufCcS4dS in __2LmcNBIR0jfS8GYTr2kkiCGg:
		var s: int = __yahqYFHbn7BRvWfteyluXUPy[__5WNa3ATkgIvOnK7rCYCGTzZn]
		if __KKz3AlH1JobOpXDmIHDSv9ll != null and __KKz3AlH1JobOpXDmIHDSv9ll.__XlyecKoUZWL4KyL0Lkce70AI(s) and __ifUAqOmtFvNZXIqHYuzi470Y(s) == null and __IuDP9w3LX3PDa0VZR_faHzyc(__5WNa3ATkgIvOnK7rCYCGTzZn, s) == "":
			__5WNa3ATkgIvOnK7rCYCGTzZn.__q26f3dCYzrR9TyO_pwwz7lre = s
			__5WNa3ATkgIvOnK7rCYCGTzZn.__ofKSCLcCg7jWtqacDa153ehk = __3pHTyYQlMesWCy5zSJELYO80
func __Jn0DggJ3VJO4B7DN8siFvl8n() -> __s8yZigV26lPAvEmbOWzMbnjE:
	var __y0JTcmJP9DC7wpKVpXn0whyl: __s8yZigV26lPAvEmbOWzMbnjE = __s8yZigV26lPAvEmbOWzMbnjE.__YCYCLM7wn8U5KL1mw3RC4lIU(__3pHTyYQlMesWCy5zSJELYO80, __n49srIn8KerL_HEIiCdNmOxf.duplicate(), PackedInt32Array(), __4SUknJBgHUaV9w15IdBVFhd5.duplicate(), __9tVQSDzDk22f49xhH1zXYlPe.duplicate(), __6jT8KoopEZhRFiDaeOpZK1bT.duplicate(), __da10PLrO3b92oiJTS9g3Vfve.duplicate(), __a_utLkfvPV74XmpUxv0T2jqV.duplicate(), PackedInt32Array(), __DbuthnnVI6mcaRxkjF633v6v, PackedInt32Array(), __WkXP3BSGyqCbt6VAuFzmJWsZ.duplicate(), __RqhcyeP1iDTNK0TaIVLeMfUM.duplicate())
	__y0JTcmJP9DC7wpKVpXn0whyl.__NELIelBEafKRGQultNqYAbM7 = __cYNPT_ygRY3o9ufvyN3FSzFH
	return __y0JTcmJP9DC7wpKVpXn0whyl
var __9tVQSDzDk22f49xhH1zXYlPe: = PackedInt32Array()
func __jKjv1tq5RRmN4J8UhZ1oGLwE(__1J0G9cdxonBNCgHXONPMkCjF: __CgOl36_UCxYZW5PzufCcS4dS, amount: int) -> void :
	__1J0G9cdxonBNCgHXONPMkCjF.exp += amount
	while __1J0G9cdxonBNCgHXONPMkCjF.__zMZVCIoyJu5zkEI6YyKqPDoG < __ZEf8MUQNZMeLjokl2rCxl51Z() and __1J0G9cdxonBNCgHXONPMkCjF.exp >= __pRmI0Gva0OZ3_r554GsEvNGr(__1J0G9cdxonBNCgHXONPMkCjF.__zMZVCIoyJu5zkEI6YyKqPDoG):
		__1J0G9cdxonBNCgHXONPMkCjF.exp -= __pRmI0Gva0OZ3_r554GsEvNGr(__1J0G9cdxonBNCgHXONPMkCjF.__zMZVCIoyJu5zkEI6YyKqPDoG)
		__7G5al7c8rrhrq_VnoCfQSLbW(__1J0G9cdxonBNCgHXONPMkCjF)
	if __1J0G9cdxonBNCgHXONPMkCjF.__zMZVCIoyJu5zkEI6YyKqPDoG >= __ZEf8MUQNZMeLjokl2rCxl51Z():
		__1J0G9cdxonBNCgHXONPMkCjF.exp = 0
func __PAKIM19pbIBfCQgBDhV5DbBM(__a4cFgciRrEN9XqGTaG_OICUt: __CgOl36_UCxYZW5PzufCcS4dS) -> void :
	if __a4cFgciRrEN9XqGTaG_OICUt.__q26f3dCYzrR9TyO_pwwz7lre >= 0:
		__a4cFgciRrEN9XqGTaG_OICUt.__q26f3dCYzrR9TyO_pwwz7lre = -1
		__a4cFgciRrEN9XqGTaG_OICUt.__ofKSCLcCg7jWtqacDa153ehk = -1
		save()
func __wWQPTwNxf7FYYNB2o2X8fVEX(__eFdpB5J93_FaMeFhMcT9RhEu: __CgOl36_UCxYZW5PzufCcS4dS, __fhOZa6MqOaR98sw7DAnLKtWQ: int) -> int:
	if not __ZRS6lZJh1TuB38TS82wWLE09.enabled():
		return 0
	var __WlLdD4xySW0c03XVapc9CFKb: PackedInt32Array = __eFdpB5J93_FaMeFhMcT9RhEu.__pY661vwzoRY0D6Y5ORWYVaB_
	var __ZzsNZBP7eccz7oYygpafuqHgi: int = clampi(__WlLdD4xySW0c03XVapc9CFKb[2] + __fhOZa6MqOaR98sw7DAnLKtWQ, 0, __76YQlbOoFzFgpPn_qa5fce31(__eFdpB5J93_FaMeFhMcT9RhEu)) - __WlLdD4xySW0c03XVapc9CFKb[2]
	if __ZzsNZBP7eccz7oYygpafuqHgi == 0:
		return 0
	var __CgvZmZbRHzXjiCdpOIiEL6Yr: int = maxi(__WlLdD4xySW0c03XVapc9CFKb[0] + __WlLdD4xySW0c03XVapc9CFKb[1] + __WlLdD4xySW0c03XVapc9CFKb[2] + __ZzsNZBP7eccz7oYygpafuqHgi - __CcuJfEJlHGrXUgnJDReo2jb7(__eFdpB5J93_FaMeFhMcT9RhEu), 0)
	var __KF15Dut1QPKcyNm4iVCmN7b9: int = - mini(__CgvZmZbRHzXjiCdpOIiEL6Yr, __WlLdD4xySW0c03XVapc9CFKb[0])
	var __kbz6pc8TqaYxyPiYL6QH0Hku: int = - mini(__CgvZmZbRHzXjiCdpOIiEL6Yr + __KF15Dut1QPKcyNm4iVCmN7b9, __WlLdD4xySW0c03XVapc9CFKb[1])
	__eFdpB5J93_FaMeFhMcT9RhEu.__pY661vwzoRY0D6Y5ORWYVaB_ = PackedInt32Array([__WlLdD4xySW0c03XVapc9CFKb[0] + __KF15Dut1QPKcyNm4iVCmN7b9, __WlLdD4xySW0c03XVapc9CFKb[1] + __kbz6pc8TqaYxyPiYL6QH0Hku, __WlLdD4xySW0c03XVapc9CFKb[2] + __ZzsNZBP7eccz7oYygpafuqHgi])
	__jx52K0fsGItWa4CN83U1DY2k.__uXq7lesweQwPVFt806V2gCAg(__eFdpB5J93_FaMeFhMcT9RhEu.id, __Bsl33jE0VgUtGf0ZDYkuZAkg.__pY661vwzoRY0D6Y5ORWYVaB_(__KF15Dut1QPKcyNm4iVCmN7b9, __kbz6pc8TqaYxyPiYL6QH0Hku, __ZzsNZBP7eccz7oYygpafuqHgi))
	save()
	return __ZzsNZBP7eccz7oYygpafuqHgi
func __qvx0LmqSpjUyS4lCTqX_h5vz(__9PiSEPLfo2VEGLZpZMGSLNKS: Array[int], __aRHzQeiAVXn2GdauTGfT8w2J: int) -> __CgOl36_UCxYZW5PzufCcS4dS:
	if __9PiSEPLfo2VEGLZpZMGSLNKS.is_empty() or not __o4BlGoLwjfAD3TYKD8Kt7FzU.__FLBcWdmSyKhlCkG_2_FUG10K(___FfBuNdLnmIikyyvatNDz628.__plTZcPXT3j_x0cUIlOEd5bfe(__9PiSEPLfo2VEGLZpZMGSLNKS[0])):
		return null
	var __XcRDKW3UjGFGCKUO7ZjLxpic: = __CgOl36_UCxYZW5PzufCcS4dS.new()
	var __oLv7dRnUFQva90qulhxn5oVC: Dictionary = ___FfBuNdLnmIikyyvatNDz628.__plTZcPXT3j_x0cUIlOEd5bfe(__9PiSEPLfo2VEGLZpZMGSLNKS[0])
	__XcRDKW3UjGFGCKUO7ZjLxpic.__mpLpovabZnp87HNkreW4pWJY = int(__oLv7dRnUFQva90qulhxn5oVC["row"])
	__XcRDKW3UjGFGCKUO7ZjLxpic.__wC11jxHS1J5bzkNesfKgNncZ = __geUHcewBqVa9L7LKcQ8q2MXR(__oLv7dRnUFQva90qulhxn5oVC)
	var __sPgF63wi7zxP6Gt3J0WK3vJS: int = 0
	for __hiO6VEQI4Gw4erM6g3NgdzzQ: int in range(1, clampi(__aRHzQeiAVXn2GdauTGfT8w2J, 1, __ZEf8MUQNZMeLjokl2rCxl51Z())):
		while __sPgF63wi7zxP6Gt3J0WK3vJS + 1 < __9PiSEPLfo2VEGLZpZMGSLNKS.size():
			var __x1wfkYhdjBXTFOqooERL5yCN: Dictionary = ___FfBuNdLnmIikyyvatNDz628.__plTZcPXT3j_x0cUIlOEd5bfe(__9PiSEPLfo2VEGLZpZMGSLNKS[__sPgF63wi7zxP6Gt3J0WK3vJS + 1])
			if not __o4BlGoLwjfAD3TYKD8Kt7FzU.__FLBcWdmSyKhlCkG_2_FUG10K(__x1wfkYhdjBXTFOqooERL5yCN) or int(__x1wfkYhdjBXTFOqooERL5yCN["req_level"]) > __hiO6VEQI4Gw4erM6g3NgdzzQ:
				break
			__sPgF63wi7zxP6Gt3J0WK3vJS += 1
			__XcRDKW3UjGFGCKUO7ZjLxpic.__mpLpovabZnp87HNkreW4pWJY = int(__x1wfkYhdjBXTFOqooERL5yCN["row"])
			__ucghM4LTcG__8IQ3ww4psLhB(__XcRDKW3UjGFGCKUO7ZjLxpic, __x1wfkYhdjBXTFOqooERL5yCN)
		__7G5al7c8rrhrq_VnoCfQSLbW(__XcRDKW3UjGFGCKUO7ZjLxpic)
	return __XcRDKW3UjGFGCKUO7ZjLxpic
func __ucghM4LTcG__8IQ3ww4psLhB(__AskrvqH4D0rs9VB9ZSDG14py: __CgOl36_UCxYZW5PzufCcS4dS, __5qTHt6LhbENVNu0JSa3l7obu: Dictionary) -> PackedInt32Array:
	var g: PackedInt32Array = __5qTHt6LhbENVNu0JSa3l7obu.get("growth", PackedInt32Array())
	var d: = PackedInt32Array()
	d.resize(__o4BlGoLwjfAD3TYKD8Kt7FzU.__yJKOGHp90JmK10a2SV3ahPUB)
	for __YGP3RNOmZhzJfWt4otMXmEr9: int in mini(g.size(), __o4BlGoLwjfAD3TYKD8Kt7FzU.__yJKOGHp90JmK10a2SV3ahPUB):
		var __ljo8daytnIeMkMOwSGAdhJzr: int = __AskrvqH4D0rs9VB9ZSDG14py.__wC11jxHS1J5bzkNesfKgNncZ[__YGP3RNOmZhzJfWt4otMXmEr9]
		var __s8upnndT8rojNfCIzNB8QCZH: int = maxi(0, __ljo8daytnIeMkMOwSGAdhJzr + g[__YGP3RNOmZhzJfWt4otMXmEr9])
		__AskrvqH4D0rs9VB9ZSDG14py.__wC11jxHS1J5bzkNesfKgNncZ[__YGP3RNOmZhzJfWt4otMXmEr9] = __s8upnndT8rojNfCIzNB8QCZH
		d[__YGP3RNOmZhzJfWt4otMXmEr9] = __s8upnndT8rojNfCIzNB8QCZH - __ljo8daytnIeMkMOwSGAdhJzr
	return d
const __CK83XjuJnreQUu2blQSJAB0t: = 80
func __VbZUWaBQx57NXvzCmbgibMgO() -> int:
	return __Z1L5javwTdjxkGCkHOIHLDVI.__77YZ0E3pilwCWMSZ5lHzv_es(__Jn0DggJ3VJO4B7DN8siFvl8n()).x if __3pHTyYQlMesWCy5zSJELYO80 >= 0 and __Z1L5javwTdjxkGCkHOIHLDVI.__S427rIy8YAPI_7NTPBneiPZH(__3pHTyYQlMesWCy5zSJELYO80) else 0
func __JFzRtNKpReBJQ2eNbAIhCiEi() -> Vector2i:
	var __OZwh330knsTFbLTJlsbc0SVm: Dictionary = __qyvbOrjVYs2zGM2jUVQYSgGR.get("recruit", {})
	var __9XR4nm81Gu8MoGQVYJ2go6PK: int = int(__OZwh330knsTFbLTJlsbc0SVm.get("growth_picks", 0))
	if __9XR4nm81Gu8MoGQVYJ2go6PK <= 0:
		return Vector2i.ZERO
	var __wHIBWvalthsPwtwDEjBIbqk6: int = maxi(int(__OZwh330knsTFbLTJlsbc0SVm.get("growth_pick_min", 1)), 0)
	return Vector2i(0, maxi(__HslzQboO3K5FDdlVipS3DDoE(), __wHIBWvalthsPwtwDEjBIbqk6 * __9XR4nm81Gu8MoGQVYJ2go6PK) - __wHIBWvalthsPwtwDEjBIbqk6 * (__9XR4nm81Gu8MoGQVYJ2go6PK - 1))
const __ThKAxtrVk_ROrnDyOUbAWswZ: = {"雾都舰长": "英国舰长", "铁血舰长": "德国舰长"}
var __vkknSGjjhXgPnF0lq0pScRPK: = __lQA2X_Tbdwp3cdBqDfL8XMPe.new()
var __tA3YJLknlQFRzbdlkSywAVMu: __1OkQgYNA0NkvkBligBeQgZWC
func __HLHOhLerr4MTNsPRhGHUILYV(__Qq_GlajhKL1dbln_UqFPY8R2: __CgOl36_UCxYZW5PzufCcS4dS) -> String:
	if not __o4BlGoLwjfAD3TYKD8Kt7FzU.__jImD0sut02cad96nddoNN3be(__LVCMU4xMBMMHO5bxpAYeHYWt(__Qq_GlajhKL1dbln_UqFPY8R2)):
		return "UI_TREE_ERR_NOT_CAPTAIN"
	if __Qq_GlajhKL1dbln_UqFPY8R2.__JMsr0yCjBlwnkO_7FV9gE93o():
		return "UI_TREE_ERR_ON_SHIP"
	if points < __cy8MlQEbWMnDn0W8brML_OIf():
		return "UI_CREW_ERR_POINTS"
	__8gf1LRFmWIu4atdcX2YYGtf5(__Bsl33jE0VgUtGf0ZDYkuZAkg.__5PtJNefDe19NzOk_RhsGCA9a, 0, - __cy8MlQEbWMnDn0W8brML_OIf(), __Qq_GlajhKL1dbln_UqFPY8R2.id)
	__Qq_GlajhKL1dbln_UqFPY8R2.__hJTRC1qsUs9T0VQkseYzTT2f = __1OkQgYNA0NkvkBligBeQgZWC.__R2X7seLnTY5XT91Rew6aCtxr
	__Qq_GlajhKL1dbln_UqFPY8R2.__1U0d7dXiK8nppclbz5xhDxaz = PackedInt32Array()
	__jx52K0fsGItWa4CN83U1DY2k.__uXq7lesweQwPVFt806V2gCAg(__Qq_GlajhKL1dbln_UqFPY8R2.id, __Bsl33jE0VgUtGf0ZDYkuZAkg.__Jtifg3uTCyMJvjtHgVtGl8WD())
	save()
	return ""
var __a_utLkfvPV74XmpUxv0T2jqV: = PackedInt32Array()
func __bfRmJb7Z1nlLKjV3Ju11h42w() -> int:
	return __VbZUWaBQx57NXvzCmbgibMgO() + __RuEf8sDpDtu0ArTJYzf6W0JG()
func __Sn0Tcqw1tUdVUvraDQFCbHi2(__XhCUx1DXgpmm0OQfMnqRr4pS: __CgOl36_UCxYZW5PzufCcS4dS) -> PackedInt32Array:
	var __zRoMAxNJnu0bXwtwyZtKJipx: = PackedInt32Array()
	var __Man65wjPZEZyldqUd3XVoC5u: int = int(__LVCMU4xMBMMHO5bxpAYeHYWt(__XhCUx1DXgpmm0OQfMnqRr4pS).get("nation", 0))
	for __O3VeGqZpLKs1xwAQsY3RmJIU: int in __tA3YJLknlQFRzbdlkSywAVMu.children(__XhCUx1DXgpmm0OQfMnqRr4pS.__hJTRC1qsUs9T0VQkseYzTT2f):
		if __tA3YJLknlQFRzbdlkSywAVMu.__ODueSvGeVnWggM8WyoKBoh4p(__O3VeGqZpLKs1xwAQsY3RmJIU) and (__tA3YJLknlQFRzbdlkSywAVMu.__V9nPx6hwHXTjiZSit4R51eP0(__O3VeGqZpLKs1xwAQsY3RmJIU) == 0 or __tA3YJLknlQFRzbdlkSywAVMu.__V9nPx6hwHXTjiZSit4R51eP0(__O3VeGqZpLKs1xwAQsY3RmJIU) == __Man65wjPZEZyldqUd3XVoC5u):
			__zRoMAxNJnu0bXwtwyZtKJipx.append(__O3VeGqZpLKs1xwAQsY3RmJIU)
	return __zRoMAxNJnu0bXwtwyZtKJipx
var __WkXP3BSGyqCbt6VAuFzmJWsZ: = PackedInt32Array()
func __cQ9sPbueMGXZt2aYRGhozxDp(___XqF2ybDmXzNnb3cQjbp25CN: int) -> Array[__CgOl36_UCxYZW5PzufCcS4dS]:
	var __gYB07WiyvFapBAAvKEr0j1ZC: Array[__CgOl36_UCxYZW5PzufCcS4dS] = []
	for __tpctzVvLQULZVQtEWB3yOI0P: __CgOl36_UCxYZW5PzufCcS4dS in __qpoG34O1fgw9L8TB5rO8XCfq:
		if __tpctzVvLQULZVQtEWB3yOI0P.__q26f3dCYzrR9TyO_pwwz7lre >= 0 and __tpctzVvLQULZVQtEWB3yOI0P.__ofKSCLcCg7jWtqacDa153ehk == ___XqF2ybDmXzNnb3cQjbp25CN:
			__gYB07WiyvFapBAAvKEr0j1ZC.append(__tpctzVvLQULZVQtEWB3yOI0P)
	return __gYB07WiyvFapBAAvKEr0j1ZC
func __qjglTczmNRKz8jgKx_fuNYec(__FORXfvRJhDhdaCLiRXce84kw: int, __ncnFv8myylLHRK0dNKn5AoKP: int) -> bool:
	return (__FORXfvRJhDhdaCLiRXce84kw <= 0 or __ktyxvkLP8cTjwSfnZb3DAVcL >= __FORXfvRJhDhdaCLiRXce84kw) and (__ncnFv8myylLHRK0dNKn5AoKP <= 0 or points >= __ncnFv8myylLHRK0dNKn5AoKP)
func __4RDwOIqpO2l04SXduuzJ3oe9(id: int) -> __CgOl36_UCxYZW5PzufCcS4dS:
	for __u2NHsL6YwOhCahAQ0b0hVUcD: __CgOl36_UCxYZW5PzufCcS4dS in __qpoG34O1fgw9L8TB5rO8XCfq:
		if __u2NHsL6YwOhCahAQ0b0hVUcD.id == id:
			return __u2NHsL6YwOhCahAQ0b0hVUcD
	return null
const __jACT03rMxjSbi3wGd52LcC6f: = __k8pdL_GB8yADpq0vqeDWpz5v.__WCJwObvLR1DJzgS3ilz1tj81
func __uOjfVymJkWxwS467Gg0WBv5P(__r8WRkmbH0vNHQAdjs1bGz7dA: __CgOl36_UCxYZW5PzufCcS4dS, target: Dictionary) -> String:
	if __r8WRkmbH0vNHQAdjs1bGz7dA.__JMsr0yCjBlwnkO_7FV9gE93o():
		return "UI_CREW_ERR_ON_SHIP_CLASS"
	if not __o4BlGoLwjfAD3TYKD8Kt7FzU.__FLBcWdmSyKhlCkG_2_FUG10K(target) or not (int(target["key"]) in __LVCMU4xMBMMHO5bxpAYeHYWt(__r8WRkmbH0vNHQAdjs1bGz7dA).get("transfer", PackedInt32Array())):
		return "UI_CREW_ERR_CLASS"
	if __Se4EsxPBCHX48h1ZS5MexaMl.__G8VgBybQlmXf2sdRasT3PwJT(int(target["nation"])) and int(target["nation"]) != int(__LVCMU4xMBMMHO5bxpAYeHYWt(__r8WRkmbH0vNHQAdjs1bGz7dA).get("nation", 0)):
		return "UI_CREW_ERR_CLASS"
	if __r8WRkmbH0vNHQAdjs1bGz7dA.__zMZVCIoyJu5zkEI6YyKqPDoG < int(target["req_level"]):
		return "UI_CREW_ERR_CLASS_LEVEL"
	if points < int(target["cost"]):
		return "UI_CREW_ERR_POINTS"
	return ""
func __OoFGVnRF4oDKBuT2mZR_exPH(__r8WRkmbH0vNHQAdjs1bGz7dA: __CgOl36_UCxYZW5PzufCcS4dS, target: Dictionary) -> String:
	var __y2PEuGjLtp9KsTsEf3RD1X09: String = __uOjfVymJkWxwS467Gg0WBv5P(__r8WRkmbH0vNHQAdjs1bGz7dA, target)
	if __y2PEuGjLtp9KsTsEf3RD1X09 != "":
		return __y2PEuGjLtp9KsTsEf3RD1X09
	__8gf1LRFmWIu4atdcX2YYGtf5(__Bsl33jE0VgUtGf0ZDYkuZAkg.__EaNyg5Yg3rjJDbZsQnJHnegM, 0, - int(target["cost"]), __r8WRkmbH0vNHQAdjs1bGz7dA.id)
	__r8WRkmbH0vNHQAdjs1bGz7dA.__mpLpovabZnp87HNkreW4pWJY = int(target["row"])
	var g: PackedInt32Array = __ucghM4LTcG__8IQ3ww4psLhB(__r8WRkmbH0vNHQAdjs1bGz7dA, target)
	__jx52K0fsGItWa4CN83U1DY2k.__uXq7lesweQwPVFt806V2gCAg(__r8WRkmbH0vNHQAdjs1bGz7dA.id, __Bsl33jE0VgUtGf0ZDYkuZAkg.__oiM_iYX5Oqbb4gAx9EC1NYQC(__r8WRkmbH0vNHQAdjs1bGz7dA.__mpLpovabZnp87HNkreW4pWJY, g))

	if not meti_has_retrained(__r8WRkmbH0vNHQAdjs1bGz7dA):
		__3nBTaKE3TpnV6QkZ1xXz24mz(__r8WRkmbH0vNHQAdjs1bGz7dA, target, g)
	save()
	return ""
func __a49zmSJznHy0atFlCkwUPi4M(__1aU4okAZp914x0UedBb9Su0Y: __CgOl36_UCxYZW5PzufCcS4dS, __NMJfZJzy7rzYEkKYz68TJ_uO: __CgOl36_UCxYZW5PzufCcS4dS = null) -> void :
	if __1aU4okAZp914x0UedBb9Su0Y.__q26f3dCYzrR9TyO_pwwz7lre < 0:
		return
	__7uYhXLkOUAfh6nv5PwanpntJ(__1aU4okAZp914x0UedBb9Su0Y, __NMJfZJzy7rzYEkKYz68TJ_uO)
	__PAKIM19pbIBfCQgBDhV5DbBM(__1aU4okAZp914x0UedBb9Su0Y)
func __3nBTaKE3TpnV6QkZ1xXz24mz(__FCTxtDBV6NPHKwW6IJnQOpmC: __CgOl36_UCxYZW5PzufCcS4dS, target: Dictionary, g: PackedInt32Array) -> void :
	var __mBeWh_kgSfbLV2k8holoV0WI: int = __FCTxtDBV6NPHKwW6IJnQOpmC.__zMZVCIoyJu5zkEI6YyKqPDoG - int(target["req_level"])
	if __mBeWh_kgSfbLV2k8holoV0WI <= 0:
		return
	var __BWAzrZgjxqdHmn7QNwPBlpm2: PackedInt32Array = __FCTxtDBV6NPHKwW6IJnQOpmC.__4ObdBYhtKkHScUayTPgiYzH_
	var d: = PackedInt32Array()
	d.resize(__o4BlGoLwjfAD3TYKD8Kt7FzU.__yJKOGHp90JmK10a2SV3ahPUB)
	var any: bool = false
	for __Wxqx6KGV8YSuV8yVEkPrHBG8: int in __o4BlGoLwjfAD3TYKD8Kt7FzU.__yJKOGHp90JmK10a2SV3ahPUB:
		var v: int = clampi(__BWAzrZgjxqdHmn7QNwPBlpm2[__Wxqx6KGV8YSuV8yVEkPrHBG8] + g[__Wxqx6KGV8YSuV8yVEkPrHBG8] * __mBeWh_kgSfbLV2k8holoV0WI, 0, __LlOvNfSW39vQFa_X5z9isu0g.__5mUmXzFHF3sOKQKf_XcZ1XFe)
		d[__Wxqx6KGV8YSuV8yVEkPrHBG8] = v - __BWAzrZgjxqdHmn7QNwPBlpm2[__Wxqx6KGV8YSuV8yVEkPrHBG8]
		__BWAzrZgjxqdHmn7QNwPBlpm2[__Wxqx6KGV8YSuV8yVEkPrHBG8] = v
		any = any or d[__Wxqx6KGV8YSuV8yVEkPrHBG8] != 0
	if not any:
		return
	__FCTxtDBV6NPHKwW6IJnQOpmC.__4ObdBYhtKkHScUayTPgiYzH_ = __BWAzrZgjxqdHmn7QNwPBlpm2
	__jx52K0fsGItWa4CN83U1DY2k.__uXq7lesweQwPVFt806V2gCAg(__FCTxtDBV6NPHKwW6IJnQOpmC.id, __Bsl33jE0VgUtGf0ZDYkuZAkg.__EeeOnAaW3x79G4evvLjbMh4l(d))
static func __Cyu6IBxi2DxLC2MY5kbD50yT(__t595V_wqMvg29AsGD88HFht0: int) -> float:
	return 1.0

func __wENDX6Cu8Q_iHBD18A1i8VX0(__aImau6I48OSZzlRW5KOQspoJ: int = -1) -> PackedInt32Array:
	return __LlOvNfSW39vQFa_X5z9isu0g.__zWv_ztXn2aihNeNL01cSh9EQ(__cQ9sPbueMGXZt2aYRGhozxDp(__3pHTyYQlMesWCy5zSJELYO80 if __aImau6I48OSZzlRW5KOQspoJ < 0 else __aImau6I48OSZzlRW5KOQspoJ))
func __Iglm6KYHkU_C_pzeHfOvxeYS(___3RqtGY1qSGLvpFd0oUqBSnI: int) -> void :
	var any: bool = false
	for __oL9pM73dE6atrQufECRKtyw1: __CgOl36_UCxYZW5PzufCcS4dS in __cQ9sPbueMGXZt2aYRGhozxDp(___3RqtGY1qSGLvpFd0oUqBSnI):
		__oL9pM73dE6atrQufECRKtyw1.__q26f3dCYzrR9TyO_pwwz7lre = -1
		__oL9pM73dE6atrQufECRKtyw1.__ofKSCLcCg7jWtqacDa153ehk = -1
		any = true
	if any:
		save()
func __hN4a7punGT3ktCMQCiR5zjz7(__2_Khi6D6KKlZKdUWaj924TQv: int, __fxMzixCIQmsWXRsoCwBKn4_T: int, source: int = __Bsl33jE0VgUtGf0ZDYkuZAkg.__sHonv71pRuEn82ajAXfAug6Z, __OtprV2Qxi3E5dvnf2xrMpcBe: int = 0) -> void :
	__8gf1LRFmWIu4atdcX2YYGtf5(source, __2_Khi6D6KKlZKdUWaj924TQv, __fxMzixCIQmsWXRsoCwBKn4_T, __OtprV2Qxi3E5dvnf2xrMpcBe)
	save()
var path: String = __jACT03rMxjSbi3wGd52LcC6f
var __6jT8KoopEZhRFiDaeOpZK1bT: = PackedInt32Array()
func __R8eeLnrHRznQldyBPlLJbDHQ(__Is7II53btxsj_L98Jezh0qYG: __CgOl36_UCxYZW5PzufCcS4dS) -> int:
	return int(__LVCMU4xMBMMHO5bxpAYeHYWt(__Is7II53btxsj_L98Jezh0qYG).get("cost", 0)) + meti_recruit_fee(__Is7II53btxsj_L98Jezh0qYG)
func __pRmI0Gva0OZ3_r554GsEvNGr(__lzUYDfTBavaPXghDBjrRgFJC: int) -> int:
	var __3IpgvrChItTkO3_77xhk38Rr: Dictionary = __qyvbOrjVYs2zGM2jUVQYSgGR.get("exp_curve", {})
	return int(round(float(__3IpgvrChItTkO3_77xhk38Rr.get("a", 50)) * pow(float(__lzUYDfTBavaPXghDBjrRgFJC), float(__3IpgvrChItTkO3_77xhk38Rr.get("p", 1.6)))))
var __NZtxVGdhytJuFkBWqJKzc9o4: __bzxMmNAcE_RKMny5gklgDglw
func __mwMeGaMTJbEgeKmC9RauiMQu() -> __CgOl36_UCxYZW5PzufCcS4dS:
	if points < __8je_IJ9qXhG3jZ1HE7jMMTAq():
		return null
	__8gf1LRFmWIu4atdcX2YYGtf5(__Bsl33jE0VgUtGf0ZDYkuZAkg.__jXTZH_Ija8TZywRECMkziNYF, 0, - __8je_IJ9qXhG3jZ1HE7jMMTAq(), 0)
	save()
	return __6PFrcId2T_VUOlJQ2HU0rfRp()
func __geUHcewBqVa9L7LKcQ8q2MXR(__Jx_7mV214awdtVIT0STpIm_G: Dictionary) -> PackedInt32Array:
	var __Kw8LvG_cHTl5d_d4tz1J1fGu: = PackedInt32Array()
	__Kw8LvG_cHTl5d_d4tz1J1fGu.resize(__o4BlGoLwjfAD3TYKD8Kt7FzU.__yJKOGHp90JmK10a2SV3ahPUB)
	var __1ikXQEhD3dBYsnpFW1Vc5Arg: int = int(__Jx_7mV214awdtVIT0STpIm_G.get("key", -1))
	var __Q8hb75kw0U8n3DVGuKDLN1Iu: Dictionary = {0: -1}
	var __W_JTJ83R0FaorSzxNSOB4YOM: Array[int] = [0]
	while not __W_JTJ83R0FaorSzxNSOB4YOM.is_empty() and not __Q8hb75kw0U8n3DVGuKDLN1Iu.has(__1ikXQEhD3dBYsnpFW1Vc5Arg):
		var __I4yR3TdB8twpDRu4KmYuvV0y: int = __W_JTJ83R0FaorSzxNSOB4YOM.pop_front()
		for __LOt7yjf41nyY8PGVbIFd7sIV: Dictionary in ___FfBuNdLnmIikyyvatNDz628.__ub1YxTiOmN7pfRXO5aM4nha0(___FfBuNdLnmIikyyvatNDz628.__plTZcPXT3j_x0cUIlOEd5bfe(__I4yR3TdB8twpDRu4KmYuvV0y)):
			if not __Q8hb75kw0U8n3DVGuKDLN1Iu.has(int(__LOt7yjf41nyY8PGVbIFd7sIV["key"])):
				__Q8hb75kw0U8n3DVGuKDLN1Iu[int(__LOt7yjf41nyY8PGVbIFd7sIV["key"])] = __I4yR3TdB8twpDRu4KmYuvV0y
				__W_JTJ83R0FaorSzxNSOB4YOM.append(int(__LOt7yjf41nyY8PGVbIFd7sIV["key"]))
	var path: Array[int] = []
	if __Q8hb75kw0U8n3DVGuKDLN1Iu.has(__1ikXQEhD3dBYsnpFW1Vc5Arg):
		var __TJtlHV0kxZ1lwaKXzcgefenO: int = __1ikXQEhD3dBYsnpFW1Vc5Arg
		while __TJtlHV0kxZ1lwaKXzcgefenO != -1:
			path.append(__TJtlHV0kxZ1lwaKXzcgefenO)
			__TJtlHV0kxZ1lwaKXzcgefenO = int(__Q8hb75kw0U8n3DVGuKDLN1Iu[__TJtlHV0kxZ1lwaKXzcgefenO])
	else:
		path.append(__1ikXQEhD3dBYsnpFW1Vc5Arg)
	path.reverse()
	for __WoI619DJMNytslMnrVGC191R: int in path:
		var g: PackedInt32Array = ___FfBuNdLnmIikyyvatNDz628.__plTZcPXT3j_x0cUIlOEd5bfe(__WoI619DJMNytslMnrVGC191R).get("growth", PackedInt32Array())
		for __L7ale7zcETZ1P8qA0bCmCW50: int in mini(g.size(), __o4BlGoLwjfAD3TYKD8Kt7FzU.__yJKOGHp90JmK10a2SV3ahPUB):
			__Kw8LvG_cHTl5d_d4tz1J1fGu[__L7ale7zcETZ1P8qA0bCmCW50] = maxi(0, __Kw8LvG_cHTl5d_d4tz1J1fGu[__L7ale7zcETZ1P8qA0bCmCW50] + g[__L7ale7zcETZ1P8qA0bCmCW50])
	return __Kw8LvG_cHTl5d_d4tz1J1fGu
func __CcuJfEJlHGrXUgnJDReo2jb7(__x05fthTQOGmYRYnpnDxMC6DL: __CgOl36_UCxYZW5PzufCcS4dS) -> int:
	return __LlOvNfSW39vQFa_X5z9isu0g.__CcuJfEJlHGrXUgnJDReo2jb7(__x05fthTQOGmYRYnpnDxMC6DL.__zMZVCIoyJu5zkEI6YyKqPDoG)
var __FpK20dPAMc4oZfgOO0plePC2: bool = false
static func __jFwqhnqGTT88GyqAXfNQgMwD(__IYCL9tXFUg01z27ZOC4ptAGU: int) -> int:
	return maxi(__IYCL9tXFUg01z27ZOC4ptAGU, 0) * int((__9MFWgnc8oYQpY6kqM0OFfhrH.__qyvbOrjVYs2zGM2jUVQYSgGR().get("battle", {}) as Dictionary).get("exp_mult_pct", 100)) / 100
func __OFvzEBmSOaaka_xG3IPSAJTS() -> int:
	return maxi(0, int((__qyvbOrjVYs2zGM2jUVQYSgGR.get("battle", {}) as Dictionary).get("settle_permille", 3)))
func __zWR20uspUQuHgajid8HBmEnj(__ke6XEr4LsaSUnhd9Wcp_bKAj: __CgOl36_UCxYZW5PzufCcS4dS, id: int) -> void :
	var path: PackedInt32Array = __tA3YJLknlQFRzbdlkSywAVMu.__uKhbbUT93aFU7Wz45XY9c1cf(id)
	__ke6XEr4LsaSUnhd9Wcp_bKAj.__1U0d7dXiK8nppclbz5xhDxaz = PackedInt32Array()
	__ke6XEr4LsaSUnhd9Wcp_bKAj.__hJTRC1qsUs9T0VQkseYzTT2f = __1OkQgYNA0NkvkBligBeQgZWC.__R2X7seLnTY5XT91Rew6aCtxr
	if path.is_empty():
		return
	__ke6XEr4LsaSUnhd9Wcp_bKAj.__hJTRC1qsUs9T0VQkseYzTT2f = path[path.size() - 1]
	for __rXTIxcWrrpAqMq6ZXpQrR4TE: int in mini(path.size() - 1, __1OkQgYNA0NkvkBligBeQgZWC.__3fKBPF8xIVn7LnRIBUmAHIz6):
		__ke6XEr4LsaSUnhd9Wcp_bKAj.__1U0d7dXiK8nppclbz5xhDxaz.append(path[__rXTIxcWrrpAqMq6ZXpQrR4TE])
func __jNPgEYKDT9jO3SpFHUZ8HJAM(__cRIOSlXRxQEkPzjuvAeLBDvx: String) -> String:
	var __PS4VwxxXtdzropiCYjbQ30WL: Dictionary = __qyvbOrjVYs2zGM2jUVQYSgGR.get("rename", {})
	var s: String = __cRIOSlXRxQEkPzjuvAeLBDvx.strip_edges()
	if s.length() < int(__PS4VwxxXtdzropiCYjbQ30WL.get("min_len", 2)) or s.length() > int(__PS4VwxxXtdzropiCYjbQ30WL.get("max_len", 12)):
		return "UI_CREW_ERR_NAME_LEN"
	for __IuL2jCiejMyLcPkwDMbJEKDx: String in s:
		if __IuL2jCiejMyLcPkwDMbJEKDx == " " or __IuL2jCiejMyLcPkwDMbJEKDx == "'" or __IuL2jCiejMyLcPkwDMbJEKDx.unicode_at(0) < 32:
			return "UI_CREW_ERR_NAME_CHAR"
	return ""
func rename(__WTmwHxsVDM_cYOF8Dxku779k: __CgOl36_UCxYZW5PzufCcS4dS, __1CpsAZajhK0hGO9pcuQrZ1Kn: String) -> String:
	var __bFgzoCiUwENt2Uuo7BpC93Es: String = __jNPgEYKDT9jO3SpFHUZ8HJAM(__1CpsAZajhK0hGO9pcuQrZ1Kn)
	if __bFgzoCiUwENt2Uuo7BpC93Es != "":
		return __bFgzoCiUwENt2Uuo7BpC93Es
	__WTmwHxsVDM_cYOF8Dxku779k.name = __1CpsAZajhK0hGO9pcuQrZ1Kn.strip_edges()
	save()
	return ""
static func __gMVsR2m9YSKpVTBiU_rKodWS(flags: int) -> int:
	if flags & 2149581824:
		return 11
	if flags & 2048:
		return 12
	if flags & 8192:
		return 13
	if flags & 4096:
		return 14
	return -1
const __H6mtDVIhQe4CS6g4xXFL4G7V: = "res://assets/data/crew_rules.json"
func __Dg5_6UDaoA9lq2iM2xl0VAM5() -> void :
	for __gyZ1zPtNLLm7ynya8EE2bx9R: __CgOl36_UCxYZW5PzufCcS4dS in __JMsr0yCjBlwnkO_7FV9gE93o():
		__gyZ1zPtNLLm7ynya8EE2bx9R.__q26f3dCYzrR9TyO_pwwz7lre = -1
		__gyZ1zPtNLLm7ynya8EE2bx9R.__ofKSCLcCg7jWtqacDa153ehk = -1
	save()
func reset() -> void :
	__qpoG34O1fgw9L8TB5rO8XCfq.clear()
	__dFm6DOUISO0GARjmCPdhCxZ0.__3mEO1aZpZMAejcctzfT6J6wd()
	points = int(__qyvbOrjVYs2zGM2jUVQYSgGR.get("start_points", 0))
	__ktyxvkLP8cTjwSfnZb3DAVcL = __9MFWgnc8oYQpY6kqM0OFfhrH.__smzfG1UnW0vxTjXlKlUHVrKa()
	__GeYr1koKZu4yf18L5fqj_M1U = 1
	__3pHTyYQlMesWCy5zSJELYO80 = -1
	__n49srIn8KerL_HEIiCdNmOxf = PackedInt32Array()
	__4SUknJBgHUaV9w15IdBVFhd5 = PackedInt32Array()
	__9tVQSDzDk22f49xhH1zXYlPe = PackedInt32Array()
	__6jT8KoopEZhRFiDaeOpZK1bT = PackedInt32Array()
	__da10PLrO3b92oiJTS9g3Vfve = PackedInt32Array()
	__WkXP3BSGyqCbt6VAuFzmJWsZ = PackedInt32Array()
	__a_utLkfvPV74XmpUxv0T2jqV = PackedInt32Array()
	__RqhcyeP1iDTNK0TaIVLeMfUM = PackedInt32Array()
	__cYNPT_ygRY3o9ufvyN3FSzFH = __s8yZigV26lPAvEmbOWzMbnjE.__gzDclDFgoL3uDH5vfZQtcFjr
	for s: Dictionary in __qyvbOrjVYs2zGM2jUVQYSgGR.get("starter", []):
		var keys: Array[int] = []
		for __Z3QkCncynfQGsZyoJv9sG3Ai: Variant in s.get("path", []):
			keys.append(int(__Z3QkCncynfQGsZyoJv9sG3Ai))
		var __mjTDwdGoNbOu2amKSrr2LiC0: __CgOl36_UCxYZW5PzufCcS4dS = null
		if s.has("advantage"):
			__mjTDwdGoNbOu2amKSrr2LiC0 = __6PFrcId2T_VUOlJQ2HU0rfRp()
			var __5xqD76v51_MhxUz7p7FTtxoH: Array[int] = []
			for __upZCn2UA47Q2Z62_qxAHTvr3: Variant in s["advantage"]:
				__5xqD76v51_MhxUz7p7FTtxoH.append(int(__upZCn2UA47Q2Z62_qxAHTvr3))
			var rest: Array[int] = []
			for __TTVCLc5JsR3Y4ZqJTZy9gUJw: int in __o4BlGoLwjfAD3TYKD8Kt7FzU.__yJKOGHp90JmK10a2SV3ahPUB:
				if not __5xqD76v51_MhxUz7p7FTtxoH.has(__TTVCLc5JsR3Y4ZqJTZy9gUJw):
					rest.append(__TTVCLc5JsR3Y4ZqJTZy9gUJw)
			for __TaZ0HL_TYFHRiePHsReosZx5: int in mini(int(s.get("advantage_extra", 0)), rest.size()):
				__5xqD76v51_MhxUz7p7FTtxoH.append(rest.pop_at(__FOzOkL_5wngFw83WISq0FbBm.randi_range(0, rest.size() - 1)))
			__mjTDwdGoNbOu2amKSrr2LiC0.__wC11jxHS1J5bzkNesfKgNncZ = __geUHcewBqVa9L7LKcQ8q2MXR(__LVCMU4xMBMMHO5bxpAYeHYWt(__mjTDwdGoNbOu2amKSrr2LiC0))
			var g: PackedInt32Array = __rOp4mnR3hdtXTfVHeKqxRGI9(__5xqD76v51_MhxUz7p7FTtxoH, int(s.get("bucket", -1)))
			for __w05nwzYL6k3kFLWQKN2di0j5: int in __o4BlGoLwjfAD3TYKD8Kt7FzU.__yJKOGHp90JmK10a2SV3ahPUB:
				__mjTDwdGoNbOu2amKSrr2LiC0.__wC11jxHS1J5bzkNesfKgNncZ[__w05nwzYL6k3kFLWQKN2di0j5] += g[__w05nwzYL6k3kFLWQKN2di0j5]
		else:
			__mjTDwdGoNbOu2amKSrr2LiC0 = __qvx0LmqSpjUyS4lCTqX_h5vz(keys, int(s.get("level", 1)))
		if __mjTDwdGoNbOu2amKSrr2LiC0 == null:
			continue
		__mjTDwdGoNbOu2amKSrr2LiC0.name = str(s.get("name", ""))
		if s.has("route_to"):
			__zWR20uspUQuHgajid8HBmEnj(__mjTDwdGoNbOu2amKSrr2LiC0, int(s["route_to"]))
		var __IibjI8AXYMN1o3jB7feUbCb3: Array = s.get("men", [20, 0, 0])
		for __SBSz5mRV9sZfC_ME2cGiongS: int in 3:
			__mjTDwdGoNbOu2amKSrr2LiC0.__pY661vwzoRY0D6Y5ORWYVaB_[__SBSz5mRV9sZfC_ME2cGiongS] = int(__IibjI8AXYMN1o3jB7feUbCb3[__SBSz5mRV9sZfC_ME2cGiongS]) if __SBSz5mRV9sZfC_ME2cGiongS < __IibjI8AXYMN1o3jB7feUbCb3.size() else 0
		__mjTDwdGoNbOu2amKSrr2LiC0.id = __GeYr1koKZu4yf18L5fqj_M1U
		__GeYr1koKZu4yf18L5fqj_M1U += 1
		__qpoG34O1fgw9L8TB5rO8XCfq.append(__mjTDwdGoNbOu2amKSrr2LiC0)
	var start: Array[__s8yZigV26lPAvEmbOWzMbnjE] = __U7UMfwBewiXSLEeaDnywaCO7.__L2VQmKwffmZoSc7aBlsgVZny(__Z1L5javwTdjxkGCkHOIHLDVI, __tA3YJLknlQFRzbdlkSywAVMu)
	var __9GK7D6b2ujdppzjgSi1aCGX8: = PackedInt32Array()
	for __B1lOGqJjYLuV1I8wptpQYcCf: __s8yZigV26lPAvEmbOWzMbnjE in start:
		__9GK7D6b2ujdppzjgSi1aCGX8.append(__B1lOGqJjYLuV1I8wptpQYcCf.__WeB9Hi0OxaFBUuwm2WU2qKEH)
	__jx52K0fsGItWa4CN83U1DY2k.__0p9bxVkwi7sidVOHmnpVNAjJ(__Bsl33jE0VgUtGf0ZDYkuZAkg.__5f0RrQR56jqvrh4Tz8mXvqyN(__ktyxvkLP8cTjwSfnZb3DAVcL, points, __9GK7D6b2ujdppzjgSi1aCGX8))
	for __RUp7rE_fDNI4j0892q75BHDt: __CgOl36_UCxYZW5PzufCcS4dS in __qpoG34O1fgw9L8TB5rO8XCfq:
		__jx52K0fsGItWa4CN83U1DY2k.__uXq7lesweQwPVFt806V2gCAg(__RUp7rE_fDNI4j0892q75BHDt.id, __Bsl33jE0VgUtGf0ZDYkuZAkg.__4Ru6nQhfQM3V8TFwZzShiQgn(__RUp7rE_fDNI4j0892q75BHDt))
var __Z1L5javwTdjxkGCkHOIHLDVI: __Se4EsxPBCHX48h1ZS5MexaMl
func __eg7OQWFX4tcDQSGu_DhaMCWs() -> int:
	var __KOaBBU5xD88rTPLeQxa25TlL: Dictionary = __qyvbOrjVYs2zGM2jUVQYSgGR.get("recruit", {})
	var w: Dictionary = __KOaBBU5xD88rTPLeQxa25TlL.get("growth_bucket_weights", {})
	var keys: Array[int] = []
	var ___2UOPVDGhI35HnEyH2A35QTK: int = 0
	for __OB72NMu328knZCf12xdTtAFV: Variant in w:
		if int(w[__OB72NMu328knZCf12xdTtAFV]) > 0:
			keys.append(int(__OB72NMu328knZCf12xdTtAFV))
			___2UOPVDGhI35HnEyH2A35QTK += int(w[__OB72NMu328knZCf12xdTtAFV])
	if ___2UOPVDGhI35HnEyH2A35QTK <= 0:
		return __FOzOkL_5wngFw83WISq0FbBm.randi_range(int(__KOaBBU5xD88rTPLeQxa25TlL.get("growth_bucket_min", 4)), int(__KOaBBU5xD88rTPLeQxa25TlL.get("growth_bucket_max", 6)))
	keys.sort()
	var x: int = __FOzOkL_5wngFw83WISq0FbBm.randi_range(1, ___2UOPVDGhI35HnEyH2A35QTK)
	for __HORQC3Bcde26JZOYv6c60HS4: int in keys:
		x -= int(w[str(__HORQC3Bcde26JZOYv6c60HS4)])
		if x <= 0:
			return __HORQC3Bcde26JZOYv6c60HS4
	return keys[keys.size() - 1]
func __Vfb4Ou3z3jnnT0Pr23tgyLkU(__YM0fL8kwlT_l05d4jDvUOdoX: __CgOl36_UCxYZW5PzufCcS4dS) -> String:
	var __mW84xrY9Zmqh98ryqHOYbEyf: Dictionary = __qyvbOrjVYs2zGM2jUVQYSgGR.get("men", {})
	var __dWXDKG8tNtWHoQEm649ZjdVn: int = int((__qyvbOrjVYs2zGM2jUVQYSgGR.get("replenish", {}) as Dictionary).get("cost", 0))
	if __YM0fL8kwlT_l05d4jDvUOdoX.__O5HLNA7SlbaePlRbjeQY8Yaz() >= __CcuJfEJlHGrXUgnJDReo2jb7(__YM0fL8kwlT_l05d4jDvUOdoX):
		return "UI_CREW_ERR_MEN_FULL"
	if points < __dWXDKG8tNtWHoQEm649ZjdVn:
		return "UI_CREW_ERR_POINTS"
	if __YM0fL8kwlT_l05d4jDvUOdoX.__JMsr0yCjBlwnkO_7FV9gE93o():
		var __x1zqSaA0DPqVw5Iqo4cn6oV1: __2eoTFZc6WxKKaBxTkxeRtmOZ = __ofKSCLcCg7jWtqacDa153ehk()
		var __ojt13jkghi5KobdRw_yUA9Lp: int = int(__LVCMU4xMBMMHO5bxpAYeHYWt(__YM0fL8kwlT_l05d4jDvUOdoX).get("weight", 0))
		if __x1zqSaA0DPqVw5Iqo4cn6oV1 != null and __bfRmJb7Z1nlLKjV3Ju11h42w() + __ojt13jkghi5KobdRw_yUA9Lp > __x1zqSaA0DPqVw5Iqo4cn6oV1.__ISyWU6MieRONO0Y_61I5cH44:
			return "UI_CREW_ERR_WEIGHT"
	__8gf1LRFmWIu4atdcX2YYGtf5(__Bsl33jE0VgUtGf0ZDYkuZAkg.__Bub326MOLqfVGhpPwJu0keSE, 0, - __dWXDKG8tNtWHoQEm649ZjdVn, __YM0fL8kwlT_l05d4jDvUOdoX.id)
	__YM0fL8kwlT_l05d4jDvUOdoX.__pY661vwzoRY0D6Y5ORWYVaB_[0] += 1
	__jx52K0fsGItWa4CN83U1DY2k.__uXq7lesweQwPVFt806V2gCAg(__YM0fL8kwlT_l05d4jDvUOdoX.id, __Bsl33jE0VgUtGf0ZDYkuZAkg.__pY661vwzoRY0D6Y5ORWYVaB_(1, 0, 0))
	save()
	return ""
const __MF6yPnp9nwb3D9beyLm_G7qr: = 1
func __K_J4cy0jmtT5RPUL7bfzj638(__lrOkhNabX4mnhiBe7x56bqpI: __CgOl36_UCxYZW5PzufCcS4dS, __YH9xIBz6nwCk7dWz67VPBo1F: int) -> bool:
	var __aFk_Tpjo3FCHQsqGm2dGQUsh: int = int(__LVCMU4xMBMMHO5bxpAYeHYWt(__lrOkhNabX4mnhiBe7x56bqpI).get("nation", 0))
	return __YH9xIBz6nwCk7dWz67VPBo1F < 0 or __aFk_Tpjo3FCHQsqGm2dGQUsh == 0 or __aFk_Tpjo3FCHQsqGm2dGQUsh == __YH9xIBz6nwCk7dWz67VPBo1F or not __aGKFFuWZttAOryPti7pfE3iP(__aFk_Tpjo3FCHQsqGm2dGQUsh)
func __HslzQboO3K5FDdlVipS3DDoE() -> int:
	var __5f21auLl4JyVm9z00CY3WNIP: Dictionary = __qyvbOrjVYs2zGM2jUVQYSgGR.get("recruit", {})
	var w: Dictionary = __5f21auLl4JyVm9z00CY3WNIP.get("growth_bucket_weights", {})
	var __EbqI6N4fRSs4MAXCjm0IXtq4: int = -1
	for __7pBbhnbgfAojmfvLakIQBvv4: Variant in w:
		if int(w[__7pBbhnbgfAojmfvLakIQBvv4]) > 0:
			__EbqI6N4fRSs4MAXCjm0IXtq4 = maxi(__EbqI6N4fRSs4MAXCjm0IXtq4, int(__7pBbhnbgfAojmfvLakIQBvv4))
	return __EbqI6N4fRSs4MAXCjm0IXtq4 if __EbqI6N4fRSs4MAXCjm0IXtq4 >= 0 else int(__5f21auLl4JyVm9z00CY3WNIP.get("growth_bucket_max", 6))
func __ppcxPlgo8rFGMVWibpznKVCQ() -> Array[__CgOl36_UCxYZW5PzufCcS4dS]:
	var __lNpupY8aodpzbqSvrGPvBlQ1: Array[__CgOl36_UCxYZW5PzufCcS4dS] = []
	for __ErBgW3XkW8KdvWZSRY_ptkOV: __CgOl36_UCxYZW5PzufCcS4dS in __qpoG34O1fgw9L8TB5rO8XCfq:
		if __ErBgW3XkW8KdvWZSRY_ptkOV.__q26f3dCYzrR9TyO_pwwz7lre < 0:
			__lNpupY8aodpzbqSvrGPvBlQ1.append(__ErBgW3XkW8KdvWZSRY_ptkOV)
	return __lNpupY8aodpzbqSvrGPvBlQ1
func __vUM5mIHX8VViD73nWxABeJ0J(__BHfN3Nd1p7m8uM3hRhejLaSs: __s8yZigV26lPAvEmbOWzMbnjE, __BtTFwCKihW9DUDyR5NVptQX2: bool) -> String:
	var __UU6zpDKHUkUKyxnsl4H8diYB: int = __Z1L5javwTdjxkGCkHOIHLDVI.__BGxXnVzPsmPLUaUtEL38SXTm(__BHfN3Nd1p7m8uM3hRhejLaSs)
	if __UU6zpDKHUkUKyxnsl4H8diYB != __Se4EsxPBCHX48h1ZS5MexaMl.__5CDMR1_ZY_Be5hesPdyczkNt.OK and __UU6zpDKHUkUKyxnsl4H8diYB != __Se4EsxPBCHX48h1ZS5MexaMl.__5CDMR1_ZY_Be5hesPdyczkNt.__zG959bwdOwL5xL4s3PeplU46:
		return "UI_SS_ERR_%d" % __UU6zpDKHUkUKyxnsl4H8diYB
	if __BtTFwCKihW9DUDyR5NVptQX2 and __BHfN3Nd1p7m8uM3hRhejLaSs.__dOsDavODOasdfPxqce2DEBC3.has(__s8yZigV26lPAvEmbOWzMbnjE.__1iBjWxIGtvWf0yGsmF7yzBIR):
		return "UI_SB_ERR_GUN_EMPTY"
	if __BHfN3Nd1p7m8uM3hRhejLaSs.__vwSAcybbCInOpnt2FbN4qz7L < 0:
		return "UI_DOCK_ERR_NO_FCS"
	var __5OcqU8dfBBDkpqMrGq7kxqJb: String = __lmpWsWqjW3K_vd5n9ILNvkzw(__BHfN3Nd1p7m8uM3hRhejLaSs)
	if __5OcqU8dfBBDkpqMrGq7kxqJb != "":
		return __5OcqU8dfBBDkpqMrGq7kxqJb
	if __UU6zpDKHUkUKyxnsl4H8diYB == __Se4EsxPBCHX48h1ZS5MexaMl.__5CDMR1_ZY_Be5hesPdyczkNt.__zG959bwdOwL5xL4s3PeplU46:
		return "UI_SS_ERR_%d" % __UU6zpDKHUkUKyxnsl4H8diYB
	if __BtTFwCKihW9DUDyR5NVptQX2:
		for __3Amv5V_BwdxyZn13evrpg3Z1: __CgOl36_UCxYZW5PzufCcS4dS in __cQ9sPbueMGXZt2aYRGhozxDp(__BHfN3Nd1p7m8uM3hRhejLaSs.__WeB9Hi0OxaFBUuwm2WU2qKEH):
			if __jx52K0fsGItWa4CN83U1DY2k.__V8DSfFdAnWyCSpwqWM11mzVq(__3Amv5V_BwdxyZn13evrpg3Z1.id).is_empty():
				return "UI_SB_ERR_NO_LOG"
		if not __jx52K0fsGItWa4CN83U1DY2k.__hKFVmIXdQIF4AsxUovnLPQPE():
			return "UI_SB_ERR_NO_LOG"
	return ""
func __7G5al7c8rrhrq_VnoCfQSLbW(__Bw5tJSr6rcdsUTJAUwCw2BLg: __CgOl36_UCxYZW5PzufCcS4dS) -> void :
	var __k7jOWrpzIBxH9r5PeIO7205c: PackedInt32Array = __Bw5tJSr6rcdsUTJAUwCw2BLg.__4ObdBYhtKkHScUayTPgiYzH_
	__Bw5tJSr6rcdsUTJAUwCw2BLg.__zMZVCIoyJu5zkEI6YyKqPDoG += 1
	var __5g9ASrIJX8z2e7yppYvZs1oT: PackedInt32Array = __Bw5tJSr6rcdsUTJAUwCw2BLg.__4ObdBYhtKkHScUayTPgiYzH_
	var __OLq29QqryUszVJ0Z91zvIYLG: PackedInt32Array = __Bw5tJSr6rcdsUTJAUwCw2BLg.__wC11jxHS1J5bzkNesfKgNncZ
	for __28vEm_dgHa1OrV7UMkiF_IGA: int in __o4BlGoLwjfAD3TYKD8Kt7FzU.__yJKOGHp90JmK10a2SV3ahPUB:
		__5g9ASrIJX8z2e7yppYvZs1oT[__28vEm_dgHa1OrV7UMkiF_IGA] = clampi(__5g9ASrIJX8z2e7yppYvZs1oT[__28vEm_dgHa1OrV7UMkiF_IGA] + __OLq29QqryUszVJ0Z91zvIYLG[__28vEm_dgHa1OrV7UMkiF_IGA], 0, __LlOvNfSW39vQFa_X5z9isu0g.__5mUmXzFHF3sOKQKf_XcZ1XFe)
	__Bw5tJSr6rcdsUTJAUwCw2BLg.__4ObdBYhtKkHScUayTPgiYzH_ = __5g9ASrIJX8z2e7yppYvZs1oT
	var __ZHS3jyfvcw4yzIjjznIUbHvj: int = mini(int((__qyvbOrjVYs2zGM2jUVQYSgGR.get("men", {}) as Dictionary).get("levelup_promote", 2)), __Bw5tJSr6rcdsUTJAUwCw2BLg.__pY661vwzoRY0D6Y5ORWYVaB_[0])
	__Bw5tJSr6rcdsUTJAUwCw2BLg.__pY661vwzoRY0D6Y5ORWYVaB_[0] -= __ZHS3jyfvcw4yzIjjznIUbHvj
	__Bw5tJSr6rcdsUTJAUwCw2BLg.__pY661vwzoRY0D6Y5ORWYVaB_[1] += __ZHS3jyfvcw4yzIjjznIUbHvj
	if __Bw5tJSr6rcdsUTJAUwCw2BLg.id > 0 and __qpoG34O1fgw9L8TB5rO8XCfq.has(__Bw5tJSr6rcdsUTJAUwCw2BLg):
		var d: = PackedInt32Array()
		d.resize(__o4BlGoLwjfAD3TYKD8Kt7FzU.__yJKOGHp90JmK10a2SV3ahPUB)
		for __PneCdt7vvSV4YjhuFMdqeMnP: int in __o4BlGoLwjfAD3TYKD8Kt7FzU.__yJKOGHp90JmK10a2SV3ahPUB:
			d[__PneCdt7vvSV4YjhuFMdqeMnP] = __5g9ASrIJX8z2e7yppYvZs1oT[__PneCdt7vvSV4YjhuFMdqeMnP] - __k7jOWrpzIBxH9r5PeIO7205c[__PneCdt7vvSV4YjhuFMdqeMnP]
		__jx52K0fsGItWa4CN83U1DY2k.__uXq7lesweQwPVFt806V2gCAg(__Bw5tJSr6rcdsUTJAUwCw2BLg.id, __Bsl33jE0VgUtGf0ZDYkuZAkg.__C515wFpFrWEK5NdcSsTKRWJT(d, PackedInt32Array([ - __ZHS3jyfvcw4yzIjjznIUbHvj, __ZHS3jyfvcw4yzIjjznIUbHvj, 0])))
var __ktyxvkLP8cTjwSfnZb3DAVcL: int:
	get: return __NYy2YToEB4fxxEoFuo45AarQ.get_value()
	set(v): __NYy2YToEB4fxxEoFuo45AarQ.set_value(v)
func save() -> void :
	__dFm6DOUISO0GARjmCPdhCxZ0.set_value("crew", null)
	changed.emit()
func __LVCMU4xMBMMHO5bxpAYeHYWt(__taX0EmfFPj77UdB5mtpibLf7: __CgOl36_UCxYZW5PzufCcS4dS) -> Dictionary:
	return ___FfBuNdLnmIikyyvatNDz628.__eKMOY9vZxsK1HnP0cqwVRqgs(__taX0EmfFPj77UdB5mtpibLf7.__mpLpovabZnp87HNkreW4pWJY)
func __6vukUhU2G_4b_rRHatkEj0ZY(__TFLxry3rskq9pyJ7tqArHyPw: int, __sgK21hFgz1gbYlVLbr7DoUQ3: Dictionary = {}, __W2rpy8xzhL2hwa1Xw18hmr3w: int = -1, __nU3nf0B4tDqvQn6KCWgSzvbk: int = 0, __pJ8gNvFO998rNvWpBtHPdzKC: Dictionary = {}, __M3vOrHEsEik_42d5TzcbgEg1: PackedInt32Array = PackedInt32Array()) -> Dictionary:
	var __Jyqf_nfdoxHvAzXkPxIqImtQ: Dictionary = __qyvbOrjVYs2zGM2jUVQYSgGR.get("battle", {})
	var __xMR2CdHZNvAsM1Q8BnsrlE0M: int = int(__sgK21hFgz1gbYlVLbr7DoUQ3.get("points", int(__Jyqf_nfdoxHvAzXkPxIqImtQ.get("base_points", 0)) + __TFLxry3rskq9pyJ7tqArHyPw * int(__Jyqf_nfdoxHvAzXkPxIqImtQ.get("points_per_exp", 0))))
	var ___491hZHqXolfhfbSpTPzioWB: int = int(__sgK21hFgz1gbYlVLbr7DoUQ3.get("credits", 0))
	var __Fd6QmIS48B61qRPzrBnag_cb: int = __3pHTyYQlMesWCy5zSJELYO80 if __W2rpy8xzhL2hwa1Xw18hmr3w < 0 else __W2rpy8xzhL2hwa1Xw18hmr3w
	var __wSa_x1YxfQkukcj8tu0rMsJL: int = __ktyxvkLP8cTjwSfnZb3DAVcL
	var __r0NrJtYX_akZqJvaO_DbCeul: int = points
	var __i1dv6MU4xAAEIfdxKTUyycDn: int = __jx52K0fsGItWa4CN83U1DY2k.__Q9JUjZRWNbCr3yIljSlxPDDP(__Bsl33jE0VgUtGf0ZDYkuZAkg.__jqrpAP5Ufi5CUtUDTkl21WOq(__Fd6QmIS48B61qRPzrBnag_cb, __TFLxry3rskq9pyJ7tqArHyPw, ___491hZHqXolfhfbSpTPzioWB, __xMR2CdHZNvAsM1Q8BnsrlE0M, __nU3nf0B4tDqvQn6KCWgSzvbk) if __pJ8gNvFO998rNvWpBtHPdzKC.is_empty()
		else __Bsl33jE0VgUtGf0ZDYkuZAkg.__2WcXt43cd12t3Ju7LqI11H80(__Fd6QmIS48B61qRPzrBnag_cb, int(__pJ8gNvFO998rNvWpBtHPdzKC["match_id"]), __TFLxry3rskq9pyJ7tqArHyPw, ___491hZHqXolfhfbSpTPzioWB, __xMR2CdHZNvAsM1Q8BnsrlE0M, int(__pJ8gNvFO998rNvWpBtHPdzKC["server_time"]), __pJ8gNvFO998rNvWpBtHPdzKC["sig"]))
	__8gf1LRFmWIu4atdcX2YYGtf5(__Bsl33jE0VgUtGf0ZDYkuZAkg.__UIv2WzsH9TzMENAvL2h37Lud, ___491hZHqXolfhfbSpTPzioWB, __xMR2CdHZNvAsM1Q8BnsrlE0M, __i1dv6MU4xAAEIfdxKTUyycDn)
	var __8BafXQP4Uavy5f0VSfAFHgJi: Array = []
	for __IANsMcRF4sFipQ0qNx88syrJ: __CgOl36_UCxYZW5PzufCcS4dS in __cQ9sPbueMGXZt2aYRGhozxDp(__Fd6QmIS48B61qRPzrBnag_cb):
		var __SGvHx04oRsR1yYr7clXw9dTD: int = __IANsMcRF4sFipQ0qNx88syrJ.__zMZVCIoyJu5zkEI6YyKqPDoG
		var __9wCGMOJ_RfY8CfKGpNqoNbvz: int = __IANsMcRF4sFipQ0qNx88syrJ.exp
		var __ouUQ4GruZYipVRYcwL06OHYI: Array = Array(__IANsMcRF4sFipQ0qNx88syrJ.__4ObdBYhtKkHScUayTPgiYzH_)
		var __X119FaHIzrG5JQkJWRnBC3_R: Array = Array(__IANsMcRF4sFipQ0qNx88syrJ.__pY661vwzoRY0D6Y5ORWYVaB_)
		__jKjv1tq5RRmN4J8UhZ1oGLwE(__IANsMcRF4sFipQ0qNx88syrJ, __TFLxry3rskq9pyJ7tqArHyPw)
		__jx52K0fsGItWa4CN83U1DY2k.__uXq7lesweQwPVFt806V2gCAg(__IANsMcRF4sFipQ0qNx88syrJ.id, __Bsl33jE0VgUtGf0ZDYkuZAkg.__v56w0nDh5mq2I0MTm9draNQd(__i1dv6MU4xAAEIfdxKTUyycDn, __IANsMcRF4sFipQ0qNx88syrJ.exp - __9wCGMOJ_RfY8CfKGpNqoNbvz))
		var __xXxjmeAfyRdXb2XV9iWLrAy9: int = __ezmCKdWm9cDeYJ_774xlKddx(__IANsMcRF4sFipQ0qNx88syrJ, __M3vOrHEsEik_42d5TzcbgEg1[__IANsMcRF4sFipQ0qNx88syrJ.__q26f3dCYzrR9TyO_pwwz7lre] if __IANsMcRF4sFipQ0qNx88syrJ.__q26f3dCYzrR9TyO_pwwz7lre >= 0 and __IANsMcRF4sFipQ0qNx88syrJ.__q26f3dCYzrR9TyO_pwwz7lre < __M3vOrHEsEik_42d5TzcbgEg1.size() else 0)
		__8BafXQP4Uavy5f0VSfAFHgJi.append({"id": __IANsMcRF4sFipQ0qNx88syrJ.id, "name": __IANsMcRF4sFipQ0qNx88syrJ.name, "class": str(__LVCMU4xMBMMHO5bxpAYeHYWt(__IANsMcRF4sFipQ0qNx88syrJ).get("name", "")), "slot": __IANsMcRF4sFipQ0qNx88syrJ.__q26f3dCYzrR9TyO_pwwz7lre, "gain": __TFLxry3rskq9pyJ7tqArHyPw, "lv0": __SGvHx04oRsR1yYr7clXw9dTD, "lv1": __IANsMcRF4sFipQ0qNx88syrJ.__zMZVCIoyJu5zkEI6YyKqPDoG, "exp": __IANsMcRF4sFipQ0qNx88syrJ.exp, "need": __pRmI0Gva0OZ3_r554GsEvNGr(__IANsMcRF4sFipQ0qNx88syrJ.__zMZVCIoyJu5zkEI6YyKqPDoG), "ab0": __ouUQ4GruZYipVRYcwL06OHYI, "men0": __X119FaHIzrG5JQkJWRnBC3_R, "rookie_up": __xXxjmeAfyRdXb2XV9iWLrAy9})
	save()
	return {"total": __TFLxry3rskq9pyJ7tqArHyPw, "points": __xMR2CdHZNvAsM1Q8BnsrlE0M, "credits": ___491hZHqXolfhfbSpTPzioWB, "rows": __8BafXQP4Uavy5f0VSfAFHgJi, "credits_total": __ktyxvkLP8cTjwSfnZb3DAVcL, "points_total": points, "credits_delta": __ktyxvkLP8cTjwSfnZb3DAVcL - __wSa_x1YxfQkukcj8tu0rMsJL, "points_delta": points - __r0NrJtYX_akZqJvaO_DbCeul}
static func create(__GFsDdTtXeEebLVsMcHQKnnYh: __bzxMmNAcE_RKMny5gklgDglw, __VKOl48BgcIEt6R10zU5ZjmAq: __Se4EsxPBCHX48h1ZS5MexaMl, __E9vHABkHrzhalhtgfdqiDyv_: __o4BlGoLwjfAD3TYKD8Kt7FzU, __oMCJcRixjLD9_gHwJj4TG7LK: String = __jACT03rMxjSbi3wGd52LcC6f) -> __MxRtF5kMQ2PhDOJRxJ1ej8ie:
	var r: = __MxRtF5kMQ2PhDOJRxJ1ej8ie.new()
	r.__NZtxVGdhytJuFkBWqJKzc9o4 = __GFsDdTtXeEebLVsMcHQKnnYh
	r.__Z1L5javwTdjxkGCkHOIHLDVI = __VKOl48BgcIEt6R10zU5ZjmAq
	r.___FfBuNdLnmIikyyvatNDz628 = __E9vHABkHrzhalhtgfdqiDyv_
	r.__tA3YJLknlQFRzbdlkSywAVMu = __1OkQgYNA0NkvkBligBeQgZWC.__x4dRhV0emeOXyfnjujX6iOAP()
	r.path = __oMCJcRixjLD9_gHwJj4TG7LK
	r.__dFm6DOUISO0GARjmCPdhCxZ0 = __k8pdL_GB8yADpq0vqeDWpz5v.__EQSSy6KHEM37BgV1J4KGqz8Y() if __oMCJcRixjLD9_gHwJj4TG7LK == __jACT03rMxjSbi3wGd52LcC6f else __k8pdL_GB8yADpq0vqeDWpz5v.__gZkaWUwasJf6pMV_XotrMI6s(__oMCJcRixjLD9_gHwJj4TG7LK)
	if __oMCJcRixjLD9_gHwJj4TG7LK != __jACT03rMxjSbi3wGd52LcC6f:
		r.__dFm6DOUISO0GARjmCPdhCxZ0.__BUvCjivOPP1QUw_ZYo4pQFFp = false
	r.__jx52K0fsGItWa4CN83U1DY2k = r.__dFm6DOUISO0GARjmCPdhCxZ0.__W6QsuD1d3329_0oIzLomMBJU()
	var v: Variant = JSON.parse_string(__gebnXaZA9PFUWGVFWlMPDEta.text(__H6mtDVIhQe4CS6g4xXFL4G7V))
	r.__qyvbOrjVYs2zGM2jUVQYSgGR = v if v is Dictionary else {}
	r.__FOzOkL_5wngFw83WISq0FbBm.randomize()
	if not r._load():
		r.reset()
		r.__FpK20dPAMc4oZfgOO0plePC2 = true
	return r
func __30bFo4mrG0v_5UuwZqMhzIBK(__63FwtpXy0sIqQFNyw4dYMTKq: __CgOl36_UCxYZW5PzufCcS4dS) -> PackedInt32Array:
	var __n0TDjCis3bbmCJopPmsCYq1M: PackedInt32Array = __63FwtpXy0sIqQFNyw4dYMTKq.__1U0d7dXiK8nppclbz5xhDxaz.duplicate()
	__n0TDjCis3bbmCJopPmsCYq1M.append(__63FwtpXy0sIqQFNyw4dYMTKq.__hJTRC1qsUs9T0VQkseYzTT2f)
	return __n0TDjCis3bbmCJopPmsCYq1M
func __DNylqQ3lXnvZsUmwZubbVYvv(__wV10YDI2VFBES4KcwTU1Q5Lp: __CgOl36_UCxYZW5PzufCcS4dS) -> Dictionary:
	var __k07rtlcjmEYo4YYWM9TsBC_E: Dictionary = __qyvbOrjVYs2zGM2jUVQYSgGR.get("promote", {})
	var __ljBSBd72ORlCcKIUQ1fXMRK2: int = int(__k07rtlcjmEYo4YYWM9TsBC_E.get("cost", 0))
	var __IwEfceeatLEqZ30rxW31RAM0: int = __5xe9ruE_3UmhX284W8xBhd_j()
	if __wV10YDI2VFBES4KcwTU1Q5Lp.__pY661vwzoRY0D6Y5ORWYVaB_[1] < __IwEfceeatLEqZ30rxW31RAM0:
		return {"err": "UI_CREW_ERR_NO_SKILLED", "ok": false, "lost": 0}
	if __wV10YDI2VFBES4KcwTU1Q5Lp.__pY661vwzoRY0D6Y5ORWYVaB_[2] + __IwEfceeatLEqZ30rxW31RAM0 > __76YQlbOoFzFgpPn_qa5fce31(__wV10YDI2VFBES4KcwTU1Q5Lp):
		return {"err": "UI_CREW_ERR_TECH_RATIO", "ok": false, "lost": 0}
	if points < __ljBSBd72ORlCcKIUQ1fXMRK2:
		return {"err": "UI_CREW_ERR_POINTS", "ok": false, "lost": 0}
	__8gf1LRFmWIu4atdcX2YYGtf5(__Bsl33jE0VgUtGf0ZDYkuZAkg.__XiEb4ye1ZKK5O4qAb053JFLI, 0, - __ljBSBd72ORlCcKIUQ1fXMRK2, __wV10YDI2VFBES4KcwTU1Q5Lp.id)
	if __FOzOkL_5wngFw83WISq0FbBm.randf() < __jzYnT2qz6bxMyJubqlRmPdDW(__wV10YDI2VFBES4KcwTU1Q5Lp.__pY661vwzoRY0D6Y5ORWYVaB_[2]) / 100.0:
		__wV10YDI2VFBES4KcwTU1Q5Lp.__pY661vwzoRY0D6Y5ORWYVaB_[1] -= __IwEfceeatLEqZ30rxW31RAM0
		__wV10YDI2VFBES4KcwTU1Q5Lp.__pY661vwzoRY0D6Y5ORWYVaB_[2] += __IwEfceeatLEqZ30rxW31RAM0
		__jx52K0fsGItWa4CN83U1DY2k.__uXq7lesweQwPVFt806V2gCAg(__wV10YDI2VFBES4KcwTU1Q5Lp.id, __Bsl33jE0VgUtGf0ZDYkuZAkg.__pY661vwzoRY0D6Y5ORWYVaB_(0, - __IwEfceeatLEqZ30rxW31RAM0, __IwEfceeatLEqZ30rxW31RAM0))
		save()
		return {"err": "", "ok": true, "lost": 0}
	var __e7wIYzP57KyAOja27gOhKKjX: int = mini(__5keQ3Ns1NqlbEP7Qxzkm52AK(__k07rtlcjmEYo4YYWM9TsBC_E.get("fail_lost_weights", [1])) + 1, __wV10YDI2VFBES4KcwTU1Q5Lp.__pY661vwzoRY0D6Y5ORWYVaB_[1])
	__wV10YDI2VFBES4KcwTU1Q5Lp.__pY661vwzoRY0D6Y5ORWYVaB_[1] -= __e7wIYzP57KyAOja27gOhKKjX
	__jx52K0fsGItWa4CN83U1DY2k.__uXq7lesweQwPVFt806V2gCAg(__wV10YDI2VFBES4KcwTU1Q5Lp.id, __Bsl33jE0VgUtGf0ZDYkuZAkg.__pY661vwzoRY0D6Y5ORWYVaB_(0, - __e7wIYzP57KyAOja27gOhKKjX, 0))
	save()
	return {"err": "", "ok": false, "lost": __e7wIYzP57KyAOja27gOhKKjX}
func __OMmZ8ceL80Cz6iW2ABlJwosY(__KC7oEoQStFrPfZ_pBWi8DNdD: int = -1) -> PackedInt32Array:
	var __mz4FrHcLPE4jJROyLCVllQZY: int = __3pHTyYQlMesWCy5zSJELYO80 if __KC7oEoQStFrPfZ_pBWi8DNdD < 0 else __KC7oEoQStFrPfZ_pBWi8DNdD
	var __SQVO31ZXIG35x2A6QgPakey1: __2eoTFZc6WxKKaBxTkxeRtmOZ = __EhjJRLjwGbixjchwHoi91WQb(__mz4FrHcLPE4jJROyLCVllQZY)
	return __LlOvNfSW39vQFa_X5z9isu0g.__YjdecicvdCo7i83L_WSJxXd6(__cQ9sPbueMGXZt2aYRGhozxDp(__mz4FrHcLPE4jJROyLCVllQZY), ___FfBuNdLnmIikyyvatNDz628, __SQVO31ZXIG35x2A6QgPakey1.__V9nPx6hwHXTjiZSit4R51eP0 if __SQVO31ZXIG35x2A6QgPakey1 != null else 0)
var __jx52K0fsGItWa4CN83U1DY2k: __BEkn2Y2Ro4u7ElF9E_zRzXba
var __n49srIn8KerL_HEIiCdNmOxf: = PackedInt32Array()
func __lmpWsWqjW3K_vd5n9ILNvkzw(__yGFirIr7wMznNvOqqNbSnvgL: __s8yZigV26lPAvEmbOWzMbnjE) -> String:
	var __lizYkpIZbq1IeogEEPc2EaW8: __2eoTFZc6WxKKaBxTkxeRtmOZ = __EhjJRLjwGbixjchwHoi91WQb(__yGFirIr7wMznNvOqqNbSnvgL.__WeB9Hi0OxaFBUuwm2WU2qKEH)
	if __lizYkpIZbq1IeogEEPc2EaW8 == null:
		return "UI_CREW_ERR_NO_CAPTAIN"
	var __AR1kmIzg4LaZ_wnVR9HEGihT: Array[__CgOl36_UCxYZW5PzufCcS4dS] = __cQ9sPbueMGXZt2aYRGhozxDp(__yGFirIr7wMznNvOqqNbSnvgL.__WeB9Hi0OxaFBUuwm2WU2qKEH)
	var __wrvDTGue26v84rC1SOtFACEl: __CgOl36_UCxYZW5PzufCcS4dS = null
	var __DEjq8EoD3aynrwidKLrbiqhX: int = 0
	for __HUrxinAfQFtuFK5QvJr7YOym: __CgOl36_UCxYZW5PzufCcS4dS in __AR1kmIzg4LaZ_wnVR9HEGihT:
		if __HUrxinAfQFtuFK5QvJr7YOym.__q26f3dCYzrR9TyO_pwwz7lre == 0:
			__wrvDTGue26v84rC1SOtFACEl = __HUrxinAfQFtuFK5QvJr7YOym
		__DEjq8EoD3aynrwidKLrbiqhX += __HUrxinAfQFtuFK5QvJr7YOym.__Ln9avrueTbF2AkgyV87ZgBiF(__LVCMU4xMBMMHO5bxpAYeHYWt(__HUrxinAfQFtuFK5QvJr7YOym), __lizYkpIZbq1IeogEEPc2EaW8.__JzUUCYNEpRcSKSi9X3gAiTQK())
	if __wrvDTGue26v84rC1SOtFACEl == null:
		return "UI_CREW_ERR_NO_CAPTAIN"
	if __o4BlGoLwjfAD3TYKD8Kt7FzU.__fayWacQjLgGI2Tr23o7x3Xvx(__LVCMU4xMBMMHO5bxpAYeHYWt(__wrvDTGue26v84rC1SOtFACEl)):
		return "UI_CREW_ERR_MEDIC_BRIDGE"
	if __Z1L5javwTdjxkGCkHOIHLDVI.__77YZ0E3pilwCWMSZ5lHzv_es(__yGFirIr7wMznNvOqqNbSnvgL).x + __DEjq8EoD3aynrwidKLrbiqhX > __lizYkpIZbq1IeogEEPc2EaW8.__ISyWU6MieRONO0Y_61I5cH44:
		return "UI_CREW_ERR_OVERLOAD"
	if __lizYkpIZbq1IeogEEPc2EaW8.__RZSGss6vMJxzvS6fmWkQMma8 == __2eoTFZc6WxKKaBxTkxeRtmOZ.__UdurGu7NlLw_5NC5J7D7nIXj:
		var __iC70PfAHa_56e4G2GEZl_Y8b: int = 0
		for __3SQhsSFxDGqwjjE89LjdpQhd: __CgOl36_UCxYZW5PzufCcS4dS in __AR1kmIzg4LaZ_wnVR9HEGihT:
			if __lizYkpIZbq1IeogEEPc2EaW8.__ykzgAs0XCiNBCa5N91GVfvLY(__3SQhsSFxDGqwjjE89LjdpQhd.__q26f3dCYzrR9TyO_pwwz7lre) and int(__LVCMU4xMBMMHO5bxpAYeHYWt(__3SQhsSFxDGqwjjE89LjdpQhd).get("flags", 0)) & __o4BlGoLwjfAD3TYKD8Kt7FzU.__qK3r1tHFgcp6FlfZzG1_VPQy:
				__iC70PfAHa_56e4G2GEZl_Y8b += 1
		if __iC70PfAHa_56e4G2GEZl_Y8b < __Se4EsxPBCHX48h1ZS5MexaMl.__bJI9NQxQ5UDVu7ffWvlBR9CJ:
			return "UI_CREW_ERR_CV_PILOTS"
	if __lizYkpIZbq1IeogEEPc2EaW8.__RZSGss6vMJxzvS6fmWkQMma8 == __Se4EsxPBCHX48h1ZS5MexaMl.__4cYyo29DcWFPcLdEsHACapS4:
		for __MG11i3ekcFD6K133bjsluluI: __CgOl36_UCxYZW5PzufCcS4dS in __AR1kmIzg4LaZ_wnVR9HEGihT:
			if __lizYkpIZbq1IeogEEPc2EaW8.__ykzgAs0XCiNBCa5N91GVfvLY(__MG11i3ekcFD6K133bjsluluI.__q26f3dCYzrR9TyO_pwwz7lre) and int(__LVCMU4xMBMMHO5bxpAYeHYWt(__MG11i3ekcFD6K133bjsluluI).get("flags", 0)) & __o4BlGoLwjfAD3TYKD8Kt7FzU.__qK3r1tHFgcp6FlfZzG1_VPQy:
				return "UI_CREW_ERR_SUB_PILOTS"
	return ""
func __5xe9ruE_3UmhX284W8xBhd_j() -> int:
	return maxi(1, int((__qyvbOrjVYs2zGM2jUVQYSgGR.get("promote", {}) as Dictionary).get("group", 10)))
func __rOp4mnR3hdtXTfVHeKqxRGI9(__mgyt59_ArIcHLao3K0KNQcYU: Array[int] = [], __CmyNVsTh6zBIFNpRp0SYJhVZ: int = -1) -> PackedInt32Array:
	var __Bs73OhJtjU4Qz0_RvSovjQf2: Dictionary = __qyvbOrjVYs2zGM2jUVQYSgGR.get("recruit", {})
	var g: = PackedInt32Array()
	g.resize(__o4BlGoLwjfAD3TYKD8Kt7FzU.__yJKOGHp90JmK10a2SV3ahPUB)
	if not __mgyt59_ArIcHLao3K0KNQcYU.is_empty():
		var __gr7Lx25L8ubgs20WVf3t6WRl: int = maxi(int(__Bs73OhJtjU4Qz0_RvSovjQf2.get("growth_pick_min", 1)), 0)
		var __D0eaEePCj2s2DtS_V3yOwqx5: int = maxi(__CmyNVsTh6zBIFNpRp0SYJhVZ if __CmyNVsTh6zBIFNpRp0SYJhVZ >= 0 else __eg7OQWFX4tcDQSGu_DhaMCWs(), __gr7Lx25L8ubgs20WVf3t6WRl * __mgyt59_ArIcHLao3K0KNQcYU.size())
		for __j8E4tbgAY93dK6892THeV7PZ: int in __mgyt59_ArIcHLao3K0KNQcYU.size():
			var __VHyiBDsjLa4IPvhCgtz_Tsbh: int = __D0eaEePCj2s2DtS_V3yOwqx5 if __j8E4tbgAY93dK6892THeV7PZ == __mgyt59_ArIcHLao3K0KNQcYU.size() - 1 else __FOzOkL_5wngFw83WISq0FbBm.randi_range(__gr7Lx25L8ubgs20WVf3t6WRl, __D0eaEePCj2s2DtS_V3yOwqx5 - __gr7Lx25L8ubgs20WVf3t6WRl * (__mgyt59_ArIcHLao3K0KNQcYU.size() - 1 - __j8E4tbgAY93dK6892THeV7PZ))
			g[clampi(__mgyt59_ArIcHLao3K0KNQcYU[__j8E4tbgAY93dK6892THeV7PZ], 0, __o4BlGoLwjfAD3TYKD8Kt7FzU.__yJKOGHp90JmK10a2SV3ahPUB - 1)] += __VHyiBDsjLa4IPvhCgtz_Tsbh
			__D0eaEePCj2s2DtS_V3yOwqx5 -= __VHyiBDsjLa4IPvhCgtz_Tsbh
		return g
	var __pGCDrimLkX3uLGlwxcwwa4VK: int = clampi(int(__Bs73OhJtjU4Qz0_RvSovjQf2.get("growth_picks", 0)), 0, __o4BlGoLwjfAD3TYKD8Kt7FzU.__yJKOGHp90JmK10a2SV3ahPUB)
	if __pGCDrimLkX3uLGlwxcwwa4VK <= 0:
		return g
	var __5FsjtsJLCNbSSo7IsTKTzEk7: int = maxi(int(__Bs73OhJtjU4Qz0_RvSovjQf2.get("growth_pick_min", 1)), 0)
	if __CmyNVsTh6zBIFNpRp0SYJhVZ < 0:
		__CmyNVsTh6zBIFNpRp0SYJhVZ = __eg7OQWFX4tcDQSGu_DhaMCWs()
	__CmyNVsTh6zBIFNpRp0SYJhVZ = maxi(__CmyNVsTh6zBIFNpRp0SYJhVZ, __5FsjtsJLCNbSSo7IsTKTzEk7 * __pGCDrimLkX3uLGlwxcwwa4VK)
	var __FfxOx_haH8lrvP3ss7YFPZ06: Array[int] = []
	for __z8mi50kDHEPpLiF3NoR34b9E: int in __o4BlGoLwjfAD3TYKD8Kt7FzU.__yJKOGHp90JmK10a2SV3ahPUB:
		__FfxOx_haH8lrvP3ss7YFPZ06.append(__z8mi50kDHEPpLiF3NoR34b9E)
	for __QQV3TUkTTuilYx2wc6_GjAx5: int in __pGCDrimLkX3uLGlwxcwwa4VK:
		var __nZsqOnqmppO2ne1CLfUSvPL3: int = __FOzOkL_5wngFw83WISq0FbBm.randi_range(__QQV3TUkTTuilYx2wc6_GjAx5, __FfxOx_haH8lrvP3ss7YFPZ06.size() - 1)
		var __vdsU0Zd4x8BjMVCjFlutKzzx: int = __FfxOx_haH8lrvP3ss7YFPZ06[__QQV3TUkTTuilYx2wc6_GjAx5]
		__FfxOx_haH8lrvP3ss7YFPZ06[__QQV3TUkTTuilYx2wc6_GjAx5] = __FfxOx_haH8lrvP3ss7YFPZ06[__nZsqOnqmppO2ne1CLfUSvPL3]
		__FfxOx_haH8lrvP3ss7YFPZ06[__nZsqOnqmppO2ne1CLfUSvPL3] = __vdsU0Zd4x8BjMVCjFlutKzzx
	var left: int = __CmyNVsTh6zBIFNpRp0SYJhVZ
	for __uznXRbIwZE3NuRABEFkoEa8Q: int in __pGCDrimLkX3uLGlwxcwwa4VK:
		var v: int = left if __uznXRbIwZE3NuRABEFkoEa8Q == __pGCDrimLkX3uLGlwxcwwa4VK - 1 else __FOzOkL_5wngFw83WISq0FbBm.randi_range(__5FsjtsJLCNbSSo7IsTKTzEk7, left - __5FsjtsJLCNbSSo7IsTKTzEk7 * (__pGCDrimLkX3uLGlwxcwwa4VK - 1 - __uznXRbIwZE3NuRABEFkoEa8Q))
		g[__FfxOx_haH8lrvP3ss7YFPZ06[__uznXRbIwZE3NuRABEFkoEa8Q]] = v
		left -= v
	return g
static func __g1fieNYIazuBRAy4BIxDTBLm(__dbNuL1Vev8c0DMhpiCvDAYdi: int, __b0UGLnmS6ZD4mlzoDtBBlPql: int) -> bool:
	return __dbNuL1Vev8c0DMhpiCvDAYdi == 0 or __dbNuL1Vev8c0DMhpiCvDAYdi == __b0UGLnmS6ZD4mlzoDtBBlPql
func __ZEf8MUQNZMeLjokl2rCxl51Z() -> int:
	return int(__qyvbOrjVYs2zGM2jUVQYSgGR.get("max_level", 120))
func __B86qYsoJTUWkDknPfQUrbbfH(amount: int) -> void :
	if not __ZRS6lZJh1TuB38TS82wWLE09.enabled():
		return
	__8gf1LRFmWIu4atdcX2YYGtf5(__Bsl33jE0VgUtGf0ZDYkuZAkg.__SqQACpn7NvvJhPhBxGiVO55D, 0, amount, 0)
	save()
func __JMsr0yCjBlwnkO_7FV9gE93o() -> Array[__CgOl36_UCxYZW5PzufCcS4dS]:
	return __cQ9sPbueMGXZt2aYRGhozxDp(__3pHTyYQlMesWCy5zSJELYO80)
var __FOzOkL_5wngFw83WISq0FbBm: = RandomNumberGenerator.new()
func __5keQ3Ns1NqlbEP7Qxzkm52AK(__sDPCHIN5kOAv7AQREtEowwcJ: Variant) -> int:
	var w: Array = __sDPCHIN5kOAv7AQREtEowwcJ if __sDPCHIN5kOAv7AQREtEowwcJ is Array else [1]
	var __UKTsIv885byMtFs4WiGNjpyY: int = 0
	for x: Variant in w:
		__UKTsIv885byMtFs4WiGNjpyY += maxi(int(x), 0)
	if __UKTsIv885byMtFs4WiGNjpyY <= 0:
		return 0
	var r: int = __FOzOkL_5wngFw83WISq0FbBm.randi_range(0, __UKTsIv885byMtFs4WiGNjpyY - 1)
	for __FglhPuVcPz3RGaftyMYUYey1: int in w.size():
		r -= maxi(int(w[__FglhPuVcPz3RGaftyMYUYey1]), 0)
		if r < 0:
			return __FglhPuVcPz3RGaftyMYUYey1
	return w.size() - 1
func __EnIkrxRIuwB5ebUIEdBi2u89(__V7ak1DWengcZ2w2ltuPpc9W2: __CgOl36_UCxYZW5PzufCcS4dS, __BVQ2BMXtrtmwuPL891DoDqln: int) -> String:
	if __V7ak1DWengcZ2w2ltuPpc9W2.__JMsr0yCjBlwnkO_7FV9gE93o() and __V7ak1DWengcZ2w2ltuPpc9W2.__ofKSCLcCg7jWtqacDa153ehk != __3pHTyYQlMesWCy5zSJELYO80:
		return "UI_CREW_ERR_OTHER_SHIP"
	if __ifUAqOmtFvNZXIqHYuzi470Y(__BVQ2BMXtrtmwuPL891DoDqln) != null and __ifUAqOmtFvNZXIqHYuzi470Y(__BVQ2BMXtrtmwuPL891DoDqln) != __V7ak1DWengcZ2w2ltuPpc9W2:
		return "UI_CREW_ERR_NO_SEAT"
	var __t18W8WNbjmf2C0LDi0MqfjW6: String = __IuDP9w3LX3PDa0VZR_faHzyc(__V7ak1DWengcZ2w2ltuPpc9W2, __BVQ2BMXtrtmwuPL891DoDqln)
	if __t18W8WNbjmf2C0LDi0MqfjW6 != "":
		return __t18W8WNbjmf2C0LDi0MqfjW6
	__V7ak1DWengcZ2w2ltuPpc9W2.__q26f3dCYzrR9TyO_pwwz7lre = __BVQ2BMXtrtmwuPL891DoDqln
	__V7ak1DWengcZ2w2ltuPpc9W2.__ofKSCLcCg7jWtqacDa153ehk = __3pHTyYQlMesWCy5zSJELYO80
	save()
	return ""


func __76YQlbOoFzFgpPn_qa5fce31(__6SK353oXdHPwAS9tWYG0QRd5: __CgOl36_UCxYZW5PzufCcS4dS) -> int:
	return __LlOvNfSW39vQFa_X5z9isu0g.__76YQlbOoFzFgpPn_qa5fce31(__6SK353oXdHPwAS9tWYG0QRd5.__zMZVCIoyJu5zkEI6YyKqPDoG)
func __nfaBZ_xIiHIPY3GkBUUjEEyF(__4rQZCPzeYmzfuQ4onT3KFQIY: __s8yZigV26lPAvEmbOWzMbnjE) -> __s8yZigV26lPAvEmbOWzMbnjE:
	var __lzIoqv0RvR015HeSEUbBfI9x: __s8yZigV26lPAvEmbOWzMbnjE = __4rQZCPzeYmzfuQ4onT3KFQIY.__12ty6aWt7_v7eYEbKtP71Dlf()
	__lzIoqv0RvR015HeSEUbBfI9x.__snrAZjpE4d_OgyrfimxyspWI = __OMmZ8ceL80Cz6iW2ABlJwosY(__4rQZCPzeYmzfuQ4onT3KFQIY.__WeB9Hi0OxaFBUuwm2WU2qKEH)
	__lzIoqv0RvR015HeSEUbBfI9x.___eFzo1uyZh_e9NPYOmnK6zN7 = __wENDX6Cu8Q_iHBD18A1i8VX0(__4rQZCPzeYmzfuQ4onT3KFQIY.__WeB9Hi0OxaFBUuwm2WU2qKEH)
	var __OPEKghDjYAUzLKEjaQq1iuV9: __2eoTFZc6WxKKaBxTkxeRtmOZ = __EhjJRLjwGbixjchwHoi91WQb(__4rQZCPzeYmzfuQ4onT3KFQIY.__WeB9Hi0OxaFBUuwm2WU2qKEH)
	__lzIoqv0RvR015HeSEUbBfI9x.__RuEf8sDpDtu0ArTJYzf6W0JG = 0
	for __wUq35pvGO1gYFe3GjlrRgnos: __CgOl36_UCxYZW5PzufCcS4dS in __cQ9sPbueMGXZt2aYRGhozxDp(__4rQZCPzeYmzfuQ4onT3KFQIY.__WeB9Hi0OxaFBUuwm2WU2qKEH):
		__lzIoqv0RvR015HeSEUbBfI9x.__RuEf8sDpDtu0ArTJYzf6W0JG += __wUq35pvGO1gYFe3GjlrRgnos.__Ln9avrueTbF2AkgyV87ZgBiF(__LVCMU4xMBMMHO5bxpAYeHYWt(__wUq35pvGO1gYFe3GjlrRgnos), __OPEKghDjYAUzLKEjaQq1iuV9 != null and __OPEKghDjYAUzLKEjaQq1iuV9.__JzUUCYNEpRcSKSi9X3gAiTQK())
	var __tn9dicoiCL20iWjKhjVk3Lpg: PackedInt32Array = __LlOvNfSW39vQFa_X5z9isu0g.__Q83ZAVFR9EzPCKEIptkCFVQ6(__cQ9sPbueMGXZt2aYRGhozxDp(__4rQZCPzeYmzfuQ4onT3KFQIY.__WeB9Hi0OxaFBUuwm2WU2qKEH), ___FfBuNdLnmIikyyvatNDz628, __OPEKghDjYAUzLKEjaQq1iuV9.__V9nPx6hwHXTjiZSit4R51eP0 if __OPEKghDjYAUzLKEjaQq1iuV9 != null else 0)
	__lzIoqv0RvR015HeSEUbBfI9x.__cjydLbm8C2baEiOLevaaqeZb = __tn9dicoiCL20iWjKhjVk3Lpg[0]
	__lzIoqv0RvR015HeSEUbBfI9x.__mGIZJhxr5PQZ0GE9oRbvkFoX = __tn9dicoiCL20iWjKhjVk3Lpg[1]
	__lzIoqv0RvR015HeSEUbBfI9x.__r9BsTmtwzeYPsGTYxXbgs5gZ = __LlOvNfSW39vQFa_X5z9isu0g.__H0DwMsc8mv6Cogy3GckKi2Fc(__cQ9sPbueMGXZt2aYRGhozxDp(__4rQZCPzeYmzfuQ4onT3KFQIY.__WeB9Hi0OxaFBUuwm2WU2qKEH), ___FfBuNdLnmIikyyvatNDz628, __OPEKghDjYAUzLKEjaQq1iuV9.__V9nPx6hwHXTjiZSit4R51eP0 if __OPEKghDjYAUzLKEjaQq1iuV9 != null else 0, __NZtxVGdhytJuFkBWqJKzc9o4.__Jy2hcMM9emCF3iBBkLMyeUr7("Frame", __4rQZCPzeYmzfuQ4onT3KFQIY.__WeB9Hi0OxaFBUuwm2WU2qKEH, 4) & 992)
	__lzIoqv0RvR015HeSEUbBfI9x.__gyktaSCba5fvGkS2KC4ukPix = __rq_chOHOjEfHcgxVh53u7ecD(__4rQZCPzeYmzfuQ4onT3KFQIY)
	__lzIoqv0RvR015HeSEUbBfI9x.__d6qgIYt4mBpXZyL2iqdT_09D = __2dlO_ydjjaq3W473KRjPZyHh(__4rQZCPzeYmzfuQ4onT3KFQIY)
	return __lzIoqv0RvR015HeSEUbBfI9x
func __g7F3EfgE1iugY6qyUxtrpa1X(__XrrS4_ehqLtC2CcPpWN_XylD: __s8yZigV26lPAvEmbOWzMbnjE) -> void :
	if __XrrS4_ehqLtC2CcPpWN_XylD.__WeB9Hi0OxaFBUuwm2WU2qKEH != __3pHTyYQlMesWCy5zSJELYO80:
		__3pHTyYQlMesWCy5zSJELYO80 = __XrrS4_ehqLtC2CcPpWN_XylD.__WeB9Hi0OxaFBUuwm2WU2qKEH
		__V4HMBvKJ0ZkFXfFel313zhG5 = null
	__n49srIn8KerL_HEIiCdNmOxf = __XrrS4_ehqLtC2CcPpWN_XylD.__dOsDavODOasdfPxqce2DEBC3.duplicate()
	__4SUknJBgHUaV9w15IdBVFhd5 = __XrrS4_ehqLtC2CcPpWN_XylD.__t1UipS__8EvFgumrL932qeyd.duplicate()
	__9tVQSDzDk22f49xhH1zXYlPe = __XrrS4_ehqLtC2CcPpWN_XylD.__mqMCtdrkbQOwk3Mp57NCIW7w.duplicate()
	__6jT8KoopEZhRFiDaeOpZK1bT = __XrrS4_ehqLtC2CcPpWN_XylD.__t3YSlOfvQe4R_b9rHMAz7hq0.duplicate()
	__da10PLrO3b92oiJTS9g3Vfve = __XrrS4_ehqLtC2CcPpWN_XylD.__ZCQBCv36ysTHU0iBaYX6GvwS.duplicate()
	__WkXP3BSGyqCbt6VAuFzmJWsZ = __XrrS4_ehqLtC2CcPpWN_XylD.__nQdkAoXs7wyREcSJQ0Beyel6.duplicate()
	__a_utLkfvPV74XmpUxv0T2jqV = __XrrS4_ehqLtC2CcPpWN_XylD.__g7JC3EJmfsOWnIyqLGGB93eB.duplicate()
	__DbuthnnVI6mcaRxkjF633v6v = __XrrS4_ehqLtC2CcPpWN_XylD.__vwSAcybbCInOpnt2FbN4qz7L
	__RqhcyeP1iDTNK0TaIVLeMfUM = __XrrS4_ehqLtC2CcPpWN_XylD.__cQ8JInnnrEoGxd_1jglej7pR.duplicate()
	__cYNPT_ygRY3o9ufvyN3FSzFH = __XrrS4_ehqLtC2CcPpWN_XylD.__NELIelBEafKRGQultNqYAbM7
	__xUdVQnSQPkxPs4_Ls3mOD1xu()
	save()
var __dFm6DOUISO0GARjmCPdhCxZ0: __k8pdL_GB8yADpq0vqeDWpz5v
var __cYNPT_ygRY3o9ufvyN3FSzFH: int = __s8yZigV26lPAvEmbOWzMbnjE.__gzDclDFgoL3uDH5vfZQtcFjr
signal changed


func meti_recruit_budget(member: __CgOl36_UCxYZW5PzufCcS4dS) -> int:
	if member != null and member.has_meta("meti_custom_budget"):
		return int(member.get_meta("meti_custom_budget"))
	if member == null or not member.has_meta("meti_original_growth") or not member.has_meta("meti_base_growth"):
		return 0
	var original: PackedInt32Array = member.get_meta("meti_original_growth")
	var base: PackedInt32Array = member.get_meta("meti_base_growth")
	var total: int = 0
	for i: int in 11:
		total += original[i] - base[i]
	return total

func meti_recruit_validate(member: __CgOl36_UCxYZW5PzufCcS4dS, values: PackedInt32Array) -> String:
	if member == null or member.id != 0 or member.__zMZVCIoyJu5zkEI6YyKqPDoG != 1 or member.__mpLpovabZnp87HNkreW4pWJY != 0 or member.__q26f3dCYzrR9TyO_pwwz7lre != -1 or __qpoG34O1fgw9L8TB5rO8XCfq.has(member):
		return "只能調整尚未雇用的新水兵。"
	if values.size() != 11 or not member.has_meta("meti_base_growth") or not member.has_meta("meti_original_growth"):
		return "這名候選人的成長資料無效，請重新招募。"
	if member.has_meta("meti_custom_budget"):
		return meti_custom_validate(member, values)
	var base: PackedInt32Array = member.get_meta("meti_base_growth")
	var total: int = 0
	var picks: int = 0
	for i: int in 11:
		var bonus: int = values[i] - base[i]
		if bonus < 0 or bonus > 6:
			return "成長分配超出抽選額度。"
		total += bonus
		if bonus > 0: picks += 1
	if total != meti_recruit_budget(member) or total < 4 or total > 6 or picks != 2:
		return "須保留抽選總額，並分配至兩項不同能力。"
	return ""

func meti_recruit_apply(member: __CgOl36_UCxYZW5PzufCcS4dS, values: PackedInt32Array) -> String:
	var err: String = meti_recruit_validate(member, values)
	if err != "": return err
	member.__wC11jxHS1J5bzkNesfKgNncZ = values.duplicate()
	return ""

func meti_recruit_fee(member: __CgOl36_UCxYZW5PzufCcS4dS) -> int:
	if member == null or member.id != 0 or not member.has_meta("meti_original_growth"):
		return 0
	if member.has_meta("meti_custom_budget"):
		return maxi(0, meti_custom_price(meti_recruit_budget(member)) - int(__LVCMU4xMBMMHO5bxpAYeHYWt(member).get("cost", 0)))
	var original: PackedInt32Array = member.get_meta("meti_original_growth")
	if member.__wC11jxHS1J5bzkNesfKgNncZ == original:
		return 0
	return maxi(0, int((__qyvbOrjVYs2zGM2jUVQYSgGR.get("recruit", {}) as Dictionary).get("meti_growth_selection_cost", 500)))


func meti_custom_rules() -> Dictionary:
	return (__qyvbOrjVYs2zGM2jUVQYSgGR.get("recruit", {}) as Dictionary).get("meti_custom_recruit", {})

func meti_custom_price(budget: int) -> int:
	if budget not in [15, 20, 25]: return -1
	return int((meti_custom_rules().get("prices", {}) as Dictionary).get(str(budget), -1))

func meti_custom_new(budget: int = 15) -> __CgOl36_UCxYZW5PzufCcS4dS:
	if meti_custom_price(budget) < 2000: return null
	var member = __CgOl36_UCxYZW5PzufCcS4dS.new()
	member.__mpLpovabZnp87HNkreW4pWJY = 0
	member.__zMZVCIoyJu5zkEI6YyKqPDoG = 1
	var base: PackedInt32Array = __geUHcewBqVa9L7LKcQ8q2MXR(__LVCMU4xMBMMHO5bxpAYeHYWt(member))
	member.__wC11jxHS1J5bzkNesfKgNncZ = base.duplicate()
	var abilities = PackedInt32Array()
	abilities.resize(11)
	abilities.fill(int(meti_custom_rules().get("initial_ability", 50)))
	member.__4ObdBYhtKkHScUayTPgiYzH_ = abilities
	member.__pY661vwzoRY0D6Y5ORWYVaB_ = PackedInt32Array([int((__qyvbOrjVYs2zGM2jUVQYSgGR.get("men", {}) as Dictionary).get("recruit", 55)), 0, 0])
	member.set_meta("meti_base_growth", base.duplicate())
	member.set_meta("meti_original_growth", base.duplicate())
	member.set_meta("meti_custom_budget", budget)
	return member

func meti_custom_validate(member: __CgOl36_UCxYZW5PzufCcS4dS, values: PackedInt32Array) -> String:
	var budget: int = meti_recruit_budget(member)
	if meti_custom_price(budget) < 2000:
		return "自訂招募方案無效。"
	var initial: int = int(meti_custom_rules().get("initial_ability", 50))
	for ability: int in member.__4ObdBYhtKkHScUayTPgiYzH_:
		if ability != initial: return "自訂招募的初始能力必須各為%d。" % initial
	var base: PackedInt32Array = member.get_meta("meti_base_growth")
	var cap: int = int(meti_custom_rules().get("per_ability_cap", 5))
	var total: int = 0
	for i: int in 11:
		var bonus: int = values[i] - base[i]
		if bonus < 0 or bonus > cap:
			return "每項自訂成長須介於0至%d點。" % cap
		total += bonus
	if total != budget:
		return "須分配完%d點成長，才能套用或雇用。" % budget
	return ""


func meti_birth_growth(member: __CgOl36_UCxYZW5PzufCcS4dS) -> PackedInt32Array:

	var data: PackedByteArray = __jx52K0fsGItWa4CN83U1DY2k.__V8DSfFdAnWyCSpwqWM11mzVq(member.id)
	var reader = __2qo9vfpnxQybzUL4GHGzcXBB.new(data)
	if reader.__vlQDTtuyQZ3KmvKohFfizJCm() != __Bsl33jE0VgUtGf0ZDYkuZAkg.__oxEN0ma_5PMnWmKeSO6Aarw4:
		return PackedInt32Array()
	reader.__pGLr1ud1V6XsMMJoSyeTRFjY()
	var born_row: int = reader.__Jy2hcMM9emCF3iBBkLMyeUr7()
	reader.__vlQDTtuyQZ3KmvKohFfizJCm()
	reader.__pGLr1ud1V6XsMMJoSyeTRFjY()
	for index: int in 11:
		reader.__Jy2hcMM9emCF3iBBkLMyeUr7()
	var growth = PackedInt32Array()
	for index: int in 11:
		growth.append(reader.__R8EBxRBQac1wukJKPScUj3_n())
	var born_class: Dictionary = ___FfBuNdLnmIikyyvatNDz628.__eKMOY9vZxsK1HnP0cqwVRqgs(born_row)
	if not reader.__g0MBgfYiqCb6SBmlLlXYetmr or born_class.is_empty():
		return PackedInt32Array()
	var profession: PackedInt32Array = __geUHcewBqVa9L7LKcQ8q2MXR(born_class)
	for index: int in 11:
		growth[index] -= profession[index]
	return growth


func meti_has_retrained(member: __CgOl36_UCxYZW5PzufCcS4dS) -> bool:
	if member.has_meta("meti_retrained"):
		return bool(member.get_meta("meti_retrained"))
	var events: Variant = __Bsl33jE0VgUtGf0ZDYkuZAkg.__MOlINPJ4rQitdShzA4Rmk2jR(__jx52K0fsGItWa4CN83U1DY2k.__V8DSfFdAnWyCSpwqWM11mzVq(member.id))
	var previous: Dictionary = {}
	var found: bool = false
	if events is Array:
		for event: Dictionary in events:
			if not event.has("class_row"):
				continue
			var next: Dictionary = ___FfBuNdLnmIikyyvatNDz628.__eKMOY9vZxsK1HnP0cqwVRqgs(int(event["class_row"]))
			if not previous.is_empty() and int(event["kind"]) == __Bsl33jE0VgUtGf0ZDYkuZAkg.__CVGI5VRieG3AtLLmAeCFQ3Yb and int(previous.get("row", -1)) == int(next.get("row", -2)):
				found = true
			previous = next
	member.set_meta("meti_retrained", found)
	return found


func meti_nation_fee() -> int:
	return __cy8MlQEbWMnDn0W8brML_OIf()


func meti_nation_error(member: __CgOl36_UCxYZW5PzufCcS4dS, nation: int, captain: bool) -> String:
	if member == null or not __qpoG34O1fgw9L8TB5rO8XCfq.has(member):
		return "找不到這名水兵。"
	if member.__JMsr0yCjBlwnkO_7FV9gE93o():
		return "請先將水兵從船上卸下，再進行轉籍或重修。"
	if nation < 1 or nation > 7:
		return "請選擇美國、英國、日本、德國、法國、蘇聯或義大利。"
	var current: Dictionary = __LVCMU4xMBMMHO5bxpAYeHYWt(member)
	if captain and not __o4BlGoLwjfAD3TYKD8Kt7FzU.__jImD0sut02cad96nddoNN3be(current):
		return "此操作只適用於船長。"
	if not captain and __o4BlGoLwjfAD3TYKD8Kt7FzU.__jImD0sut02cad96nddoNN3be(current):
		return "船長請使用船艦科技樹的重置／轉籍。"
	var target: Dictionary = ___FfBuNdLnmIikyyvatNDz628.__plTZcPXT3j_x0cUIlOEd5bfe(64 + nation if captain else nation)
	if target.is_empty() or not __o4BlGoLwjfAD3TYKD8Kt7FzU.__FLBcWdmSyKhlCkG_2_FUG10K(target):
		return "找不到目標國家的基礎兵種。"
	if member.__zMZVCIoyJu5zkEI6YyKqPDoG < int(target["req_level"]):
		return "轉籍需要水兵等級至少 %d。" % int(target["req_level"])
	if points < meti_nation_fee():
		return "海點不足，需要 %d 海點。" % meti_nation_fee()
	if int(current["row"]) == int(target["row"]):
		if not captain or (member.__hJTRC1qsUs9T0VQkseYzTT2f == __1OkQgYNA0NkvkBligBeQgZWC.__R2X7seLnTY5XT91Rew6aCtxr and member.__1U0d7dXiK8nppclbz5xhDxaz.is_empty()):
			return "目前已是這個國家的起始狀態，無須重置。"
	if not captain and meti_birth_growth(member).size() != 11:
		return "原始招募紀錄無法讀取，已停止操作以保留養成資料。"
	return ""


func meti_change_nation(member: __CgOl36_UCxYZW5PzufCcS4dS, nation: int, captain: bool) -> String:
	var error: String = meti_nation_error(member, nation, captain)
	if error != "":
		return error
	var target: Dictionary = ___FfBuNdLnmIikyyvatNDz628.__plTZcPXT3j_x0cUIlOEd5bfe(64 + nation if captain else nation)
	var growth: PackedInt32Array = member.__wC11jxHS1J5bzkNesfKgNncZ
	var delta = PackedInt32Array()
	delta.resize(11)
	if not captain:
		var initial: PackedInt32Array = meti_birth_growth(member)
		for index: int in 11:
			var next: int = initial[index] + int(target["growth"][index])
			delta[index] = next - growth[index]
			growth[index] = next
	__8gf1LRFmWIu4atdcX2YYGtf5(__Bsl33jE0VgUtGf0ZDYkuZAkg.__5PtJNefDe19NzOk_RhsGCA9a, 0, - meti_nation_fee(), member.id)
	if not captain:

		var zero = PackedInt32Array()
		zero.resize(11)
		__jx52K0fsGItWa4CN83U1DY2k.__uXq7lesweQwPVFt806V2gCAg(member.id, __Bsl33jE0VgUtGf0ZDYkuZAkg.__oiM_iYX5Oqbb4gAx9EC1NYQC(member.__mpLpovabZnp87HNkreW4pWJY, zero))
	member.__mpLpovabZnp87HNkreW4pWJY = int(target["row"])
	member.__wC11jxHS1J5bzkNesfKgNncZ = growth
	member.__hJTRC1qsUs9T0VQkseYzTT2f = __1OkQgYNA0NkvkBligBeQgZWC.__R2X7seLnTY5XT91Rew6aCtxr
	member.__1U0d7dXiK8nppclbz5xhDxaz = PackedInt32Array()
	__jx52K0fsGItWa4CN83U1DY2k.__uXq7lesweQwPVFt806V2gCAg(member.id, __Bsl33jE0VgUtGf0ZDYkuZAkg.__oiM_iYX5Oqbb4gAx9EC1NYQC(int(target["row"]), delta))
	__jx52K0fsGItWa4CN83U1DY2k.__uXq7lesweQwPVFt806V2gCAg(member.id, __Bsl33jE0VgUtGf0ZDYkuZAkg.__Jtifg3uTCyMJvjtHgVtGl8WD())
	member.set_meta("meti_retrained", not captain or meti_has_retrained(member))
	save()
	return ""
