extends Node
func __A6XI74bFN3243pFbSLAzzTVt(___p3lbTxKa428agV0Mz9RNaef: int) -> String:
	var __bcMiNDPSJ2ZLow7KMiEiqRAI: Dictionary = __PtNURh2PaYHMgsPlkLtni90Y().__ofKSCLcCg7jWtqacDa153ehk(___p3lbTxKa428agV0Mz9RNaef)
	if __bcMiNDPSJ2ZLow7KMiEiqRAI.is_empty():
		return "?"
	var name: String = __YWyGam_15HuUyuIa4REmc8J4(___p3lbTxKa428agV0Mz9RNaef)
	return __HVxw_6qDWS_HQ5iaO3EUrNrz(int(__bcMiNDPSJ2ZLow7KMiEiqRAI["kind"]), name if name != "" else __AqRLmDaYMC2aA5Jk6DLdJAGf(str(__bcMiNDPSJ2ZLow7KMiEiqRAI["label"])))
const __jB3BoSr0wjbmaulI2AtY9qfK: = {"花旗": "美国", "雾都": "英国", "樱花": "日本", "铁血": "德国", 
	"凯旋": "法国", "乌拉": "苏联", "撒丁": "意大利", "炎黄": "中国"}
func __4LYv61CodBQNQe84HI7yb2vE(__TuRUqIdftOrZxXvzY5pNi7S_: __s8yZigV26lPAvEmbOWzMbnjE) -> __s8yZigV26lPAvEmbOWzMbnjE:
	return __M0ImV248NGNrBFXy9NCs5jwX().__nfaBZ_xIiHIPY3GkBUUjEEyF(__TuRUqIdftOrZxXvzY5pNi7S_)
var __W489J4Gtntjtp_hMofn_wpkk: __bO69ohbc7qstOVzkOQ46HazE
func __MmzTu5Qu8ljNTyzkdxs4GEtt(__1BqThsO8JO6ki2yuS3Bo77OQ: Dictionary = {}) -> void :
	UI.clear()
	__iQ6zA7j8vaK25mGjzbSHhX3K = {"lobby": true, "room": __1BqThsO8JO6ki2yuS3Bo77OQ}
	get_tree().change_scene_to_file.call_deferred(__adx3IzFL60MY3L9tFBMzLvz7)
func __GtkTK7qTutmHKfVnGFduJfcl() -> bool:
	return Session.client != null and Session.client.__EQuCPPWLxyLUNOZAfxsuqiRH() and Session.client.__bEaVqnUpkbc9pnzD2IA0HDfW != null
func __HVxw_6qDWS_HQ5iaO3EUrNrz(__L703lphkZtesb_BVSds30KY2: int, name: String) -> String:
	return "%s. %s" % [tr("UI_SHIPTYPE_%d" % __L703lphkZtesb_BVSds30KY2), name]
func __IqPMdBxwlJl4nvNb5_MAfI_h() -> __s8yZigV26lPAvEmbOWzMbnjE:
	return __U7UMfwBewiXSLEeaDnywaCO7.__V0erSRNWoPFGOr7bG6vGIpsK()
var __Z1L5javwTdjxkGCkHOIHLDVI: __Se4EsxPBCHX48h1ZS5MexaMl
var __iQ6zA7j8vaK25mGjzbSHhX3K: Dictionary = {}
static func __iJzy1hAJBRqw29e5Qa_DWSi0(label: String) -> int:
	var __C371uP5DTVJ6AKyVd5fgU0mj: RegExMatch = RegEx.create_from_string("-\\d+-(\\d+)级$").search(label)
	return int(__C371uP5DTVJ6AKyVd5fgU0mj.get_string(1)) if __C371uP5DTVJ6AKyVd5fgU0mj != null else 0
var __NZtxVGdhytJuFkBWqJKzc9o4: __bzxMmNAcE_RKMny5gklgDglw
func __C1KFt9tOFvmtDu5lhMey47Lc(__rZTZ3Jyn2s8plZ5GesTOoOa3: Dictionary) -> void :
	get_tree().change_scene_to_file.call_deferred(__J4y56SXvPKCbvS6w_9iaUZq9)
	UI.replace("result", __rZTZ3Jyn2s8plZ5GesTOoOa3)
var __5HeZ085eBrXRSmVsBtsjICws: Dictionary = {}
func __jDDjlLaS8SZXYc9osASNUrjv(__lugwqL_2XKQRZJrmjs1dHqHQ: int) -> String:
	var __AdOTp0NRMaf0hzbIPiFEQJ2F: Dictionary = __PtNURh2PaYHMgsPlkLtni90Y().__ofKSCLcCg7jWtqacDa153ehk(__lugwqL_2XKQRZJrmjs1dHqHQ)
	if __AdOTp0NRMaf0hzbIPiFEQJ2F.is_empty():
		return "?"
	var name: String = __YWyGam_15HuUyuIa4REmc8J4(__lugwqL_2XKQRZJrmjs1dHqHQ)
	if name == "":
		name = __AqRLmDaYMC2aA5Jk6DLdJAGf(str(__AdOTp0NRMaf0hzbIPiFEQJ2F["base"]))
	return "%s %s" % [tr("UI_SHIPTYPE_%d" % int(__AdOTp0NRMaf0hzbIPiFEQJ2F["kind"])), name]
func __PtNURh2PaYHMgsPlkLtni90Y() -> __Se4EsxPBCHX48h1ZS5MexaMl:
	if __Z1L5javwTdjxkGCkHOIHLDVI == null:
		__Z1L5javwTdjxkGCkHOIHLDVI = __Se4EsxPBCHX48h1ZS5MexaMl.__x4dRhV0emeOXyfnjujX6iOAP(__HK31GsUXVl4XqVVZwVbhBKW7 + "/catalog.json")
	return __Z1L5javwTdjxkGCkHOIHLDVI
func __qCPTUUg6F8JnpOzFBXJFg8nU() -> Dictionary:
	var __88EDgHhuLEOfOSW3tcD6BnrR: Dictionary = __iQ6zA7j8vaK25mGjzbSHhX3K
	__iQ6zA7j8vaK25mGjzbSHhX3K = {}
	return __88EDgHhuLEOfOSW3tcD6BnrR
func __72kAp8sMQh2gIPcLl7onOgPE(__GJEwQYhCvpp6urJtYbLcrvCa: int) -> int:
	if __GJEwQYhCvpp6urJtYbLcrvCa < 0 or __GJEwQYhCvpp6urJtYbLcrvCa >= ___qFCN2viGM2bPW1uGV9qys9h().__IO68NHb5_E2BotbL8ReE7rAA("Frame"):
		return 0
	var __V80FQ2ffu1LJlyGvKnhHKG9K: int = ___qFCN2viGM2bPW1uGV9qys9h().__Jy2hcMM9emCF3iBBkLMyeUr7("Frame", __GJEwQYhCvpp6urJtYbLcrvCa, 862) / 1000
	return __V80FQ2ffu1LJlyGvKnhHKG9K if __V80FQ2ffu1LJlyGvKnhHKG9K <= 8 else 0
func __M0ImV248NGNrBFXy9NCs5jwX() -> __MxRtF5kMQ2PhDOJRxJ1ej8ie:
	if __CdSJVoXvVKAAL3yOnGfpJf5T == null:
		__CdSJVoXvVKAAL3yOnGfpJf5T = __MxRtF5kMQ2PhDOJRxJ1ej8ie.create(___qFCN2viGM2bPW1uGV9qys9h(), __PtNURh2PaYHMgsPlkLtni90Y(), __HqUdoga9EZH8HJx1sDVi59md())
		var __CHQOvohz0rRwmgzOodaVicTm: __s8yZigV26lPAvEmbOWzMbnjE = __U7UMfwBewiXSLEeaDnywaCO7.__V0erSRNWoPFGOr7bG6vGIpsK()
		if __CdSJVoXvVKAAL3yOnGfpJf5T.__3pHTyYQlMesWCy5zSJELYO80 != __CHQOvohz0rRwmgzOodaVicTm.__WeB9Hi0OxaFBUuwm2WU2qKEH or __CdSJVoXvVKAAL3yOnGfpJf5T.__n49srIn8KerL_HEIiCdNmOxf != __CHQOvohz0rRwmgzOodaVicTm.__dOsDavODOasdfPxqce2DEBC3 or __CdSJVoXvVKAAL3yOnGfpJf5T.__4SUknJBgHUaV9w15IdBVFhd5 != __CHQOvohz0rRwmgzOodaVicTm.__t1UipS__8EvFgumrL932qeyd\
		or __CdSJVoXvVKAAL3yOnGfpJf5T.__9tVQSDzDk22f49xhH1zXYlPe != __CHQOvohz0rRwmgzOodaVicTm.__mqMCtdrkbQOwk3Mp57NCIW7w or __CdSJVoXvVKAAL3yOnGfpJf5T.__6jT8KoopEZhRFiDaeOpZK1bT != __CHQOvohz0rRwmgzOodaVicTm.__t3YSlOfvQe4R_b9rHMAz7hq0\
		or __CdSJVoXvVKAAL3yOnGfpJf5T.__da10PLrO3b92oiJTS9g3Vfve != __CHQOvohz0rRwmgzOodaVicTm.__ZCQBCv36ysTHU0iBaYX6GvwS or __CdSJVoXvVKAAL3yOnGfpJf5T.__DbuthnnVI6mcaRxkjF633v6v != __CHQOvohz0rRwmgzOodaVicTm.__vwSAcybbCInOpnt2FbN4qz7L or __CdSJVoXvVKAAL3yOnGfpJf5T.__WkXP3BSGyqCbt6VAuFzmJWsZ != __CHQOvohz0rRwmgzOodaVicTm.__nQdkAoXs7wyREcSJQ0Beyel6 or __CdSJVoXvVKAAL3yOnGfpJf5T.__cYNPT_ygRY3o9ufvyN3FSzFH != __CHQOvohz0rRwmgzOodaVicTm.__NELIelBEafKRGQultNqYAbM7:
			__CdSJVoXvVKAAL3yOnGfpJf5T.__g7F3EfgE1iugY6qyUxtrpa1X(__CHQOvohz0rRwmgzOodaVicTm)
		if __CdSJVoXvVKAAL3yOnGfpJf5T.__FpK20dPAMc4oZfgOO0plePC2:
			__CdSJVoXvVKAAL3yOnGfpJf5T.___NcBFFeS8VOtaADppynFhzPW()
	return __CdSJVoXvVKAAL3yOnGfpJf5T
const __C70SHOw_Dud5j_o4PUukTYjz: = "user://last_offline.json"
const __J4y56SXvPKCbvS6w_9iaUZq9: = "res://client/blank.tscn"
func ___qFCN2viGM2bPW1uGV9qys9h() -> __bzxMmNAcE_RKMny5gklgDglw:
	if __NZtxVGdhytJuFkBWqJKzc9o4 == null:
		if not __TXCdoY85HWzo9E7Qcf9l8raZ.__uyQM9rjcZyla4JxuFML8GSkU():
			__TXCdoY85HWzo9E7Qcf9l8raZ.__C0f2MWgnGmAVaEjURoBXIqs2(__HK31GsUXVl4XqVVZwVbhBKW7)
		__NZtxVGdhytJuFkBWqJKzc9o4 = __bzxMmNAcE_RKMny5gklgDglw.__TG9dwC6BEv9A1GTE4YTMr8Ng(__HK31GsUXVl4XqVVZwVbhBKW7)
	return __NZtxVGdhytJuFkBWqJKzc9o4
func __0c3JysxUtpK91MthAf7KgrRJ(__MxUoCIOZQXYB0MyYQsfcGywD: __s8yZigV26lPAvEmbOWzMbnjE) -> void :
	__U7UMfwBewiXSLEeaDnywaCO7.__VvG2q5CwvCNDjBta5Gspay17(__MxUoCIOZQXYB0MyYQsfcGywD)
	__M0ImV248NGNrBFXy9NCs5jwX().__g7F3EfgE1iugY6qyUxtrpa1X(__MxUoCIOZQXYB0MyYQsfcGywD)
	Session.__R7ELz7zJC7hosKgl7dZAW2Qf = null
	if Session.client != null:
		Session.client.__8GAy89ezh8eNwLsg6ZUUA_QV = false
func __osvnldQaTJn2CnkRb0X8V_cT(id: String, __ggySM8Dhb1uUfFI0qhHysphN: Dictionary = {}) -> void :
	get_tree().change_scene_to_file.call_deferred(__J4y56SXvPKCbvS6w_9iaUZq9)
	UI.replace(id, __ggySM8Dhb1uUfFI0qhHysphN)
func __XA31hlcqDbRgIKg3l91mYJVw() -> void :
	Session.__6boYmTBi229EPYhIG1rS9EZs()
	Chat.clear()
	get_tree().change_scene_to_file.call_deferred(__J4y56SXvPKCbvS6w_9iaUZq9)
	UI.replace("connect")
func __qePsfDFFBrWRngzVSNQGFjJX(__P0YvSniggiu5Gb6Vk6gkKFEz: PackedStringArray) -> void :
	___qFCN2viGM2bPW1uGV9qys9h()
	Session.__eXg3hMS7akhCfGmWn242Awpx()
	var __Sh7huHjPu37nUvt4pke23WkU: Dictionary = {}
	var __hRDNs45lkcLPuA2WgQrU_vBI: int = __P0YvSniggiu5Gb6Vk6gkKFEz.find("--offline")
	if __hRDNs45lkcLPuA2WgQrU_vBI >= 0:
		var name: String = __P0YvSniggiu5Gb6Vk6gkKFEz[__hRDNs45lkcLPuA2WgQrU_vBI + 1] if __hRDNs45lkcLPuA2WgQrU_vBI + 1 < __P0YvSniggiu5Gb6Vk6gkKFEz.size() and not __P0YvSniggiu5Gb6Vk6gkKFEz[__hRDNs45lkcLPuA2WgQrU_vBI + 1].begins_with("--") else "duel"
		__Sh7huHjPu37nUvt4pke23WkU["scenario"] = __c4QtsqvfMNtDaAvZKm8zQkQA.get(name, __zKZrf1ciyEFELFgvd_rF5hzx)
	__hRDNs45lkcLPuA2WgQrU_vBI = __P0YvSniggiu5Gb6Vk6gkKFEz.find("--replay")
	if __hRDNs45lkcLPuA2WgQrU_vBI >= 0 and __hRDNs45lkcLPuA2WgQrU_vBI + 1 < __P0YvSniggiu5Gb6Vk6gkKFEz.size():
		__Sh7huHjPu37nUvt4pke23WkU["scenario"] = __P0YvSniggiu5Gb6Vk6gkKFEz[__hRDNs45lkcLPuA2WgQrU_vBI + 1]
		__Sh7huHjPu37nUvt4pke23WkU["replay"] = true
	__hRDNs45lkcLPuA2WgQrU_vBI = __P0YvSniggiu5Gb6Vk6gkKFEz.find("--shot")
	if __hRDNs45lkcLPuA2WgQrU_vBI >= 0 and __hRDNs45lkcLPuA2WgQrU_vBI + 1 < __P0YvSniggiu5Gb6Vk6gkKFEz.size():
		__Sh7huHjPu37nUvt4pke23WkU["shot"] = int(__P0YvSniggiu5Gb6Vk6gkKFEz[__hRDNs45lkcLPuA2WgQrU_vBI + 1])
	__hRDNs45lkcLPuA2WgQrU_vBI = __P0YvSniggiu5Gb6Vk6gkKFEz.find("--out")
	if __hRDNs45lkcLPuA2WgQrU_vBI >= 0 and __hRDNs45lkcLPuA2WgQrU_vBI + 1 < __P0YvSniggiu5Gb6Vk6gkKFEz.size():
		__Sh7huHjPu37nUvt4pke23WkU["out"] = __P0YvSniggiu5Gb6Vk6gkKFEz[__hRDNs45lkcLPuA2WgQrU_vBI + 1]
	if __P0YvSniggiu5Gb6Vk6gkKFEz.has("--shot-cam"):
		__Sh7huHjPu37nUvt4pke23WkU["shot_cam"] = __yW8LLge425pcZIzRPuh5N2bX.value(__P0YvSniggiu5Gb6Vk6gkKFEz, "--shot-cam", "")
	if __P0YvSniggiu5Gb6Vk6gkKFEz.has("--ship") and __Sh7huHjPu37nUvt4pke23WkU.has("scenario") and not __Sh7huHjPu37nUvt4pke23WkU.has("replay"):
		var __mS3haN0R1FmNGGfIqABQQzpl: int = int(__yW8LLge425pcZIzRPuh5N2bX.value(__P0YvSniggiu5Gb6Vk6gkKFEz, "--ship", "-1"))
		if __PtNURh2PaYHMgsPlkLtni90Y().__S427rIy8YAPI_7NTPBneiPZH(__mS3haN0R1FmNGGfIqABQQzpl):
			__Sh7huHjPu37nUvt4pke23WkU["player_ship"] = __PtNURh2PaYHMgsPlkLtni90Y().__vTRMq3igRP2hTt2npyhiJ5UU(__mS3haN0R1FmNGGfIqABQQzpl)
	if __P0YvSniggiu5Gb6Vk6gkKFEz.has("--autopilot") and __Sh7huHjPu37nUvt4pke23WkU.has("scenario"):
		__Sh7huHjPu37nUvt4pke23WkU["autopilot"] = true
	if __Sh7huHjPu37nUvt4pke23WkU.has("scenario"):
		__Tkvq4ILU1jnZ1bZKQjgCs2ff.__45ShgJBLXECGhibLP5sx3N3c()
		__YSjTfQqs5EaM1aKxXA9xKhjP(__Sh7huHjPu37nUvt4pke23WkU)
		return
	var __o6uEWu10EBEvlS2F9qEMLEjG: Dictionary = {"auto_ready": __P0YvSniggiu5Gb6Vk6gkKFEz.has("--auto-ready"), "autopilot": __P0YvSniggiu5Gb6Vk6gkKFEz.has("--autopilot"), 
		"auto_start": int(__yW8LLge425pcZIzRPuh5N2bX.value(__P0YvSniggiu5Gb6Vk6gkKFEz, "--auto-start", "0")), "rounds": int(__yW8LLge425pcZIzRPuh5N2bX.value(__P0YvSniggiu5Gb6Vk6gkKFEz, "--rounds", "1")), 
		"shot": __Sh7huHjPu37nUvt4pke23WkU.get("shot", 0), "out": __Sh7huHjPu37nUvt4pke23WkU.get("out", "user://shot.png"), 
		"shot_stall": __yW8LLge425pcZIzRPuh5N2bX.value(__P0YvSniggiu5Gb6Vk6gkKFEz, "--shot-stall", ""), "auto_back": __P0YvSniggiu5Gb6Vk6gkKFEz.has("--auto-ready"), 
		"tour": __P0YvSniggiu5Gb6Vk6gkKFEz.has("--tour"), "ticks_limit": int(__yW8LLge425pcZIzRPuh5N2bX.value(__P0YvSniggiu5Gb6Vk6gkKFEz, "--ticks", "0"))}
	if __P0YvSniggiu5Gb6Vk6gkKFEz.has("--countdown"):
		__o6uEWu10EBEvlS2F9qEMLEjG["countdown"] = int(__yW8LLge425pcZIzRPuh5N2bX.value(__P0YvSniggiu5Gb6Vk6gkKFEz, "--countdown", "20"))
	if not __ZRS6lZJh1TuB38TS82wWLE09.enabled():
		for __fz2SBuncjhDme0o6pP7W1wAP: String in ["autopilot", "auto_ready", "auto_back", "ticks_limit", "countdown"]:
			__o6uEWu10EBEvlS2F9qEMLEjG.erase(__fz2SBuncjhDme0o6pP7W1wAP)
		__o6uEWu10EBEvlS2F9qEMLEjG["auto_start"] = 0
		__o6uEWu10EBEvlS2F9qEMLEjG["rounds"] = 1
	if __P0YvSniggiu5Gb6Vk6gkKFEz.has("--stay"):
		__o6uEWu10EBEvlS2F9qEMLEjG["stay"] = true
	if __P0YvSniggiu5Gb6Vk6gkKFEz.has("--pick-slot"):
		__o6uEWu10EBEvlS2F9qEMLEjG["pick_slot"] = int(__yW8LLge425pcZIzRPuh5N2bX.value(__P0YvSniggiu5Gb6Vk6gkKFEz, "--pick-slot", "0"))
	if __P0YvSniggiu5Gb6Vk6gkKFEz.has("--hover-key"):
		__o6uEWu10EBEvlS2F9qEMLEjG["hover_key"] = true
	if __P0YvSniggiu5Gb6Vk6gkKFEz.has("--open-create"):
		__o6uEWu10EBEvlS2F9qEMLEjG["open_create"] = true
	if __P0YvSniggiu5Gb6Vk6gkKFEz.has("--click-card"):
		__o6uEWu10EBEvlS2F9qEMLEjG["click_card"] = true
	if __P0YvSniggiu5Gb6Vk6gkKFEz.has("--shipyard"):
		__o6uEWu10EBEvlS2F9qEMLEjG["mode"] = "shipyard"
	if __P0YvSniggiu5Gb6Vk6gkKFEz.has("--no-server"):
		__o6uEWu10EBEvlS2F9qEMLEjG["no_server"] = true
	if __P0YvSniggiu5Gb6Vk6gkKFEz.has("--area"):
		__o6uEWu10EBEvlS2F9qEMLEjG["area"] = int(__yW8LLge425pcZIzRPuh5N2bX.value(__P0YvSniggiu5Gb6Vk6gkKFEz, "--area", "17"))
	if __P0YvSniggiu5Gb6Vk6gkKFEz.has("--snap-after"):
		__o6uEWu10EBEvlS2F9qEMLEjG["snap_after"] = float(__yW8LLge425pcZIzRPuh5N2bX.value(__P0YvSniggiu5Gb6Vk6gkKFEz, "--snap-after", "5"))
	if __P0YvSniggiu5Gb6Vk6gkKFEz.has("--offline-harbor"):
		__o6uEWu10EBEvlS2F9qEMLEjG["auto_offline"] = true
	if __P0YvSniggiu5Gb6Vk6gkKFEz.has("--offline-room"):
		__o6uEWu10EBEvlS2F9qEMLEjG["auto_offline"] = true
		__o6uEWu10EBEvlS2F9qEMLEjG["stay"] = true
		__o6uEWu10EBEvlS2F9qEMLEjG["offline_room"] = __yW8LLge425pcZIzRPuh5N2bX.value(__P0YvSniggiu5Gb6Vk6gkKFEz, "--offline-room", "duel")
	if __P0YvSniggiu5Gb6Vk6gkKFEz.has("--name"):
		__o6uEWu10EBEvlS2F9qEMLEjG["name"] = __yW8LLge425pcZIzRPuh5N2bX.value(__P0YvSniggiu5Gb6Vk6gkKFEz, "--name", "")
	if __P0YvSniggiu5Gb6Vk6gkKFEz.has("--chat-say"):
		Chat.__zbaFgErvMZp1LuHQy7VAjJuQ = __yW8LLge425pcZIzRPuh5N2bX.value(__P0YvSniggiu5Gb6Vk6gkKFEz, "--chat-say", "")
	if __P0YvSniggiu5Gb6Vk6gkKFEz.has("--auto-update"):
		__o6uEWu10EBEvlS2F9qEMLEjG["auto_update"] = true
	if __P0YvSniggiu5Gb6Vk6gkKFEz.has("--connect"):
		__o6uEWu10EBEvlS2F9qEMLEjG["addr"] = __yW8LLge425pcZIzRPuh5N2bX.value(__P0YvSniggiu5Gb6Vk6gkKFEz, "--connect", "")
	if __P0YvSniggiu5Gb6Vk6gkKFEz.has("--host-local"):
		__o6uEWu10EBEvlS2F9qEMLEjG["auto_host"] = true
		__o6uEWu10EBEvlS2F9qEMLEjG["auto_create"] = true
	elif __P0YvSniggiu5Gb6Vk6gkKFEz.has("--connect"):
		__o6uEWu10EBEvlS2F9qEMLEjG["auto_connect"] = true
		__o6uEWu10EBEvlS2F9qEMLEjG["auto_join" if __P0YvSniggiu5Gb6Vk6gkKFEz.has("--join") else "auto_create"] = true
	get_tree().change_scene_to_file.call_deferred(__J4y56SXvPKCbvS6w_9iaUZq9)

	for meti_key in ["auto_host", "auto_connect", "auto_create", "auto_join", "auto_update"]:
		__o6uEWu10EBEvlS2F9qEMLEjG.erase(meti_key)
	__o6uEWu10EBEvlS2F9qEMLEjG["no_server"] = true
	__o6uEWu10EBEvlS2F9qEMLEjG["auto_offline"] = true
	UI.replace("connect", __o6uEWu10EBEvlS2F9qEMLEjG)
func __pfG_u2ARk43BVzB84_fO3y03(__BvsiPZiaE_nso9aiaI4clcte: int) -> String:
	var __AeRZej9r8by7aOeEseZ7TspK: Dictionary = __PtNURh2PaYHMgsPlkLtni90Y().__ofKSCLcCg7jWtqacDa153ehk(__BvsiPZiaE_nso9aiaI4clcte)
	if __AeRZej9r8by7aOeEseZ7TspK.is_empty():
		return "?"
	var __mUfTP_9Z4BqZg84bqKjAZ7RE: String = __AqRLmDaYMC2aA5Jk6DLdJAGf(str(__AeRZej9r8by7aOeEseZ7TspK["label"]))
	return __A6XI74bFN3243pFbSLAzzTVt(__BvsiPZiaE_nso9aiaI4clcte) + ("（%s）" % __mUfTP_9Z4BqZg84bqKjAZ7RE if __YWyGam_15HuUyuIa4REmc8J4(__BvsiPZiaE_nso9aiaI4clcte) != "" else "")
func __HqUdoga9EZH8HJx1sDVi59md() -> __o4BlGoLwjfAD3TYKD8Kt7FzU:
	if __QM7KCdmZcvPhLeIwvjBpkJoX == null:
		__QM7KCdmZcvPhLeIwvjBpkJoX = __o4BlGoLwjfAD3TYKD8Kt7FzU.__x4dRhV0emeOXyfnjujX6iOAP()
	return __QM7KCdmZcvPhLeIwvjBpkJoX
func __YSjTfQqs5EaM1aKxXA9xKhjP(__MoBYuYM4WFCjS7Zu8wMw4uvJ: Dictionary) -> void :
	UI.clear()
	__iQ6zA7j8vaK25mGjzbSHhX3K = __MoBYuYM4WFCjS7Zu8wMw4uvJ
	get_tree().change_scene_to_file.call_deferred(__adx3IzFL60MY3L9tFBMzLvz7)
const __c4QtsqvfMNtDaAvZKm8zQkQA: = {
	"duel": "res://assets/scenarios/duel.json", 
	"fleet5": "res://assets/scenarios/fleet_5v5.json", 
	"fleet10": "res://assets/scenarios/fleet_10v10.json", 
	"fleet": "res://assets/scenarios/fleet_20v20.json", 
}
const __adx3IzFL60MY3L9tFBMzLvz7: = "res://client/battle/battle.tscn"
var __QM7KCdmZcvPhLeIwvjBpkJoX: __o4BlGoLwjfAD3TYKD8Kt7FzU
static func __tnlzCyZrhTeBX3ip2sZWmxBX(label: String) -> String:
	var __Vo4_Ts8MklCRrR6zonRlmcRV: = RegEx.create_from_string("\\[[^\\]]*\\]")
	var __iBJwCo1Bbq54HEiEeUpWF0kO: String = ""
	for __qsR9x89I9fcpV91TxL_4b7mK: RegExMatch in __Vo4_Ts8MklCRrR6zonRlmcRV.search_all(label):
		__iBJwCo1Bbq54HEiEeUpWF0kO += __qsR9x89I9fcpV91TxL_4b7mK.get_string()
	return __iBJwCo1Bbq54HEiEeUpWF0kO
func __AqRLmDaYMC2aA5Jk6DLdJAGf(label: String) -> String:
	for code: String in __jB3BoSr0wjbmaulI2AtY9qfK:
		label = label.replace(code, __jB3BoSr0wjbmaulI2AtY9qfK[code])
	return label
const __HK31GsUXVl4XqVVZwVbhBKW7: = "res://assets/data"
func __YWyGam_15HuUyuIa4REmc8J4(__fbGID5A5A9DFuMthhwsLz3Nn: int) -> String:
	if __5HeZ085eBrXRSmVsBtsjICws.is_empty():
		var v: Variant = JSON.parse_string(__gebnXaZA9PFUWGVFWlMPDEta.text(__HK31GsUXVl4XqVVZwVbhBKW7 + "/ship_names.json"))
		__5HeZ085eBrXRSmVsBtsjICws = (v as Dictionary).get("rows", {}) if v is Dictionary else {}
		__5HeZ085eBrXRSmVsBtsjICws["_loaded"] = true
	var __osNuCXOHYL4fuxi9L_22jJsl: Variant = __5HeZ085eBrXRSmVsBtsjICws.get(str(__fbGID5A5A9DFuMthhwsLz3Nn))
	return str((__osNuCXOHYL4fuxi9L_22jJsl as Dictionary).get("zh", "")) if __osNuCXOHYL4fuxi9L_22jJsl is Dictionary else ""
var __CdSJVoXvVKAAL3yOnGfpJf5T: __MxRtF5kMQ2PhDOJRxJ1ej8ie
const __zKZrf1ciyEFELFgvd_rF5hzx: = "res://assets/scenarios/duel.json"
func __VyWx49mpJs7424hYJ22diA_s(__O6RtBgwYxdDlTR4gZoCDdSc8: Dictionary = {}) -> void :
	get_tree().change_scene_to_file.call_deferred(__J4y56SXvPKCbvS6w_9iaUZq9)
	__O6RtBgwYxdDlTR4gZoCDdSc8["hub"] = true
	if not __O6RtBgwYxdDlTR4gZoCDdSc8.has("mode"):
		__O6RtBgwYxdDlTR4gZoCDdSc8["mode"] = "shipyard"
	UI.replace("dock", __O6RtBgwYxdDlTR4gZoCDdSc8)
