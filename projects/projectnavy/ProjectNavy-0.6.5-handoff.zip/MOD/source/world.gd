class_name __aDswGCE4WWdmypkp3eC7rExn
extends RefCounted
func __QydBfC_Rl2VPiev0QJQPMkN2(a: __YCYnibBjVPRhMDf3YPwizbkN, __MsIMRj2mPukXd10G_4G2LLc3: int, __dRRtFeIj4VN2Fj_MQyNnthHz: int, __KvpiD3GwsDbffzKzycMQ1OcM: int, __eQBIMJTsi2U5XZpft3vjUKk1: int) -> void :
	var b: Dictionary = a.__0VloNlBtp7lq4vh_B_l9Y2Ll
	var __R2u99OzI4iyR58KbOoWWjXob: int = int(b.get("proj_row", -1))
	if __R2u99OzI4iyR58KbOoWWjXob < 0:
		return
	var __BrplanC_f9Yp2HC2Wscnm8vV: int = ___qFCN2viGM2bPW1uGV9qys9h.__Jy2hcMM9emCF3iBBkLMyeUr7("Projectile", __R2u99OzI4iyR58KbOoWWjXob, 156)
	var __Wf0Skt2t0Rq0scWMo30VYD4H: int = ___qFCN2viGM2bPW1uGV9qys9h.__vlQDTtuyQZ3KmvKohFfizJCm("Projectile", __R2u99OzI4iyR58KbOoWWjXob, 155) & 15
	var __u5BlTDft0Q1Dfc34jp1scJUx: int = __BrplanC_f9Yp2HC2Wscnm8vV if __Wf0Skt2t0Rq0scWMo30VYD4H == 5 else __BrplanC_f9Yp2HC2Wscnm8vV * (90 + __T3MhJL9nMTQaWMJrYSTIXXqi[(__eQBIMJTsi2U5XZpft3vjUKk1 & 4294967295) % __T3MhJL9nMTQaWMJrYSTIXXqi.size()] %20) / 100
	var __w2y5VMlQ05heTMbY9iHZrp8f: int = ___qFCN2viGM2bPW1uGV9qys9h.__vlQDTtuyQZ3KmvKohFfizJCm("Projectile", __R2u99OzI4iyR58KbOoWWjXob, 154)
	var __Q1khsTllgjlt6PGvb9OMzgSe: = {
		"x": a.__EsOQaggwtLEnMAHn6g7H_r7O() * __jSHCPDm8k9O9CtctnqkQJ6b2, "y": a.__KrKPdZs_d6uEOIuRq3UQy1fb() * __W_7fSiIVO80l6wn6KwvCuoPH, "h": (a.__aBKovnuyCiI63tVuI2prB5MN / 1000) * 400, 
		"vx": __MsIMRj2mPukXd10G_4G2LLc3, "vy": __dRRtFeIj4VN2Fj_MQyNnthHz, "vz": __KvpiD3GwsDbffzKzycMQ1OcM, "owner": a.owner, 
		"t0": b["t0"], "kind": __Wf0Skt2t0Rq0scWMo30VYD4H, "Ms": b["Ms"], "Ca": b["Ca"], 
		"c1cc": (__w2y5VMlQ05heTMbY9iHZrp8f - 256 if __w2y5VMlQ05heTMbY9iHZrp8f >= 128 else __w2y5VMlQ05heTMbY9iHZrp8f) * 10 + 100, 
		"grade": b["grade"], "acc70": 0, "frames": 0, "alive": true, "gun_idx": -1, 
		"HE": __u5BlTDft0Q1Dfc34jp1scJUx, "is_ap": __u5BlTDft0Q1Dfc34jp1scJUx == 0, "cursor": __eQBIMJTsi2U5XZpft3vjUKk1, "air": true, 
	}
	___1qGksmzNRubFckXIU7Ogyjh.append(__Q1khsTllgjlt6PGvb9OMzgSe)
	__wIebi2RHJicnHeiUm6xYwBpd(__QzfA1_MgHwBGTTBizdgA8rkk.__FSW4WCXpupwYSF0KaHCFCNKb.__13xdeilLgdjil6FE_cmvWKMm, a, a.type)
const __XEhbqfK4xUhJnH4N8eESpzL4: = 4000
func __iaETM43CHl2xsxBnGjisMUgG(s: __YdhZSn3k6BLtSITi5naOCb7n) -> void :
	__2nLQ763tFkgAwvH1QSmnnqh3(__QzfA1_MgHwBGTTBizdgA8rkk.__FSW4WCXpupwYSF0KaHCFCNKb.__o4UgLmyYvgr3J9nBpaLdFkqq, s.index, s.x(), s.y(), __lAo0PsogaUvqHw4muTzPsHiR.__kJiZhKac7aZLQMeVJVWRIdct)
const __W_7fSiIVO80l6wn6KwvCuoPH: = __a3Qlrip4DI7L5IkLGkgxE5xK.__W_7fSiIVO80l6wn6KwvCuoPH
var __UhGbxyY1hNuGzD53VHzu_vzw: int = 0
func __hTfETy1GbJqN6AkV7BYpZilZ() -> int:
	__9rro_RsNE1gdH3AkrS5cj0hH += 1
	return __9rro_RsNE1gdH3AkrS5cj0hH
func __2nLQ763tFkgAwvH1QSmnnqh3(__tmhWi24_40c3tgky00RYppyK: int, __IbUE9IJNfKK4bl9BtTdLTWA9: int, __rUf3hBWQCS6QKPc9B6Hj4esY: int, __byIbc68iFjiYcQ3cpmnueuRB: int, value: int = 0, 
		__lY8iE3xMHiwL5nzCGckLrf_c: PackedInt32Array = PackedInt32Array()) -> void :
	if __8t25G5WNXpxXjotieTtR4L5d or __tmhWi24_40c3tgky00RYppyK == __QzfA1_MgHwBGTTBizdgA8rkk.__FSW4WCXpupwYSF0KaHCFCNKb.__QECI9RHRtVBcNl93XhYVIrYe or __tmhWi24_40c3tgky00RYppyK == __QzfA1_MgHwBGTTBizdgA8rkk.__FSW4WCXpupwYSF0KaHCFCNKb.__tsbqIr5ld5OPHHXy4mMiC8xs:
		__SmXVMct8mHIMx6HdC4TMDErT.append(__QzfA1_MgHwBGTTBizdgA8rkk.__YCYCLM7wn8U5KL1mw3RC4lIU(__tmhWi24_40c3tgky00RYppyK, __u0nkAKG5lGiEsenIJI6PFvMF, __IbUE9IJNfKK4bl9BtTdLTWA9, __rUf3hBWQCS6QKPc9B6Hj4esY, __byIbc68iFjiYcQ3cpmnueuRB, value, __lY8iE3xMHiwL5nzCGckLrf_c))
func __FNSSrZjYm1kMWB8ZA1h6htpt(__eGdSwC9wbw5ZOjBP7QmDvels: __PvnLOrlcJy1UWxLTLMpWrcWS) -> void :
	assert (__t2UdGLb5AjoD9DJacXSIpDUA == 0)
	__EaiCL_s7Is8n8XhLMgCmd8bh = __eGdSwC9wbw5ZOjBP7QmDvels.__EaiCL_s7Is8n8XhLMgCmd8bh
	__T3MhJL9nMTQaWMJrYSTIXXqi = __3RMEFseeX7lwG1B9fZj8jUzH.generate(__EaiCL_s7Is8n8XhLMgCmd8bh)
	for ___Aro4Cw_DTNdf3AiyiDNBq9u: int in __eGdSwC9wbw5ZOjBP7QmDvels.__LYNzM9N3A8Dmo_1zq54GljKm.size():
		var __pyVgaQvPkU1LbkcCdyAyOKNt: __rkQFXFkST3Ffhp6uJi54lr83 = __eGdSwC9wbw5ZOjBP7QmDvels.__LYNzM9N3A8Dmo_1zq54GljKm[___Aro4Cw_DTNdf3AiyiDNBq9u]
		for __6cr6Cc4tO4thlUNXI30PawT7: __REjpG8i8fp_pDKfx6CV3uyDe in __pyVgaQvPkU1LbkcCdyAyOKNt.__TvSfxzgQXaZCIjioVO_AuUCJ:
			assert (__6cr6Cc4tO4thlUNXI30PawT7.__t2UdGLb5AjoD9DJacXSIpDUA >= 0 and __6cr6Cc4tO4thlUNXI30PawT7.__t2UdGLb5AjoD9DJacXSIpDUA < __lAo0PsogaUvqHw4muTzPsHiR.__BvjYOp5V9D51FL_PzBjk4Wlf)
			__VTWOx4yuLhyJ3SI2VTF9IvPN.append([___Aro4Cw_DTNdf3AiyiDNBq9u, __6cr6Cc4tO4thlUNXI30PawT7.code, __6cr6Cc4tO4thlUNXI30PawT7.__It3Y2BjKAtGZJyez5KMqb_lE, __u0nkAKG5lGiEsenIJI6PFvMF + __6cr6Cc4tO4thlUNXI30PawT7.__t2UdGLb5AjoD9DJacXSIpDUA])
		if __pyVgaQvPkU1LbkcCdyAyOKNt.__YTVy5e6INU6CjmYwkCz1bhli == __lAo0PsogaUvqHw4muTzPsHiR.__n3adFYesObTMohn4zGUJjnNR:
			__LYNzM9N3A8Dmo_1zq54GljKm[___Aro4Cw_DTNdf3AiyiDNBq9u].state = 0
			__cV1TfO9LYjqVJIVXjDHEK396.__YYZnqeqcW24r4NHVJSm4X6pk(__LYNzM9N3A8Dmo_1zq54GljKm[___Aro4Cw_DTNdf3AiyiDNBq9u])
			__qUuRE3qEzIGmcU0ysMMtWssY.reset(__LYNzM9N3A8Dmo_1zq54GljKm[___Aro4Cw_DTNdf3AiyiDNBq9u])
	for s: __YdhZSn3k6BLtSITi5naOCb7n in __LYNzM9N3A8Dmo_1zq54GljKm:
		if s.state == __lAo0PsogaUvqHw4muTzPsHiR.__pRO7nOY10o2GAU3KzWQvIvwY and s.__F41ZT8z_0zKKqYDFwqS1WGTs <= 0:
			s.state = 0
			s.__l9VibzAjJA8MnBH74WNhUJZL = __u0nkAKG5lGiEsenIJI6PFvMF
			__cV1TfO9LYjqVJIVXjDHEK396.__c8MA39tm6BoC78N3GABrZORw(self, s)
			__qUuRE3qEzIGmcU0ysMMtWssY.reset(s)
			__2nLQ763tFkgAwvH1QSmnnqh3(__QzfA1_MgHwBGTTBizdgA8rkk.__FSW4WCXpupwYSF0KaHCFCNKb.__tsbqIr5ld5OPHHXy4mMiC8xs, s.index, s.x(), s.y())
var __SmXVMct8mHIMx6HdC4TMDErT: Array[__QzfA1_MgHwBGTTBizdgA8rkk] = []
func __nOE6zCjalZI4xwRPUBrEgF5F() -> void :
	if __VTWOx4yuLhyJ3SI2VTF9IvPN.is_empty():
		return
	var __mQJv0dx_bygPXfNBccVOr4JE: Array[Array] = []
	var rest: Array[Array] = []
	for __ZZVpfY1QribDA3Vjh8JRoyOX: Array in __VTWOx4yuLhyJ3SI2VTF9IvPN:
		if __ZZVpfY1QribDA3Vjh8JRoyOX[3] == __u0nkAKG5lGiEsenIJI6PFvMF:
			__mQJv0dx_bygPXfNBccVOr4JE.append(__ZZVpfY1QribDA3Vjh8JRoyOX)
		else:
			rest.append(__ZZVpfY1QribDA3Vjh8JRoyOX)
	if __mQJv0dx_bygPXfNBccVOr4JE.is_empty():
		return
	__VTWOx4yuLhyJ3SI2VTF9IvPN = rest
	var __Cva7YofDgdL5v9M_zWR2ny06: Array[int] = []
	for __qDNN8d82DiMlDA9e1O7mCeCV: int in __mQJv0dx_bygPXfNBccVOr4JE.size():
		__Cva7YofDgdL5v9M_zWR2ny06.append(__qDNN8d82DiMlDA9e1O7mCeCV)
	__Cva7YofDgdL5v9M_zWR2ny06.sort_custom( func(a: int, b: int) -> bool:
		return __mQJv0dx_bygPXfNBccVOr4JE[a][0] < __mQJv0dx_bygPXfNBccVOr4JE[b][0] or (__mQJv0dx_bygPXfNBccVOr4JE[a][0] == __mQJv0dx_bygPXfNBccVOr4JE[b][0] and a < b))
	for __KT87sSOd6F5rarVQ5IoTrgwx: int in __Cva7YofDgdL5v9M_zWR2ny06:
		var __i5Wx8ysoQOCSZ9tXxqybbHDi: Array = __mQJv0dx_bygPXfNBccVOr4JE[__KT87sSOd6F5rarVQ5IoTrgwx]
		var s: __YdhZSn3k6BLtSITi5naOCb7n = __LYNzM9N3A8Dmo_1zq54GljKm[__i5Wx8ysoQOCSZ9tXxqybbHDi[0]]
		if s.state == __lAo0PsogaUvqHw4muTzPsHiR.__pRO7nOY10o2GAU3KzWQvIvwY:
			if __i5Wx8ysoQOCSZ9tXxqybbHDi[1] == __lAo0PsogaUvqHw4muTzPsHiR.__6Z410v1VboT0hLD2rdNAdHy8:
				var __kwDpwUcLFLwc4rDVsw7tGun5: PackedByteArray = __i5Wx8ysoQOCSZ9tXxqybbHDi[2]
				if __kwDpwUcLFLwc4rDVsw7tGun5.size() >= 2 and __kwDpwUcLFLwc4rDVsw7tGun5[0] == __lAo0PsogaUvqHw4muTzPsHiR.__XDVHVm7m319ODJlneIf4qgkj:
					__qUuRE3qEzIGmcU0ysMMtWssY.apply(self, s, __kwDpwUcLFLwc4rDVsw7tGun5[1])
				else:
					__cV1TfO9LYjqVJIVXjDHEK396.__ZrbT7kYiRUNNS0DaW5bPeCHg(self, s, __kwDpwUcLFLwc4rDVsw7tGun5)
			elif __i5Wx8ysoQOCSZ9tXxqybbHDi[1] == __lAo0PsogaUvqHw4muTzPsHiR.__W0Ohfu0ZYBIIULGBAJhK38D1:
				__cV1TfO9LYjqVJIVXjDHEK396.__uU1Ja3PG9KT7fTWexG_8vWbA(self, s, __i5Wx8ysoQOCSZ9tXxqybbHDi[2])
			elif __i5Wx8ysoQOCSZ9tXxqybbHDi[1] == __lAo0PsogaUvqHw4muTzPsHiR.__JmLf5yUyHKAY5pdN5P69DmWL:
				var __OVOlZ1gXmBu21W8WIuywBCi4: PackedByteArray = __i5Wx8ysoQOCSZ9tXxqybbHDi[2]
				if __OVOlZ1gXmBu21W8WIuywBCi4.size() >= 4:
					s.__4CMfwHAY4YJgIN_C4boQ2qiP(__OVOlZ1gXmBu21W8WIuywBCi4.decode_s16(0), __OVOlZ1gXmBu21W8WIuywBCi4.decode_s16(2))
			else:
				if __i5Wx8ysoQOCSZ9tXxqybbHDi[1] == __lAo0PsogaUvqHw4muTzPsHiR.__QBgR4salFkVbsOQyeDL2U7FY or __i5Wx8ysoQOCSZ9tXxqybbHDi[1] == __lAo0PsogaUvqHw4muTzPsHiR.__cewsf_vW3eJj1apjb3LfTBVx:
					__ojs8o4FAfa94EAyfqhpeTDrg = true
				s.__QYxNDclhLiUG8cH9G_EpMh6K(__i5Wx8ysoQOCSZ9tXxqybbHDi[1], __i5Wx8ysoQOCSZ9tXxqybbHDi[2])
const __jSHCPDm8k9O9CtctnqkQJ6b2: = __a3Qlrip4DI7L5IkLGkgxE5xK.__jSHCPDm8k9O9CtctnqkQJ6b2
func __VkzoyB_koPjfXQZjEINKML3x(s: __YdhZSn3k6BLtSITi5naOCb7n, __K8Q0P1ZQMql_Sv7YpwwXXqYM: int) -> void :
	__2nLQ763tFkgAwvH1QSmnnqh3(__QzfA1_MgHwBGTTBizdgA8rkk.__FSW4WCXpupwYSF0KaHCFCNKb.__PbaJd7abiSk0NwFQGB9iKA0a, s.index, s.x(), s.y(), __K8Q0P1ZQMql_Sv7YpwwXXqYM)
var __bLc0ZDHxlrSL7QCGVI55zc6I: = PackedInt64Array()
func __d0KpenxuhH7YKfTNllTgXwJb(__KKonCZNvc5oQEH_Ta3NauiWa: int, __jXpX4zzT0cdWT2JzSZQNeDiL: Dictionary, __d0IXHbGSOlt5gw9Lq3KDHwdC: Vector2i, __5019jaCMxRkck5gGfcCo3DLZ: int = 0) -> void :
	if __KKonCZNvc5oQEH_Ta3NauiWa == __QzfA1_MgHwBGTTBizdgA8rkk.__FSW4WCXpupwYSF0KaHCFCNKb.__5Ao1SINeFaYDCuLTKr4lvApZ:
		__2nLQ763tFkgAwvH1QSmnnqh3(__KKonCZNvc5oQEH_Ta3NauiWa, __jXpX4zzT0cdWT2JzSZQNeDiL["owner"], __d0IXHbGSOlt5gw9Lq3KDHwdC.x, __d0IXHbGSOlt5gw9Lq3KDHwdC.y, __jXpX4zzT0cdWT2JzSZQNeDiL["id"])
	else:
		__2nLQ763tFkgAwvH1QSmnnqh3(__KKonCZNvc5oQEH_Ta3NauiWa, __jXpX4zzT0cdWT2JzSZQNeDiL["owner"], __d0IXHbGSOlt5gw9Lq3KDHwdC.x, __d0IXHbGSOlt5gw9Lq3KDHwdC.y, __5019jaCMxRkck5gGfcCo3DLZ, PackedInt32Array([__jXpX4zzT0cdWT2JzSZQNeDiL["id"], int(__jXpX4zzT0cdWT2JzSZQNeDiL.get("code", 1))]))
func __3CvsQr5D8yh_q4kbKcqfckGU(__zMHjbcp3IcZxcxsYrhs24D9e: Dictionary) -> void :
	var start: Array = [__zMHjbcp3IcZxcxsYrhs24D9e["x"], __zMHjbcp3IcZxcxsYrhs24D9e["y"], __zMHjbcp3IcZxcxsYrhs24D9e["h"]]
	__a3Qlrip4DI7L5IkLGkgxE5xK.step(__zMHjbcp3IcZxcxsYrhs24D9e, __zMHjbcp3IcZxcxsYrhs24D9e["t0"], __zMHjbcp3IcZxcxsYrhs24D9e["kind"])
	__zMHjbcp3IcZxcxsYrhs24D9e["frames"] = int(__zMHjbcp3IcZxcxsYrhs24D9e["frames"]) + 1
	var h: int = __zMHjbcp3IcZxcxsYrhs24D9e["h"]
	var __sACDV5dgyOtvSnEOwdzHieWP: int = __zMHjbcp3IcZxcxsYrhs24D9e["vz"]
	var __3ZeCAWLs6oYWVoYxhnkBhBC7: int = h + __sACDV5dgyOtvSnEOwdzHieWP
	if __3ZeCAWLs6oYWVoYxhnkBhBC7 < 0:
		var __8c5witGur_dgqeX2UVgDsEq6: int = absi(h * 100 / __sACDV5dgyOtvSnEOwdzHieWP) if __sACDV5dgyOtvSnEOwdzHieWP != 0 else 0
		__zMHjbcp3IcZxcxsYrhs24D9e["alive"] = false
		var __2hWiswamnXWku6dw6Dtaw631: int = (int(__zMHjbcp3IcZxcxsYrhs24D9e["x"]) + int(__zMHjbcp3IcZxcxsYrhs24D9e["vx"]) * __8c5witGur_dgqeX2UVgDsEq6 / 100) / __jSHCPDm8k9O9CtctnqkQJ6b2
		var __fXmrMKs7_BP41iQF91RGaL_H: int = (int(__zMHjbcp3IcZxcxsYrhs24D9e["y"]) + int(__zMHjbcp3IcZxcxsYrhs24D9e["vy"]) * __8c5witGur_dgqeX2UVgDsEq6 / 100) / __W_7fSiIVO80l6wn6KwvCuoPH
		__2nLQ763tFkgAwvH1QSmnnqh3(__QzfA1_MgHwBGTTBizdgA8rkk.__FSW4WCXpupwYSF0KaHCFCNKb.__ztB2fBnXLqKMIQ0Nub8JQJwo, __zMHjbcp3IcZxcxsYrhs24D9e["owner"], __2hWiswamnXWku6dw6Dtaw631, __fXmrMKs7_BP41iQF91RGaL_H, __zMHjbcp3IcZxcxsYrhs24D9e["grade"], 
			PackedInt32Array([1 if __zMHjbcp3IcZxcxsYrhs24D9e["is_ap"] else 0, __zMHjbcp3IcZxcxsYrhs24D9e["gun_idx"]]))
		if int(__zMHjbcp3IcZxcxsYrhs24D9e["kind"]) == __d8xiL_JJ6KRqOmUd2Sqej_FE or int(__zMHjbcp3IcZxcxsYrhs24D9e["kind"]) == __12ToK7nPtbWRgXmYD4WWUesJ:
			__i5VSVLoXQftICZ42J3cK2_5r.spawn(self, __zMHjbcp3IcZxcxsYrhs24D9e["owner"], __2hWiswamnXWku6dw6Dtaw631, __fXmrMKs7_BP41iQF91RGaL_H, __zMHjbcp3IcZxcxsYrhs24D9e["HE"], __zMHjbcp3IcZxcxsYrhs24D9e["Ms"])
			__TPIGeUdFb_AXx4vCwcpTGg3n = true
		return
	var end: Array = [int(__zMHjbcp3IcZxcxsYrhs24D9e["x"]) + int(__zMHjbcp3IcZxcxsYrhs24D9e["vx"]), int(__zMHjbcp3IcZxcxsYrhs24D9e["y"]) + int(__zMHjbcp3IcZxcxsYrhs24D9e["vy"]), __3ZeCAWLs6oYWVoYxhnkBhBC7]
	if h < __XEhbqfK4xUhJnH4N8eESpzL4 or __3ZeCAWLs6oYWVoYxhnkBhBC7 < __XEhbqfK4xUhJnH4N8eESpzL4:
		var r: Variant = __a3Qlrip4DI7L5IkLGkgxE5xK.__feGVgInD4izIDZgdfCqE8YS9(start, end, __NTPi8_rHrS8Qu6hcZEXu3a9n, __NTPi8_rHrS8Qu6hcZEXu3a9n[__zMHjbcp3IcZxcxsYrhs24D9e["owner"]], false)
		if r != null:
			__ivTDO5W1hLMqNjpaIfF2FuQb(__zMHjbcp3IcZxcxsYrhs24D9e, __LYNzM9N3A8Dmo_1zq54GljKm[int((r as Array)[1]["ship"])], end)
			return
	__zMHjbcp3IcZxcxsYrhs24D9e["x"] = end[0]
	__zMHjbcp3IcZxcxsYrhs24D9e["y"] = end[1]
	__zMHjbcp3IcZxcxsYrhs24D9e["h"] = end[2]
	if int(__zMHjbcp3IcZxcxsYrhs24D9e["kind"]) == __4Pcd1OiOt0B8w5S3xs6Gpm_P and not __zMHjbcp3IcZxcxsYrhs24D9e.get("air", false) and h >= __XEhbqfK4xUhJnH4N8eESpzL4 and __3ZeCAWLs6oYWVoYxhnkBhBC7 >= __XEhbqfK4xUhJnH4N8eESpzL4:
		if __cV1TfO9LYjqVJIVXjDHEK396.__L5HR6YCW7VZBKEE4q3BherRG(self, __zMHjbcp3IcZxcxsYrhs24D9e):
			__ofPJrMgW6ShEieMKY9H64SqU(__zMHjbcp3IcZxcxsYrhs24D9e, 1)
		elif __sACDV5dgyOtvSnEOwdzHieWP <= __RYRrt8mJAHprqxvpaMKNmsBZ:
			if int(__zMHjbcp3IcZxcxsYrhs24D9e.get("aa_gun", 0)) == 1:
				__zMHjbcp3IcZxcxsYrhs24D9e["alive"] = false
			else:
				__ofPJrMgW6ShEieMKY9H64SqU(__zMHjbcp3IcZxcxsYrhs24D9e, 0)
var terrain: __NYbIaW78BNqdaS0BgoYwqAci.__O1Urlr6IdUTnFWvioe6wcQrt
func __Bv2Jl7Fo059EPXCqJvbQUflR(__8SsvRU8y6nyJi5fsM5Fc0KAU: int, x: int, y: int, __xa2WouifJ0ynMbrHMYi5CKBs: int) -> void :
	__2nLQ763tFkgAwvH1QSmnnqh3(__8SsvRU8y6nyJi5fsM5Fc0KAU, __xa2WouifJ0ynMbrHMYi5CKBs, x, y)
static func __HhTA24hez5BRkkqq2ub8Jrr9(__dIYKwJQEwt8XijIOjqWHoBi6: int, __IqSC_qzp4MHoFwgGB0HYkJS4: int, __BZGbGKUVQrU1_A9lx1GGtEMZ: int, __Kv26_abnHi_t6ZB3G7hznHbG: int, __8GG3m00ls6gZYeZZtOOMMtW2: int, __ycv3Ekkhtec40bNY8n9cW2rG: int, __PfbGiJkGUOgPefB5cJfML3Mz: int) -> Array[int]:
	var v: int
	var __qBtRRfPVIuEgvTjCaOuh3paX: int
	var __JhwP2DQuLXcLTq1QaAw9KuA3: int
	if __dIYKwJQEwt8XijIOjqWHoBi6 == 1:
		v = __Kv26_abnHi_t6ZB3G7hznHbG * __Kv26_abnHi_t6ZB3G7hznHbG / 100 * __8GG3m00ls6gZYeZZtOOMMtW2
		__qBtRRfPVIuEgvTjCaOuh3paX = v / 4
		__JhwP2DQuLXcLTq1QaAw9KuA3 = __qBtRRfPVIuEgvTjCaOuh3paX * 3 / 2
	else:
		var __7FZ99Wgdk6m8ve2OH6TKdho5: int = __Irz9hiGcyslSDsJT8BenfEt2.__f8g2PjfN7nwJbTHn9ePhmeZH(__IqSC_qzp4MHoFwgGB0HYkJS4 * __IqSC_qzp4MHoFwgGB0HYkJS4 + __BZGbGKUVQrU1_A9lx1GGtEMZ * __BZGbGKUVQrU1_A9lx1GGtEMZ)
		v = __7FZ99Wgdk6m8ve2OH6TKdho5 * __7FZ99Wgdk6m8ve2OH6TKdho5 / 100 * __8GG3m00ls6gZYeZZtOOMMtW2
		__qBtRRfPVIuEgvTjCaOuh3paX = v
		__JhwP2DQuLXcLTq1QaAw9KuA3 = v / 2
	var __dO2ktP1kBrUqp9iSfT23OV8b: int = __JhwP2DQuLXcLTq1QaAw9KuA3 / 120 * __PfbGiJkGUOgPefB5cJfML3Mz
	var __LR9FJgVggkTt6rTph6sIqJys: int = __qBtRRfPVIuEgvTjCaOuh3paX / 100 * __PfbGiJkGUOgPefB5cJfML3Mz / (__ycv3Ekkhtec40bNY8n9cW2rG * __ycv3Ekkhtec40bNY8n9cW2rG)
	return [__dO2ktP1kBrUqp9iSfT23OV8b, __LR9FJgVggkTt6rTph6sIqJys]
func __EeaM5brz45Ll1madYIYSP5pp() -> int:
	var __JLTdgC_HkwYhMeGtzsDV4LtA: = PackedStringArray([str(__u0nkAKG5lGiEsenIJI6PFvMF), str(__EaiCL_s7Is8n8XhLMgCmd8bh), str(__t2UdGLb5AjoD9DJacXSIpDUA)])
	for s: __YdhZSn3k6BLtSITi5naOCb7n in __LYNzM9N3A8Dmo_1zq54GljKm:
		var a: Dictionary = s.__gz4iZzIm1ic26sbX2dyDa0Lg
		__JLTdgC_HkwYhMeGtzsDV4LtA.append_array([str(s.state), str(s.__F41ZT8z_0zKKqYDFwqS1WGTs), str(a["x"]), str(a["y"]), str(a["acc_x"]), 
			str(a["acc_y"]), str(a["heading"]), str(a["speed"]), str(s.__NELIelBEafKRGQultNqYAbM7["notch"]), 
			"1" if s.__tUvbj0r8Sx1dDiR_V1FeCNWc else "0", str(s.__pzCTF_BkwoDdXpHKn6Fvy06v), str(s.__aD1qlnd4hnNTYgeXVdepDA_r), str(s.__1_VYwkJQtQVG29nVEi0IzFyr), str(s.target.__tU3LKkiKFkCz9gqPVWopN1ej)])
		if s.__NELIelBEafKRGQultNqYAbM7.has("model"):
			__JLTdgC_HkwYhMeGtzsDV4LtA.append_array([str(s.__NELIelBEafKRGQultNqYAbM7["heat"]), str(s.__NELIelBEafKRGQultNqYAbM7["fix"]), "1" if s.__NELIelBEafKRGQultNqYAbM7["broken"] else "0", str(s.__NELIelBEafKRGQultNqYAbM7["cap"])])
		for g: Dictionary in s.__BJReFJ4ugditvprP9JFCx5S2:
			__JLTdgC_HkwYhMeGtzsDV4LtA.append_array([str(g["angle"]), str(g["elev"]), str(g["reload_cnt"]), 
				"1" if g["ready"] else "0"])
		if not s.__bFJ1csmbpVraScDCZhw1ETZ5.is_empty():
			__JLTdgC_HkwYhMeGtzsDV4LtA.append_array([str(s.__1Z7OFhxB6TttwviVl7guTYN5), str(int(s.__NNllNpdcFaCi_4XYufJlvaqy[0]) + 2 * int(s.__NNllNpdcFaCi_4XYufJlvaqy[1])
				+ 4 * int(s.__dFQZCtulu2HCzKfxAuhLiq1b[0]) + 8 * int(s.__dFQZCtulu2HCzKfxAuhLiq1b[1]))])
			for __iA__w2vKeHSMzfAxUL7Ak4GI: Dictionary in s.__bFJ1csmbpVraScDCZhw1ETZ5:
				__JLTdgC_HkwYhMeGtzsDV4LtA.append_array([str(__iA__w2vKeHSMzfAxUL7Ak4GI["angle"]), str(__iA__w2vKeHSMzfAxUL7Ak4GI["reload_cnt"]), str(__iA__w2vKeHSMzfAxUL7Ak4GI["ammo"]), 
					"1" if __iA__w2vKeHSMzfAxUL7Ak4GI["ready"] else "0"])
	for __h82G7wrUZaD1lrpQEtsYpq3j: Dictionary in ___1qGksmzNRubFckXIU7Ogyjh:
		__JLTdgC_HkwYhMeGtzsDV4LtA.append_array([str(__h82G7wrUZaD1lrpQEtsYpq3j["x"]), str(__h82G7wrUZaD1lrpQEtsYpq3j["y"]), str(__h82G7wrUZaD1lrpQEtsYpq3j["h"]), str(__h82G7wrUZaD1lrpQEtsYpq3j["vx"]), str(__h82G7wrUZaD1lrpQEtsYpq3j["vy"]), 
			str(__h82G7wrUZaD1lrpQEtsYpq3j["vz"])])
	for __nZVqnfrap77CgLNyoW4HaB8A: Dictionary in __PHRyUPhEHZ95rcQCVAqnc4Y6:
		__JLTdgC_HkwYhMeGtzsDV4LtA.append_array(["T", str(__nZVqnfrap77CgLNyoW4HaB8A["x"]), str(__nZVqnfrap77CgLNyoW4HaB8A["y"]), str(__nZVqnfrap77CgLNyoW4HaB8A["ax"]), str(__nZVqnfrap77CgLNyoW4HaB8A["ay"]), str(__nZVqnfrap77CgLNyoW4HaB8A["state"]), 
			str(__nZVqnfrap77CgLNyoW4HaB8A["t"]), "1" if __nZVqnfrap77CgLNyoW4HaB8A["armed"] else "0"])
	if __TPIGeUdFb_AXx4vCwcpTGg3n:
		for s: __YdhZSn3k6BLtSITi5naOCb7n in __LYNzM9N3A8Dmo_1zq54GljKm:
			if s.__AReCBHrBYt7dD7H_WiK9Tklz.is_empty():
				continue
			__JLTdgC_HkwYhMeGtzsDV4LtA.append_array(["S", str(s.__AReCBHrBYt7dD7H_WiK9Tklz["state"]), str(s.__AReCBHrBYt7dD7H_WiK9Tklz["timer"]), str(s.__AReCBHrBYt7dD7H_WiK9Tklz["cooldown"]), 
				str(s.__AReCBHrBYt7dD7H_WiK9Tklz["o2"]), str(s.__AReCBHrBYt7dD7H_WiK9Tklz["crit_o2"])])
		for b: Dictionary in __pZlzu4JO6f_sgap1yOU60LoH:
			__JLTdgC_HkwYhMeGtzsDV4LtA.append_array(["B", str(b["x"]), str(b["y"]), str(b["t"])])
	if __GrLwyamZ57OX31Lkvv8RpSj0:
		for s: __YdhZSn3k6BLtSITi5naOCb7n in __LYNzM9N3A8Dmo_1zq54GljKm:
			if s.__g7JC3EJmfsOWnIyqLGGB93eB == null:
				continue
			var w: __1q0DwOCFFBOQDiHI3310K_lq = s.__g7JC3EJmfsOWnIyqLGGB93eB
			__JLTdgC_HkwYhMeGtzsDV4LtA.append_array(["A", str(w.__4xREaDvbh74nCbB3paXnMRd1), str(__VtC8pLMhL6BfWWcFD6bsOCll[s.index])])
			for __rouz1bY2JLhYgii1gK0lVa6w: Dictionary in w.__xYLJ4HxXNYIH9o2lodd303ua:
				__JLTdgC_HkwYhMeGtzsDV4LtA.append_array([str(__rouz1bY2JLhYgii1gK0lVa6w["hangar"]), str(__rouz1bY2JLhYgii1gK0lVa6w["stock"])])
			for __vjCCYvqqjI8bUYmFIzMUV7Ap: Dictionary in w.__MMezevmh2WzjfDPiLXmgyJbQ:
				__JLTdgC_HkwYhMeGtzsDV4LtA.append(str((__vjCCYvqqjI8bUYmFIzMUV7Ap["members"] as Array).size()))
		for a: __YCYnibBjVPRhMDf3YPwizbkN in __gobxGwIVlftvCfJ1fsNzSlj7:
			__JLTdgC_HkwYhMeGtzsDV4LtA.append_array(["P", str(a.id), str(a.__CYx_P43ujHK1YF5Dtz9hb_PN), str(a.__zcQSNSE8gcZixJwEAvw9gtcc), str(a.__aBKovnuyCiI63tVuI2prB5MN), str(a.__2cQt3I45k0XXwSr_0reYodT2), str(a.__vqYa6WuT8lqRfpObeEEtFMHG), 
				str(a.pitch), str(a.__wK6c6xRBxB0Lka8tqK6RrNfH), str(a.state), str(a.sub), str(a.__F41ZT8z_0zKKqYDFwqS1WGTs), str(a.__6ol9zXLNVbGS9s_iAdvMaxLC), str(a.__ZCQBCv36ysTHU0iBaYX6GvwS), 
				str(a.__Yp_qPJiGc1SjsM8_KRc4rLwV), str(a.__3epXDNnmkHn9cpXlvNEl2W4g), str(a.__C3JQvlRdH1p7kRdolXEDy8oi), str(a.__TlWqW0m63x0ks40OasJLgdcp), str(a.__auam0OiXATfV0FV2pOZQsnnt), 
				str(int(a.active) | int(a.__2nVqHzJsE4wg_diKnctoD6kY) << 1 | int(a.__sRdhcmPDkaBIPIzTf0y2eZwL) << 2 | int(a.__skELt8hzOP5jTm2IrBPiYtZM) << 3
					| int(a.__Mwx0mipYOX_Do2pZ7_nf22Nm) << 4 | int(a.__jKXPrtchy4v7fjo9Z9kJG9SX) << 5 | int(a.__Q4PVEYDqIobYx26SsJ1Qdl3_) << 6 | int(a.__H0IfsdkHBf2MPjU13h3e655G) << 7
					| int(a.__eYCv0HeDvti_w5wj1jxJpmfT) << 8)])
	if __xQC5OOLEt4J5D0Pcc1mgbzBU:
		for s: __YdhZSn3k6BLtSITi5naOCb7n in __LYNzM9N3A8Dmo_1zq54GljKm:
			if s.__sfrhGgpP8JHW6nvd0GQRC91I:
				__JLTdgC_HkwYhMeGtzsDV4LtA.append_array(["F", str(s.__k2tNHcrJ7Ubu73oDndNmYPUU), str(s.__PnHs8Uffgi24ue5O7EVvelTY), str(s.__QiHzrKvwrwbVmkkk810kJg1o), 
					str(s.__zju8koRRwto7fzzxR5TTU1ZT[0]), str(s.__zju8koRRwto7fzzxR5TTU1ZT[1])])
	if __ojs8o4FAfa94EAyfqhpeTDrg:
		for s: __YdhZSn3k6BLtSITi5naOCb7n in __LYNzM9N3A8Dmo_1zq54GljKm:
			if s.__rWMF7C3LY0TC6hhI0FLU6j3w or s.__EUkbEAh4d5DldiqwEPuX9leZ:
				__JLTdgC_HkwYhMeGtzsDV4LtA.append_array(["Q", str(s.index), "1" if s.__rWMF7C3LY0TC6hhI0FLU6j3w else "0", "1" if s.__EUkbEAh4d5DldiqwEPuX9leZ else "0"])
	__JLTdgC_HkwYhMeGtzsDV4LtA = __BW1tyWiDgrdOHeYq159RRkr4.__O3AqiiAroVPS_Hk0GVNQz5at.__jnhGLKO5XNeuNkgjG6gJDv3C(self, __JLTdgC_HkwYhMeGtzsDV4LtA)
	return __TLv8G0UEEF0SRh5237eRUkIr.__1FV4ZSo8CQyRdZ0aAV68MO4Z(",".join(__JLTdgC_HkwYhMeGtzsDV4LtA))
func __g5GsOdGtwfiw4c8qS32PmFoT(__Drmc6_gaMlcae2THBH_1zjmZ: int, __8f9FNwabZ6mvC3N50WpcdERU: int) -> bool:
	for __no9vODYqwVMUFtbIpfIHynFz: Array in __VTWOx4yuLhyJ3SI2VTF9IvPN:
		if __no9vODYqwVMUFtbIpfIHynFz[0] == __Drmc6_gaMlcae2THBH_1zjmZ and __no9vODYqwVMUFtbIpfIHynFz[3] == __8f9FNwabZ6mvC3N50WpcdERU:
			return true
	return false
var __f8I9gUlf4vPw6xR4KNFvw66k: int = __lAo0PsogaUvqHw4muTzPsHiR.__nbNt7X55zG6_WZmrWTE7nXlh
func __ivTDO5W1hLMqNjpaIfF2FuQb(__4aSpXjGSBQWDCJod_Lj5wLMV: Dictionary, __SYhybfh2zDbHbA2xiqw54ds2: __YdhZSn3k6BLtSITi5naOCb7n, end: Array) -> void :
	__4aSpXjGSBQWDCJod_Lj5wLMV["alive"] = false
	var __y5VPNUYMd1P1e2BwhaXmHXtN: int = __4aSpXjGSBQWDCJod_Lj5wLMV["vx"]
	var ___7mlQZRAfFjUZhiUbLGtxsi9: int = __4aSpXjGSBQWDCJod_Lj5wLMV["vy"]
	var __b9Qg_ZIiw6leY4FnXll8xa32: int = __4aSpXjGSBQWDCJod_Lj5wLMV["vz"]
	var __zTAYCYe4GIWZJcpks7ZDNyAS: int = __kNaPtT1SLWxw85RAZgluou4V(__y5VPNUYMd1P1e2BwhaXmHXtN, ___7mlQZRAfFjUZhiUbLGtxsi9, __b9Qg_ZIiw6leY4FnXll8xa32)
	if __4aSpXjGSBQWDCJod_Lj5wLMV.get("air", false):
		__zTAYCYe4GIWZJcpks7ZDNyAS = 350 + __T3MhJL9nMTQaWMJrYSTIXXqi[((__EaiCL_s7Is8n8XhLMgCmd8bh + __t2UdGLb5AjoD9DJacXSIpDUA) * 17 + 3) % __T3MhJL9nMTQaWMJrYSTIXXqi.size()] %101
	var __KKV0g7zXFqljA8HMczdjy0G1: int = __u5LsEZXAUJO5yjK7IObacEwF(__zTAYCYe4GIWZJcpks7ZDNyAS, __T3MhJL9nMTQaWMJrYSTIXXqi, __4aSpXjGSBQWDCJod_Lj5wLMV["cursor"])
	var __qHF_tmWOg7006fB1Yp8UhHoe: Array[int] = __HhTA24hez5BRkkqq2ub8Jrr9(__KKV0g7zXFqljA8HMczdjy0G1, __y5VPNUYMd1P1e2BwhaXmHXtN, ___7mlQZRAfFjUZhiUbLGtxsi9, __b9Qg_ZIiw6leY4FnXll8xa32, __4aSpXjGSBQWDCJod_Lj5wLMV["Ms"], __4aSpXjGSBQWDCJod_Lj5wLMV["Ca"], __4aSpXjGSBQWDCJod_Lj5wLMV["c1cc"])
	var __Gg6K9Aq_M5lcW6VIc4C762Z4: int = __qHF_tmWOg7006fB1Yp8UhHoe[0] / 1800 / 56
	if __4aSpXjGSBQWDCJod_Lj5wLMV.get("air", false):
		match int(__4aSpXjGSBQWDCJod_Lj5wLMV["kind"]):
			1:
				__Gg6K9Aq_M5lcW6VIc4C762Z4 = 0
			2:
				__Gg6K9Aq_M5lcW6VIc4C762Z4 = __qHF_tmWOg7006fB1Yp8UhHoe[0] / 2000
			3, 4:
				__Gg6K9Aq_M5lcW6VIc4C762Z4 = __qHF_tmWOg7006fB1Yp8UhHoe[0]
	var __KA5CkrjLWwYcYE9dBYSOpIVX: Array[int] = __nZxK7u5JB3kHTF7XC5Hr9MHe.__iLUTtdlJz90LVGliQf9aQ68R(__SYhybfh2zDbHbA2xiqw54ds2.target, __T3MhJL9nMTQaWMJrYSTIXXqi, __4aSpXjGSBQWDCJod_Lj5wLMV["cursor"], __fQaf8iG3sz2LcRoqJcnIWF0f, __Gg6K9Aq_M5lcW6VIc4C762Z4, __4aSpXjGSBQWDCJod_Lj5wLMV["HE"], __KKV0g7zXFqljA8HMczdjy0G1, __qHF_tmWOg7006fB1Yp8UhHoe[1], __nZxK7u5JB3kHTF7XC5Hr9MHe.margin(__SYhybfh2zDbHbA2xiqw54ds2.target, __4aSpXjGSBQWDCJod_Lj5wLMV["acc70"]))
	var __YRvM8ornTIyvuux2OIFTDH_E: int = __SYhybfh2zDbHbA2xiqw54ds2.__F41ZT8z_0zKKqYDFwqS1WGTs
	var __qxISKxUkOlgCABpQiQoNJGmG: Array[int] = __TyBlH2mrRyRh1_U5lXYpPSlQ(__SYhybfh2zDbHbA2xiqw54ds2, __KA5CkrjLWwYcYE9dBYSOpIVX, __fQaf8iG3sz2LcRoqJcnIWF0f, __KKV0g7zXFqljA8HMczdjy0G1, __qHF_tmWOg7006fB1Yp8UhHoe[1], int(__4aSpXjGSBQWDCJod_Lj5wLMV["Ca"]), int(__4aSpXjGSBQWDCJod_Lj5wLMV["owner"]))
	__UfEKTxE0kEIGUl7MshOPCLso(int(__4aSpXjGSBQWDCJod_Lj5wLMV["owner"]), __SYhybfh2zDbHbA2xiqw54ds2, __qxISKxUkOlgCABpQiQoNJGmG[0])
	if not __4aSpXjGSBQWDCJod_Lj5wLMV.get("air", false):
		____QC9P4TDwHwfULO6rX_AKV5(int(__4aSpXjGSBQWDCJod_Lj5wLMV["owner"]), __SYhybfh2zDbHbA2xiqw54ds2, __9E4XvVmzfljiQT1Q9Qiml72N.__YuZeYY7hy6d4LpvCdwH08LkS(__qxISKxUkOlgCABpQiQoNJGmG[1], __YRvM8ornTIyvuux2OIFTDH_E, __SYhybfh2zDbHbA2xiqw54ds2.__RZSGss6vMJxzvS6fmWkQMma8, int(__4aSpXjGSBQWDCJod_Lj5wLMV["Ca"]), true), __zTAYCYe4GIWZJcpks7ZDNyAS, false)
	if __KA5CkrjLWwYcYE9dBYSOpIVX[0] != __nZxK7u5JB3kHTF7XC5Hr9MHe.___pHbcRk5biyJr9D8s1t3RC5B.__1nO8cAfZDr9W3jpcIyrUyDBq:
		__SYhybfh2zDbHbA2xiqw54ds2.__eApL0Mnhi3qPFjXtuxe0KTtH(Vector2i(int(end[0]) / __jSHCPDm8k9O9CtctnqkQJ6b2, int(end[1]) / __W_7fSiIVO80l6wn6KwvCuoPH))
	__B3bsjI8m3TLvZt0xBFiWVrDM(__SYhybfh2zDbHbA2xiqw54ds2, __KA5CkrjLWwYcYE9dBYSOpIVX, __4aSpXjGSBQWDCJod_Lj5wLMV["cursor"])
	if not __4aSpXjGSBQWDCJod_Lj5wLMV.get("air", false):
		__caiJN7usYIEMNh51fTf1ETV8.__OQrGtDcRsCMEUwKcJuznn_WJ(self, __LYNzM9N3A8Dmo_1zq54GljKm[int(__4aSpXjGSBQWDCJod_Lj5wLMV["owner"])], __SYhybfh2zDbHbA2xiqw54ds2, int(__4aSpXjGSBQWDCJod_Lj5wLMV["Ca"]), __KA5CkrjLWwYcYE9dBYSOpIVX[2], __SYhybfh2zDbHbA2xiqw54ds2.target.he_deck if __KKV0g7zXFqljA8HMczdjy0G1 == 1 else __SYhybfh2zDbHbA2xiqw54ds2.target.he_side, __4aSpXjGSBQWDCJod_Lj5wLMV["cursor"])
	__2nLQ763tFkgAwvH1QSmnnqh3(__QzfA1_MgHwBGTTBizdgA8rkk.__FSW4WCXpupwYSF0KaHCFCNKb.__QECI9RHRtVBcNl93XhYVIrYe, __SYhybfh2zDbHbA2xiqw54ds2.index, int(end[0]) / __jSHCPDm8k9O9CtctnqkQJ6b2, int(end[1]) / __W_7fSiIVO80l6wn6KwvCuoPH, __qxISKxUkOlgCABpQiQoNJGmG[0], PackedInt32Array([__4aSpXjGSBQWDCJod_Lj5wLMV["grade"], 1 if __4aSpXjGSBQWDCJod_Lj5wLMV["is_ap"] else 0, __KA5CkrjLWwYcYE9dBYSOpIVX[0], __KKV0g7zXFqljA8HMczdjy0G1, __zTAYCYe4GIWZJcpks7ZDNyAS, __4aSpXjGSBQWDCJod_Lj5wLMV["HE"], __4aSpXjGSBQWDCJod_Lj5wLMV["owner"]]))
var __N1ilymCfsLddzeuvTHx1qlZw: int = 0
var __gobxGwIVlftvCfJ1fsNzSlj7: Array[__YCYnibBjVPRhMDf3YPwizbkN] = []
var __xQC5OOLEt4J5D0Pcc1mgbzBU: bool = false
var __T3MhJL9nMTQaWMJrYSTIXXqi: PackedInt32Array
func __TyBlH2mrRyRh1_U5lXYpPSlQ(__vnq6MHTSdIU5dtNT2Rlus5Vs: __YdhZSn3k6BLtSITi5naOCb7n, __lqQaZIp4zBdQeCwlHvjbA1gm: Array[int], __yqYIt00W8anX7y_us3wJY7kT: int, __PQbCzG3Zu3LKEi5ERLV40vXQ: int, __4G5UAAInF1QSHm3An3QFlOvw: int, __uL0QHDFqneff2x52QNQteqIa: int, meti_owner: int = -1) -> Array[int]:
	var ___wHPDJJGfLf6KEsJzbtkwhmI: int = __vnq6MHTSdIU5dtNT2Rlus5Vs.target.ap_deck if __PQbCzG3Zu3LKEi5ERLV40vXQ == 1 else __vnq6MHTSdIU5dtNT2Rlus5Vs.target.ap_side
	var __Pb2RxztB5Elax8BvW_keReUv: Array[int] = __nZxK7u5JB3kHTF7XC5Hr9MHe.split(__vnq6MHTSdIU5dtNT2Rlus5Vs.target, __lqQaZIp4zBdQeCwlHvjbA1gm[0], __lqQaZIp4zBdQeCwlHvjbA1gm[1], __yqYIt00W8anX7y_us3wJY7kT, __PQbCzG3Zu3LKEi5ERLV40vXQ, __4G5UAAInF1QSHm3An3QFlOvw, ___wHPDJJGfLf6KEsJzbtkwhmI, __uL0QHDFqneff2x52QNQteqIa, __vnq6MHTSdIU5dtNT2Rlus5Vs.__RZSGss6vMJxzvS6fmWkQMma8)
	if meti_owner >= 0 and meti_owner < __LYNzM9N3A8Dmo_1zq54GljKm.size() and __2ZIL9u7_cM4KOmaAUAdneX5d.meti_is_boosted(__LYNzM9N3A8Dmo_1zq54GljKm[meti_owner]):
		for meti_i: int in 3:
			__Pb2RxztB5Elax8BvW_keReUv[meti_i] = __2ZIL9u7_cM4KOmaAUAdneX5d.meti_gain(__Pb2RxztB5Elax8BvW_keReUv[meti_i])
	var __LHe2XuPbu4zc_5geC0KXP0ku: int = __vnq6MHTSdIU5dtNT2Rlus5Vs.__F41ZT8z_0zKKqYDFwqS1WGTs
	var __AWiMgMx3wKq06KC_EJCPZRNe: int = __vnq6MHTSdIU5dtNT2Rlus5Vs.__zp3VN8122KJqD8VYx2at1x2y(__Pb2RxztB5Elax8BvW_keReUv[0], __Pb2RxztB5Elax8BvW_keReUv[1], __Pb2RxztB5Elax8BvW_keReUv[2], __lqQaZIp4zBdQeCwlHvjbA1gm[3], __PQbCzG3Zu3LKEi5ERLV40vXQ)
	return [__LHe2XuPbu4zc_5geC0KXP0ku - __vnq6MHTSdIU5dtNT2Rlus5Vs.__F41ZT8z_0zKKqYDFwqS1WGTs, __AWiMgMx3wKq06KC_EJCPZRNe]
var __PHRyUPhEHZ95rcQCVAqnc4Y6: Array[Dictionary] = []
var __J7C_o18LIGdZ9b2iqkKpR5o0: = PackedInt64Array()
var __8t25G5WNXpxXjotieTtR4L5d: bool = true
var __VtC8pLMhL6BfWWcFD6bsOCll: = PackedInt32Array()
func ____QC9P4TDwHwfULO6rX_AKV5(__4pSFl1baHRF8yaHNfx8mIWjZ: int, __DdaHa5UeqNMfPx1_V_7LNxL1: __YdhZSn3k6BLtSITi5naOCb7n, __X_7tmZRXpuXBT_QS8pz4_W_1: int, ___5uHhlQzVQCJaSoX2zNrPZ0o: int, __j4CJnRBLhRO6tRW9qJxPa_tY: bool) -> void :
	if __4pSFl1baHRF8yaHNfx8mIWjZ < 0 or __4pSFl1baHRF8yaHNfx8mIWjZ >= __LYNzM9N3A8Dmo_1zq54GljKm.size() or __X_7tmZRXpuXBT_QS8pz4_W_1 <= 0:
		return
	var __DByjMeOJFDCfAiEOuIsTcCYF: __YdhZSn3k6BLtSITi5naOCb7n = __LYNzM9N3A8Dmo_1zq54GljKm[__4pSFl1baHRF8yaHNfx8mIWjZ]
	if __DByjMeOJFDCfAiEOuIsTcCYF.__7OKcEzdMfOdabzyMipWdSzWD == __DdaHa5UeqNMfPx1_V_7LNxL1.__7OKcEzdMfOdabzyMipWdSzWD or __DByjMeOJFDCfAiEOuIsTcCYF.__7OKcEzdMfOdabzyMipWdSzWD < 0 or __DByjMeOJFDCfAiEOuIsTcCYF.__7OKcEzdMfOdabzyMipWdSzWD >= 2:
		return
	var __KJpoDp734l7ff6FEcNr204tG: int = __9E4XvVmzfljiQT1Q9Qiml72N.__lonUiaYfggHujFk5tTX3l0kK(__X_7tmZRXpuXBT_QS8pz4_W_1, __DdaHa5UeqNMfPx1_V_7LNxL1, ___5uHhlQzVQCJaSoX2zNrPZ0o, __j4CJnRBLhRO6tRW9qJxPa_tY)
	__J7C_o18LIGdZ9b2iqkKpR5o0[__DByjMeOJFDCfAiEOuIsTcCYF.__7OKcEzdMfOdabzyMipWdSzWD] += __9E4XvVmzfljiQT1Q9Qiml72N.__ie_sG3gCfb7Xu0YlvdgG_K5T * __KJpoDp734l7ff6FEcNr204tG
	__bLc0ZDHxlrSL7QCGVI55zc6I[__4pSFl1baHRF8yaHNfx8mIWjZ] += __9E4XvVmzfljiQT1Q9Qiml72N.__bLc0ZDHxlrSL7QCGVI55zc6I(__KJpoDp734l7ff6FEcNr204tG, __DByjMeOJFDCfAiEOuIsTcCYF, __DdaHa5UeqNMfPx1_V_7LNxL1)
var __u0nkAKG5lGiEsenIJI6PFvMF: int = 0
var __Jp9a8_iVrNYpIRTSu22QxY8F: __osOG1KsSfr5d06WoVaC5BGTs
func __ovyp70i1JBes2t2GGYYhg5I0(__HH2l8yndmsNWjUY14D9QfXpw: Dictionary, __Jd6AE_rQuhfQucbHrKkodSOp: __YdhZSn3k6BLtSITi5naOCb7n, __TDPJzZCvYgVE63WK3cjruo68: int, __Vd3AyRJ4F_y4kZKSkz4aqdMV: int, __OzpNwoyI3r72pIcVlpSgTN3w: Vector2i) -> void :
	var __qvadXkQk561npvw1ktxzFxZG: int = __EaiCL_s7Is8n8XhLMgCmd8bh + __t2UdGLb5AjoD9DJacXSIpDUA if __Vd3AyRJ4F_y4kZKSkz4aqdMV < 0 else int(__HH2l8yndmsNWjUY14D9QfXpw["cursor"])
	var __wDT6ohMZQZ8dBnrw3e1tH3G8: Array[int] = __nZxK7u5JB3kHTF7XC5Hr9MHe.__iLUTtdlJz90LVGliQf9aQ68R(__Jd6AE_rQuhfQucbHrKkodSOp.target, __T3MhJL9nMTQaWMJrYSTIXXqi, __qvadXkQk561npvw1ktxzFxZG, __0QiGqbYBLZEUENpkfN6eZqIr.__KfqT3g4u0J2svd5Kj6xbywDW, 0, __TDPJzZCvYgVE63WK3cjruo68, 2, __Vd3AyRJ4F_y4kZKSkz4aqdMV, 0)
	var __Pn69dN1WLzZTeNHYNviZJv3L: int = __Jd6AE_rQuhfQucbHrKkodSOp.__F41ZT8z_0zKKqYDFwqS1WGTs
	var __Sq1gB7Cz6bgvcyGvzb9SmACg: Array[int] = __TyBlH2mrRyRh1_U5lXYpPSlQ(__Jd6AE_rQuhfQucbHrKkodSOp, __wDT6ohMZQZ8dBnrw3e1tH3G8, __0QiGqbYBLZEUENpkfN6eZqIr.__KfqT3g4u0J2svd5Kj6xbywDW, 2, __Vd3AyRJ4F_y4kZKSkz4aqdMV, 0, int(__HH2l8yndmsNWjUY14D9QfXpw["owner"]))
	__UfEKTxE0kEIGUl7MshOPCLso(int(__HH2l8yndmsNWjUY14D9QfXpw["owner"]), __Jd6AE_rQuhfQucbHrKkodSOp, __Sq1gB7Cz6bgvcyGvzb9SmACg[0])
	____QC9P4TDwHwfULO6rX_AKV5(int(__HH2l8yndmsNWjUY14D9QfXpw["owner"]), __Jd6AE_rQuhfQucbHrKkodSOp, __9E4XvVmzfljiQT1Q9Qiml72N.__YuZeYY7hy6d4LpvCdwH08LkS(__Sq1gB7Cz6bgvcyGvzb9SmACg[1], __Pn69dN1WLzZTeNHYNviZJv3L, __Jd6AE_rQuhfQucbHrKkodSOp.__RZSGss6vMJxzvS6fmWkQMma8, 0, false), 0, true)
	if __wDT6ohMZQZ8dBnrw3e1tH3G8[0] != __nZxK7u5JB3kHTF7XC5Hr9MHe.___pHbcRk5biyJr9D8s1t3RC5B.__1nO8cAfZDr9W3jpcIyrUyDBq:
		__Jd6AE_rQuhfQucbHrKkodSOp.__eApL0Mnhi3qPFjXtuxe0KTtH(__OzpNwoyI3r72pIcVlpSgTN3w)
	__B3bsjI8m3TLvZt0xBFiWVrDM(__Jd6AE_rQuhfQucbHrKkodSOp, __wDT6ohMZQZ8dBnrw3e1tH3G8, __qvadXkQk561npvw1ktxzFxZG)
	__2nLQ763tFkgAwvH1QSmnnqh3(__QzfA1_MgHwBGTTBizdgA8rkk.__FSW4WCXpupwYSF0KaHCFCNKb.__QECI9RHRtVBcNl93XhYVIrYe, __Jd6AE_rQuhfQucbHrKkodSOp.index, __OzpNwoyI3r72pIcVlpSgTN3w.x, __OzpNwoyI3r72pIcVlpSgTN3w.y, __Sq1gB7Cz6bgvcyGvzb9SmACg[0], PackedInt32Array([3, 0, __wDT6ohMZQZ8dBnrw3e1tH3G8[0], 2, 0, __TDPJzZCvYgVE63WK3cjruo68, __HH2l8yndmsNWjUY14D9QfXpw["owner"], int(__HH2l8yndmsNWjUY14D9QfXpw.get("code", 1)) if __Vd3AyRJ4F_y4kZKSkz4aqdMV == 0 else 2]))
func __ofPJrMgW6ShEieMKY9H64SqU(__Vyl_YhGgXOFy7ptnNSXBqOTZ: Dictionary, __oPS0zQ84VVc7jGNLp_fzU1MT: int) -> void :
	__Vyl_YhGgXOFy7ptnNSXBqOTZ["alive"] = false
	__2nLQ763tFkgAwvH1QSmnnqh3(__QzfA1_MgHwBGTTBizdgA8rkk.__FSW4WCXpupwYSF0KaHCFCNKb.__qZ3wnnAFJS3SUu1E5CtR2tWW, __Vyl_YhGgXOFy7ptnNSXBqOTZ["owner"], int(__Vyl_YhGgXOFy7ptnNSXBqOTZ["x"]) / __jSHCPDm8k9O9CtctnqkQJ6b2, int(__Vyl_YhGgXOFy7ptnNSXBqOTZ["y"]) / __W_7fSiIVO80l6wn6KwvCuoPH, __Vyl_YhGgXOFy7ptnNSXBqOTZ["grade"], 
		PackedInt32Array([int(__Vyl_YhGgXOFy7ptnNSXBqOTZ["h"]) / 400, __oPS0zQ84VVc7jGNLp_fzU1MT, int(__Vyl_YhGgXOFy7ptnNSXBqOTZ.get("aa_gun", 0))]))
func __Yq2X83AEQtIErwzrOVjQzqag() -> int:
	__UhGbxyY1hNuGzD53VHzu_vzw += 1
	return __UhGbxyY1hNuGzD53VHzu_vzw
func __6UoHldZawwvQeZTuLJQHRrnw() -> int:
	var __CkWCdfH97PzWPoCD1cpG92kA: Array[int] = [0, 0]
	for s: __YdhZSn3k6BLtSITi5naOCb7n in __LYNzM9N3A8Dmo_1zq54GljKm:
		if s.state == __lAo0PsogaUvqHw4muTzPsHiR.__pRO7nOY10o2GAU3KzWQvIvwY and s.__F41ZT8z_0zKKqYDFwqS1WGTs > 0:
			__CkWCdfH97PzWPoCD1cpG92kA[s.__7OKcEzdMfOdabzyMipWdSzWD] += 1
	if __CkWCdfH97PzWPoCD1cpG92kA[0] > 0 and __CkWCdfH97PzWPoCD1cpG92kA[1] > 0:
		return 0
	if __CkWCdfH97PzWPoCD1cpG92kA[0] > 0:
		return 1
	if __CkWCdfH97PzWPoCD1cpG92kA[1] > 0:
		return 2
	return 3
var __B6EBQXlVU15lz9jEUjjfdaw4: = PackedInt64Array()
var __LYNzM9N3A8Dmo_1zq54GljKm: Array[__YdhZSn3k6BLtSITi5naOCb7n] = []
const __d8xiL_JJ6KRqOmUd2Sqej_FE: = 4
var __EaiCL_s7Is8n8XhLMgCmd8bh: int = 0
var __t2UdGLb5AjoD9DJacXSIpDUA: int = 0
const __12ToK7nPtbWRgXmYD4WWUesJ: = 5
func __IC7N1I1QJO8YNIQnm7tL0_rG(__XYztTGENUGX075VRAD0EDBoZ: int, code: int, __JSak9YfluOriduPICfK_Vcon: PackedByteArray = PackedByteArray()) -> void :
	var __5DAE46tUhS2UGxhlVTdVrzHo: int = __u0nkAKG5lGiEsenIJI6PFvMF + __lAo0PsogaUvqHw4muTzPsHiR.__BvjYOp5V9D51FL_PzBjk4Wlf
	while __g5GsOdGtwfiw4c8qS32PmFoT(__XYztTGENUGX075VRAD0EDBoZ, __5DAE46tUhS2UGxhlVTdVrzHo):
		__5DAE46tUhS2UGxhlVTdVrzHo += 1
	__VTWOx4yuLhyJ3SI2VTF9IvPN.append([__XYztTGENUGX075VRAD0EDBoZ, code, __JSak9YfluOriduPICfK_Vcon, __5DAE46tUhS2UGxhlVTdVrzHo])
var ___qFCN2viGM2bPW1uGV9qys9h: __bzxMmNAcE_RKMny5gklgDglw
func __B3bsjI8m3TLvZt0xBFiWVrDM(__ujAKOWP61ipuLpuydL162zYv: __YdhZSn3k6BLtSITi5naOCb7n, __sR81kOVEueiKWkrePhNctjWI: Array[int], __efjVaYstce086kQ5tMHyw6pw: int) -> void :
	if __sR81kOVEueiKWkrePhNctjWI[2] == 0 or not __ujAKOWP61ipuLpuydL162zYv.__NELIelBEafKRGQultNqYAbM7.has("model") or __ujAKOWP61ipuLpuydL162zYv.state != __lAo0PsogaUvqHw4muTzPsHiR.__pRO7nOY10o2GAU3KzWQvIvwY:
		return
	var __v35A3QtvF21aLfOtJGSedec8: int = __T3MhJL9nMTQaWMJrYSTIXXqi[__Irz9hiGcyslSDsJT8BenfEt2.__pGLr1ud1V6XsMMJoSyeTRFjY(__efjVaYstce086kQ5tMHyw6pw) % __T3MhJL9nMTQaWMJrYSTIXXqi.size()]
	var __1fUaKbAr4TNtSAYSbmcjRgHz: int = 10000 / (int(__ujAKOWP61ipuLpuydL162zYv.__NELIelBEafKRGQultNqYAbM7["engine_a"]) + 100) * 50 / 100
	if __v35A3QtvF21aLfOtJGSedec8 % 10000 < __1fUaKbAr4TNtSAYSbmcjRgHz:
		__NYbIaW78BNqdaS0BgoYwqAci.__zQ9E7mate78Irh8XhqTJhd6J(__ujAKOWP61ipuLpuydL162zYv.__NELIelBEafKRGQultNqYAbM7, __v35A3QtvF21aLfOtJGSedec8 % 250)
		__p4BfRGGYcGsflWTqyV1NyITt(__ujAKOWP61ipuLpuydL162zYv, __NYbIaW78BNqdaS0BgoYwqAci.__oj0fZgh_8Nb6kwHfmU6ttWyD.__pExmHZbh1pnHLlW16eo3jrv8)
		__ujAKOWP61ipuLpuydL162zYv.__NELIelBEafKRGQultNqYAbM7["evt"] = __NYbIaW78BNqdaS0BgoYwqAci.__oj0fZgh_8Nb6kwHfmU6ttWyD.NONE
func __wIebi2RHJicnHeiUm6xYwBpd(__w8j8PTTDCCvr4gyqCqkt5x8M: int, a: __YCYnibBjVPRhMDf3YPwizbkN, value: int = 0, __zEecFiZlPxWo68vCTyDNcA2H: int = -1) -> void :
	var __pCIeQSULvCDEOvDRMNYyfGaz: bool = __w8j8PTTDCCvr4gyqCqkt5x8M == __QzfA1_MgHwBGTTBizdgA8rkk.__FSW4WCXpupwYSF0KaHCFCNKb.__Z4zb38Z0p0n5agncEYj9TLFK or __w8j8PTTDCCvr4gyqCqkt5x8M == __QzfA1_MgHwBGTTBizdgA8rkk.__FSW4WCXpupwYSF0KaHCFCNKb.__45wf1EUrEd2h1nLzhl4r4KPt or __w8j8PTTDCCvr4gyqCqkt5x8M == __QzfA1_MgHwBGTTBizdgA8rkk.__FSW4WCXpupwYSF0KaHCFCNKb.__P9cFBk_3FslN6JJuhJMb1tym or __w8j8PTTDCCvr4gyqCqkt5x8M == __QzfA1_MgHwBGTTBizdgA8rkk.__FSW4WCXpupwYSF0KaHCFCNKb.__7u4clDqtCMcaEbPT4aWekmiB or __w8j8PTTDCCvr4gyqCqkt5x8M == __QzfA1_MgHwBGTTBizdgA8rkk.__FSW4WCXpupwYSF0KaHCFCNKb.__yHmb2E8eufNCblP8NvDELVKl
	if __8t25G5WNXpxXjotieTtR4L5d or __pCIeQSULvCDEOvDRMNYyfGaz:
		__SmXVMct8mHIMx6HdC4TMDErT.append(__QzfA1_MgHwBGTTBizdgA8rkk.__YCYCLM7wn8U5KL1mw3RC4lIU(__w8j8PTTDCCvr4gyqCqkt5x8M, __u0nkAKG5lGiEsenIJI6PFvMF, a.owner, a.__EsOQaggwtLEnMAHn6g7H_r7O(), a.__caDHon68LplNQ04cMl2MMJ71(), value, 
			PackedInt32Array([a.id, a.owner, a.__knUj879QWUN8clA4_f5YGzfw, a.type, __zEecFiZlPxWo68vCTyDNcA2H, a.value])))
var __VTWOx4yuLhyJ3SI2VTF9IvPN: Array[Array] = []
var __ojs8o4FAfa94EAyfqhpeTDrg: bool = false
var __pZlzu4JO6f_sgap1yOU60LoH: Array[Dictionary] = []
func _init(__v76Lhtgrz_iVKdquzHRF5leH: __bzxMmNAcE_RKMny5gklgDglw, __e6VNihnB0ewY8n5WmQwCS1Af: Dictionary, __vQWlzZpPjXtf6u1otqg2MCNR: Array[Dictionary]) -> void :
	___qFCN2viGM2bPW1uGV9qys9h = __v76Lhtgrz_iVKdquzHRF5leH
	terrain = __NYbIaW78BNqdaS0BgoYwqAci.__O1Urlr6IdUTnFWvioe6wcQrt.new(__e6VNihnB0ewY8n5WmQwCS1Af["cols"], __e6VNihnB0ewY8n5WmQwCS1Af["rows"])
	for __dp0rqR5HPI5WGbsmc5dsQT4D: Variant in __e6VNihnB0ewY8n5WmQwCS1Af.get("islands", []):
		var r: Array = __dp0rqR5HPI5WGbsmc5dsQT4D
		for __pwafYQfLuiwYV2Eh2zs_z9FP: int in range(int(r[1]), int(r[3]) + 1):
			for __Hgi24Uiq14_MAz56m4IBqq5f: int in range(int(r[0]), int(r[2]) + 1):
				terrain.__gqBKCXcqTt4K3Vmce3XR6LHx(__Hgi24Uiq14_MAz56m4IBqq5f, __pwafYQfLuiwYV2Eh2zs_z9FP)
	for __GYP87zbjm5o54Ou0Yl2TyfR5: int in __vQWlzZpPjXtf6u1otqg2MCNR.size():
		__LYNzM9N3A8Dmo_1zq54GljKm.append(__2ZIL9u7_cM4KOmaAUAdneX5d.__CqzDpplM5ETWU2SW2VGKogkg(___qFCN2viGM2bPW1uGV9qys9h, __vQWlzZpPjXtf6u1otqg2MCNR[__GYP87zbjm5o54Ou0Yl2TyfR5], terrain, __GYP87zbjm5o54Ou0Yl2TyfR5))
	for s: __YdhZSn3k6BLtSITi5naOCb7n in __LYNzM9N3A8Dmo_1zq54GljKm:
		__NTPi8_rHrS8Qu6hcZEXu3a9n.append(s.__NqcLKvQgaJD_pE3JD6vSe71E)
		__GrLwyamZ57OX31Lkvv8RpSj0 = __GrLwyamZ57OX31Lkvv8RpSj0 or s.__g7JC3EJmfsOWnIyqLGGB93eB != null
		__TPIGeUdFb_AXx4vCwcpTGg3n = __TPIGeUdFb_AXx4vCwcpTGg3n or not s.__AReCBHrBYt7dD7H_WiK9Tklz.is_empty()
		__xQC5OOLEt4J5D0Pcc1mgbzBU = __xQC5OOLEt4J5D0Pcc1mgbzBU or s.__sfrhGgpP8JHW6nvd0GQRC91I
	__VtC8pLMhL6BfWWcFD6bsOCll.resize(__LYNzM9N3A8Dmo_1zq54GljKm.size())
	for s: __YdhZSn3k6BLtSITi5naOCb7n in __LYNzM9N3A8Dmo_1zq54GljKm:
		s.__kWx_ghjWrsvKfbTBZsiahQQd.resize(__LYNzM9N3A8Dmo_1zq54GljKm.size())
	__bLc0ZDHxlrSL7QCGVI55zc6I.resize(__LYNzM9N3A8Dmo_1zq54GljKm.size())
	__J7C_o18LIGdZ9b2iqkKpR5o0.resize(2)
	__B6EBQXlVU15lz9jEUjjfdaw4.resize(2)
	for s: __YdhZSn3k6BLtSITi5naOCb7n in __LYNzM9N3A8Dmo_1zq54GljKm:
		if s.__7OKcEzdMfOdabzyMipWdSzWD >= 0 and s.__7OKcEzdMfOdabzyMipWdSzWD < 2:
			__B6EBQXlVU15lz9jEUjjfdaw4[s.__7OKcEzdMfOdabzyMipWdSzWD] += __2ZIL9u7_cM4KOmaAUAdneX5d.meti_reward_hp(s)
	__T3MhJL9nMTQaWMJrYSTIXXqi = __3RMEFseeX7lwG1B9fZj8jUzH.generate(__e6VNihnB0ewY8n5WmQwCS1Af["seed0"])
	__Jp9a8_iVrNYpIRTSu22QxY8F = __osOG1KsSfr5d06WoVaC5BGTs.new(terrain.__9Zy5NwQKLR2WXbpStDOauEMz, terrain.__0xMwoIVfT_j6GZoLP_HkB6nE)
	__Jp9a8_iVrNYpIRTSu22QxY8F.__kC6zD903kIOB35eRqjx8Rhn6(self)
	__f8I9gUlf4vPw6xR4KNFvw66k = clampi(int(__e6VNihnB0ewY8n5WmQwCS1Af.get("difficulty", __lAo0PsogaUvqHw4muTzPsHiR.__nbNt7X55zG6_WZmrWTE7nXlh)), __lAo0PsogaUvqHw4muTzPsHiR.___2WtfK17HDU4ZlLEJlLUcifm, __lAo0PsogaUvqHw4muTzPsHiR.__nbNt7X55zG6_WZmrWTE7nXlh)
	__BW1tyWiDgrdOHeYq159RRkr4 = __FbfcZh7zipvK02thKpA13yoN.new()
	__BW1tyWiDgrdOHeYq159RRkr4.__UVnQBnVztacNlIM8ny7FpkJG(self)
func step(__ifpFRlrXIfGsud9Bj0fCLtyZ: bool = true) -> void :
	__8t25G5WNXpxXjotieTtR4L5d = __ifpFRlrXIfGsud9Bj0fCLtyZ
	__nOE6zCjalZI4xwRPUBrEgF5F()
	if __GrLwyamZ57OX31Lkvv8RpSj0:
		for s: __YdhZSn3k6BLtSITi5naOCb7n in __LYNzM9N3A8Dmo_1zq54GljKm:
			if s.state == __lAo0PsogaUvqHw4muTzPsHiR.__pRO7nOY10o2GAU3KzWQvIvwY and s.__g7JC3EJmfsOWnIyqLGGB93eB != null:
				__cV1TfO9LYjqVJIVXjDHEK396.___ifkpkcx4U2OpwQGcnHHye7Z(s)
	for s: __YdhZSn3k6BLtSITi5naOCb7n in __LYNzM9N3A8Dmo_1zq54GljKm:
		s.__kC6zD903kIOB35eRqjx8Rhn6(self)
	if __GrLwyamZ57OX31Lkvv8RpSj0 and (__EaiCL_s7Is8n8XhLMgCmd8bh + __t2UdGLb5AjoD9DJacXSIpDUA) % 4 == 0:
		for s: __YdhZSn3k6BLtSITi5naOCb7n in __LYNzM9N3A8Dmo_1zq54GljKm:
			if s.state == __lAo0PsogaUvqHw4muTzPsHiR.__pRO7nOY10o2GAU3KzWQvIvwY:
				__cV1TfO9LYjqVJIVXjDHEK396.__v48U0So26gp9fuKCktN7vwEn(self, s)
	for s: __YdhZSn3k6BLtSITi5naOCb7n in __LYNzM9N3A8Dmo_1zq54GljKm:
		s.__KMQO2Dqf4U7hxuzv7dYCmrfF()
	if not __gobxGwIVlftvCfJ1fsNzSlj7.is_empty():
		for a: __YCYnibBjVPRhMDf3YPwizbkN in __gobxGwIVlftvCfJ1fsNzSlj7:
			if a.__dRotcb2ldVZQLm2YDYWTTU9J:
				__cV1TfO9LYjqVJIVXjDHEK396.update(self, a)
		var __SxI5Vyhhafgs09bWLT2Ngh3p: Array[__YCYnibBjVPRhMDf3YPwizbkN] = []
		for a: __YCYnibBjVPRhMDf3YPwizbkN in __gobxGwIVlftvCfJ1fsNzSlj7:
			if a.__dRotcb2ldVZQLm2YDYWTTU9J:
				__SxI5Vyhhafgs09bWLT2Ngh3p.append(a)
		__gobxGwIVlftvCfJ1fsNzSlj7 = __SxI5Vyhhafgs09bWLT2Ngh3p
	for __UE_z8BEAAkEXu0RAcQipqXNl: Dictionary in ___1qGksmzNRubFckXIU7Ogyjh:
		if __UE_z8BEAAkEXu0RAcQipqXNl["alive"]:
			__3CvsQr5D8yh_q4kbKcqfckGU(__UE_z8BEAAkEXu0RAcQipqXNl)
	var __L9OlZia800ETM5IzWJ7AjK8G: Array[Dictionary] = []
	for __G4xP8hhhzBQZ4t1gvry7gIvX: Dictionary in ___1qGksmzNRubFckXIU7Ogyjh:
		if __G4xP8hhhzBQZ4t1gvry7gIvX["alive"]:
			__L9OlZia800ETM5IzWJ7AjK8G.append(__G4xP8hhhzBQZ4t1gvry7gIvX)
	___1qGksmzNRubFckXIU7Ogyjh = __L9OlZia800ETM5IzWJ7AjK8G
	if not __PHRyUPhEHZ95rcQCVAqnc4Y6.is_empty():
		for __61G26UnX28w6f13lYYS3NltH: Dictionary in __PHRyUPhEHZ95rcQCVAqnc4Y6:
			__0QiGqbYBLZEUENpkfN6eZqIr.step(self, __61G26UnX28w6f13lYYS3NltH)
		var __0Imu14Dc6cLId68I40Hm40TH: Array[Dictionary] = []
		for __JdWM7ylpjTWia8Mofu6S1Wgq: Dictionary in __PHRyUPhEHZ95rcQCVAqnc4Y6:
			if int(__JdWM7ylpjTWia8Mofu6S1Wgq["state"]) != __0QiGqbYBLZEUENpkfN6eZqIr.State.__6UYfqniV1sSjlgtQyYOzUEuP:
				__0Imu14Dc6cLId68I40Hm40TH.append(__JdWM7ylpjTWia8Mofu6S1Wgq)
		__PHRyUPhEHZ95rcQCVAqnc4Y6 = __0Imu14Dc6cLId68I40Hm40TH
	if not __pZlzu4JO6f_sgap1yOU60LoH.is_empty():
		for b: Dictionary in __pZlzu4JO6f_sgap1yOU60LoH:
			__i5VSVLoXQftICZ42J3cK2_5r.step(self, b)
		var __YNXavkVAcZbSq0eVtTspng2P: Array[Dictionary] = []
		for b: Dictionary in __pZlzu4JO6f_sgap1yOU60LoH:
			if b["alive"]:
				__YNXavkVAcZbSq0eVtTspng2P.append(b)
		__pZlzu4JO6f_sgap1yOU60LoH = __YNXavkVAcZbSq0eVtTspng2P
	__Jp9a8_iVrNYpIRTSu22QxY8F.__kC6zD903kIOB35eRqjx8Rhn6(self)
	if __u0nkAKG5lGiEsenIJI6PFvMF % __FbfcZh7zipvK02thKpA13yoN.__h1dHVNyByTRE2gK_yUxgW8WS == 0:
		for s: __YdhZSn3k6BLtSITi5naOCb7n in __LYNzM9N3A8Dmo_1zq54GljKm:
			var __BCEmIWLwQYuVIl4PDlt9r24J: PackedInt32Array = s.__kWx_ghjWrsvKfbTBZsiahQQd
			for __ob7JQD9uXmSTprcnD_ADwGBK: int in __BCEmIWLwQYuVIl4PDlt9r24J.size():
				__BCEmIWLwQYuVIl4PDlt9r24J[__ob7JQD9uXmSTprcnD_ADwGBK] = __BCEmIWLwQYuVIl4PDlt9r24J[__ob7JQD9uXmSTprcnD_ADwGBK] * __FbfcZh7zipvK02thKpA13yoN.__2_hfYDCAZvSCO2HoTmW5HjKI / __FbfcZh7zipvK02thKpA13yoN.__aCXgjVcRcAdCwQ8lyLrwpR4F
			s.__kWx_ghjWrsvKfbTBZsiahQQd = __BCEmIWLwQYuVIl4PDlt9r24J
	for s: __YdhZSn3k6BLtSITi5naOCb7n in __LYNzM9N3A8Dmo_1zq54GljKm:
		if s.__KLxhKPISj_AUmBVDjcFeRqL7 != "" and s.state == __lAo0PsogaUvqHw4muTzPsHiR.__pRO7nOY10o2GAU3KzWQvIvwY:
			__BW1tyWiDgrdOHeYq159RRkr4.__WPEWrmYcW3Wtflky6_s8B6qC(self, s)
	__u0nkAKG5lGiEsenIJI6PFvMF += 1
	__t2UdGLb5AjoD9DJacXSIpDUA = (__t2UdGLb5AjoD9DJacXSIpDUA + 1) % __lAo0PsogaUvqHw4muTzPsHiR.__BvjYOp5V9D51FL_PzBjk4Wlf
static func __u5LsEZXAUJO5yjK7IObacEwF(__e1AHKAaeP_1TAPMsxN4yEKKu: int, __JRfBKQwnmKHsOgLIPMwZIKAN: PackedInt32Array, __4lc2EzS3ovvAaBhGljlgnU09: int) -> int:
	var __Ub7L6tuncRTWAuiGZ458rJE9: int = 3 * __e1AHKAaeP_1TAPMsxN4yEKKu + 900
	var __Pf4nVtoo2lD44iXOcBkpZqWb: int = __JRfBKQwnmKHsOgLIPMwZIKAN[__4lc2EzS3ovvAaBhGljlgnU09 % __JRfBKQwnmKHsOgLIPMwZIKAN.size()] %__Ub7L6tuncRTWAuiGZ458rJE9 + 1
	return 1 if __Pf4nVtoo2lD44iXOcBkpZqWb <= 4 * __e1AHKAaeP_1TAPMsxN4yEKKu else 2
func __00bBZDN3MIh6G8fMyPRVYOsa(owner: __YdhZSn3k6BLtSITi5naOCb7n, __0CLA3iyo5O02O6Azswkn9GM2: int) -> void :
	var __28mBbcRg1caJSwf1acZojod3: Dictionary = owner.__bFJ1csmbpVraScDCZhw1ETZ5[__0CLA3iyo5O02O6Azswkn9GM2]
	var __s3h54aLc5O5PMzIWEfMsBdlg: Vector2i = owner.__oc4DIMhqXqRDsyYDHkfod1e6(__28mBbcRg1caJSwf1acZojod3)
	var __9eW6KY9dbt1wXa1Tkhl6GzU4: Array[Dictionary] = __0QiGqbYBLZEUENpkfN6eZqIr.__lWuahpWVNpSTiO1pFrDGM69k(self, owner, __0CLA3iyo5O02O6Azswkn9GM2, __s3h54aLc5O5PMzIWEfMsBdlg, owner.__Rzlu0K6FmW_AJtyGtfyruX3f(__28mBbcRg1caJSwf1acZojod3))
	for __aTOlvg_OVBHB4byztqYZQec4: int in __9eW6KY9dbt1wXa1Tkhl6GzU4.size():
		var __5rKw1Hz3nygO23UTuTDtVJvy: Dictionary = __9eW6KY9dbt1wXa1Tkhl6GzU4[__aTOlvg_OVBHB4byztqYZQec4]
		__PHRyUPhEHZ95rcQCVAqnc4Y6.append(__5rKw1Hz3nygO23UTuTDtVJvy)
		if __5rKw1Hz3nygO23UTuTDtVJvy.get("deep", false):
			continue
		var __oCcONWPW7vqge5yVLkZE1lCj: Vector2i = __5rKw1Hz3nygO23UTuTDtVJvy["p1"]
		__2nLQ763tFkgAwvH1QSmnnqh3(__QzfA1_MgHwBGTTBizdgA8rkk.__FSW4WCXpupwYSF0KaHCFCNKb.__FQpHhLpGeC7GzvpE2kUyp8v9, owner.index, __oCcONWPW7vqge5yVLkZE1lCj.x, __oCcONWPW7vqge5yVLkZE1lCj.y, __5rKw1Hz3nygO23UTuTDtVJvy["dir36"], 
			PackedInt32Array([__0CLA3iyo5O02O6Azswkn9GM2, __aTOlvg_OVBHB4byztqYZQec4, __5rKw1Hz3nygO23UTuTDtVJvy["id"]]))
const __4Pcd1OiOt0B8w5S3xs6Gpm_P: = 1
var __9rro_RsNE1gdH3AkrS5cj0hH: int = 0
func __Uo0uDMT1gnhOPcJf1aAPCwxL(b: Dictionary, __XtF_W8sv9BOPlOZ9b4aG7lfS: __YdhZSn3k6BLtSITi5naOCb7n, __Zj1_pPYucv6hIeyLHM0jR335: int) -> void :
	var __CUTL0pAZWF6JhqASwDEiqZ3z: int = __EaiCL_s7Is8n8XhLMgCmd8bh + __t2UdGLb5AjoD9DJacXSIpDUA
	var __q8VEb8Pcf2KgGPjJPCSljJSb: Array[int] = __nZxK7u5JB3kHTF7XC5Hr9MHe.__iLUTtdlJz90LVGliQf9aQ68R(__XtF_W8sv9BOPlOZ9b4aG7lfS.target, __T3MhJL9nMTQaWMJrYSTIXXqi, __CUTL0pAZWF6JhqASwDEiqZ3z, __0QiGqbYBLZEUENpkfN6eZqIr.__KfqT3g4u0J2svd5Kj6xbywDW, 0, __Zj1_pPYucv6hIeyLHM0jR335, 2, -1, b["ms"])
	var __qI5K6Fd7HbFOYEpRC1QyLllm: int = __XtF_W8sv9BOPlOZ9b4aG7lfS.__F41ZT8z_0zKKqYDFwqS1WGTs
	var __DHfywypSZUlBEwawD7ddedXV: Array[int] = __TyBlH2mrRyRh1_U5lXYpPSlQ(__XtF_W8sv9BOPlOZ9b4aG7lfS, __q8VEb8Pcf2KgGPjJPCSljJSb, __0QiGqbYBLZEUENpkfN6eZqIr.__KfqT3g4u0J2svd5Kj6xbywDW, 2, -1, 0, int(b["owner"]))
	__UfEKTxE0kEIGUl7MshOPCLso(int(b["owner"]), __XtF_W8sv9BOPlOZ9b4aG7lfS, __DHfywypSZUlBEwawD7ddedXV[0])
	____QC9P4TDwHwfULO6rX_AKV5(int(b["owner"]), __XtF_W8sv9BOPlOZ9b4aG7lfS, __9E4XvVmzfljiQT1Q9Qiml72N.__YuZeYY7hy6d4LpvCdwH08LkS(__DHfywypSZUlBEwawD7ddedXV[1], __qI5K6Fd7HbFOYEpRC1QyLllm, __XtF_W8sv9BOPlOZ9b4aG7lfS.__RZSGss6vMJxzvS6fmWkQMma8, 0, false), 0, true)
	__B3bsjI8m3TLvZt0xBFiWVrDM(__XtF_W8sv9BOPlOZ9b4aG7lfS, __q8VEb8Pcf2KgGPjJPCSljJSb, __CUTL0pAZWF6JhqASwDEiqZ3z)
	__2nLQ763tFkgAwvH1QSmnnqh3(__QzfA1_MgHwBGTTBizdgA8rkk.__FSW4WCXpupwYSF0KaHCFCNKb.__QECI9RHRtVBcNl93XhYVIrYe, __XtF_W8sv9BOPlOZ9b4aG7lfS.index, int(b["x"]), int(b["y"]), __DHfywypSZUlBEwawD7ddedXV[0], PackedInt32Array([3, 0, __q8VEb8Pcf2KgGPjJPCSljJSb[0], 2, 0, __Zj1_pPYucv6hIeyLHM0jR335, b["owner"], 2]))
func __JYxJx4zlqiQBArRmmnWoLfZB() -> int:
	__N1ilymCfsLddzeuvTHx1qlZw += 1
	return __N1ilymCfsLddzeuvTHx1qlZw
func __5qXTJOmsZn24MQnA1EmYdcbg(a: __YCYnibBjVPRhMDf3YPwizbkN, __dSLCFjT_KMtWw4qycftS4tjx: __YdhZSn3k6BLtSITi5naOCb7n, __HpEhYLSZSa9AglD_30zlO51s: int, __8l8gFJgPIyEHOVJnyP1bGqTY: Array[int], __GZXN9F9m9n0AxvuUJuA25o8_: int) -> void :
	__2nLQ763tFkgAwvH1QSmnnqh3(__QzfA1_MgHwBGTTBizdgA8rkk.__FSW4WCXpupwYSF0KaHCFCNKb.__QECI9RHRtVBcNl93XhYVIrYe, __dSLCFjT_KMtWw4qycftS4tjx.index, a.__EsOQaggwtLEnMAHn6g7H_r7O(), a.__caDHon68LplNQ04cMl2MMJ71(), __GZXN9F9m9n0AxvuUJuA25o8_, 
		PackedInt32Array([2, 0, __8l8gFJgPIyEHOVJnyP1bGqTY[0], 1, 0, __HpEhYLSZSa9AglD_30zlO51s, a.owner]))
	__wIebi2RHJicnHeiUm6xYwBpd(__QzfA1_MgHwBGTTBizdgA8rkk.__FSW4WCXpupwYSF0KaHCFCNKb.__xk8jBvS0AnE9BlXf0u9T8gb1, a, __dSLCFjT_KMtWw4qycftS4tjx.index)
var __BW1tyWiDgrdOHeYq159RRkr4: __FbfcZh7zipvK02thKpA13yoN
var ___1qGksmzNRubFckXIU7Ogyjh: Array[Dictionary] = []
func __SDO_gx_r7X0a5aDqKCZQvEOl(owner: __YdhZSn3k6BLtSITi5naOCb7n, __cX0xvLjFykbKvHMIPeFnfm2N: Dictionary, __dnYO7JVMsVgfUPrhE8Ojoeb1: int, __JUt_JEjNw03F8dcqrZqlJar4: int = 0, 
		__zduRQYoHM3TaD5NW0SfGL24h: Vector2i = Vector2i.ZERO, __7hRvt_NNnxPqd4IY_zphbRg_: int = 0, __kRE5CuE8PMoYmpp5DxDIL9MS: int = 0) -> void :
	var __0_Y6Vls3SzMp6OPxdu8g33cn: Dictionary = owner.__BJReFJ4ugditvprP9JFCx5S2[__dnYO7JVMsVgfUPrhE8Ojoeb1] if __dnYO7JVMsVgfUPrhE8Ojoeb1 < owner.__BJReFJ4ugditvprP9JFCx5S2.size() else owner.__BJReFJ4ugditvprP9JFCx5S2[0]
	var __cnI1dDFEnFwVyQu5xxsnKTeU: Dictionary = __0_Y6Vls3SzMp6OPxdu8g33cn["shell"] if int(__0_Y6Vls3SzMp6OPxdu8g33cn.get("cargo", 0)) == 0 else __0_Y6Vls3SzMp6OPxdu8g33cn.get("shell_b", __0_Y6Vls3SzMp6OPxdu8g33cn["shell"])
	var __dLyZbWz0IJWzoffsa2PZaWaF: = {
		"x": __cX0xvLjFykbKvHMIPeFnfm2N["x"], "y": __cX0xvLjFykbKvHMIPeFnfm2N["y"], "h": __cX0xvLjFykbKvHMIPeFnfm2N["h"], 
		"vx": __cX0xvLjFykbKvHMIPeFnfm2N["vx"], "vy": __cX0xvLjFykbKvHMIPeFnfm2N["vy"], "vz": __cX0xvLjFykbKvHMIPeFnfm2N["vz"], 
		"owner": owner.index, 
		"t0": __cnI1dDFEnFwVyQu5xxsnKTeU["t0"], "kind": __cnI1dDFEnFwVyQu5xxsnKTeU["kind"], "Ms": __cnI1dDFEnFwVyQu5xxsnKTeU["Ms"], "Ca": __cnI1dDFEnFwVyQu5xxsnKTeU["Ca"], 
		"c1cc": __cnI1dDFEnFwVyQu5xxsnKTeU["c1cc"], "grade": __cnI1dDFEnFwVyQu5xxsnKTeU["grade"], "acc70": __0_Y6Vls3SzMp6OPxdu8g33cn["acc70"], 
		"frames": 0, "alive": true, "gun_idx": __dnYO7JVMsVgfUPrhE8Ojoeb1, "aa_gun": int(__0_Y6Vls3SzMp6OPxdu8g33cn.get("aa", 0)), 
	}
	var __OWyArjwXfjMwWqZgZ8AssqHz: int = __EaiCL_s7Is8n8XhLMgCmd8bh + __t2UdGLb5AjoD9DJacXSIpDUA + ___1qGksmzNRubFckXIU7Ogyjh.size()
	var __JsZCyjPJm6YA8XjZ8IV75HuO: int = __T3MhJL9nMTQaWMJrYSTIXXqi[__OWyArjwXfjMwWqZgZ8AssqHz % __T3MhJL9nMTQaWMJrYSTIXXqi.size()] %20
	__dLyZbWz0IJWzoffsa2PZaWaF["HE"] = int(__cnI1dDFEnFwVyQu5xxsnKTeU["HE_base"]) * (90 + __JsZCyjPJm6YA8XjZ8IV75HuO) / 100
	__dLyZbWz0IJWzoffsa2PZaWaF["is_ap"] = int(__dLyZbWz0IJWzoffsa2PZaWaF["HE"]) == 0
	__dLyZbWz0IJWzoffsa2PZaWaF["cursor"] = __OWyArjwXfjMwWqZgZ8AssqHz
	___1qGksmzNRubFckXIU7Ogyjh.append(__dLyZbWz0IJWzoffsa2PZaWaF)
	if __8t25G5WNXpxXjotieTtR4L5d:
		var __g5qetAkxBGIK8JaCrUPBQnL3: int = 0
		if int(__0_Y6Vls3SzMp6OPxdu8g33cn.get("aa", 0)) == 1:
			__g5qetAkxBGIK8JaCrUPBQnL3 = __T3MhJL9nMTQaWMJrYSTIXXqi[((__zduRQYoHM3TaD5NW0SfGL24h.x * 5 + __EaiCL_s7Is8n8XhLMgCmd8bh + __t2UdGLb5AjoD9DJacXSIpDUA + 3 * __JUt_JEjNw03F8dcqrZqlJar4) & 4294967295) % __T3MhJL9nMTQaWMJrYSTIXXqi.size()] & 7
		__2nLQ763tFkgAwvH1QSmnnqh3(__QzfA1_MgHwBGTTBizdgA8rkk.__FSW4WCXpupwYSF0KaHCFCNKb.__aO41k8gx8LZFJAoRdHhDtndC, owner.index, __zduRQYoHM3TaD5NW0SfGL24h.x + int(__cX0xvLjFykbKvHMIPeFnfm2N["spawn_x"]), __zduRQYoHM3TaD5NW0SfGL24h.y + int(__cX0xvLjFykbKvHMIPeFnfm2N["spawn_y"]), 
			__dnYO7JVMsVgfUPrhE8Ojoeb1, PackedInt32Array([__JUt_JEjNw03F8dcqrZqlJar4, __cnI1dDFEnFwVyQu5xxsnKTeU["grade"], __7hRvt_NNnxPqd4IY_zphbRg_, __kRE5CuE8PMoYmpp5DxDIL9MS, __cX0xvLjFykbKvHMIPeFnfm2N["vx"], - int(__cX0xvLjFykbKvHMIPeFnfm2N["vy"]), 
			int(__cX0xvLjFykbKvHMIPeFnfm2N["vz"]) / 2, __0_Y6Vls3SzMp6OPxdu8g33cn["caliber"], __0_Y6Vls3SzMp6OPxdu8g33cn.get("aa", 0), __g5qetAkxBGIK8JaCrUPBQnL3]))
const __RYRrt8mJAHprqxvpaMKNmsBZ: = -3000
func __UfEKTxE0kEIGUl7MshOPCLso(__Hcb9EvuZ8edXjjMfGyu22eQk: int, __1Df8RAkoqEfTLvInPrlte67D: __YdhZSn3k6BLtSITi5naOCb7n, __Gn2QAik3E5JMmuCIjEQXCEpV: int) -> void :
	if __Gn2QAik3E5JMmuCIjEQXCEpV > 0 and __Hcb9EvuZ8edXjjMfGyu22eQk >= 0 and __Hcb9EvuZ8edXjjMfGyu22eQk < __1Df8RAkoqEfTLvInPrlte67D.__kWx_ghjWrsvKfbTBZsiahQQd.size():
		__1Df8RAkoqEfTLvInPrlte67D.__kWx_ghjWrsvKfbTBZsiahQQd[__Hcb9EvuZ8edXjjMfGyu22eQk] = mini(__1Df8RAkoqEfTLvInPrlte67D.__kWx_ghjWrsvKfbTBZsiahQQd[__Hcb9EvuZ8edXjjMfGyu22eQk] + __Gn2QAik3E5JMmuCIjEQXCEpV, 1073741823)
var __GrLwyamZ57OX31Lkvv8RpSj0: bool = false
func __p4BfRGGYcGsflWTqyV1NyITt(s: __YdhZSn3k6BLtSITi5naOCb7n, code: int) -> void :
	__2nLQ763tFkgAwvH1QSmnnqh3(__QzfA1_MgHwBGTTBizdgA8rkk.__FSW4WCXpupwYSF0KaHCFCNKb.__ib7uB05JH2a_eoqGxv3it3Um, s.index, s.x(), s.y(), code)
var __TPIGeUdFb_AXx4vCwcpTGg3n: bool = false
func __JW6kWzl9mmLENz2OGP5I1qGI() -> Array[__QzfA1_MgHwBGTTBizdgA8rkk]:
	var __Hazz8M8VXG_8C8TibMglK4zz: Array[__QzfA1_MgHwBGTTBizdgA8rkk] = __SmXVMct8mHIMx6HdC4TMDErT
	__SmXVMct8mHIMx6HdC4TMDErT = []
	return __Hazz8M8VXG_8C8TibMglK4zz
const __fQaf8iG3sz2LcRoqJcnIWF0f: = __nZxK7u5JB3kHTF7XC5Hr9MHe.__fQaf8iG3sz2LcRoqJcnIWF0f
func __C7KC9_8obIScUs3UrOqPmWr1(owner: __YdhZSn3k6BLtSITi5naOCb7n, __fG2B0BJ7HF1bcV2u6HV5A9dY: int) -> void :
	var __uVbY_F_wBktS0pT7RkfcbSLI: Dictionary = owner.__bFJ1csmbpVraScDCZhw1ETZ5[__fG2B0BJ7HF1bcV2u6HV5A9dY]
	var __SpoWNv51uYdWKi9mKe0uqGGM: Vector2i = owner.__oc4DIMhqXqRDsyYDHkfod1e6(__uVbY_F_wBktS0pT7RkfcbSLI)
	var __LgGh_VfKsB38VeAWaYrCSPdF: int = ((owner.__Rzlu0K6FmW_AJtyGtfyruX3f(__uVbY_F_wBktS0pT7RkfcbSLI) + 50) / 100) % 36
	var __JBPy_gQpqb2ZcFb5lqXu7qCD: int = clampi(int(__uVbY_F_wBktS0pT7RkfcbSLI["ammo"]), 0, maxi(1, int(__uVbY_F_wBktS0pT7RkfcbSLI["tubes"])))
	for __YaA_iODacQOJK0OVZSGAe_ph: int in __JBPy_gQpqb2ZcFb5lqXu7qCD:
		var __aOrKc0qziLeuf7D57HRUNFZm: PackedInt32Array = __0QiGqbYBLZEUENpkfN6eZqIr.__r52cmnAlp1tX51EV6dhiVTAi(__uVbY_F_wBktS0pT7RkfcbSLI, __YaA_iODacQOJK0OVZSGAe_ph, __LgGh_VfKsB38VeAWaYrCSPdF)
		__i5VSVLoXQftICZ42J3cK2_5r.spawn(self, owner.index, __SpoWNv51uYdWKi9mKe0uqGGM.x + __aOrKc0qziLeuf7D57HRUNFZm[4], __SpoWNv51uYdWKi9mKe0uqGGM.y - __aOrKc0qziLeuf7D57HRUNFZm[5] + 12, int(__uVbY_F_wBktS0pT7RkfcbSLI["dmg"]), int(__uVbY_F_wBktS0pT7RkfcbSLI["ms"]))
	__TPIGeUdFb_AXx4vCwcpTGg3n = true
static func __kNaPtT1SLWxw85RAZgluou4V(__lthQYtqkbgk35l1XT9sBL2RU: int, __hw8u9o_mc2DQGe5GIygF5Ius: int, __UZvM9Y53UOmlk0LnAEnCrMva: int) -> int:
	var __XG_WeeKHS7AKjpr7h5HiSmV6: int = __Irz9hiGcyslSDsJT8BenfEt2.__f8g2PjfN7nwJbTHn9ePhmeZH(__lthQYtqkbgk35l1XT9sBL2RU * __lthQYtqkbgk35l1XT9sBL2RU + __hw8u9o_mc2DQGe5GIygF5Ius * __hw8u9o_mc2DQGe5GIygF5Ius)
	if __XG_WeeKHS7AKjpr7h5HiSmV6 == 0:
		__XG_WeeKHS7AKjpr7h5HiSmV6 = 1
	return __TXCdoY85HWzo9E7Qcf9l8raZ.__KboCFqRH_Lt6RKsZGS_Zbtl9(absi(__UZvM9Y53UOmlk0LnAEnCrMva / 2), __XG_WeeKHS7AKjpr7h5HiSmV6)
var __NTPi8_rHrS8Qu6hcZEXu3a9n: Array[Dictionary] = []
func __3m4l4K572e33JO3BZwxAsGgP(s: __YdhZSn3k6BLtSITi5naOCb7n, __srxiSfP7WLQ2rufvYCsGGYUB: int) -> void :
	__SmXVMct8mHIMx6HdC4TMDErT.append(__QzfA1_MgHwBGTTBizdgA8rkk.__YCYCLM7wn8U5KL1mw3RC4lIU(__QzfA1_MgHwBGTTBizdgA8rkk.__FSW4WCXpupwYSF0KaHCFCNKb.__yGHpMzctK_Zt2LAbBAKLwUsS, __u0nkAKG5lGiEsenIJI6PFvMF, s.index, s.x(), s.y(), __srxiSfP7WLQ2rufvYCsGGYUB))
