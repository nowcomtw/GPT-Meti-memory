extends RefCounted

# This is the game's own integer ballistic integrator, not an external physics
# approximation. Cache range curves by ammunition and weapon characteristics.
const MAX_TICKS:int=5000
const X_SCALE:int=280
const Y_SCALE:int=327
static var curves:Dictionary={}

static func fall_profile(shot:Dictionary,shell:Dictionary) -> Dictionary:
    var probe:Dictionary={"h":int(shot["h"]),"vz":int(shot["vz"]),"vx":0,"vy":0}
    var factors:PackedInt32Array=PackedInt32Array()
    for tick:int in range(1,MAX_TICKS):
        var factor:int=__a3Qlrip4DI7L5IkLGkgxE5xK.step(probe,int(shell["t0"]),int(shell.get("kind",0)))
        factors.append(factor)
        var h:int=int(probe["h"]);var vz:int=int(probe["vz"])
        if h+vz<0:
            return {"factors":factors,"fraction":absi(h*100/vz) if vz!=0 else 0}
        probe["h"]=h+vz
    return {}

static func axis_end(start:int,velocity:int,factors:PackedInt32Array,fraction:int) -> int:
    var p:int=start;var v:int=velocity
    for i:int in factors.size():
        v=v*factors[i]/10000
        if i==factors.size()-1:p+=v*fraction/100
        else:p+=v
    return p

static func axis_solution(start:int,velocity:int,target:int,scale:int,factors:PackedInt32Array,fraction:int,span:int) -> Dictionary:
    var wanted_min:int=target*scale;var wanted_max:int=wanted_min+scale-1
    var low:int=velocity-span;var high:int=velocity+span
    while low<=high:
        var middle:int=low+(high-low)/2
        var point:int=axis_end(start,middle,factors,fraction)
        if point<wanted_min:low=middle+1
        elif point>wanted_max:high=middle-1
        else:return {"velocity":middle,"exact":true}
    var best:int=clampi(low,velocity-span,velocity+span)
    var other:int=clampi(high,velocity-span,velocity+span)
    var center:int=wanted_min+scale/2
    if absi(axis_end(start,other,factors,fraction)-center)<absi(axis_end(start,best,factors,fraction)-center):best=other
    return {"velocity":best,"exact":false}

static func align_shots(shots:Array[Dictionary],shell:Dictionary,target:Vector2i) -> Array[Dictionary]:
    if shots.is_empty():return shots
    # The native simulator integrates integer x/y velocity independently once
    # height is fixed. Invert that same integrator for each muzzle, limiting
    # the fine correction to 1% of horizontal speed so range is not invented.
    var profile:Dictionary=fall_profile(shots[0],shell)
    if profile.is_empty():return shots
    var factors:PackedInt32Array=profile["factors"];var fraction:int=int(profile["fraction"])
    for shot:Dictionary in shots:
        var old_x:int=int(shot["vx"]);var old_y:int=int(shot["vy"])
        var speed:float=Vector2(old_x,old_y).length()
        var span:int=maxi(2,ceili(speed*0.01))
        var x:Dictionary=axis_solution(int(shot["x"]),old_x,target.x,X_SCALE,factors,fraction,span)
        var y:Dictionary=axis_solution(int(shot["y"]),old_y,target.y,Y_SCALE,factors,fraction,span)
        var dx:int=int(x["velocity"])-old_x;var dy:int=int(y["velocity"])-old_y
        if Vector2(dx,dy).length()<=float(span):
            shot["vx"]=int(x["velocity"]);shot["vy"]=int(y["velocity"])
    return shots

static func impact(g:Dictionary,shell:Dictionary,az:int,elev:int,origin:Vector2i) -> Dictionary:
    var shots:Array[Dictionary]=__a3Qlrip4DI7L5IkLGkgxE5xK.__Uinp0qKlBAx07Wxg3OpdJrIb(g,posmod(az,3600),clampi(elev,0,int(g["max_el"])),0,0,PackedInt32Array(),origin.x,origin.y,false)
    if shots.is_empty():return {}
    var first:Dictionary=shots[0].duplicate()
    var first_x:int=int(first["x"]);var first_y:int=int(first["y"])
    var offset:Vector2=Vector2.ZERO
    for shot:Dictionary in shots:offset+=Vector2(int(shot["x"])-first_x,int(shot["y"])-first_y)
    offset/=float(shots.size())
    for tick:int in range(1,MAX_TICKS):
        __a3Qlrip4DI7L5IkLGkgxE5xK.step(first,int(shell["t0"]),int(shell.get("kind",0)))
        var h:int=int(first["h"]);var vz:int=int(first["vz"])
        if h+vz<0:
            var fraction:int=absi(h*100/vz) if vz!=0 else 0
            var fixed:=Vector2(int(first["x"])+int(first["vx"])*fraction/100,int(first["y"])+int(first["vy"])*fraction/100)+offset
            return {"point":Vector2(fixed.x/X_SCALE,fixed.y/Y_SCALE),"ticks":tick,"spawn":Vector2((first_x+offset.x)/X_SCALE,(first_y+offset.y)/Y_SCALE)}
        first["x"]=int(first["x"])+int(first["vx"])
        first["y"]=int(first["y"])+int(first["vy"])
        first["h"]=h+vz
    return {}

static func curve(g:Dictionary,shell:Dictionary) -> Array:
    var key:String="%s/%s/%s/%s/%s" % [g["V0"],g["max_el"],shell["t0"],shell.get("kind",0),g.get("meti_range_pct",100)]
    if curves.has(key):return curves[key]
    var values:Array=[]
    for el:int in range(0,int(g["max_el"])+1,10):
        var result:Dictionary=impact(g,shell,0,el,Vector2i.ZERO)
        if not result.is_empty():values.append(Vector2(float(el),float(result["point"].x-result["spawn"].x)))
    if curves.size()>=24:curves.clear()
    curves[key]=values
    return values

static func estimated_elev(values:Array,distance:float,max_el:int) -> int:
    if values.is_empty():return -1
    var peak:int=0
    for i:int in values.size():
        if values[i].y>values[peak].y:peak=i
    var closest:int=0
    for i:int in range(1,peak+1):
        if absf(values[i].y-distance)<absf(values[closest].y-distance):closest=i
    var neighbor:int=closest
    if distance>values[closest].y and closest<peak:neighbor=closest+1
    elif distance<values[closest].y and closest>0:neighbor=closest-1
    if neighbor==closest:return clampi(roundi(values[closest].x),0,max_el)
    var a:Vector2=values[closest];var b:Vector2=values[neighbor]
    if absf(b.y-a.y)<0.001:return clampi(roundi(a.x),0,max_el)
    return clampi(roundi(a.x+(distance-a.y)*(b.x-a.x)/(b.y-a.y)),0,max_el)

static func solve(g:Dictionary,shell:Dictionary,origin:Vector2i,target:Vector2i) -> Dictionary:
    if int(g.get("barrels",0))<=0 or int(g.get("V0",0))<=0 or int(g.get("max_el",0))<=0 or int(shell.get("proj_row",-1))<0 or int(shell.get("kind",0)) in [1,3]:return {}
    var values:Array=curve(g,shell)
    if values.is_empty():return {}
    var dx:int=target.x-origin.x;var dy:int=target.y-origin.y
    var az:int=__NYbIaW78BNqdaS0BgoYwqAci.__KojNCs5E3fJteg0BP_ow8L2D(dx,dy*Y_SCALE/X_SCALE)
    var distance:float=Vector2(float(dx),float(dy)*Y_SCALE/X_SCALE).length()
    var el:int=estimated_elev(values,distance,int(g["max_el"]))
    if el<0:return {}
    # Muzzle locations vary with turret direction and elevation; adjust using
    # the mean of the real barrel spawn offsets, then refine by actual impacts.
    var guess:Dictionary=impact(g,shell,az,el,origin)
    if guess.is_empty():return {}
    var spawn:Vector2=guess["spawn"]
    az=__NYbIaW78BNqdaS0BgoYwqAci.__KojNCs5E3fJteg0BP_ow8L2D(roundi(target.x-spawn.x),roundi((target.y-spawn.y)*Y_SCALE/X_SCALE))
    distance=Vector2(target.x-spawn.x,(target.y-spawn.y)*Y_SCALE/X_SCALE).length()
    el=estimated_elev(values,distance,int(g["max_el"]))
    var best:Dictionary={};var best_error:float=INF
    for candidate:int in range(maxi(0,el-4),mini(int(g["max_el"]),el+4)+1):
        var hit:Dictionary=impact(g,shell,az,candidate,origin)
        if hit.is_empty():continue
        var error:float=(hit["point"] as Vector2).distance_squared_to(Vector2(target))
        if error<best_error:
            best_error=error;best={"az":az,"elev":candidate,"point":hit["point"],"ticks":hit["ticks"]}
    if best.is_empty():return {}
    for delta:int in [-2,-1,1,2]:
        var trial_az:int=posmod(az+delta,3600)
        var hit:Dictionary=impact(g,shell,trial_az,int(best["elev"]),origin)
        if hit.is_empty():continue
        var error:float=(hit["point"] as Vector2).distance_squared_to(Vector2(target))
        if error<best_error:
            best_error=error;best={"az":trial_az,"elev":int(best["elev"]),"point":hit["point"],"ticks":hit["ticks"]}
    best["error"]=sqrt(best_error)
    var max_range:float=0
    for row:Vector2 in values:max_range=maxf(max_range,row.y)
    best["in_range"]=distance<=max_range+1.0
    return best
