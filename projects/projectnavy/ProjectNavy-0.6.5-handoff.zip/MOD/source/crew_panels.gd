class_name __Yhtjf6iNuuOlPMKYYcWPcH_E
static func __utU8bvpPZFKe1fFfcvjifyvC(__7I5j02pwbXpFmOiQzTpxjqzr: __CgOl36_UCxYZW5PzufCcS4dS, target: Dictionary, __R44L3qpA5M9oDwVIQuz3R1pJ: __MxRtF5kMQ2PhDOJRxJ1ej8ie) -> bool:
	if __o4BlGoLwjfAD3TYKD8Kt7FzU.__jImD0sut02cad96nddoNN3be({"flags": int(target["flags"])}) or int(target["c8"]) == 75:
		var __hDpRV83ap8Gy7Z05eetxY3hJ: int = await UI.__Dzq5SbxUBHUUe7FLUyy2rI_S(TranslationServer.translate("UI_CREW_CLASS"), TranslationServer.translate("UI_CREW_CLASS_ASK") % str(target["name"]), [TranslationServer.translate("UI_OK"), TranslationServer.translate("UI_CANCEL")])
		if __hDpRV83ap8Gy7Z05eetxY3hJ != 0:
			return false
	var __wTr1XtTph99Ftli3ZGv_DLd2: String = __R44L3qpA5M9oDwVIQuz3R1pJ.__OoFGVnRF4oDKBuT2mZR_exPH(__7I5j02pwbXpFmOiQzTpxjqzr, target)
	if __wTr1XtTph99Ftli3ZGv_DLd2 != "":
		UI.__FZyGB2TVbKGb1g8kgT4bm_x4(TranslationServer.translate(__wTr1XtTph99Ftli3ZGv_DLd2))
		return false
	return true
const __BiFSUv8Gzh1wsdt1e8Siujil: Array[int] = [11, 10, 11, 12, 13, 11, 11, 13, 10]
class __RLSwe47ouZBk3dWw_QB5K8jx extends __z3gRH6PysI2uTsBRMQHzukNF:
	const __hSpZpDTcxWTVvydkdFVmYShU: Array[int] = [12, 88, 164]
	const __iLDfHQAVCLgGvMYfwHAweK01: Array[Color] = [Color8(220, 232, 245), Color8(120, 220, 140), Color8(255, 214, 110)]
	var __KSdqot0w9nlf_OnU9FBvnx34: __cBjn_l7I8v2A2mo4oxWc1Hx5
	var __pY661vwzoRY0D6Y5ORWYVaB_: = PackedInt32Array([0, 0, 0])
	var __E7y2lnfLTWAN5lJ2R6i8eFM7: int = 40
	func _draw() -> void :
		super._draw()
		if __KSdqot0w9nlf_OnU9FBvnx34 != null and __KSdqot0w9nlf_OnU9FBvnx34.__9GUNq0RC3I2wtF6RyGyGCuST != null:
			for __2FfAMdL1bcHsqpS1Zr9Q3VyJ: int in 3:
				var __dfXKUnB1Tnm5ARhgQlaQ0C7I: = Rect2(19 + 36 * __2FfAMdL1bcHsqpS1Zr9Q3VyJ, 243, 31, 23)
				draw_texture_rect_region(__KSdqot0w9nlf_OnU9FBvnx34.__9GUNq0RC3I2wtF6RyGyGCuST, Rect2(__hSpZpDTcxWTVvydkdFVmYShU[__2FfAMdL1bcHsqpS1Zr9Q3VyJ], 106, 31, 23), Rect2(__dfXKUnB1Tnm5ARhgQlaQ0C7I.position - Vector2(__KSdqot0w9nlf_OnU9FBvnx34.__0qOEymYSM0v6_xaX4s5nNVDN), __dfXKUnB1Tnm5ARhgQlaQ0C7I.size))
		var __alNYXVlY3mcDONn2GMIxPW5J: = Rect2(12, 145, size.x - 24, 6)
		draw_rect(__alNYXVlY3mcDONn2GMIxPW5J, Color(0.01, 0.03, 0.05, 1))
		var x: float = __alNYXVlY3mcDONn2GMIxPW5J.position.x
		for __dOtEIa8Vn8g_CfpU1D1Y95lP: int in 3:
			var w: float = __alNYXVlY3mcDONn2GMIxPW5J.size.x * float(__pY661vwzoRY0D6Y5ORWYVaB_[__dOtEIa8Vn8g_CfpU1D1Y95lP]) / float(maxi(1, __E7y2lnfLTWAN5lJ2R6i8eFM7))
			draw_rect(Rect2(x, __alNYXVlY3mcDONn2GMIxPW5J.position.y, w, __alNYXVlY3mcDONn2GMIxPW5J.size.y), Color(__iLDfHQAVCLgGvMYfwHAweK01[__dOtEIa8Vn8g_CfpU1D1Y95lP], 0.85))
			x += w
		draw_rect(Rect2(__alNYXVlY3mcDONn2GMIxPW5J.position + Vector2(0.5, 0.5), __alNYXVlY3mcDONn2GMIxPW5J.size - Vector2.ONE), __l0ljxOzuGuAaMAg0E9tYqY8N.__IBVvKw1yASSe7F4G5OVPjjdj, false, 1.0)
class __c5kmFT2SvI9SdnXe1GWcZOD7 extends Control:
	func _init() -> void :
		mouse_filter = Control.MOUSE_FILTER_IGNORE
	func _draw() -> void :
		draw_rect(Rect2(Vector2.ZERO, size), __l0ljxOzuGuAaMAg0E9tYqY8N.__FZypoysBpi4L67LAu9AxsRfZ)
		draw_rect(Rect2(1, 1, size.x - 2, 29), __l0ljxOzuGuAaMAg0E9tYqY8N.__uM0syOiZSyAoYRI1egXEgPRF)
		draw_rect(Rect2(Vector2(0.5, 0.5), size - Vector2.ONE), __l0ljxOzuGuAaMAg0E9tYqY8N.__UaQzKGmq2KuW6fOzrZIiSZtk, false, 1.0)
		draw_rect(Rect2(10, 30, size.x - 20, 1), __l0ljxOzuGuAaMAg0E9tYqY8N.__uZsUn6KOOVv_qJLmAUYOaxgm)
		var __TlmY4OEaJ9OrjWfBqaZWfN7i: = Rect2(13, 39, __Er3qHKxcEkfUWPtjkXRE6sZ3.__kD5MpGbGI03ItQXuZAiXJBoV.x + 2, __Er3qHKxcEkfUWPtjkXRE6sZ3.__kD5MpGbGI03ItQXuZAiXJBoV.y + 2)
		draw_rect(__TlmY4OEaJ9OrjWfBqaZWfN7i, __l0ljxOzuGuAaMAg0E9tYqY8N.__uM0syOiZSyAoYRI1egXEgPRF)
		draw_rect(Rect2(__TlmY4OEaJ9OrjWfBqaZWfN7i.position + Vector2(0.5, 0.5), __TlmY4OEaJ9OrjWfBqaZWfN7i.size - Vector2.ONE), __l0ljxOzuGuAaMAg0E9tYqY8N.__IBVvKw1yASSe7F4G5OVPjjdj, false, 1.0)
		draw_rect(Rect2(10, 96, size.x - 20, 1), __l0ljxOzuGuAaMAg0E9tYqY8N.__IBVvKw1yASSe7F4G5OVPjjdj)
		var b: Rect2 = __xXbVr55THU92NdaPxzeEXd_h.__pWC4Lw85eIIQ6L7FOw9dTRtR
		var __Y9rVCd0zF9e3onfC8pJSTyJH: float = __xXbVr55THU92NdaPxzeEXd_h.__u_mWzXEMeG_9VFI5MApAt2Dc - b.position.x - 12
		draw_rect(b, Color(0, 0, 0, 0.18))
		draw_rect(Rect2(b.position + Vector2(0.5, 0.5), b.size - Vector2.ONE), __l0ljxOzuGuAaMAg0E9tYqY8N.__5BdrvxK7qD5BiVk_0jPZ4czq, false, 1.0)
		draw_rect(Rect2(b.position.x + 4, __xXbVr55THU92NdaPxzeEXd_h.__bnDOqWP3lWfVe62etmbCZMYd + 17, __Y9rVCd0zF9e3onfC8pJSTyJH, 1), __l0ljxOzuGuAaMAg0E9tYqY8N.__IBVvKw1yASSe7F4G5OVPjjdj)
		draw_rect(Rect2(b.position.x + 4, __xXbVr55THU92NdaPxzeEXd_h.__f66ayMgRt4uOdqPgDKMl78Bf - 1, __Y9rVCd0zF9e3onfC8pJSTyJH, 18), Color(1, 1, 1, 0.035))
		var __tyVO41qhkZOqcNYCJPxlh4Au: float = __xXbVr55THU92NdaPxzeEXd_h.__tEZYhYnE3gAAHmCIZRjpBqLu - __xXbVr55THU92NdaPxzeEXd_h.__eYJeFqnS6PlCvh3rZyQxCFCv / 2.0 - 1
		draw_rect(Rect2(__tyVO41qhkZOqcNYCJPxlh4Au, b.position.y + 6, 1, b.size.y - 12), __l0ljxOzuGuAaMAg0E9tYqY8N.__IBVvKw1yASSe7F4G5OVPjjdj)
		draw_rect(Rect2(__xXbVr55THU92NdaPxzeEXd_h.__u_mWzXEMeG_9VFI5MApAt2Dc - 8, b.position.y + 6, 1, b.size.y - 12), __l0ljxOzuGuAaMAg0E9tYqY8N.__IBVvKw1yASSe7F4G5OVPjjdj)
		for __MA4CMAGlfKQpcwDPor0p1WAu: int in range(1, __o4BlGoLwjfAD3TYKD8Kt7FzU.__yJKOGHp90JmK10a2SV3ahPUB):
			draw_rect(Rect2(__tyVO41qhkZOqcNYCJPxlh4Au + __xXbVr55THU92NdaPxzeEXd_h.__eYJeFqnS6PlCvh3rZyQxCFCv * __MA4CMAGlfKQpcwDPor0p1WAu, __xXbVr55THU92NdaPxzeEXd_h.__bnDOqWP3lWfVe62etmbCZMYd + 4, 1, 9), __l0ljxOzuGuAaMAg0E9tYqY8N.__IBVvKw1yASSe7F4G5OVPjjdj)
		var __C1ruPcqriChmKeC24BxWFSQZ: Rect2 = __xXbVr55THU92NdaPxzeEXd_h.__3D8rEUrXO1lnz_yuRW4rFKxG
		draw_rect(Rect2(__C1ruPcqriChmKeC24BxWFSQZ.position + Vector2(0.5, 0.5), __C1ruPcqriChmKeC24BxWFSQZ.size - Vector2.ONE), __l0ljxOzuGuAaMAg0E9tYqY8N.__IBVvKw1yASSe7F4G5OVPjjdj, false, 1.0)
		draw_rect(Rect2(10, __xXbVr55THU92NdaPxzeEXd_h.__EaclKTmUdkf08KLlspkVhdxX, size.x - 20, 1), __l0ljxOzuGuAaMAg0E9tYqY8N.__uZsUn6KOOVv_qJLmAUYOaxgm)
class __lQX5ntoCWn2WuikaDdKciIIf extends __F4kscdCfLUw02HL8Nfie7uTc:
	const __kD5MpGbGI03ItQXuZAiXJBoV: = Vector2(339, 290)
	const __ozs9e29DA3MhbcWb417V8f4M: = Rect2(146, 0, 28, 0)
	var __V0pOn5Sa7N2eQmRM4kwRkT34: __CgOl36_UCxYZW5PzufCcS4dS
	var __Mmp51LLqIAW5OSN1oubWjb4m: int = 0
	var __YyyuYRZmnD8PnVuYYxyaG5v1: = PackedInt32Array()
	var __oJl8GnIy7S8y_id3LFblK_WV: = PackedInt32Array()
	func __YNjSGlrkuU4xu5LIhzsrDpM7() -> void :
		__2rdl1YpQzYXJobnYMjl8amhK.size = __kD5MpGbGI03ItQXuZAiXJBoV
		var __JWVw9kXfpDlrM3lGrlUF042m: Dictionary = __M0ImV248NGNrBFXy9NCs5jwX.__LVCMU4xMBMMHO5bxpAYeHYWt(__V0pOn5Sa7N2eQmRM4kwRkT34)
		var __WclAU3NgoPWTregVCyFYkNLv: bool = __o4BlGoLwjfAD3TYKD8Kt7FzU.__jImD0sut02cad96nddoNN3be(__JWVw9kXfpDlrM3lGrlUF042m)
		var __T3mxxGBrCRwLVOc7dch4bYmP: int = maxi(__V0pOn5Sa7N2eQmRM4kwRkT34.__zMZVCIoyJu5zkEI6YyKqPDoG - __Mmp51LLqIAW5OSN1oubWjb4m, 0)
		var __9SbN3MZ6EjSYzO9Ksscfj4SC: = PackedInt32Array()
		__9SbN3MZ6EjSYzO9Ksscfj4SC.resize(__o4BlGoLwjfAD3TYKD8Kt7FzU.__yJKOGHp90JmK10a2SV3ahPUB)
		var __4hfhH41NRmKLTdotky8ryO9n: int = 1
		for __5C51nBwD2RLm1yP7sgaFGhk9: int in __o4BlGoLwjfAD3TYKD8Kt7FzU.__yJKOGHp90JmK10a2SV3ahPUB:
			__9SbN3MZ6EjSYzO9Ksscfj4SC[__5C51nBwD2RLm1yP7sgaFGhk9] = __YyyuYRZmnD8PnVuYYxyaG5v1[__5C51nBwD2RLm1yP7sgaFGhk9] if __5C51nBwD2RLm1yP7sgaFGhk9 < __YyyuYRZmnD8PnVuYYxyaG5v1.size() else clampi(__V0pOn5Sa7N2eQmRM4kwRkT34.__4ObdBYhtKkHScUayTPgiYzH_[__5C51nBwD2RLm1yP7sgaFGhk9] - __V0pOn5Sa7N2eQmRM4kwRkT34.__wC11jxHS1J5bzkNesfKgNncZ[__5C51nBwD2RLm1yP7sgaFGhk9] * __T3mxxGBrCRwLVOc7dch4bYmP, 0, __LlOvNfSW39vQFa_X5z9isu0g.__5mUmXzFHF3sOKQKf_XcZ1XFe)
			__4hfhH41NRmKLTdotky8ryO9n = maxi(__4hfhH41NRmKLTdotky8ryO9n, maxi(__V0pOn5Sa7N2eQmRM4kwRkT34.__4ObdBYhtKkHScUayTPgiYzH_[__5C51nBwD2RLm1yP7sgaFGhk9], __9SbN3MZ6EjSYzO9Ksscfj4SC[__5C51nBwD2RLm1yP7sgaFGhk9]))
		var back: = __x8D5xTQfqU6JU4YzZJQsRfQX.new()
		back.size = __kD5MpGbGI03ItQXuZAiXJBoV
		for __0wEkn28MOGBSuAZLr2ZKePej: int in __o4BlGoLwjfAD3TYKD8Kt7FzU.__yJKOGHp90JmK10a2SV3ahPUB:
			back.__sXgRgHytcg6HgOlJ6CDefAZU.append(float(__9SbN3MZ6EjSYzO9Ksscfj4SC[__0wEkn28MOGBSuAZLr2ZKePej]) / float(__4hfhH41NRmKLTdotky8ryO9n))
			back.__SZ042_ROeSDDdE52PwCc_xc_.append(float(__V0pOn5Sa7N2eQmRM4kwRkT34.__4ObdBYhtKkHScUayTPgiYzH_[__0wEkn28MOGBSuAZLr2ZKePej]) / float(__4hfhH41NRmKLTdotky8ryO9n))
		__2rdl1YpQzYXJobnYMjl8amhK.add_child(back)
		__2rdl1YpQzYXJobnYMjl8amhK.label(tr("UI_LVUP_TITLE_CAPTAIN" if __WclAU3NgoPWTregVCyFYkNLv else "UI_LVUP_TITLE"), Vector2(14, 6), 180, 15, __eBt5HIxcCIYFCRhcyd21idU2.__pCUi6LToFPukNiGDrBwJ7It8)
		__2rdl1YpQzYXJobnYMjl8amhK.label(str(__JWVw9kXfpDlrM3lGrlUF042m.get("name", "")), Vector2(180, 12), __kD5MpGbGI03ItQXuZAiXJBoV.x - 194, 10, Color8(150, 200, 255), HORIZONTAL_ALIGNMENT_RIGHT)
		__2rdl1YpQzYXJobnYMjl8amhK.label(tr("UI_RECRUIT_GROWTH"), Vector2(__8yu8GD_ZgOog4dbaHoAeo0ZT.__zeoy5WjtGnie9mU_K404PnIk.position.x, 40), __8yu8GD_ZgOog4dbaHoAeo0ZT.__zeoy5WjtGnie9mU_K404PnIk.size.x, 10, __eBt5HIxcCIYFCRhcyd21idU2.__kVYXi_NVoyPvuzc3ek8hOGFd, HORIZONTAL_ALIGNMENT_RIGHT)
		__2rdl1YpQzYXJobnYMjl8amhK.label(tr("UI_RECRUIT_ABILITY"), Vector2(__8yu8GD_ZgOog4dbaHoAeo0ZT.__HBvlsuMmw3a1jcJDwOSu9p9N.position.x, 40), __x8D5xTQfqU6JU4YzZJQsRfQX.__uyDAR_38FXBwtog_opLjnv5d, 10, __eBt5HIxcCIYFCRhcyd21idU2.__kVYXi_NVoyPvuzc3ek8hOGFd, HORIZONTAL_ALIGNMENT_CENTER)
		__2rdl1YpQzYXJobnYMjl8amhK.label(tr("UI_LVUP_GAIN"), Vector2(__ozs9e29DA3MhbcWb417V8f4M.position.x, 40), __ozs9e29DA3MhbcWb417V8f4M.size.x, 10, __eBt5HIxcCIYFCRhcyd21idU2.__kVYXi_NVoyPvuzc3ek8hOGFd, HORIZONTAL_ALIGNMENT_CENTER)
		for __E_PR08qmCei5nPjyNsGDcbnq: int in __o4BlGoLwjfAD3TYKD8Kt7FzU.__yJKOGHp90JmK10a2SV3ahPUB:
			var y: float = __8yu8GD_ZgOog4dbaHoAeo0ZT.__PVfrKMpssNfX1J97RR8JxrWt + __E_PR08qmCei5nPjyNsGDcbnq * __8yu8GD_ZgOog4dbaHoAeo0ZT.__O_krrF5upjv1sZYM1ft4t0FV
			var g: int = __V0pOn5Sa7N2eQmRM4kwRkT34.__wC11jxHS1J5bzkNesfKgNncZ[__E_PR08qmCei5nPjyNsGDcbnq]
			__2rdl1YpQzYXJobnYMjl8amhK.label("%+d" % g if g != 0 else "0", Vector2(__8yu8GD_ZgOog4dbaHoAeo0ZT.__zeoy5WjtGnie9mU_K404PnIk.position.x, y), __8yu8GD_ZgOog4dbaHoAeo0ZT.__zeoy5WjtGnie9mU_K404PnIk.size.x, 10, __eBt5HIxcCIYFCRhcyd21idU2.__RIF_kToydsL5hGiT2p5OxAaC if g > 0 else __eBt5HIxcCIYFCRhcyd21idU2.__PDJ2eYH1RM56AXV47Yaop2B3 if g < 0 else __eBt5HIxcCIYFCRhcyd21idU2.__kVYXi_NVoyPvuzc3ek8hOGFd, HORIZONTAL_ALIGNMENT_RIGHT)
			var __Qyrg5q3tY0EMPwphij14CbCL: bool = __WclAU3NgoPWTregVCyFYkNLv and __E_PR08qmCei5nPjyNsGDcbnq == __o4BlGoLwjfAD3TYKD8Kt7FzU.__zQFbz4wT5ybXvNTatdPLjuFc.__AuLYcgB557BmcSJZGEBo_8wk
			__2rdl1YpQzYXJobnYMjl8amhK.label(tr(__o4BlGoLwjfAD3TYKD8Kt7FzU.__nhIhJXV65hiKRA5xP5eP8UVS[__E_PR08qmCei5nPjyNsGDcbnq]), Vector2(__8yu8GD_ZgOog4dbaHoAeo0ZT.__8DH0IlpFmjMCyvkslQ4FdpdO.position.x, y), __8yu8GD_ZgOog4dbaHoAeo0ZT.__8DH0IlpFmjMCyvkslQ4FdpdO.size.x, 10, __eBt5HIxcCIYFCRhcyd21idU2.GOLD if __Qyrg5q3tY0EMPwphij14CbCL else __eBt5HIxcCIYFCRhcyd21idU2.__pCUi6LToFPukNiGDrBwJ7It8, HORIZONTAL_ALIGNMENT_CENTER)
			__2rdl1YpQzYXJobnYMjl8amhK.label(str(__V0pOn5Sa7N2eQmRM4kwRkT34.__4ObdBYhtKkHScUayTPgiYzH_[__E_PR08qmCei5nPjyNsGDcbnq]), Vector2(__8yu8GD_ZgOog4dbaHoAeo0ZT.__HBvlsuMmw3a1jcJDwOSu9p9N.position.x, y), __x8D5xTQfqU6JU4YzZJQsRfQX.__uyDAR_38FXBwtog_opLjnv5d, 10, __eBt5HIxcCIYFCRhcyd21idU2.__pCUi6LToFPukNiGDrBwJ7It8, HORIZONTAL_ALIGNMENT_RIGHT)
			var d: int = __V0pOn5Sa7N2eQmRM4kwRkT34.__4ObdBYhtKkHScUayTPgiYzH_[__E_PR08qmCei5nPjyNsGDcbnq] - __9SbN3MZ6EjSYzO9Ksscfj4SC[__E_PR08qmCei5nPjyNsGDcbnq]
			if d != 0:
				__2rdl1YpQzYXJobnYMjl8amhK.label("%+d" % d, Vector2(__ozs9e29DA3MhbcWb417V8f4M.position.x, y), __ozs9e29DA3MhbcWb417V8f4M.size.x, 10, __eBt5HIxcCIYFCRhcyd21idU2.__RIF_kToydsL5hGiT2p5OxAaC if d > 0 else __eBt5HIxcCIYFCRhcyd21idU2.__PDJ2eYH1RM56AXV47Yaop2B3)
		var __mdc4A9_M8JJZ0XQX4t8v3g1W: int = int(__JWVw9kXfpDlrM3lGrlUF042m.get("nation", 0))
		if __mdc4A9_M8JJZ0XQX4t8v3g1W > 0 and __mdc4A9_M8JJZ0XQX4t8v3g1W < 9:
			var __yTX9MMAjDFS9NOSgaWltb6lT: __3CVc7kD6yGCHSiBfO0OphMVd = __2rdl1YpQzYXJobnYMjl8amhK.frame("ITPNFS", __BiFSUv8Gzh1wsdt1e8Siujil[__mdc4A9_M8JJZ0XQX4t8v3g1W])
			if __yTX9MMAjDFS9NOSgaWltb6lT.__5SRgdq4kqUc88lslGOc_6RxY != null and __yTX9MMAjDFS9NOSgaWltb6lT.__5SRgdq4kqUc88lslGOc_6RxY.__9GUNq0RC3I2wtF6RyGyGCuST != null:
				__yTX9MMAjDFS9NOSgaWltb6lT.position = (__8yu8GD_ZgOog4dbaHoAeo0ZT.__cJNoqh2PxHxeipGeIuo3EilA.get_center() - __yTX9MMAjDFS9NOSgaWltb6lT.__5SRgdq4kqUc88lslGOc_6RxY.__9GUNq0RC3I2wtF6RyGyGCuST.get_size() / 2.0 - Vector2(__yTX9MMAjDFS9NOSgaWltb6lT.__5SRgdq4kqUc88lslGOc_6RxY.__0qOEymYSM0v6_xaX4s5nNVDN)).floor()
			__yTX9MMAjDFS9NOSgaWltb6lT.modulate = Color(1, 1, 1, 0.35)
		var __5JiSGRu3YcCTEIPo_hvFqtFL: = __Er3qHKxcEkfUWPtjkXRE6sZ3.new()
		__5JiSGRu3YcCTEIPo_hvFqtFL.position = (__8yu8GD_ZgOog4dbaHoAeo0ZT.__cJNoqh2PxHxeipGeIuo3EilA.get_center() - __Er3qHKxcEkfUWPtjkXRE6sZ3.__kD5MpGbGI03ItQXuZAiXJBoV / 2.0).floor()
		__2rdl1YpQzYXJobnYMjl8amhK.add_child(__5JiSGRu3YcCTEIPo_hvFqtFL)
		__5JiSGRu3YcCTEIPo_hvFqtFL.__H8edGzuZdf8pc4sUjNkAWiOb(__JWVw9kXfpDlrM3lGrlUF042m)
		var __LP_BEzXYaXSjgVhWZHZvQkub: float = __8yu8GD_ZgOog4dbaHoAeo0ZT.__fK8FknhpJRE7MqOD7OXQuDIf + 2
		var __cRW0HV3eaXZ5MYuAaQUN3Zv4: float = __kD5MpGbGI03ItQXuZAiXJBoV.x - __8yu8GD_ZgOog4dbaHoAeo0ZT.__fK8FknhpJRE7MqOD7OXQuDIf - 4
		__2rdl1YpQzYXJobnYMjl8amhK.label(__V0pOn5Sa7N2eQmRM4kwRkT34.name, Vector2(__LP_BEzXYaXSjgVhWZHZvQkub, 130), __cRW0HV3eaXZ5MYuAaQUN3Zv4, 12, __eBt5HIxcCIYFCRhcyd21idU2.__pCUi6LToFPukNiGDrBwJ7It8, HORIZONTAL_ALIGNMENT_CENTER)
		__2rdl1YpQzYXJobnYMjl8amhK.label("Lv %d  ▶  %d" % [__Mmp51LLqIAW5OSN1oubWjb4m, __V0pOn5Sa7N2eQmRM4kwRkT34.__zMZVCIoyJu5zkEI6YyKqPDoG], Vector2(__LP_BEzXYaXSjgVhWZHZvQkub, 150), __cRW0HV3eaXZ5MYuAaQUN3Zv4, 16, __eBt5HIxcCIYFCRhcyd21idU2.GOLD, HORIZONTAL_ALIGNMENT_CENTER)
		for __vNzWNsQIukrIzyS_fdzqpqDX: Label in [__2rdl1YpQzYXJobnYMjl8amhK.label(tr("UI_LVUP_CONGRATS"), Vector2(__LP_BEzXYaXSjgVhWZHZvQkub, 182), __cRW0HV3eaXZ5MYuAaQUN3Zv4, 10, __eBt5HIxcCIYFCRhcyd21idU2.__pCUi6LToFPukNiGDrBwJ7It8, HORIZONTAL_ALIGNMENT_CENTER), __2rdl1YpQzYXJobnYMjl8amhK.label(tr("UI_LVUP_MSG_CAPTAIN" if __WclAU3NgoPWTregVCyFYkNLv else "UI_LVUP_MSG"), Vector2(__LP_BEzXYaXSjgVhWZHZvQkub, 196), __cRW0HV3eaXZ5MYuAaQUN3Zv4, 10, __eBt5HIxcCIYFCRhcyd21idU2.__kVYXi_NVoyPvuzc3ek8hOGFd, HORIZONTAL_ALIGNMENT_CENTER)]:
			__vNzWNsQIukrIzyS_fdzqpqDX.size.x = __cRW0HV3eaXZ5MYuAaQUN3Zv4
		var __nfzT2zo6F39HfxPBeesiuuTj: int = __V0pOn5Sa7N2eQmRM4kwRkT34.__pY661vwzoRY0D6Y5ORWYVaB_[1] - __oJl8GnIy7S8y_id3LFblK_WV[1] if __oJl8GnIy7S8y_id3LFblK_WV.size() >= 2 else 0
		if __nfzT2zo6F39HfxPBeesiuuTj > 0:
			__2rdl1YpQzYXJobnYMjl8amhK.label(tr("UI_LVUP_PROMOTE") % __nfzT2zo6F39HfxPBeesiuuTj, Vector2(__LP_BEzXYaXSjgVhWZHZvQkub, 222), __cRW0HV3eaXZ5MYuAaQUN3Zv4, 10, __eBt5HIxcCIYFCRhcyd21idU2.__RIF_kToydsL5hGiT2p5OxAaC, HORIZONTAL_ALIGNMENT_CENTER)
		var __I52RFKABtw7sFXF6ZT7AAvip: int = __M0ImV248NGNrBFXy9NCs5jwX.__pRmI0Gva0OZ3_r554GsEvNGr(__V0pOn5Sa7N2eQmRM4kwRkT34.__zMZVCIoyJu5zkEI6YyKqPDoG)
		back.__6pGuYMNz2cjH28iKvvYu0wom = clampf(float(__V0pOn5Sa7N2eQmRM4kwRkT34.exp) / maxf(1.0, float(__I52RFKABtw7sFXF6ZT7AAvip)), 0.0, 1.0)
		__2rdl1YpQzYXJobnYMjl8amhK.label("%s  %d / %d" % [tr("UI_CARD_EXP"), __V0pOn5Sa7N2eQmRM4kwRkT34.exp, __I52RFKABtw7sFXF6ZT7AAvip], Vector2(14, __8yu8GD_ZgOog4dbaHoAeo0ZT.__EaclKTmUdkf08KLlspkVhdxX + 8), 180, 10, __eBt5HIxcCIYFCRhcyd21idU2.__kVYXi_NVoyPvuzc3ek8hOGFd)
		var __At16s3gIHwkofLVXIDLlFV92: Button = __yDUDnCjoYKMLR7KGcyuw646g(tr("UI_OK"), Rect2(__kD5MpGbGI03ItQXuZAiXJBoV.x - 82, __8yu8GD_ZgOog4dbaHoAeo0ZT.__EaclKTmUdkf08KLlspkVhdxX + 12, 68, 22), "", 10)
		__At16s3gIHwkofLVXIDLlFV92.pressed.connect(close)
class __xXbVr55THU92NdaPxzeEXd_h extends __F4kscdCfLUw02HL8Nfie7uTc:
	const __kD5MpGbGI03ItQXuZAiXJBoV: = Vector2(480, 392)
	const __4zvyOezpgnjL3lcWNbR9Y73g: = 122.0
	const __EAngT4XM92o86omnQAsnQQOS: = 148.0
	const __QQgnQeRrN7wJIJKvm09xCuCc: = 22.0
	const __WNUtXQMzTzPqteJzV1_okpgI: = Vector2(154, 26)
	const __LYF3hcMLqPtVyXu6cBugo9UR: = 202.0
	const __pWC4Lw85eIIQ6L7FOw9dTRtR: = Rect2(10, 222, 460, 72)
	const __tEZYhYnE3gAAHmCIZRjpBqLu: = 70.0
	const __eYJeFqnS6PlCvh3rZyQxCFCv: = 28.0
	const __bnDOqWP3lWfVe62etmbCZMYd: = 228.0
	const __f66ayMgRt4uOdqPgDKMl78Bf: = 250.0
	const __iAH8FdCFMv1fBO6rsWK3aN0j: = 270.0
	const __u_mWzXEMeG_9VFI5MApAt2Dc: = 384.0
	const __3D8rEUrXO1lnz_yuRW4rFKxG: = Rect2(10, 300, 460, 52)
	const __EaclKTmUdkf08KLlspkVhdxX: = 360.0
	var __V0pOn5Sa7N2eQmRM4kwRkT34: __CgOl36_UCxYZW5PzufCcS4dS
	var __ODueSvGeVnWggM8WyoKBoh4p: Callable
	var __U6N_ijf_udU9aKiHHWkvm3eL: Dictionary = {}
	var __KeZdsKW86rRuZW68Ov4YLv1z: Button
	var __de8ke5F8u2VbeCZhxGkKdbQ9: Label
	var __UBhhhF6iRr94DKLQvVjANsh4: Label
	var __DtOxMB1xW5h_zLv8KZsLsc5W: Label
	var __a1IjpQ12r8cu_mfF788x73jw: __Er3qHKxcEkfUWPtjkXRE6sZ3
	var __e7qC1lVVTwlSYMCZWB8RAeBf: Array = []
	var __fiIxltLZIjKpZaUcDPA_VTrw: Label
	var __ZEcbZkWzGsgLMfbuw96OSzV8: Label
	var __dcoyKKoyVrfXazt060r7nlNQ: Array[Label] = []
	var __0fbpjzU1GTaECaOEvJip62FT: Array[Label] = []
	var __VZQzur6SAOqVTiIqFaXmkkIe: Label
	var __lQPAyXJHr0cOe0aO4tS122nB: Label
	var __SZIyxJrIfE4tCQ8YTGZog0Fu: Label
	func __YNjSGlrkuU4xu5LIhzsrDpM7() -> void :
		__2rdl1YpQzYXJobnYMjl8amhK.size = __kD5MpGbGI03ItQXuZAiXJBoV
		var back: = __c5kmFT2SvI9SdnXe1GWcZOD7.new()
		back.size = __kD5MpGbGI03ItQXuZAiXJBoV
		__2rdl1YpQzYXJobnYMjl8amhK.add_child(back)
		__2rdl1YpQzYXJobnYMjl8amhK.label(tr("UI_CC_TITLE"), Vector2(14, 6), 160, 15, __eBt5HIxcCIYFCRhcyd21idU2.__pCUi6LToFPukNiGDrBwJ7It8)
		var x: Button = __yDUDnCjoYKMLR7KGcyuw646g("×", Rect2(__kD5MpGbGI03ItQXuZAiXJBoV.x - 28, 6, 20, 18), tr("UI_CLOSE"))
		x.pressed.connect(close)
		__a1IjpQ12r8cu_mfF788x73jw = __Er3qHKxcEkfUWPtjkXRE6sZ3.new()
		__a1IjpQ12r8cu_mfF788x73jw.position = Vector2(14, 40)
		__2rdl1YpQzYXJobnYMjl8amhK.add_child(__a1IjpQ12r8cu_mfF788x73jw)
		__2rdl1YpQzYXJobnYMjl8amhK.label(__V0pOn5Sa7N2eQmRM4kwRkT34.name, Vector2(88, 38), 240, 13, __eBt5HIxcCIYFCRhcyd21idU2.__pCUi6LToFPukNiGDrBwJ7It8)
		__de8ke5F8u2VbeCZhxGkKdbQ9 = __2rdl1YpQzYXJobnYMjl8amhK.label("", Vector2(88, 57), 240, 11, Color8(150, 200, 255))
		__UBhhhF6iRr94DKLQvVjANsh4 = __2rdl1YpQzYXJobnYMjl8amhK.label("", Vector2(88, 74), 240, 10, __eBt5HIxcCIYFCRhcyd21idU2.__kVYXi_NVoyPvuzc3ek8hOGFd)
		__DtOxMB1xW5h_zLv8KZsLsc5W = __2rdl1YpQzYXJobnYMjl8amhK.label("", Vector2(__kD5MpGbGI03ItQXuZAiXJBoV.x - 174, 74), 160, 10, __eBt5HIxcCIYFCRhcyd21idU2.__kVYXi_NVoyPvuzc3ek8hOGFd, HORIZONTAL_ALIGNMENT_RIGHT)
		__2rdl1YpQzYXJobnYMjl8amhK.label(tr("UI_CC_TARGETS"), Vector2(14, 102), 160, 11, __eBt5HIxcCIYFCRhcyd21idU2.__pCUi6LToFPukNiGDrBwJ7It8)
		__fiIxltLZIjKpZaUcDPA_VTrw = __2rdl1YpQzYXJobnYMjl8amhK.label(tr("UI_CREW_CLASS_NONE"), Vector2(14, __4zvyOezpgnjL3lcWNbR9Y73g + 4), 300, 11, __eBt5HIxcCIYFCRhcyd21idU2.__kVYXi_NVoyPvuzc3ek8hOGFd)
		__ZEcbZkWzGsgLMfbuw96OSzV8 = __2rdl1YpQzYXJobnYMjl8amhK.label("", Vector2(14, __LYF3hcMLqPtVyXu6cBugo9UR), __kD5MpGbGI03ItQXuZAiXJBoV.x - 28, 11, __eBt5HIxcCIYFCRhcyd21idU2.__kVYXi_NVoyPvuzc3ek8hOGFd)
		__cYz97ABSEU6TQPub4slEjEBW()
		__2rdl1YpQzYXJobnYMjl8amhK.label(tr("UI_RECRUIT_GROWTH"), Vector2(18, __f66ayMgRt4uOdqPgDKMl78Bf), 40, 10, __eBt5HIxcCIYFCRhcyd21idU2.__kVYXi_NVoyPvuzc3ek8hOGFd)
		__2rdl1YpQzYXJobnYMjl8amhK.label(tr("UI_RECRUIT_ABILITY"), Vector2(18, __iAH8FdCFMv1fBO6rsWK3aN0j), 40, 10, __eBt5HIxcCIYFCRhcyd21idU2.__kVYXi_NVoyPvuzc3ek8hOGFd)
		for __5NBUUgo2giZ6TrwLfW8h40aw: int in __o4BlGoLwjfAD3TYKD8Kt7FzU.__yJKOGHp90JmK10a2SV3ahPUB:
			var __1wxA0fDUdCWkhlFOvml3dWs5: float = __tEZYhYnE3gAAHmCIZRjpBqLu + __eYJeFqnS6PlCvh3rZyQxCFCv * __5NBUUgo2giZ6TrwLfW8h40aw
			__2rdl1YpQzYXJobnYMjl8amhK.label(tr(__o4BlGoLwjfAD3TYKD8Kt7FzU.__nhIhJXV65hiKRA5xP5eP8UVS[__5NBUUgo2giZ6TrwLfW8h40aw]), Vector2(__1wxA0fDUdCWkhlFOvml3dWs5 - 14, __bnDOqWP3lWfVe62etmbCZMYd), 28, 10, Color8(150, 200, 255), HORIZONTAL_ALIGNMENT_CENTER)
			__dcoyKKoyVrfXazt060r7nlNQ.append(__2rdl1YpQzYXJobnYMjl8amhK.label("", Vector2(__1wxA0fDUdCWkhlFOvml3dWs5 - 14, __f66ayMgRt4uOdqPgDKMl78Bf), 28, 11, __eBt5HIxcCIYFCRhcyd21idU2.__kVYXi_NVoyPvuzc3ek8hOGFd, HORIZONTAL_ALIGNMENT_CENTER))
			__0fbpjzU1GTaECaOEvJip62FT.append(__2rdl1YpQzYXJobnYMjl8amhK.label("", Vector2(__1wxA0fDUdCWkhlFOvml3dWs5 - 14, __iAH8FdCFMv1fBO6rsWK3aN0j), 28, 11, __eBt5HIxcCIYFCRhcyd21idU2.__pCUi6LToFPukNiGDrBwJ7It8, HORIZONTAL_ALIGNMENT_CENTER))
		__2rdl1YpQzYXJobnYMjl8amhK.label(tr("UI_CC_REQ_LEVEL"), Vector2(__u_mWzXEMeG_9VFI5MApAt2Dc, __bnDOqWP3lWfVe62etmbCZMYd + 8), 52, 10, __eBt5HIxcCIYFCRhcyd21idU2.__kVYXi_NVoyPvuzc3ek8hOGFd)
		__2rdl1YpQzYXJobnYMjl8amhK.label(tr("UI_CC_REQ_POINTS"), Vector2(__u_mWzXEMeG_9VFI5MApAt2Dc, __bnDOqWP3lWfVe62etmbCZMYd + 30), 52, 10, __eBt5HIxcCIYFCRhcyd21idU2.__kVYXi_NVoyPvuzc3ek8hOGFd)
		__VZQzur6SAOqVTiIqFaXmkkIe = __2rdl1YpQzYXJobnYMjl8amhK.label("", Vector2(__u_mWzXEMeG_9VFI5MApAt2Dc + 40, __bnDOqWP3lWfVe62etmbCZMYd + 7), 42, 11, __eBt5HIxcCIYFCRhcyd21idU2.__pCUi6LToFPukNiGDrBwJ7It8, HORIZONTAL_ALIGNMENT_RIGHT)
		__lQPAyXJHr0cOe0aO4tS122nB = __2rdl1YpQzYXJobnYMjl8amhK.label("", Vector2(__u_mWzXEMeG_9VFI5MApAt2Dc + 40, __bnDOqWP3lWfVe62etmbCZMYd + 29), 42, 11, __eBt5HIxcCIYFCRhcyd21idU2.__pCUi6LToFPukNiGDrBwJ7It8, HORIZONTAL_ALIGNMENT_RIGHT)
		var __PB1AnojNUvMfEj0Tavi48MeZ: PackedStringArray = tr("UI_CC_LEGEND").split("|")
		var __QqIL8dwbR6SXBkCMhiV6lEkA: float = __3D8rEUrXO1lnz_yuRW4rFKxG.size.x / maxf(1.0, __PB1AnojNUvMfEj0Tavi48MeZ.size())
		for g: int in __PB1AnojNUvMfEj0Tavi48MeZ.size():
			var __5xr1HUdLNOCStV1GZjWkqyub: PackedStringArray = __PB1AnojNUvMfEj0Tavi48MeZ[g].split("/")
			for r: int in __5xr1HUdLNOCStV1GZjWkqyub.size():
				__2rdl1YpQzYXJobnYMjl8amhK.label(__5xr1HUdLNOCStV1GZjWkqyub[r], Vector2(__3D8rEUrXO1lnz_yuRW4rFKxG.position.x + __QqIL8dwbR6SXBkCMhiV6lEkA * g, __3D8rEUrXO1lnz_yuRW4rFKxG.position.y + 4 + 11 * r), __QqIL8dwbR6SXBkCMhiV6lEkA, 8, Color(__eBt5HIxcCIYFCRhcyd21idU2.__kVYXi_NVoyPvuzc3ek8hOGFd, 0.8), HORIZONTAL_ALIGNMENT_CENTER)
		__SZIyxJrIfE4tCQ8YTGZog0Fu = __2rdl1YpQzYXJobnYMjl8amhK.label("", Vector2(14, __EaclKTmUdkf08KLlspkVhdxX + 9), 140, 11, __eBt5HIxcCIYFCRhcyd21idU2.GOLD)
		if __ODueSvGeVnWggM8WyoKBoh4p.is_valid():
			var __vAeGcNV9sqiOiU54JE01BRnP: Button = __yDUDnCjoYKMLR7KGcyuw646g(tr("UI_CTREE_BTN"), Rect2(__kD5MpGbGI03ItQXuZAiXJBoV.x - 236, __EaclKTmUdkf08KLlspkVhdxX + 6, 76, 22), tr("UI_CTREE_TIP"), 11)
			__vAeGcNV9sqiOiU54JE01BRnP.pressed.connect( func() -> void : __ODueSvGeVnWggM8WyoKBoh4p.call())
		__KeZdsKW86rRuZW68Ov4YLv1z = __yDUDnCjoYKMLR7KGcyuw646g(tr("UI_OK"), Rect2(__kD5MpGbGI03ItQXuZAiXJBoV.x - 152, __EaclKTmUdkf08KLlspkVhdxX + 6, 66, 22), "", 11)
		__KeZdsKW86rRuZW68Ov4YLv1z.disabled = true
		__KeZdsKW86rRuZW68Ov4YLv1z.pressed.connect(__mbOiCnB2RrUGG8KxpVIpv81O)
		var __bs8da8n4gj5wgw5GDtITnFwE: Button = __yDUDnCjoYKMLR7KGcyuw646g(tr("UI_CANCEL"), Rect2(__kD5MpGbGI03ItQXuZAiXJBoV.x - 80, __EaclKTmUdkf08KLlspkVhdxX + 6, 66, 22), "", 11)
		__bs8da8n4gj5wgw5GDtITnFwE.pressed.connect(close)
		__EpHlYEAwAN8UPFiYA_49R8rA()
		__jEO474GcDRPRj7yr3P7HaOhQ({})
	func __cYz97ABSEU6TQPub4slEjEBW() -> void :
		for __V6jpX3DVvXlhxwgAjtIZ3oCA: Array in __e7qC1lVVTwlSYMCZWB8RAeBf:
			(__V6jpX3DVvXlhxwgAjtIZ3oCA[0] as Button).queue_free()
		__e7qC1lVVTwlSYMCZWB8RAeBf.clear()
		__U6N_ijf_udU9aKiHHWkvm3eL = {}
		var __dsqvpyMuCOi7bFyfn_WrKJ4_: Array[Dictionary] = __M0ImV248NGNrBFXy9NCs5jwX.___HvqiRmS3LxFNwDWQwWYBoXa(__V0pOn5Sa7N2eQmRM4kwRkT34)
		__fiIxltLZIjKpZaUcDPA_VTrw.visible = __dsqvpyMuCOi7bFyfn_WrKJ4_.is_empty()
		var __1zznMbipF2MmbQuTMvuSLdA4: int = 0
		for __hS98zdBbK424FYVeAT6_m6ZE: Dictionary in __dsqvpyMuCOi7bFyfn_WrKJ4_:
			var __AUcZaN81Ca0MxFx7pfyGIXuh: = Vector2(14 + __WNUtXQMzTzPqteJzV1_okpgI.x * (__1zznMbipF2MmbQuTMvuSLdA4 % 3), __4zvyOezpgnjL3lcWNbR9Y73g + __WNUtXQMzTzPqteJzV1_okpgI.y * (__1zznMbipF2MmbQuTMvuSLdA4 / 3))
			var b: Button = __yDUDnCjoYKMLR7KGcyuw646g("%s  %s  Lv%d" % [str(__hS98zdBbK424FYVeAT6_m6ZE["name"]), tr(__o4BlGoLwjfAD3TYKD8Kt7FzU.__yDkbANaLPj6K2iCfn8NT3Pwn[int(__hS98zdBbK424FYVeAT6_m6ZE["nation"])]), int(__hS98zdBbK424FYVeAT6_m6ZE["req_level"])], Rect2(__AUcZaN81Ca0MxFx7pfyGIXuh, Vector2(__EAngT4XM92o86omnQAsnQQOS, __QQgnQeRrN7wJIJKvm09xCuCc)), "", 10)
			b.toggle_mode = true
			var __7BqAfj8ibcWPu5oDfRUpMvP2: Dictionary = __hS98zdBbK424FYVeAT6_m6ZE
			b.pressed.connect( func() -> void : __W5SggII7x3dNBLrlWIqMcfDc(__7BqAfj8ibcWPu5oDfRUpMvP2))
			__e7qC1lVVTwlSYMCZWB8RAeBf.append([b, __hS98zdBbK424FYVeAT6_m6ZE])
			__1zznMbipF2MmbQuTMvuSLdA4 += 1
	func __EpHlYEAwAN8UPFiYA_49R8rA() -> void :
		var __RwcGo3W6ISrARHpkbZfq4HWV: Dictionary = __M0ImV248NGNrBFXy9NCs5jwX.__LVCMU4xMBMMHO5bxpAYeHYWt(__V0pOn5Sa7N2eQmRM4kwRkT34)
		__a1IjpQ12r8cu_mfF788x73jw.__H8edGzuZdf8pc4sUjNkAWiOb(__RwcGo3W6ISrARHpkbZfq4HWV)
		__de8ke5F8u2VbeCZhxGkKdbQ9.text = tr("UI_CC_NOW") % str(__RwcGo3W6ISrARHpkbZfq4HWV.get("name", ""))
		__UBhhhF6iRr94DKLQvVjANsh4.text = "Lv%d　%s" % [__V0pOn5Sa7N2eQmRM4kwRkT34.__zMZVCIoyJu5zkEI6YyKqPDoG, tr(__o4BlGoLwjfAD3TYKD8Kt7FzU.__yDkbANaLPj6K2iCfn8NT3Pwn[int(__RwcGo3W6ISrARHpkbZfq4HWV.get("nation", 0))])]
		__DtOxMB1xW5h_zLv8KZsLsc5W.text = tr("UI_CREW_EXP_MAX") if __V0pOn5Sa7N2eQmRM4kwRkT34.__zMZVCIoyJu5zkEI6YyKqPDoG >= __M0ImV248NGNrBFXy9NCs5jwX.__ZEf8MUQNZMeLjokl2rCxl51Z() else tr("UI_CREW_EXP_OF") % [__V0pOn5Sa7N2eQmRM4kwRkT34.exp, __M0ImV248NGNrBFXy9NCs5jwX.__pRmI0Gva0OZ3_r554GsEvNGr(__V0pOn5Sa7N2eQmRM4kwRkT34.__zMZVCIoyJu5zkEI6YyKqPDoG)]
		for __9EmWHB0eXGVGySXLPOEMzQFL: Array in __e7qC1lVVTwlSYMCZWB8RAeBf:
			(__9EmWHB0eXGVGySXLPOEMzQFL[0] as Button).disabled = __V0pOn5Sa7N2eQmRM4kwRkT34.__zMZVCIoyJu5zkEI6YyKqPDoG < int((__9EmWHB0eXGVGySXLPOEMzQFL[1] as Dictionary)["req_level"])
		__KeZdsKW86rRuZW68Ov4YLv1z.disabled = __U6N_ijf_udU9aKiHHWkvm3eL.is_empty() or __M0ImV248NGNrBFXy9NCs5jwX.__uOjfVymJkWxwS467Gg0WBv5P(__V0pOn5Sa7N2eQmRM4kwRkT34, __U6N_ijf_udU9aKiHHWkvm3eL) != ""
		__A16Bf5XHDci9_3J6mm37sq7o()
	func __W5SggII7x3dNBLrlWIqMcfDc(__XqGYccVMyuTFpKcbGsHKRWo7: Dictionary) -> void :
		__U6N_ijf_udU9aKiHHWkvm3eL = __XqGYccVMyuTFpKcbGsHKRWo7
		for __Pf7jbNZHNafWb4D9odADNnOD: Array in __e7qC1lVVTwlSYMCZWB8RAeBf:
			var b: Button = __Pf7jbNZHNafWb4D9odADNnOD[0]
			b.button_pressed = __Pf7jbNZHNafWb4D9odADNnOD[1] == __XqGYccVMyuTFpKcbGsHKRWo7
			for __qGptj2HTCzTvA07DFyN0Mo6b: String in ["font_color", "font_pressed_color", "font_hover_pressed_color"]:
				if __Pf7jbNZHNafWb4D9odADNnOD[1] == __XqGYccVMyuTFpKcbGsHKRWo7:
					b.add_theme_color_override(__qGptj2HTCzTvA07DFyN0Mo6b, __eBt5HIxcCIYFCRhcyd21idU2.GOLD)
				else:
					b.remove_theme_color_override(__qGptj2HTCzTvA07DFyN0Mo6b)
		var ___zP6LEdduVrAnfiYgZOOh58c: String = __M0ImV248NGNrBFXy9NCs5jwX.__uOjfVymJkWxwS467Gg0WBv5P(__V0pOn5Sa7N2eQmRM4kwRkT34, __XqGYccVMyuTFpKcbGsHKRWo7)
		__KeZdsKW86rRuZW68Ov4YLv1z.disabled = ___zP6LEdduVrAnfiYgZOOh58c != ""
		__pfWIDJIyscSQGiXxnlZdfYcp(tr(___zP6LEdduVrAnfiYgZOOh58c) if ___zP6LEdduVrAnfiYgZOOh58c != "" else tr("UI_CREW_CLASS_TO") % str(__XqGYccVMyuTFpKcbGsHKRWo7["name"]), __eBt5HIxcCIYFCRhcyd21idU2.__PDJ2eYH1RM56AXV47Yaop2B3 if ___zP6LEdduVrAnfiYgZOOh58c != "" else __eBt5HIxcCIYFCRhcyd21idU2.GOLD)
		__jEO474GcDRPRj7yr3P7HaOhQ(__XqGYccVMyuTFpKcbGsHKRWo7)
	func __pfWIDJIyscSQGiXxnlZdfYcp(text: String, color: Color) -> void :
		__ZEcbZkWzGsgLMfbuw96OSzV8.text = text
		__ZEcbZkWzGsgLMfbuw96OSzV8.add_theme_color_override("font_color", color)
	func __jEO474GcDRPRj7yr3P7HaOhQ(__qDGBQHF1swq6HuuT9kxihDpL: Dictionary) -> void :
		var __VpEZxUz5CEnYpjIdwAgbuimT: PackedInt32Array = __qDGBQHF1swq6HuuT9kxihDpL.get("growth", PackedInt32Array())
		for __P3iRHMOCo0bJx_GtErsILMek: int in __dcoyKKoyVrfXazt060r7nlNQ.size():
			var d: int = __VpEZxUz5CEnYpjIdwAgbuimT[__P3iRHMOCo0bJx_GtErsILMek] if __P3iRHMOCo0bJx_GtErsILMek < __VpEZxUz5CEnYpjIdwAgbuimT.size() else 0
			var __q7e63o3_UqX7O0bL6SKsCKtr: int = maxi(0, __V0pOn5Sa7N2eQmRM4kwRkT34.__wC11jxHS1J5bzkNesfKgNncZ[__P3iRHMOCo0bJx_GtErsILMek] + d)
			__dcoyKKoyVrfXazt060r7nlNQ[__P3iRHMOCo0bJx_GtErsILMek].text = "%+d" % __q7e63o3_UqX7O0bL6SKsCKtr if __q7e63o3_UqX7O0bL6SKsCKtr != 0 else "0"
			__dcoyKKoyVrfXazt060r7nlNQ[__P3iRHMOCo0bJx_GtErsILMek].add_theme_color_override("font_color", __eBt5HIxcCIYFCRhcyd21idU2.GOLD if __q7e63o3_UqX7O0bL6SKsCKtr != __V0pOn5Sa7N2eQmRM4kwRkT34.__wC11jxHS1J5bzkNesfKgNncZ[__P3iRHMOCo0bJx_GtErsILMek] else __eBt5HIxcCIYFCRhcyd21idU2.__RIF_kToydsL5hGiT2p5OxAaC if __q7e63o3_UqX7O0bL6SKsCKtr > 0 else __eBt5HIxcCIYFCRhcyd21idU2.__PDJ2eYH1RM56AXV47Yaop2B3 if __q7e63o3_UqX7O0bL6SKsCKtr < 0 else __eBt5HIxcCIYFCRhcyd21idU2.__kVYXi_NVoyPvuzc3ek8hOGFd)
			__0fbpjzU1GTaECaOEvJip62FT[__P3iRHMOCo0bJx_GtErsILMek].text = str(__V0pOn5Sa7N2eQmRM4kwRkT34.__4ObdBYhtKkHScUayTPgiYzH_[__P3iRHMOCo0bJx_GtErsILMek])
		var __rXLtctAUuueEO9PWokk6DXX8: bool = __qDGBQHF1swq6HuuT9kxihDpL.is_empty()
		__VZQzur6SAOqVTiIqFaXmkkIe.text = "-" if __rXLtctAUuueEO9PWokk6DXX8 else str(__qDGBQHF1swq6HuuT9kxihDpL["req_level"])
		__lQPAyXJHr0cOe0aO4tS122nB.text = "-" if __rXLtctAUuueEO9PWokk6DXX8 else str(__qDGBQHF1swq6HuuT9kxihDpL["cost"])
		__VZQzur6SAOqVTiIqFaXmkkIe.add_theme_color_override("font_color", __eBt5HIxcCIYFCRhcyd21idU2.__kVYXi_NVoyPvuzc3ek8hOGFd if __rXLtctAUuueEO9PWokk6DXX8
			else __eBt5HIxcCIYFCRhcyd21idU2.__PDJ2eYH1RM56AXV47Yaop2B3 if __V0pOn5Sa7N2eQmRM4kwRkT34.__zMZVCIoyJu5zkEI6YyKqPDoG < int(__qDGBQHF1swq6HuuT9kxihDpL["req_level"]) else __eBt5HIxcCIYFCRhcyd21idU2.__pCUi6LToFPukNiGDrBwJ7It8)
		__lQPAyXJHr0cOe0aO4tS122nB.add_theme_color_override("font_color", __eBt5HIxcCIYFCRhcyd21idU2.__kVYXi_NVoyPvuzc3ek8hOGFd if __rXLtctAUuueEO9PWokk6DXX8
			else __eBt5HIxcCIYFCRhcyd21idU2.__PDJ2eYH1RM56AXV47Yaop2B3 if __M0ImV248NGNrBFXy9NCs5jwX.points < int(__qDGBQHF1swq6HuuT9kxihDpL["cost"]) else __eBt5HIxcCIYFCRhcyd21idU2.__pCUi6LToFPukNiGDrBwJ7It8)
		__SZIyxJrIfE4tCQ8YTGZog0Fu.text = tr("UI_CREW_POINTS") % __M0ImV248NGNrBFXy9NCs5jwX.points
		__A16Bf5XHDci9_3J6mm37sq7o()
	func __mbOiCnB2RrUGG8KxpVIpv81O() -> void :
		if __U6N_ijf_udU9aKiHHWkvm3eL.is_empty():
			return
		var __2wlo7cts_3qb6I_D72kuqiu_: Dictionary = __U6N_ijf_udU9aKiHHWkvm3eL
		if await __Yhtjf6iNuuOlPMKYYcWPcH_E.__utU8bvpPZFKe1fFfcvjifyvC(__V0pOn5Sa7N2eQmRM4kwRkT34, __2wlo7cts_3qb6I_D72kuqiu_, __M0ImV248NGNrBFXy9NCs5jwX):
			__wr6C8oBxKi3NsqbLhFXJNUAz()
			__cYz97ABSEU6TQPub4slEjEBW()
			__EpHlYEAwAN8UPFiYA_49R8rA()
			__jEO474GcDRPRj7yr3P7HaOhQ({})
			__pfWIDJIyscSQGiXxnlZdfYcp(tr("UI_CTREE_DONE") % str(__2wlo7cts_3qb6I_D72kuqiu_["name"]), __eBt5HIxcCIYFCRhcyd21idU2.GOLD)
class __KqpJI15OWa9wtuu_qSFM18MR extends Control:
	var __tfaL_CfdgLgiWn9poTGtYJdt: = PackedFloat32Array()
	func _init() -> void :
		mouse_filter = Control.MOUSE_FILTER_IGNORE
	func _draw() -> void :
		draw_rect(Rect2(Vector2.ZERO, size), __l0ljxOzuGuAaMAg0E9tYqY8N.__FZypoysBpi4L67LAu9AxsRfZ)
		draw_rect(Rect2(Vector2(0.5, 0.5), size - Vector2.ONE), __l0ljxOzuGuAaMAg0E9tYqY8N.__UaQzKGmq2KuW6fOzrZIiSZtk, false, 1.0)
		draw_rect(Rect2(10, 30, size.x - 20, 1), __l0ljxOzuGuAaMAg0E9tYqY8N.__uZsUn6KOOVv_qJLmAUYOaxgm)
		draw_rect(Rect2(__8yu8GD_ZgOog4dbaHoAeo0ZT.__zeoy5WjtGnie9mU_K404PnIk.position.x, 54, __8yu8GD_ZgOog4dbaHoAeo0ZT.__zeoy5WjtGnie9mU_K404PnIk.size.x, 1), __l0ljxOzuGuAaMAg0E9tYqY8N.__IBVvKw1yASSe7F4G5OVPjjdj)
		draw_rect(Rect2(__8yu8GD_ZgOog4dbaHoAeo0ZT.__HBvlsuMmw3a1jcJDwOSu9p9N.position.x, 54, __8yu8GD_ZgOog4dbaHoAeo0ZT.__HBvlsuMmw3a1jcJDwOSu9p9N.size.x, 1), __l0ljxOzuGuAaMAg0E9tYqY8N.__IBVvKw1yASSe7F4G5OVPjjdj)
		var __382zOQ7Qby1KejZJ386VxBsb: float = __8yu8GD_ZgOog4dbaHoAeo0ZT.__PVfrKMpssNfX1J97RR8JxrWt - 2
		var __Q0Si7tDwod6RkCkcIKPw1qjg: float = __8yu8GD_ZgOog4dbaHoAeo0ZT.__PVfrKMpssNfX1J97RR8JxrWt + __o4BlGoLwjfAD3TYKD8Kt7FzU.__yJKOGHp90JmK10a2SV3ahPUB * __8yu8GD_ZgOog4dbaHoAeo0ZT.__O_krrF5upjv1sZYM1ft4t0FV + 2
		for __3W9a5gDgDJDUVi8dRVZvoqfJ: int in __o4BlGoLwjfAD3TYKD8Kt7FzU.__yJKOGHp90JmK10a2SV3ahPUB:
			var y: float = __8yu8GD_ZgOog4dbaHoAeo0ZT.__PVfrKMpssNfX1J97RR8JxrWt + __3W9a5gDgDJDUVi8dRVZvoqfJ * __8yu8GD_ZgOog4dbaHoAeo0ZT.__O_krrF5upjv1sZYM1ft4t0FV
			if __3W9a5gDgDJDUVi8dRVZvoqfJ % 2 == 1:
				draw_rect(Rect2(__8yu8GD_ZgOog4dbaHoAeo0ZT.__zeoy5WjtGnie9mU_K404PnIk.position.x, y, __8yu8GD_ZgOog4dbaHoAeo0ZT.__HBvlsuMmw3a1jcJDwOSu9p9N.end.x - __8yu8GD_ZgOog4dbaHoAeo0ZT.__zeoy5WjtGnie9mU_K404PnIk.position.x, __8yu8GD_ZgOog4dbaHoAeo0ZT.__O_krrF5upjv1sZYM1ft4t0FV), Color(1, 1, 1, 0.035))
			if __3W9a5gDgDJDUVi8dRVZvoqfJ < __tfaL_CfdgLgiWn9poTGtYJdt.size() and __tfaL_CfdgLgiWn9poTGtYJdt[__3W9a5gDgDJDUVi8dRVZvoqfJ] > 0.0:
				draw_rect(Rect2(__8yu8GD_ZgOog4dbaHoAeo0ZT.__HBvlsuMmw3a1jcJDwOSu9p9N.position.x + 2, y + 3, (__8yu8GD_ZgOog4dbaHoAeo0ZT.__HBvlsuMmw3a1jcJDwOSu9p9N.size.x - 22) * __tfaL_CfdgLgiWn9poTGtYJdt[__3W9a5gDgDJDUVi8dRVZvoqfJ], __8yu8GD_ZgOog4dbaHoAeo0ZT.__O_krrF5upjv1sZYM1ft4t0FV - 6), Color(__l0ljxOzuGuAaMAg0E9tYqY8N.__uZsUn6KOOVv_qJLmAUYOaxgm, 0.35))
		draw_rect(Rect2(__8yu8GD_ZgOog4dbaHoAeo0ZT.__8DH0IlpFmjMCyvkslQ4FdpdO.position.x - 2, __382zOQ7Qby1KejZJ386VxBsb, 1, __Q0Si7tDwod6RkCkcIKPw1qjg - __382zOQ7Qby1KejZJ386VxBsb), __l0ljxOzuGuAaMAg0E9tYqY8N.__IBVvKw1yASSe7F4G5OVPjjdj)
		draw_rect(Rect2(__8yu8GD_ZgOog4dbaHoAeo0ZT.__8DH0IlpFmjMCyvkslQ4FdpdO.end.x + 2, __382zOQ7Qby1KejZJ386VxBsb, 1, __Q0Si7tDwod6RkCkcIKPw1qjg - __382zOQ7Qby1KejZJ386VxBsb), __l0ljxOzuGuAaMAg0E9tYqY8N.__IBVvKw1yASSe7F4G5OVPjjdj)
		draw_rect(Rect2(__8yu8GD_ZgOog4dbaHoAeo0ZT.__fK8FknhpJRE7MqOD7OXQuDIf, 40, 1, __8yu8GD_ZgOog4dbaHoAeo0ZT.__EaclKTmUdkf08KLlspkVhdxX - 50), __l0ljxOzuGuAaMAg0E9tYqY8N.__IBVvKw1yASSe7F4G5OVPjjdj)
		var __5b86C0yzFhtueK7a5Zzp824V: Rect2 = __8yu8GD_ZgOog4dbaHoAeo0ZT.__cJNoqh2PxHxeipGeIuo3EilA
		draw_rect(__5b86C0yzFhtueK7a5Zzp824V, __l0ljxOzuGuAaMAg0E9tYqY8N.__uM0syOiZSyAoYRI1egXEgPRF)
		draw_rect(Rect2(__5b86C0yzFhtueK7a5Zzp824V.position + Vector2(0.5, 0.5), __5b86C0yzFhtueK7a5Zzp824V.size - Vector2.ONE), __l0ljxOzuGuAaMAg0E9tYqY8N.__IBVvKw1yASSe7F4G5OVPjjdj, false, 1.0)
		draw_rect(Rect2(__8yu8GD_ZgOog4dbaHoAeo0ZT.__fK8FknhpJRE7MqOD7OXQuDIf + 8, 220, size.x - __8yu8GD_ZgOog4dbaHoAeo0ZT.__fK8FknhpJRE7MqOD7OXQuDIf - 20, 1), __l0ljxOzuGuAaMAg0E9tYqY8N.__IBVvKw1yASSe7F4G5OVPjjdj)
		draw_rect(Rect2(10, __8yu8GD_ZgOog4dbaHoAeo0ZT.__EaclKTmUdkf08KLlspkVhdxX, size.x - 20, 1), __l0ljxOzuGuAaMAg0E9tYqY8N.__uZsUn6KOOVv_qJLmAUYOaxgm)
class __x8D5xTQfqU6JU4YzZJQsRfQX extends Control:
	const __uyDAR_38FXBwtog_opLjnv5d: = 44.0
	var __sXgRgHytcg6HgOlJ6CDefAZU: = PackedFloat32Array()
	var __SZ042_ROeSDDdE52PwCc_xc_: = PackedFloat32Array()
	var __6pGuYMNz2cjH28iKvvYu0wom: float = 0.0
	func _init() -> void :
		mouse_filter = Control.MOUSE_FILTER_IGNORE
	func _draw() -> void :
		draw_rect(Rect2(Vector2.ZERO, size), __l0ljxOzuGuAaMAg0E9tYqY8N.__FZypoysBpi4L67LAu9AxsRfZ)
		draw_rect(Rect2(1, 1, size.x - 2, 29), __l0ljxOzuGuAaMAg0E9tYqY8N.__uM0syOiZSyAoYRI1egXEgPRF)
		draw_rect(Rect2(Vector2(0.5, 0.5), size - Vector2.ONE), __l0ljxOzuGuAaMAg0E9tYqY8N.__UaQzKGmq2KuW6fOzrZIiSZtk, false, 1.0)
		draw_rect(Rect2(10, 30, size.x - 20, 1), __l0ljxOzuGuAaMAg0E9tYqY8N.__uZsUn6KOOVv_qJLmAUYOaxgm)
		var __mb4TRbuameCzXe6FnaRpN88t: float = __8yu8GD_ZgOog4dbaHoAeo0ZT.__zeoy5WjtGnie9mU_K404PnIk.position.x
		var __nocNm_9pdIQI_hrDonSxFXsO: float = __8yu8GD_ZgOog4dbaHoAeo0ZT.__HBvlsuMmw3a1jcJDwOSu9p9N.position.x
		var right: float = __lQX5ntoCWn2WuikaDdKciIIf.__ozs9e29DA3MhbcWb417V8f4M.end.x
		draw_rect(Rect2(__mb4TRbuameCzXe6FnaRpN88t, 54, __8yu8GD_ZgOog4dbaHoAeo0ZT.__zeoy5WjtGnie9mU_K404PnIk.size.x, 1), __l0ljxOzuGuAaMAg0E9tYqY8N.__IBVvKw1yASSe7F4G5OVPjjdj)
		draw_rect(Rect2(__nocNm_9pdIQI_hrDonSxFXsO, 54, __uyDAR_38FXBwtog_opLjnv5d, 1), __l0ljxOzuGuAaMAg0E9tYqY8N.__IBVvKw1yASSe7F4G5OVPjjdj)
		draw_rect(Rect2(__lQX5ntoCWn2WuikaDdKciIIf.__ozs9e29DA3MhbcWb417V8f4M.position.x, 54, __lQX5ntoCWn2WuikaDdKciIIf.__ozs9e29DA3MhbcWb417V8f4M.size.x, 1), __l0ljxOzuGuAaMAg0E9tYqY8N.__IBVvKw1yASSe7F4G5OVPjjdj)
		var __A3_1uT58usPxO8e61eI847RL: float = __8yu8GD_ZgOog4dbaHoAeo0ZT.__PVfrKMpssNfX1J97RR8JxrWt - 2
		var __9yoaNoae5lgWNeWdcY1OFPiV: float = __8yu8GD_ZgOog4dbaHoAeo0ZT.__PVfrKMpssNfX1J97RR8JxrWt + __o4BlGoLwjfAD3TYKD8Kt7FzU.__yJKOGHp90JmK10a2SV3ahPUB * __8yu8GD_ZgOog4dbaHoAeo0ZT.__O_krrF5upjv1sZYM1ft4t0FV + 2
		var __FiNZxilq1iF2lK3Xx5EtB_Ew: float = __uyDAR_38FXBwtog_opLjnv5d - 18
		for __IxZzMogPEu35fYBqvI57ajqB: int in __o4BlGoLwjfAD3TYKD8Kt7FzU.__yJKOGHp90JmK10a2SV3ahPUB:
			var y: float = __8yu8GD_ZgOog4dbaHoAeo0ZT.__PVfrKMpssNfX1J97RR8JxrWt + __IxZzMogPEu35fYBqvI57ajqB * __8yu8GD_ZgOog4dbaHoAeo0ZT.__O_krrF5upjv1sZYM1ft4t0FV
			if __IxZzMogPEu35fYBqvI57ajqB % 2 == 1:
				draw_rect(Rect2(__mb4TRbuameCzXe6FnaRpN88t, y, right - __mb4TRbuameCzXe6FnaRpN88t, __8yu8GD_ZgOog4dbaHoAeo0ZT.__O_krrF5upjv1sZYM1ft4t0FV), Color(1, 1, 1, 0.035))
			if __IxZzMogPEu35fYBqvI57ajqB >= __SZ042_ROeSDDdE52PwCc_xc_.size():
				continue
			var __HaM_awkuPFOvdaE0tUB_j6Uf: float = minf(__sXgRgHytcg6HgOlJ6CDefAZU[__IxZzMogPEu35fYBqvI57ajqB], __SZ042_ROeSDDdE52PwCc_xc_[__IxZzMogPEu35fYBqvI57ajqB])
			if __HaM_awkuPFOvdaE0tUB_j6Uf > 0.0:
				draw_rect(Rect2(__nocNm_9pdIQI_hrDonSxFXsO + 2, y + 3, __FiNZxilq1iF2lK3Xx5EtB_Ew * __HaM_awkuPFOvdaE0tUB_j6Uf, __8yu8GD_ZgOog4dbaHoAeo0ZT.__O_krrF5upjv1sZYM1ft4t0FV - 6), Color(__l0ljxOzuGuAaMAg0E9tYqY8N.__uZsUn6KOOVv_qJLmAUYOaxgm, 0.35))
			if __SZ042_ROeSDDdE52PwCc_xc_[__IxZzMogPEu35fYBqvI57ajqB] > __HaM_awkuPFOvdaE0tUB_j6Uf:
				draw_rect(Rect2(__nocNm_9pdIQI_hrDonSxFXsO + 2 + __FiNZxilq1iF2lK3Xx5EtB_Ew * __HaM_awkuPFOvdaE0tUB_j6Uf, y + 3, maxf(__FiNZxilq1iF2lK3Xx5EtB_Ew * (__SZ042_ROeSDDdE52PwCc_xc_[__IxZzMogPEu35fYBqvI57ajqB] - __HaM_awkuPFOvdaE0tUB_j6Uf), 1.0), __8yu8GD_ZgOog4dbaHoAeo0ZT.__O_krrF5upjv1sZYM1ft4t0FV - 6), Color(__eBt5HIxcCIYFCRhcyd21idU2.__RIF_kToydsL5hGiT2p5OxAaC, 0.7))
		draw_rect(Rect2(__8yu8GD_ZgOog4dbaHoAeo0ZT.__8DH0IlpFmjMCyvkslQ4FdpdO.position.x - 2, __A3_1uT58usPxO8e61eI847RL, 1, __9yoaNoae5lgWNeWdcY1OFPiV - __A3_1uT58usPxO8e61eI847RL), __l0ljxOzuGuAaMAg0E9tYqY8N.__IBVvKw1yASSe7F4G5OVPjjdj)
		draw_rect(Rect2(__8yu8GD_ZgOog4dbaHoAeo0ZT.__8DH0IlpFmjMCyvkslQ4FdpdO.end.x + 2, __A3_1uT58usPxO8e61eI847RL, 1, __9yoaNoae5lgWNeWdcY1OFPiV - __A3_1uT58usPxO8e61eI847RL), __l0ljxOzuGuAaMAg0E9tYqY8N.__IBVvKw1yASSe7F4G5OVPjjdj)
		draw_rect(Rect2(__8yu8GD_ZgOog4dbaHoAeo0ZT.__fK8FknhpJRE7MqOD7OXQuDIf, 40, 1, __8yu8GD_ZgOog4dbaHoAeo0ZT.__EaclKTmUdkf08KLlspkVhdxX - 50), __l0ljxOzuGuAaMAg0E9tYqY8N.__IBVvKw1yASSe7F4G5OVPjjdj)
		var __qptdCaine6HvFr78fvwCibiL: Rect2 = __8yu8GD_ZgOog4dbaHoAeo0ZT.__cJNoqh2PxHxeipGeIuo3EilA
		draw_rect(__qptdCaine6HvFr78fvwCibiL, __l0ljxOzuGuAaMAg0E9tYqY8N.__uM0syOiZSyAoYRI1egXEgPRF)
		draw_rect(Rect2(__qptdCaine6HvFr78fvwCibiL.position + Vector2(0.5, 0.5), __qptdCaine6HvFr78fvwCibiL.size - Vector2.ONE), __l0ljxOzuGuAaMAg0E9tYqY8N.__IBVvKw1yASSe7F4G5OVPjjdj, false, 1.0)
		draw_rect(Rect2(__8yu8GD_ZgOog4dbaHoAeo0ZT.__fK8FknhpJRE7MqOD7OXQuDIf + 14, 174, size.x - __8yu8GD_ZgOog4dbaHoAeo0ZT.__fK8FknhpJRE7MqOD7OXQuDIf - 28, 1), __l0ljxOzuGuAaMAg0E9tYqY8N.__IBVvKw1yASSe7F4G5OVPjjdj)
		draw_rect(Rect2(10, __8yu8GD_ZgOog4dbaHoAeo0ZT.__EaclKTmUdkf08KLlspkVhdxX, size.x - 20, 1), __l0ljxOzuGuAaMAg0E9tYqY8N.__uZsUn6KOOVv_qJLmAUYOaxgm)
		var __Vo8qwRHJV5HhRTlASujsTzR4: = Rect2(14, __8yu8GD_ZgOog4dbaHoAeo0ZT.__EaclKTmUdkf08KLlspkVhdxX + 26, 180, 4)
		draw_rect(__Vo8qwRHJV5HhRTlASujsTzR4, Color(0.01, 0.03, 0.05, 1))
		draw_rect(Rect2(__Vo8qwRHJV5HhRTlASujsTzR4.position, Vector2(__Vo8qwRHJV5HhRTlASujsTzR4.size.x * __6pGuYMNz2cjH28iKvvYu0wom, __Vo8qwRHJV5HhRTlASujsTzR4.size.y)), __l0ljxOzuGuAaMAg0E9tYqY8N.__uZsUn6KOOVv_qJLmAUYOaxgm)
		draw_rect(Rect2(__Vo8qwRHJV5HhRTlASujsTzR4.position + Vector2(0.5, 0.5), __Vo8qwRHJV5HhRTlASujsTzR4.size - Vector2.ONE), __l0ljxOzuGuAaMAg0E9tYqY8N.__IBVvKw1yASSe7F4G5OVPjjdj, false, 1.0)
class __1UIbDU5PBDW9zTROIk0EOypE extends __F4kscdCfLUw02HL8Nfie7uTc:
	const __kD5MpGbGI03ItQXuZAiXJBoV: = Vector2(240, 322)
	const __6UjHK0F4IBugLhD7xP6fOnQi: Array[int] = [86, 174, 228, 290]
	var __V0pOn5Sa7N2eQmRM4kwRkT34: __CgOl36_UCxYZW5PzufCcS4dS
	var __BfRNayRIqIsAyP38HIfsaNfd: __RLSwe47ouZBk3dWw_QB5K8jx
	var __S3uq3CMk97hdPpLJiAuEKa73: Label
	var __g4Q6WqqM555qbhOLLvFE2KuI: Array[Label] = []
	var __8FZHxQK4mEeU1H471tJvudgl: Label
	var __SZIyxJrIfE4tCQ8YTGZog0Fu: Label
	var __7H43Ndo8eGlyx33k8VIcB8Cb: Label
	var __UQpH28jj_RgSoiSTygc3G0oD: int = 1
	var __4byg609Zc4U54BTJTOpoPoGT: int = 1
	var __RJR1zfZblDn9VfFz4aPqH2A6: Label
	var __pX6xt8D5cvvTYGMFJbK2jgm8: Label
	var __XBO327ijDPCZZDxP0VhauamJ: Button
	var meti_promote_max: Button
	var __u2niK09JldXYawO9HEktUiez: Button
	var __T6cdTpUxNSycZasJLXCMWqY5: Button
	var __IY5eAN7U1gwZI6Ycq4wOyErd: Label
	var __3H20y0a5xyuZ1u6aIXwvOavt: Array[Button] = []
	func __YNjSGlrkuU4xu5LIhzsrDpM7() -> void :
		__2rdl1YpQzYXJobnYMjl8amhK.size = __kD5MpGbGI03ItQXuZAiXJBoV
		var __EODCtN2h6Yutv9iBisj4ntuZ: Dictionary = __M0ImV248NGNrBFXy9NCs5jwX.__LVCMU4xMBMMHO5bxpAYeHYWt(__V0pOn5Sa7N2eQmRM4kwRkT34)
		__BfRNayRIqIsAyP38HIfsaNfd = __RLSwe47ouZBk3dWw_QB5K8jx.new()
		__BfRNayRIqIsAyP38HIfsaNfd.size = __kD5MpGbGI03ItQXuZAiXJBoV
		__BfRNayRIqIsAyP38HIfsaNfd.__GD_Tb7il6TQtKgcYWL0lZFKw = __6UjHK0F4IBugLhD7xP6fOnQi
		__BfRNayRIqIsAyP38HIfsaNfd.__KSdqot0w9nlf_OnU9FBvnx34 = Assets.frame("ITPNFS", 326 if __o4BlGoLwjfAD3TYKD8Kt7FzU.__jImD0sut02cad96nddoNN3be(__EODCtN2h6Yutv9iBisj4ntuZ) else 329)
		__2rdl1YpQzYXJobnYMjl8amhK.add_child(__BfRNayRIqIsAyP38HIfsaNfd)
		__2rdl1YpQzYXJobnYMjl8amhK.label(tr("UI_RCT_TITLE"), Vector2(12, 6), 160, 12, __eBt5HIxcCIYFCRhcyd21idU2.GOLD)
		var x: Button = __yDUDnCjoYKMLR7KGcyuw646g("×", Rect2(__kD5MpGbGI03ItQXuZAiXJBoV.x - 28, 5, 20, 18), tr("UI_CLOSE"))
		x.pressed.connect(close)
		var __uvovUjm2P9R2_R8uUI3qQgVO: = __Er3qHKxcEkfUWPtjkXRE6sZ3.new()
		__uvovUjm2P9R2_R8uUI3qQgVO.position = Vector2(12, 32)
		__2rdl1YpQzYXJobnYMjl8amhK.add_child(__uvovUjm2P9R2_R8uUI3qQgVO)
		__uvovUjm2P9R2_R8uUI3qQgVO.__H8edGzuZdf8pc4sUjNkAWiOb(__EODCtN2h6Yutv9iBisj4ntuZ)
		__2rdl1YpQzYXJobnYMjl8amhK.label(str(__EODCtN2h6Yutv9iBisj4ntuZ.get("name", "")), Vector2(84, 32), 144, 10, Color8(150, 200, 255))
		__2rdl1YpQzYXJobnYMjl8amhK.label(__V0pOn5Sa7N2eQmRM4kwRkT34.name, Vector2(84, 46), 144, 13, __eBt5HIxcCIYFCRhcyd21idU2.__pCUi6LToFPukNiGDrBwJ7It8)
		__2rdl1YpQzYXJobnYMjl8amhK.label("Lv%d　%s" % [__V0pOn5Sa7N2eQmRM4kwRkT34.__zMZVCIoyJu5zkEI6YyKqPDoG, tr(__o4BlGoLwjfAD3TYKD8Kt7FzU.__yDkbANaLPj6K2iCfn8NT3Pwn[int(__EODCtN2h6Yutv9iBisj4ntuZ.get("nation", 0))])], Vector2(84, 63), 144, 10, __eBt5HIxcCIYFCRhcyd21idU2.__kVYXi_NVoyPvuzc3ek8hOGFd)
		__2rdl1YpQzYXJobnYMjl8amhK.label(tr("UI_RCT_MEN"), Vector2(12, 90), 100, 11, __eBt5HIxcCIYFCRhcyd21idU2.__pCUi6LToFPukNiGDrBwJ7It8)
		__S3uq3CMk97hdPpLJiAuEKa73 = __2rdl1YpQzYXJobnYMjl8amhK.label("", Vector2(120, 91), 108, 10, __eBt5HIxcCIYFCRhcyd21idU2.__kVYXi_NVoyPvuzc3ek8hOGFd, HORIZONTAL_ALIGNMENT_RIGHT)
		for __gnuxloRkwimmTuvontXeKDwp: int in 3:
			__g4Q6WqqM555qbhOLLvFE2KuI.append(__2rdl1YpQzYXJobnYMjl8amhK.label("", Vector2(__RLSwe47ouZBk3dWw_QB5K8jx.__hSpZpDTcxWTVvydkdFVmYShU[__gnuxloRkwimmTuvontXeKDwp] + 32, 108), 38, 14, __RLSwe47ouZBk3dWw_QB5K8jx.__iLDfHQAVCLgGvMYfwHAweK01[__gnuxloRkwimmTuvontXeKDwp]))
			__2rdl1YpQzYXJobnYMjl8amhK.label(tr(["UI_RCT_ROOKIE", "UI_RCT_SKILLED", "UI_RCT_VETERAN"][__gnuxloRkwimmTuvontXeKDwp]), Vector2(__RLSwe47ouZBk3dWw_QB5K8jx.__hSpZpDTcxWTVvydkdFVmYShU[__gnuxloRkwimmTuvontXeKDwp], 131), 70, 9, __eBt5HIxcCIYFCRhcyd21idU2.__kVYXi_NVoyPvuzc3ek8hOGFd)
		__8FZHxQK4mEeU1H471tJvudgl = __2rdl1YpQzYXJobnYMjl8amhK.label("", Vector2(12, 156), 216, 9, __eBt5HIxcCIYFCRhcyd21idU2.__kVYXi_NVoyPvuzc3ek8hOGFd)
		var __bMEQSB7tFP2FIPYX2IWRILBw: Dictionary = __M0ImV248NGNrBFXy9NCs5jwX.__qyvbOrjVYs2zGM2jUVQYSgGR.get("replenish", {})
		__2rdl1YpQzYXJobnYMjl8amhK.label(tr("UI_RCT_ADD_TITLE"), Vector2(12, 178), 110, 11, __eBt5HIxcCIYFCRhcyd21idU2.__pCUi6LToFPukNiGDrBwJ7It8)
		__2rdl1YpQzYXJobnYMjl8amhK.label(tr("UI_RCT_ADD_DESC") % int(__bMEQSB7tFP2FIPYX2IWRILBw.get("cost", 0)), Vector2(110, 179), 118, 9, __eBt5HIxcCIYFCRhcyd21idU2.__kVYXi_NVoyPvuzc3ek8hOGFd, HORIZONTAL_ALIGNMENT_RIGHT)
		__RJR1zfZblDn9VfFz4aPqH2A6 = __0LS6KQrfkrYLKTWUus0fGqPf(198, func(d: int) -> void :
			__UQpH28jj_RgSoiSTygc3G0oD += d
			__jEO474GcDRPRj7yr3P7HaOhQ())
		__u2niK09JldXYawO9HEktUiez = __yDUDnCjoYKMLR7KGcyuw646g("補滿", Rect2(90, 198, 32, 20), "依目前海點一次補足這組水兵", 9)
		__u2niK09JldXYawO9HEktUiez.pressed.connect( func() -> void :
			meti_refill_all())
		__XBO327ijDPCZZDxP0VhauamJ = __yDUDnCjoYKMLR7KGcyuw646g("", Rect2(126, 198, __kD5MpGbGI03ItQXuZAiXJBoV.x - 138, 20))
		__XBO327ijDPCZZDxP0VhauamJ.pressed.connect(__oKaBQBat8BGlUAt9PnWrEUIB)
		__2rdl1YpQzYXJobnYMjl8amhK.label(tr("UI_RCT_PRO_TITLE"), Vector2(12, 232), 64, 11, __eBt5HIxcCIYFCRhcyd21idU2.__pCUi6LToFPukNiGDrBwJ7It8)
		__IY5eAN7U1gwZI6Ycq4wOyErd = __2rdl1YpQzYXJobnYMjl8amhK.label("", Vector2(70, 233), 158, 9, __eBt5HIxcCIYFCRhcyd21idU2.__kVYXi_NVoyPvuzc3ek8hOGFd, HORIZONTAL_ALIGNMENT_RIGHT)
		__IY5eAN7U1gwZI6Ycq4wOyErd.size.x = 158
		__pX6xt8D5cvvTYGMFJbK2jgm8 = __0LS6KQrfkrYLKTWUus0fGqPf(252, func(d: int) -> void :
			__4byg609Zc4U54BTJTOpoPoGT += d
			__jEO474GcDRPRj7yr3P7HaOhQ())
		meti_promote_max = __yDUDnCjoYKMLR7KGcyuw646g("全晉", Rect2(90, 252, 32, 20), "依熟練兵、海點與技術兵上限，一次晉升最大人數", 9)
		meti_promote_max.pressed.connect(meti_promote_all)
		__T6cdTpUxNSycZasJLXCMWqY5 = __yDUDnCjoYKMLR7KGcyuw646g("", Rect2(126, 252, __kD5MpGbGI03ItQXuZAiXJBoV.x - 138, 20), "", 9)
		__T6cdTpUxNSycZasJLXCMWqY5.pressed.connect(__w7QZ9O3JmMeNrlVYNV1gFTCM)
		__7H43Ndo8eGlyx33k8VIcB8Cb = __2rdl1YpQzYXJobnYMjl8amhK.label("", Vector2(12, 274), 216, 10, __eBt5HIxcCIYFCRhcyd21idU2.__kVYXi_NVoyPvuzc3ek8hOGFd)
		__SZIyxJrIfE4tCQ8YTGZog0Fu = __2rdl1YpQzYXJobnYMjl8amhK.label("", Vector2(12, 298), 140, 11, __eBt5HIxcCIYFCRhcyd21idU2.GOLD)
		var __2kWqFXC5_sORr7xr94K6c69p: Button = __yDUDnCjoYKMLR7KGcyuw646g(tr("UI_CLOSE"), Rect2(__kD5MpGbGI03ItQXuZAiXJBoV.x - 72, 296, 60, 20))
		__2kWqFXC5_sORr7xr94K6c69p.pressed.connect(close)
		__jEO474GcDRPRj7yr3P7HaOhQ()
	func __0LS6KQrfkrYLKTWUus0fGqPf(y: float, step: Callable) -> Label:
		var __vMVgj7wTK8a3dnHMtslUO26Y: Button = __yDUDnCjoYKMLR7KGcyuw646g("-", Rect2(12, y, 20, 20))
		__vMVgj7wTK8a3dnHMtslUO26Y.pressed.connect( func() -> void : step.call(-1))
		var __Yt5mwfn_VX8jGM6L5u0IB7Um: Label = __2rdl1YpQzYXJobnYMjl8amhK.label("", Vector2(34, y + 2), 30, 12, __eBt5HIxcCIYFCRhcyd21idU2.__pCUi6LToFPukNiGDrBwJ7It8, HORIZONTAL_ALIGNMENT_CENTER)
		var __YtygabCZJTb74LzoHKuVWPCU: Button = __yDUDnCjoYKMLR7KGcyuw646g("+", Rect2(66, y, 20, 20))
		__YtygabCZJTb74LzoHKuVWPCU.pressed.connect( func() -> void : step.call(1))
		__3H20y0a5xyuZ1u6aIXwvOavt.append_array([__vMVgj7wTK8a3dnHMtslUO26Y, __YtygabCZJTb74LzoHKuVWPCU])
		return __Yt5mwfn_VX8jGM6L5u0IB7Um
	func __iajP58UcVT3PeJgwWqfL1fm_() -> int:
		var __kZV749YOOSklnNgbyAs2Qb3p: int = __M0ImV248NGNrBFXy9NCs5jwX.__CcuJfEJlHGrXUgnJDReo2jb7(__V0pOn5Sa7N2eQmRM4kwRkT34)
		var __sHUu4rHasDW07tq5E6tTADyV: int = maxi(1, int((__M0ImV248NGNrBFXy9NCs5jwX.__qyvbOrjVYs2zGM2jUVQYSgGR.get("replenish", {}) as Dictionary).get("cost", 0)))
		return maxi(0, mini(__kZV749YOOSklnNgbyAs2Qb3p - __V0pOn5Sa7N2eQmRM4kwRkT34.__O5HLNA7SlbaePlRbjeQY8Yaz(), __M0ImV248NGNrBFXy9NCs5jwX.points / __sHUu4rHasDW07tq5E6tTADyV))
	func __eTnQPnl0mkuCVjw7ZfkbGf9R() -> int:
		var __0iBUsdIq_OOMKaIOx74AExT2: Dictionary = __M0ImV248NGNrBFXy9NCs5jwX.__qyvbOrjVYs2zGM2jUVQYSgGR.get("promote", {})
		var __XTN09g6pT8hYKrLKH1xpnTTo: int = maxi(1, int(__0iBUsdIq_OOMKaIOx74AExT2.get("cost", 0)))
		var g: int = __M0ImV248NGNrBFXy9NCs5jwX.__5xe9ruE_3UmhX284W8xBhd_j()
		var __dX1yrFBpDVclJBVdpU6UqN5d: int = __M0ImV248NGNrBFXy9NCs5jwX.__76YQlbOoFzFgpPn_qa5fce31(__V0pOn5Sa7N2eQmRM4kwRkT34) - __V0pOn5Sa7N2eQmRM4kwRkT34.__pY661vwzoRY0D6Y5ORWYVaB_[2]
		return maxi(0, mini(mini(__V0pOn5Sa7N2eQmRM4kwRkT34.__pY661vwzoRY0D6Y5ORWYVaB_[1] / g, __dX1yrFBpDVclJBVdpU6UqN5d / g), __M0ImV248NGNrBFXy9NCs5jwX.points / __XTN09g6pT8hYKrLKH1xpnTTo))
	func __jEO474GcDRPRj7yr3P7HaOhQ() -> void :
		var __1CkaC8LvGNi0i0FlLcVZSEv8: int = __M0ImV248NGNrBFXy9NCs5jwX.__CcuJfEJlHGrXUgnJDReo2jb7(__V0pOn5Sa7N2eQmRM4kwRkT34)
		var __3tBPVQV2U822dOz60Z4py_Zo: Dictionary = __M0ImV248NGNrBFXy9NCs5jwX.__qyvbOrjVYs2zGM2jUVQYSgGR.get("promote", {})
		var __vxluzbZKPuu9mH3VeVMnDMO1: int = __V0pOn5Sa7N2eQmRM4kwRkT34.__O5HLNA7SlbaePlRbjeQY8Yaz()
		__IY5eAN7U1gwZI6Ycq4wOyErd.text = tr("UI_RCT_PRO_DESC") % [__M0ImV248NGNrBFXy9NCs5jwX.__5xe9ruE_3UmhX284W8xBhd_j(), __M0ImV248NGNrBFXy9NCs5jwX.__jzYnT2qz6bxMyJubqlRmPdDW(__V0pOn5Sa7N2eQmRM4kwRkT34.__pY661vwzoRY0D6Y5ORWYVaB_[2])]
		__S3uq3CMk97hdPpLJiAuEKa73.text = tr("UI_RCT_TOTAL") % [__vxluzbZKPuu9mH3VeVMnDMO1, __1CkaC8LvGNi0i0FlLcVZSEv8]
		for __9WylO56XYT2DSiMWraCP1HbH: int in 3:
			__g4Q6WqqM555qbhOLLvFE2KuI[__9WylO56XYT2DSiMWraCP1HbH].text = str(__V0pOn5Sa7N2eQmRM4kwRkT34.__pY661vwzoRY0D6Y5ORWYVaB_[__9WylO56XYT2DSiMWraCP1HbH])
		var __N1ofonNYZC2oT1ZLMzuRPAwW: int = int(__3tBPVQV2U822dOz60Z4py_Zo.get("tech_ratio_max", 50))
		__8FZHxQK4mEeU1H471tJvudgl.text = tr("UI_RCT_RATIO") % [__V0pOn5Sa7N2eQmRM4kwRkT34.__pY661vwzoRY0D6Y5ORWYVaB_[2] * 100 / maxi(1, __1CkaC8LvGNi0i0FlLcVZSEv8), __N1ofonNYZC2oT1ZLMzuRPAwW]
		__BfRNayRIqIsAyP38HIfsaNfd.__pY661vwzoRY0D6Y5ORWYVaB_ = __V0pOn5Sa7N2eQmRM4kwRkT34.__pY661vwzoRY0D6Y5ORWYVaB_
		__BfRNayRIqIsAyP38HIfsaNfd.__E7y2lnfLTWAN5lJ2R6i8eFM7 = __1CkaC8LvGNi0i0FlLcVZSEv8
		__BfRNayRIqIsAyP38HIfsaNfd.queue_redraw()
		var __XPjebCXMahMmK_nMxxKabdx3: int = __iajP58UcVT3PeJgwWqfL1fm_()
		var __whk5ck16tdzE9UJ2v_gUFWtS: int = __eTnQPnl0mkuCVjw7ZfkbGf9R()
		__UQpH28jj_RgSoiSTygc3G0oD = clampi(__UQpH28jj_RgSoiSTygc3G0oD, mini(1, __XPjebCXMahMmK_nMxxKabdx3), __XPjebCXMahMmK_nMxxKabdx3)
		__4byg609Zc4U54BTJTOpoPoGT = clampi(__4byg609Zc4U54BTJTOpoPoGT, mini(1, __whk5ck16tdzE9UJ2v_gUFWtS), __whk5ck16tdzE9UJ2v_gUFWtS)
		__RJR1zfZblDn9VfFz4aPqH2A6.text = str(__UQpH28jj_RgSoiSTygc3G0oD)
		__pX6xt8D5cvvTYGMFJbK2jgm8.text = str(__4byg609Zc4U54BTJTOpoPoGT * __M0ImV248NGNrBFXy9NCs5jwX.__5xe9ruE_3UmhX284W8xBhd_j())
		var __hwR_9LiFAdkdw74S_XJZ7vlP: int = int((__M0ImV248NGNrBFXy9NCs5jwX.__qyvbOrjVYs2zGM2jUVQYSgGR.get("replenish", {}) as Dictionary).get("cost", 0))
		__XBO327ijDPCZZDxP0VhauamJ.text = tr("UI_RCT_ADD_BTN") % [__UQpH28jj_RgSoiSTygc3G0oD, __UQpH28jj_RgSoiSTygc3G0oD * __hwR_9LiFAdkdw74S_XJZ7vlP]
		__T6cdTpUxNSycZasJLXCMWqY5.text = tr("UI_RCT_PRO_BTN") % [__4byg609Zc4U54BTJTOpoPoGT * __M0ImV248NGNrBFXy9NCs5jwX.__5xe9ruE_3UmhX284W8xBhd_j(), __4byg609Zc4U54BTJTOpoPoGT * int(__3tBPVQV2U822dOz60Z4py_Zo.get("cost", 0))]
		__XBO327ijDPCZZDxP0VhauamJ.disabled = __UQpH28jj_RgSoiSTygc3G0oD <= 0
		__u2niK09JldXYawO9HEktUiez.disabled = __XPjebCXMahMmK_nMxxKabdx3 <= 0
		__T6cdTpUxNSycZasJLXCMWqY5.disabled = __4byg609Zc4U54BTJTOpoPoGT <= 0
		meti_promote_max.disabled = __whk5ck16tdzE9UJ2v_gUFWtS <= 0
		__3H20y0a5xyuZ1u6aIXwvOavt[0].disabled = __UQpH28jj_RgSoiSTygc3G0oD <= 1
		__3H20y0a5xyuZ1u6aIXwvOavt[1].disabled = __UQpH28jj_RgSoiSTygc3G0oD >= __XPjebCXMahMmK_nMxxKabdx3
		__3H20y0a5xyuZ1u6aIXwvOavt[2].disabled = __4byg609Zc4U54BTJTOpoPoGT <= 1
		__3H20y0a5xyuZ1u6aIXwvOavt[3].disabled = __4byg609Zc4U54BTJTOpoPoGT >= __whk5ck16tdzE9UJ2v_gUFWtS
		__XBO327ijDPCZZDxP0VhauamJ.tooltip_text = "" if __XPjebCXMahMmK_nMxxKabdx3 > 0 else tr(__AAby3sDPbx0O3p59IMTqFbay())
		__T6cdTpUxNSycZasJLXCMWqY5.tooltip_text = "" if __whk5ck16tdzE9UJ2v_gUFWtS > 0 else __cjzYnUInmyyJ7Vy5NFlMoQ2Y()
		__SZIyxJrIfE4tCQ8YTGZog0Fu.text = tr("UI_CREW_POINTS") % __M0ImV248NGNrBFXy9NCs5jwX.points
		__A16Bf5XHDci9_3J6mm37sq7o()
	func __AAby3sDPbx0O3p59IMTqFbay() -> String:
		var __vk8RB3K5iuTEDVtpA3ytBU_8: int = __M0ImV248NGNrBFXy9NCs5jwX.__CcuJfEJlHGrXUgnJDReo2jb7(__V0pOn5Sa7N2eQmRM4kwRkT34)
		return "UI_CREW_ERR_MEN_FULL" if __V0pOn5Sa7N2eQmRM4kwRkT34.__O5HLNA7SlbaePlRbjeQY8Yaz() >= __vk8RB3K5iuTEDVtpA3ytBU_8 else "UI_CREW_ERR_POINTS"
	func __cjzYnUInmyyJ7Vy5NFlMoQ2Y() -> String:
		var __ORb56UEda5X7G2ESKRJjMV0r: Dictionary = __M0ImV248NGNrBFXy9NCs5jwX.__qyvbOrjVYs2zGM2jUVQYSgGR.get("promote", {})
		if __V0pOn5Sa7N2eQmRM4kwRkT34.__pY661vwzoRY0D6Y5ORWYVaB_[1] < __M0ImV248NGNrBFXy9NCs5jwX.__5xe9ruE_3UmhX284W8xBhd_j():
			return tr("UI_CREW_ERR_NO_SKILLED") % __M0ImV248NGNrBFXy9NCs5jwX.__5xe9ruE_3UmhX284W8xBhd_j()
		if __M0ImV248NGNrBFXy9NCs5jwX.points < int(__ORb56UEda5X7G2ESKRJjMV0r.get("cost", 0)):
			return tr("UI_CREW_ERR_POINTS")
		return tr("UI_CREW_ERR_TECH_RATIO") % int(__ORb56UEda5X7G2ESKRJjMV0r.get("tech_ratio_max", 50))
	func meti_refill_all() -> void:
		__UQpH28jj_RgSoiSTygc3G0oD = __iajP58UcVT3PeJgwWqfL1fm_()
		if __UQpH28jj_RgSoiSTygc3G0oD > 0:
			__oKaBQBat8BGlUAt9PnWrEUIB()
	func meti_promote_all() -> void:
		__4byg609Zc4U54BTJTOpoPoGT = __eTnQPnl0mkuCVjw7ZfkbGf9R()
		if __4byg609Zc4U54BTJTOpoPoGT > 0:
			__w7QZ9O3JmMeNrlVYNV1gFTCM()
	func __oKaBQBat8BGlUAt9PnWrEUIB() -> void :
		var __oTkFfhqZ8louyXNjQAyBd9rC: int = 0
		var __RfvoIn68CIqziZ5HI5THINrq: String = ""
		for __TeF8myJQLywcFLdK06C7bmWn: int in __UQpH28jj_RgSoiSTygc3G0oD:
			__RfvoIn68CIqziZ5HI5THINrq = __M0ImV248NGNrBFXy9NCs5jwX.__Vfb4Ou3z3jnnT0Pr23tgyLkU(__V0pOn5Sa7N2eQmRM4kwRkT34)
			if __RfvoIn68CIqziZ5HI5THINrq != "":
				break
			__oTkFfhqZ8louyXNjQAyBd9rC += 1
		if __oTkFfhqZ8louyXNjQAyBd9rC > 0:
			__wr6C8oBxKi3NsqbLhFXJNUAz()
		__uyeop6Qie0WxRTJMNrhG3AqM(tr("UI_RCT_ADD_DONE") % __oTkFfhqZ8louyXNjQAyBd9rC, __RfvoIn68CIqziZ5HI5THINrq, __oTkFfhqZ8louyXNjQAyBd9rC > 0)
	func __w7QZ9O3JmMeNrlVYNV1gFTCM() -> void :
		var __Jvur7aPIBduevHuB_jjGH4mW: int = 0
		var __lsxrWOHETdjOxil7y2CHTBJE: int = 0
		var __o02s_h5hYJk8l3c40iXKggG1: int = 0
		var __qZrvwuKwdMXdLHxy1273NrTr: String = ""
		for __QJ6tqYGxjvqrwS0bWwI4FO7U: int in __4byg609Zc4U54BTJTOpoPoGT:
			var r: Dictionary = __M0ImV248NGNrBFXy9NCs5jwX.__DNylqQ3lXnvZsUmwZubbVYvv(__V0pOn5Sa7N2eQmRM4kwRkT34)
			if str(r["err"]) != "":
				__qZrvwuKwdMXdLHxy1273NrTr = str(r["err"])
				break
			if bool(r["ok"]):
				__Jvur7aPIBduevHuB_jjGH4mW += 1
			else:
				__lsxrWOHETdjOxil7y2CHTBJE += 1
				__o02s_h5hYJk8l3c40iXKggG1 += int(r["lost"])
		if __Jvur7aPIBduevHuB_jjGH4mW + __lsxrWOHETdjOxil7y2CHTBJE > 0:
			__wr6C8oBxKi3NsqbLhFXJNUAz()
		var g: int = __M0ImV248NGNrBFXy9NCs5jwX.__5xe9ruE_3UmhX284W8xBhd_j()
		var text: String = tr("UI_RCT_PRO_DONE") % [(__Jvur7aPIBduevHuB_jjGH4mW + __lsxrWOHETdjOxil7y2CHTBJE) * g, __Jvur7aPIBduevHuB_jjGH4mW * g, __lsxrWOHETdjOxil7y2CHTBJE * g]
		if __o02s_h5hYJk8l3c40iXKggG1 > 0:
			text += "　" + tr("UI_RCT_PRO_LOST") % __o02s_h5hYJk8l3c40iXKggG1
		__uyeop6Qie0WxRTJMNrhG3AqM(text, __qZrvwuKwdMXdLHxy1273NrTr, __Jvur7aPIBduevHuB_jjGH4mW > 0)
	func __uyeop6Qie0WxRTJMNrhG3AqM(text: String, __65A8b61rYo7qQGMXqZkGnw3w: String, __orRVIp_VgymVe6H2H0hN_d7D: bool) -> void :
		if __65A8b61rYo7qQGMXqZkGnw3w != "":
			var __xg54Dbr8KdZfwEr3OKbM68Yw: Dictionary = __M0ImV248NGNrBFXy9NCs5jwX.__qyvbOrjVYs2zGM2jUVQYSgGR.get("promote", {})
			text += "　" + (tr(__65A8b61rYo7qQGMXqZkGnw3w) % int(__xg54Dbr8KdZfwEr3OKbM68Yw.get("tech_ratio_max", 50)) if __65A8b61rYo7qQGMXqZkGnw3w == "UI_CREW_ERR_TECH_RATIO"
				else tr(__65A8b61rYo7qQGMXqZkGnw3w) % __M0ImV248NGNrBFXy9NCs5jwX.__5xe9ruE_3UmhX284W8xBhd_j() if __65A8b61rYo7qQGMXqZkGnw3w == "UI_CREW_ERR_NO_SKILLED" else tr(__65A8b61rYo7qQGMXqZkGnw3w))
		__7H43Ndo8eGlyx33k8VIcB8Cb.text = text
		__7H43Ndo8eGlyx33k8VIcB8Cb.add_theme_color_override("font_color", __eBt5HIxcCIYFCRhcyd21idU2.__RIF_kToydsL5hGiT2p5OxAaC if __orRVIp_VgymVe6H2H0hN_d7D and __65A8b61rYo7qQGMXqZkGnw3w == "" else
			__eBt5HIxcCIYFCRhcyd21idU2.GOLD if __orRVIp_VgymVe6H2H0hN_d7D else __eBt5HIxcCIYFCRhcyd21idU2.__PDJ2eYH1RM56AXV47Yaop2B3)
		__jEO474GcDRPRj7yr3P7HaOhQ()
class __z3gRH6PysI2uTsBRMQHzukNF extends Control:
	var __GD_Tb7il6TQtKgcYWL0lZFKw: Array[int] = []
	func _init() -> void :
		mouse_filter = Control.MOUSE_FILTER_IGNORE
	func _draw() -> void :
		draw_rect(Rect2(Vector2.ZERO, size), __l0ljxOzuGuAaMAg0E9tYqY8N.__FZypoysBpi4L67LAu9AxsRfZ)
		draw_rect(Rect2(1, 1, size.x - 2, 26), __l0ljxOzuGuAaMAg0E9tYqY8N.__uM0syOiZSyAoYRI1egXEgPRF)
		draw_rect(Rect2(Vector2(0.5, 0.5), size - Vector2.ONE), __l0ljxOzuGuAaMAg0E9tYqY8N.__UaQzKGmq2KuW6fOzrZIiSZtk, false, 1.0)
		draw_rect(Rect2(8, 27, size.x - 16, 1), __l0ljxOzuGuAaMAg0E9tYqY8N.__5BdrvxK7qD5BiVk_0jPZ4czq)
		for y: int in __GD_Tb7il6TQtKgcYWL0lZFKw:
			draw_rect(Rect2(8, y, size.x - 16, 1), __l0ljxOzuGuAaMAg0E9tYqY8N.__IBVvKw1yASSe7F4G5OVPjjdj)
class __8yu8GD_ZgOog4dbaHoAeo0ZT extends __F4kscdCfLUw02HL8Nfie7uTc:
	var meti_editor: __F4kscdCfLUw02HL8Nfie7uTc
	const __kD5MpGbGI03ItQXuZAiXJBoV: = Vector2(339, 290)
	const __PVfrKMpssNfX1J97RR8JxrWt: = 60.0
	const __O_krrF5upjv1sZYM1ft4t0FV: = 14.0
	const __zeoy5WjtGnie9mU_K404PnIk: = Rect2(12, 0, 44, 0)
	const __8DH0IlpFmjMCyvkslQ4FdpdO: = Rect2(60, 0, 34, 0)
	const __HBvlsuMmw3a1jcJDwOSu9p9N: = Rect2(98, 0, 70, 0)
	const __fK8FknhpJRE7MqOD7OXQuDIf: = 178.0
	const __EaclKTmUdkf08KLlspkVhdxX: = 246.0
	const __cJNoqh2PxHxeipGeIuo3EilA: = Rect2(219, 48, 80, 76)
	var __bNpgT2BxiH3CD1iBFUUNwXbJ: __CgOl36_UCxYZW5PzufCcS4dS
	var __rTdHfnuBKvdJerDkCuzj7CJA: LineEdit
	var __BfRNayRIqIsAyP38HIfsaNfd: __KqpJI15OWa9wtuu_qSFM18MR
	var __a1IjpQ12r8cu_mfF788x73jw: __Er3qHKxcEkfUWPtjkXRE6sZ3
	var __BlMN9DF2UHk8LqS0CbSZTxR1: Label
	var __ORFbdEP7kiyEAhO6Tecs4znN: Label
	var __SZIyxJrIfE4tCQ8YTGZog0Fu: Label
	var __dcoyKKoyVrfXazt060r7nlNQ: Array[Label] = []
	var __0fbpjzU1GTaECaOEvJip62FT: Array[Label] = []
	func __YNjSGlrkuU4xu5LIhzsrDpM7() -> void :
		__2rdl1YpQzYXJobnYMjl8amhK.size = __kD5MpGbGI03ItQXuZAiXJBoV
		__bNpgT2BxiH3CD1iBFUUNwXbJ = __M0ImV248NGNrBFXy9NCs5jwX.__6PFrcId2T_VUOlJQ2HU0rfRp()
		var __nZCBH5W1_tbIX7AFcUhNTtTD: __2eoTFZc6WxKKaBxTkxeRtmOZ = __M0ImV248NGNrBFXy9NCs5jwX.__ofKSCLcCg7jWtqacDa153ehk()
		__BfRNayRIqIsAyP38HIfsaNfd = __KqpJI15OWa9wtuu_qSFM18MR.new()
		__BfRNayRIqIsAyP38HIfsaNfd.size = __kD5MpGbGI03ItQXuZAiXJBoV
		__2rdl1YpQzYXJobnYMjl8amhK.add_child(__BfRNayRIqIsAyP38HIfsaNfd)
		__2rdl1YpQzYXJobnYMjl8amhK.label(tr("UI_RECRUIT_TITLE"), Vector2(14, 6), 120, 15, __eBt5HIxcCIYFCRhcyd21idU2.__pCUi6LToFPukNiGDrBwJ7It8)
		__2rdl1YpQzYXJobnYMjl8amhK.label(tr("UI_RECRUIT_COST_EACH") % __M0ImV248NGNrBFXy9NCs5jwX.__8je_IJ9qXhG3jZ1HE7jMMTAq(), Vector2(130, 12), __kD5MpGbGI03ItQXuZAiXJBoV.x - 144, 10, __eBt5HIxcCIYFCRhcyd21idU2.__kVYXi_NVoyPvuzc3ek8hOGFd, HORIZONTAL_ALIGNMENT_RIGHT)
		__2rdl1YpQzYXJobnYMjl8amhK.label(tr("UI_RECRUIT_GROWTH"), Vector2(__zeoy5WjtGnie9mU_K404PnIk.position.x, 40), __zeoy5WjtGnie9mU_K404PnIk.size.x, 10, __eBt5HIxcCIYFCRhcyd21idU2.__kVYXi_NVoyPvuzc3ek8hOGFd, HORIZONTAL_ALIGNMENT_RIGHT)
		__2rdl1YpQzYXJobnYMjl8amhK.label(tr("UI_RECRUIT_ABILITY"), Vector2(__HBvlsuMmw3a1jcJDwOSu9p9N.position.x, 40), __HBvlsuMmw3a1jcJDwOSu9p9N.size.x, 10, __eBt5HIxcCIYFCRhcyd21idU2.__kVYXi_NVoyPvuzc3ek8hOGFd, HORIZONTAL_ALIGNMENT_RIGHT)
		for __fzYwJpsYPcMUsMzuMIcc46S1: int in __o4BlGoLwjfAD3TYKD8Kt7FzU.__yJKOGHp90JmK10a2SV3ahPUB:
			var y: float = __PVfrKMpssNfX1J97RR8JxrWt + __fzYwJpsYPcMUsMzuMIcc46S1 * __O_krrF5upjv1sZYM1ft4t0FV
			__2rdl1YpQzYXJobnYMjl8amhK.label(tr(__o4BlGoLwjfAD3TYKD8Kt7FzU.__nhIhJXV65hiKRA5xP5eP8UVS[__fzYwJpsYPcMUsMzuMIcc46S1]), Vector2(__8DH0IlpFmjMCyvkslQ4FdpdO.position.x, y), __8DH0IlpFmjMCyvkslQ4FdpdO.size.x, 10, __eBt5HIxcCIYFCRhcyd21idU2.__pCUi6LToFPukNiGDrBwJ7It8, HORIZONTAL_ALIGNMENT_CENTER)
			__dcoyKKoyVrfXazt060r7nlNQ.append(__2rdl1YpQzYXJobnYMjl8amhK.label("", Vector2(__zeoy5WjtGnie9mU_K404PnIk.position.x, y), __zeoy5WjtGnie9mU_K404PnIk.size.x, 10, __eBt5HIxcCIYFCRhcyd21idU2.__kVYXi_NVoyPvuzc3ek8hOGFd, HORIZONTAL_ALIGNMENT_RIGHT))
			__0fbpjzU1GTaECaOEvJip62FT.append(__2rdl1YpQzYXJobnYMjl8amhK.label("", Vector2(__HBvlsuMmw3a1jcJDwOSu9p9N.position.x, y), __HBvlsuMmw3a1jcJDwOSu9p9N.size.x, 10, __eBt5HIxcCIYFCRhcyd21idU2.__pCUi6LToFPukNiGDrBwJ7It8, HORIZONTAL_ALIGNMENT_RIGHT))
		var __lZxNBJlpGBTgZcw1K_kg7MY9: __3CVc7kD6yGCHSiBfO0OphMVd = __2rdl1YpQzYXJobnYMjl8amhK.frame("ITPNFS", __BiFSUv8Gzh1wsdt1e8Siujil[__nZCBH5W1_tbIX7AFcUhNTtTD.__V9nPx6hwHXTjiZSit4R51eP0 if __nZCBH5W1_tbIX7AFcUhNTtTD != null and __nZCBH5W1_tbIX7AFcUhNTtTD.__V9nPx6hwHXTjiZSit4R51eP0 < 9 else 0])
		if __lZxNBJlpGBTgZcw1K_kg7MY9.__5SRgdq4kqUc88lslGOc_6RxY != null and __lZxNBJlpGBTgZcw1K_kg7MY9.__5SRgdq4kqUc88lslGOc_6RxY.__9GUNq0RC3I2wtF6RyGyGCuST != null:
			__lZxNBJlpGBTgZcw1K_kg7MY9.position = (__cJNoqh2PxHxeipGeIuo3EilA.get_center() - __lZxNBJlpGBTgZcw1K_kg7MY9.__5SRgdq4kqUc88lslGOc_6RxY.__9GUNq0RC3I2wtF6RyGyGCuST.get_size() / 2.0 - Vector2(__lZxNBJlpGBTgZcw1K_kg7MY9.__5SRgdq4kqUc88lslGOc_6RxY.__0qOEymYSM0v6_xaX4s5nNVDN)).floor()
		__lZxNBJlpGBTgZcw1K_kg7MY9.modulate = Color(1, 1, 1, 0.35)
		__a1IjpQ12r8cu_mfF788x73jw = __Er3qHKxcEkfUWPtjkXRE6sZ3.new()
		__a1IjpQ12r8cu_mfF788x73jw.position = (__cJNoqh2PxHxeipGeIuo3EilA.get_center() - __Er3qHKxcEkfUWPtjkXRE6sZ3.__kD5MpGbGI03ItQXuZAiXJBoV / 2.0).floor()
		__2rdl1YpQzYXJobnYMjl8amhK.add_child(__a1IjpQ12r8cu_mfF788x73jw)
		__2rdl1YpQzYXJobnYMjl8amhK.label(tr("UI_CREW_NEW"), Vector2(__fK8FknhpJRE7MqOD7OXQuDIf + 4, 132), __kD5MpGbGI03ItQXuZAiXJBoV.x - __fK8FknhpJRE7MqOD7OXQuDIf - 16, 12, __eBt5HIxcCIYFCRhcyd21idU2.__pCUi6LToFPukNiGDrBwJ7It8, HORIZONTAL_ALIGNMENT_CENTER)
		__ORFbdEP7kiyEAhO6Tecs4znN = __2rdl1YpQzYXJobnYMjl8amhK.label("", Vector2(__fK8FknhpJRE7MqOD7OXQuDIf + 12, 156), __kD5MpGbGI03ItQXuZAiXJBoV.x - __fK8FknhpJRE7MqOD7OXQuDIf - 24, 10, __eBt5HIxcCIYFCRhcyd21idU2.__kVYXi_NVoyPvuzc3ek8hOGFd)
		__BlMN9DF2UHk8LqS0CbSZTxR1 = __2rdl1YpQzYXJobnYMjl8amhK.label("", Vector2(__fK8FknhpJRE7MqOD7OXQuDIf + 12, 170), __kD5MpGbGI03ItQXuZAiXJBoV.x - __fK8FknhpJRE7MqOD7OXQuDIf - 24, 10, __eBt5HIxcCIYFCRhcyd21idU2.__kVYXi_NVoyPvuzc3ek8hOGFd)
		__2rdl1YpQzYXJobnYMjl8amhK.label(tr("UI_RECRUIT_NAME"), Vector2(__fK8FknhpJRE7MqOD7OXQuDIf + 10, 200), 40, 11, Color8(150, 200, 255))
		__rTdHfnuBKvdJerDkCuzj7CJA = __wn5nAt9XM2nfbeV9j61lCf86(Rect2(__fK8FknhpJRE7MqOD7OXQuDIf + 48, 198, __kD5MpGbGI03ItQXuZAiXJBoV.x - __fK8FknhpJRE7MqOD7OXQuDIf - 60, 18), tr("UI_CREW_DEFAULT_NAME") % __M0ImV248NGNrBFXy9NCs5jwX.__GeYr1koKZu4yf18L5fqj_M1U)
		__rTdHfnuBKvdJerDkCuzj7CJA.text_submitted.connect( func(__nDfftqYJ0VuUVdJEZpaSa4Zd: String) -> void : __NEjveIvKHqpK8LMeW8CKwZk9())
		var meti_button: Button = __yDUDnCjoYKMLR7KGcyuw646g("成長自選", Rect2(190, 222, 65, 20), "保留抽選總額，分配至兩項能力；改動後雇用加收 500 海點。", 9)
		meti_button.name = "MetiGrowthOpen"
		meti_button.pressed.connect(meti_open_growth)
		var meti_custom: Button = __yDUDnCjoYKMLR7KGcyuw646g("自訂招募", Rect2(262, 222, 65, 20), "初始能力各50；固定15、20或25點成長，雇用總價5000、10000或20000海點。", 9)
		meti_custom.name = "MetiCustomOpen"
		meti_custom.pressed.connect(meti_open_custom)
		__SZIyxJrIfE4tCQ8YTGZog0Fu = __2rdl1YpQzYXJobnYMjl8amhK.label("", Vector2(14, __EaclKTmUdkf08KLlspkVhdxX + 15), 100, 10, __eBt5HIxcCIYFCRhcyd21idU2.GOLD)
		var __98MxZ4J2QxW32qzN_uZA8FIh: Button = __yDUDnCjoYKMLR7KGcyuw646g(tr("UI_CREW_REROLL") % __M0ImV248NGNrBFXy9NCs5jwX.__8je_IJ9qXhG3jZ1HE7jMMTAq(), Rect2(118, __EaclKTmUdkf08KLlspkVhdxX + 12, 88, 22), "", 10)
		__98MxZ4J2QxW32qzN_uZA8FIh.name = "MetiRecruitReroll"
		__98MxZ4J2QxW32qzN_uZA8FIh.pressed.connect(__5w_osxo9pekTSeW2zuR7Ty3L)
		var __Iu4U5V4BUlsGD_JYCB7z73WH: Button = __yDUDnCjoYKMLR7KGcyuw646g(tr("UI_CREW_HIRE"), Rect2(212, __EaclKTmUdkf08KLlspkVhdxX + 12, 56, 22), "", 10)
		__Iu4U5V4BUlsGD_JYCB7z73WH.pressed.connect(__NEjveIvKHqpK8LMeW8CKwZk9)
		var __QrDw_vcT76iib0S4g8Mxmehn: Button = __yDUDnCjoYKMLR7KGcyuw646g(tr("UI_CANCEL"), Rect2(272, __EaclKTmUdkf08KLlspkVhdxX + 12, 54, 22), "", 10)
		__QrDw_vcT76iib0S4g8Mxmehn.pressed.connect(close)
		__jEO474GcDRPRj7yr3P7HaOhQ()
	func __jEO474GcDRPRj7yr3P7HaOhQ() -> void :
		var __VVVlSlXuz2orqB2at7OqlwIj: Dictionary = __M0ImV248NGNrBFXy9NCs5jwX.__LVCMU4xMBMMHO5bxpAYeHYWt(__bNpgT2BxiH3CD1iBFUUNwXbJ)
		__a1IjpQ12r8cu_mfF788x73jw.__H8edGzuZdf8pc4sUjNkAWiOb(__VVVlSlXuz2orqB2at7OqlwIj)
		var __8kyHFDCpELJ_JG77BT6vS5rO: int = maxi(1, int((__M0ImV248NGNrBFXy9NCs5jwX.__qyvbOrjVYs2zGM2jUVQYSgGR.get("recruit", {}) as Dictionary).get("ability_max", 10)))
		for __vGRvd9aYyRh9XCM0QYpO1Kow: int in __o4BlGoLwjfAD3TYKD8Kt7FzU.__yJKOGHp90JmK10a2SV3ahPUB:
			var g: int = __bNpgT2BxiH3CD1iBFUUNwXbJ.__wC11jxHS1J5bzkNesfKgNncZ[__vGRvd9aYyRh9XCM0QYpO1Kow]
			__dcoyKKoyVrfXazt060r7nlNQ[__vGRvd9aYyRh9XCM0QYpO1Kow].text = "%+d" % g if g != 0 else "0"
			__dcoyKKoyVrfXazt060r7nlNQ[__vGRvd9aYyRh9XCM0QYpO1Kow].add_theme_color_override("font_color", __eBt5HIxcCIYFCRhcyd21idU2.__RIF_kToydsL5hGiT2p5OxAaC if g > 0 else __eBt5HIxcCIYFCRhcyd21idU2.__PDJ2eYH1RM56AXV47Yaop2B3 if g < 0 else __eBt5HIxcCIYFCRhcyd21idU2.__kVYXi_NVoyPvuzc3ek8hOGFd)
			__0fbpjzU1GTaECaOEvJip62FT[__vGRvd9aYyRh9XCM0QYpO1Kow].text = str(__bNpgT2BxiH3CD1iBFUUNwXbJ.__4ObdBYhtKkHScUayTPgiYzH_[__vGRvd9aYyRh9XCM0QYpO1Kow])
		var __aVvrckoVTquKYPhscvT2MwY_: = PackedFloat32Array()
		for __LdPpMsrQoSkNw6SIcqCqg_Eg: int in __o4BlGoLwjfAD3TYKD8Kt7FzU.__yJKOGHp90JmK10a2SV3ahPUB:
			__aVvrckoVTquKYPhscvT2MwY_.append(clampf(float(__bNpgT2BxiH3CD1iBFUUNwXbJ.__4ObdBYhtKkHScUayTPgiYzH_[__LdPpMsrQoSkNw6SIcqCqg_Eg]) / float(__8kyHFDCpELJ_JG77BT6vS5rO), 0.0, 1.0))
		__BfRNayRIqIsAyP38HIfsaNfd.__tfaL_CfdgLgiWn9poTGtYJdt = __aVvrckoVTquKYPhscvT2MwY_
		__BfRNayRIqIsAyP38HIfsaNfd.queue_redraw()
		__ORFbdEP7kiyEAhO6Tecs4znN.text = tr("UI_RECRUIT_MEN") % __bNpgT2BxiH3CD1iBFUUNwXbJ.__pY661vwzoRY0D6Y5ORWYVaB_[0]
		__BlMN9DF2UHk8LqS0CbSZTxR1.text = tr("UI_RECRUIT_PRICE") % __M0ImV248NGNrBFXy9NCs5jwX.__R8eeLnrHRznQldyBPlLJbDHQ(__bNpgT2BxiH3CD1iBFUUNwXbJ)
		__SZIyxJrIfE4tCQ8YTGZog0Fu.text = tr("UI_CREW_POINTS") % __M0ImV248NGNrBFXy9NCs5jwX.points
		var meti_is_custom: bool = __bNpgT2BxiH3CD1iBFUUNwXbJ.has_meta("meti_custom_budget")
		var meti_edit: Button = find_child("MetiGrowthOpen", true, false)
		meti_edit.text = "編輯成長" if meti_is_custom else "成長自選"
		meti_edit.tooltip_text = "編輯固定方案的成長分配，雇用時按方案總價收費。" if meti_is_custom else "保留抽選總額，分配至兩項能力；改動後雇用加收500海點。"
		var meti_reroll: Button = find_child("MetiRecruitReroll", true, false)
		meti_reroll.tooltip_text = "重擲會回到一般招募，清除這名候選人的自訂分配；收取5海點。" if meti_is_custom else "重新抽選一般候選人，收取5海點。"
		__A16Bf5XHDci9_3J6mm37sq7o()
	func __5w_osxo9pekTSeW2zuR7Ty3L() -> void :
		if is_instance_valid(meti_editor): return
		var __feooUFeedKggyvKy4kLCDXUL: __CgOl36_UCxYZW5PzufCcS4dS = __M0ImV248NGNrBFXy9NCs5jwX.__mwMeGaMTJbEgeKmC9RauiMQu()
		if __feooUFeedKggyvKy4kLCDXUL == null:
			UI.__FZyGB2TVbKGb1g8kgT4bm_x4(tr("UI_CREW_ERR_POINTS"))
			return
		__bNpgT2BxiH3CD1iBFUUNwXbJ = __feooUFeedKggyvKy4kLCDXUL
		__wr6C8oBxKi3NsqbLhFXJNUAz()
		__jEO474GcDRPRj7yr3P7HaOhQ()
	func __NEjveIvKHqpK8LMeW8CKwZk9() -> void :
		if is_instance_valid(meti_editor): return
		var __En4oQKLrN9g70MOyrRzycr9M: String = __M0ImV248NGNrBFXy9NCs5jwX.__wu4mV2iA1GlGvuVZXD0a1FwK(__bNpgT2BxiH3CD1iBFUUNwXbJ, __rTdHfnuBKvdJerDkCuzj7CJA.text)
		if __En4oQKLrN9g70MOyrRzycr9M != "":
			UI.__FZyGB2TVbKGb1g8kgT4bm_x4(tr(__En4oQKLrN9g70MOyrRzycr9M) % __M0ImV248NGNrBFXy9NCs5jwX.__YdmCDD1xIu3pkuWfqNIok5yI() if __En4oQKLrN9g70MOyrRzycr9M == "UI_CREW_ERR_ROSTER_FULL" else tr(__En4oQKLrN9g70MOyrRzycr9M))
			return
		__wr6C8oBxKi3NsqbLhFXJNUAz()
		close()
	func meti_open_growth() -> void :
		if is_instance_valid(meti_editor): return
		if __bNpgT2BxiH3CD1iBFUUNwXbJ.has_meta("meti_custom_budget"):
			meti_open_custom()
			return
		var panel = MetiRecruitGrowth.new()
		meti_editor = panel
		panel.candidate = __bNpgT2BxiH3CD1iBFUUNwXbJ
		panel.recruit_panel = self
		panel.open(get_parent(), __M0ImV248NGNrBFXy9NCs5jwX, Vector2(339, 240))
	func meti_open_custom() -> void :
		if is_instance_valid(meti_editor): return
		var panel = MetiCustomRecruit.new()
		meti_editor = panel
		panel.recruit_panel = self
		panel.open(get_parent(), __M0ImV248NGNrBFXy9NCs5jwX, Vector2(360, 365))
class __a81Vt_Q1MjjhXO3fdlyOiBFi extends __F4kscdCfLUw02HL8Nfie7uTc:
	const __kD5MpGbGI03ItQXuZAiXJBoV: = Vector2(240, 182)
	const __6UjHK0F4IBugLhD7xP6fOnQi: Array[int] = [88, 148]
	var __V0pOn5Sa7N2eQmRM4kwRkT34: __CgOl36_UCxYZW5PzufCcS4dS
	var _edit: LineEdit
	var __mXB07az9M3vWJ0ZcePAKjPsY: Label
	var __zqPSs7R9SqLUOFfixUsblLFz: Button
	func __YNjSGlrkuU4xu5LIhzsrDpM7() -> void :
		__2rdl1YpQzYXJobnYMjl8amhK.size = __kD5MpGbGI03ItQXuZAiXJBoV
		var __nYd1E9Ib2OvEJzrSA9pm5JEZ: Dictionary = __M0ImV248NGNrBFXy9NCs5jwX.__LVCMU4xMBMMHO5bxpAYeHYWt(__V0pOn5Sa7N2eQmRM4kwRkT34)
		var back: = __z3gRH6PysI2uTsBRMQHzukNF.new()
		back.size = __kD5MpGbGI03ItQXuZAiXJBoV
		back.__GD_Tb7il6TQtKgcYWL0lZFKw = __6UjHK0F4IBugLhD7xP6fOnQi
		__2rdl1YpQzYXJobnYMjl8amhK.add_child(back)
		__2rdl1YpQzYXJobnYMjl8amhK.label(tr("UI_CREW_RENAME"), Vector2(12, 6), 160, 12, __eBt5HIxcCIYFCRhcyd21idU2.GOLD)
		var x: Button = __yDUDnCjoYKMLR7KGcyuw646g("×", Rect2(__kD5MpGbGI03ItQXuZAiXJBoV.x - 28, 5, 20, 18), tr("UI_CLOSE"))
		x.pressed.connect(close)
		var __Ha7LpvsSRibR5ULvR4s5J_vC: = __Er3qHKxcEkfUWPtjkXRE6sZ3.new()
		__Ha7LpvsSRibR5ULvR4s5J_vC.position = Vector2(12, 32)
		__2rdl1YpQzYXJobnYMjl8amhK.add_child(__Ha7LpvsSRibR5ULvR4s5J_vC)
		__Ha7LpvsSRibR5ULvR4s5J_vC.__H8edGzuZdf8pc4sUjNkAWiOb(__nYd1E9Ib2OvEJzrSA9pm5JEZ)
		__2rdl1YpQzYXJobnYMjl8amhK.label(str(__nYd1E9Ib2OvEJzrSA9pm5JEZ.get("name", "")), Vector2(84, 32), 144, 10, Color8(150, 200, 255))
		__2rdl1YpQzYXJobnYMjl8amhK.label(__V0pOn5Sa7N2eQmRM4kwRkT34.name, Vector2(84, 46), 144, 13, __eBt5HIxcCIYFCRhcyd21idU2.__pCUi6LToFPukNiGDrBwJ7It8)
		__2rdl1YpQzYXJobnYMjl8amhK.label("Lv%d　%s" % [__V0pOn5Sa7N2eQmRM4kwRkT34.__zMZVCIoyJu5zkEI6YyKqPDoG, tr(__o4BlGoLwjfAD3TYKD8Kt7FzU.__yDkbANaLPj6K2iCfn8NT3Pwn[int(__nYd1E9Ib2OvEJzrSA9pm5JEZ.get("nation", 0))])], Vector2(84, 63), 144, 10, __eBt5HIxcCIYFCRhcyd21idU2.__kVYXi_NVoyPvuzc3ek8hOGFd)
		__2rdl1YpQzYXJobnYMjl8amhK.label(tr("UI_CREW_RENAME_NEW"), Vector2(12, 93), 100, 11, __eBt5HIxcCIYFCRhcyd21idU2.__pCUi6LToFPukNiGDrBwJ7It8)
		_edit = __wn5nAt9XM2nfbeV9j61lCf86(Rect2(12, 110, __kD5MpGbGI03ItQXuZAiXJBoV.x - 24, 18), __V0pOn5Sa7N2eQmRM4kwRkT34.name)
		_edit.max_length = int((__M0ImV248NGNrBFXy9NCs5jwX.__qyvbOrjVYs2zGM2jUVQYSgGR.get("rename", {}) as Dictionary).get("max_len", 12))
		_edit.text_changed.connect( func(__IPGkk8aeRDvbdyeQi0DHE_sJ: String) -> void : _validate())
		_edit.text_submitted.connect( func(__22SXR4VGzYGt9B3ihIDAJdeQ: String) -> void : __KeZdsKW86rRuZW68Ov4YLv1z())
		__mXB07az9M3vWJ0ZcePAKjPsY = __2rdl1YpQzYXJobnYMjl8amhK.label("", Vector2(12, 131), __kD5MpGbGI03ItQXuZAiXJBoV.x - 24, 9, __eBt5HIxcCIYFCRhcyd21idU2.__kVYXi_NVoyPvuzc3ek8hOGFd)
		__zqPSs7R9SqLUOFfixUsblLFz = __yDUDnCjoYKMLR7KGcyuw646g(tr("UI_OK"), Rect2(__kD5MpGbGI03ItQXuZAiXJBoV.x - 140, 156, 64, 20), "", 10)
		__zqPSs7R9SqLUOFfixUsblLFz.pressed.connect(__KeZdsKW86rRuZW68Ov4YLv1z)
		var __aDBGo1K0IVVH_STLeiQr1IWj: Button = __yDUDnCjoYKMLR7KGcyuw646g(tr("UI_CANCEL"), Rect2(__kD5MpGbGI03ItQXuZAiXJBoV.x - 72, 156, 60, 20), "", 10)
		__aDBGo1K0IVVH_STLeiQr1IWj.pressed.connect(close)
		_edit.grab_focus.call_deferred()
		_edit.select_all.call_deferred()
		_validate()
	func _validate() -> void :
		var __siYJTewlsh70uk5Wfp6YhWU3: String = __M0ImV248NGNrBFXy9NCs5jwX.__jNPgEYKDT9jO3SpFHUZ8HJAM(_edit.text)
		__mXB07az9M3vWJ0ZcePAKjPsY.text = tr(__siYJTewlsh70uk5Wfp6YhWU3) if __siYJTewlsh70uk5Wfp6YhWU3 != "" else tr("UI_CREW_RENAME_HINT")
		__mXB07az9M3vWJ0ZcePAKjPsY.add_theme_color_override("font_color", __eBt5HIxcCIYFCRhcyd21idU2.__PDJ2eYH1RM56AXV47Yaop2B3 if __siYJTewlsh70uk5Wfp6YhWU3 != "" else __eBt5HIxcCIYFCRhcyd21idU2.__kVYXi_NVoyPvuzc3ek8hOGFd)
		__zqPSs7R9SqLUOFfixUsblLFz.disabled = __siYJTewlsh70uk5Wfp6YhWU3 != ""
	func __KeZdsKW86rRuZW68Ov4YLv1z() -> void :
		var __J18IREuPtJ7OSPxB1kKRXDA6: String = __M0ImV248NGNrBFXy9NCs5jwX.rename(__V0pOn5Sa7N2eQmRM4kwRkT34, _edit.text)
		if __J18IREuPtJ7OSPxB1kKRXDA6 != "":
			UI.__FZyGB2TVbKGb1g8kgT4bm_x4(tr(__J18IREuPtJ7OSPxB1kKRXDA6))
			return
		__wr6C8oBxKi3NsqbLhFXJNUAz()
		close()

class MetiRecruitGrowth extends __F4kscdCfLUw02HL8Nfie7uTc:
	var candidate: __CgOl36_UCxYZW5PzufCcS4dS
	var recruit_panel: __8yu8GD_ZgOog4dbaHoAeo0ZT
	var first: OptionButton
	var second: OptionButton
	var share: int = 1
	var budget: int = 0
	var amount: Label
	var status: Label
	var accept: Button
	var minus: Button
	var plus: Button
	func __YNjSGlrkuU4xu5LIhzsrDpM7() -> void :
		__2rdl1YpQzYXJobnYMjl8amhK.size = Vector2(339, 240)
		var back = __z3gRH6PysI2uTsBRMQHzukNF.new()
		back.size = Vector2(339, 240)
		__2rdl1YpQzYXJobnYMjl8amhK.add_child(back)
		__2rdl1YpQzYXJobnYMjl8amhK.label("招募成長自選", Vector2(14, 6), 300, 14, Color8(255, 214, 110))
		budget = __M0ImV248NGNrBFXy9NCs5jwX.meti_recruit_budget(candidate)
		__2rdl1YpQzYXJobnYMjl8amhK.label("抽選總額 %d 點，分配至兩項不同能力。" % budget, Vector2(14, 35), 310, 11)
		__2rdl1YpQzYXJobnYMjl8amhK.label("這是每次升級的加成；初始能力維持抽選。", Vector2(14, 52), 310, 11)
		first = meti_option("MetiFirst", Vector2(14, 79))
		second = meti_option("MetiSecond", Vector2(176, 79))
		minus = __yDUDnCjoYKMLR7KGcyuw646g("－", Rect2(66, 114, 30, 22), "將一點移至右側能力", 12)
		plus = __yDUDnCjoYKMLR7KGcyuw646g("＋", Rect2(244, 114, 30, 22), "將一點移至左側能力", 12)
		minus.name = "MetiMinus"
		plus.name = "MetiPlus"
		amount = __2rdl1YpQzYXJobnYMjl8amhK.label("", Vector2(103, 117), 132, 12, Color8(150, 220, 255), HORIZONTAL_ALIGNMENT_CENTER)
		status = __2rdl1YpQzYXJobnYMjl8amhK.label("", Vector2(14, 151), 310, 11)
		__2rdl1YpQzYXJobnYMjl8amhK.label("只在確認雇用時收費，取消不扣海點。", Vector2(14, 172), 310, 11)
		var reset = __yDUDnCjoYKMLR7KGcyuw646g("恢復抽選", Rect2(14, 205, 88, 22), "恢復原本分配，免自選費。", 10)
		reset.name = "MetiReset"
		accept = __yDUDnCjoYKMLR7KGcyuw646g("套用", Rect2(191, 205, 60, 22), "先套用至候選人，尚不扣款。", 10)
		accept.name = "MetiApply"
		var cancel = __yDUDnCjoYKMLR7KGcyuw646g("取消", Rect2(259, 205, 66, 22), "放棄本次編輯。", 10)
		cancel.name = "MetiCancel"
		minus.pressed.connect( func() -> void : share = maxi(1, share - 1);meti_refresh())
		plus.pressed.connect( func() -> void : share = mini(budget - 1, share + 1);meti_refresh())
		first.item_selected.connect( func(_i: int) -> void : meti_refresh())
		second.item_selected.connect( func(_i: int) -> void : meti_refresh())
		reset.pressed.connect( func() -> void : meti_select(candidate.get_meta("meti_original_growth")))
		accept.pressed.connect(meti_apply)
		cancel.pressed.connect(close)
		meti_select(candidate.__wC11jxHS1J5bzkNesfKgNncZ)
		get_viewport().gui_release_focus()
		first.grab_focus()
	func meti_option(node_name: String, pos: Vector2) -> OptionButton:
		var option = OptionButton.new()
		option.name = node_name
		option.position = pos
		option.size = Vector2(149, 25)
		option.add_theme_font_size_override("font_size", 11)
		for i: int in 11:
			option.add_item(tr(__o4BlGoLwjfAD3TYKD8Kt7FzU.__nhIhJXV65hiKRA5xP5eP8UVS[i]), i)
		__2rdl1YpQzYXJobnYMjl8amhK.add_child(option)
		return option
	func meti_select(growth: PackedInt32Array) -> void :
		var base: PackedInt32Array = candidate.get_meta("meti_base_growth")
		var indices: Array[int] = []
		for i: int in 11:
			if growth[i] > base[i]: indices.append(i)
		if indices.size() != 2:
			accept.disabled = true
			return
		first.select(indices[0])
		second.select(indices[1])
		share = growth[indices[0]] - base[indices[0]]
		meti_refresh()
	func meti_values() -> PackedInt32Array:
		var values: PackedInt32Array = candidate.get_meta("meti_base_growth").duplicate()
		values[first.selected] += share
		values[second.selected] += budget - share
		return values
	func meti_refresh() -> void :
		amount.text = "+%d     ／     +%d" % [share, budget - share]
		minus.disabled = share <= 1
		plus.disabled = share >= budget - 1
		var values: PackedInt32Array = meti_values()
		var err: String = __M0ImV248NGNrBFXy9NCs5jwX.meti_recruit_validate(candidate, values)
		accept.disabled = err != ""
		var original: PackedInt32Array = candidate.get_meta("meti_original_growth")
		var fee: int = 0 if values == original else int((__M0ImV248NGNrBFXy9NCs5jwX.__qyvbOrjVYs2zGM2jUVQYSgGR.get("recruit", {}) as Dictionary).get("meti_growth_selection_cost", 500))
		status.text = err if err != "" else "自選費 %d 海點；另收原本雇用費。" % fee
	func meti_apply() -> void :
		var err: String = __M0ImV248NGNrBFXy9NCs5jwX.meti_recruit_apply(candidate, meti_values())
		if err != "":
			status.text = err
			return
		if is_instance_valid(recruit_panel): recruit_panel.__jEO474GcDRPRj7yr3P7HaOhQ()
		close()

class MetiCustomRecruit extends __F4kscdCfLUw02HL8Nfie7uTc:
	var recruit_panel: __8yu8GD_ZgOog4dbaHoAeo0ZT
	var draft: __CgOl36_UCxYZW5PzufCcS4dS
	var budget: int = 6
	var values: PackedInt32Array = PackedInt32Array()
	var preset: OptionButton
	var remaining: Label
	var status: Label
	var price: Label
	var accept: Button
	var amounts: Array[Label] = []
	var minuses: Array[Button] = []
	var pluses: Array[Button] = []
	func __YNjSGlrkuU4xu5LIhzsrDpM7() -> void :
		__2rdl1YpQzYXJobnYMjl8amhK.size = Vector2(360, 365)
		var back = __z3gRH6PysI2uTsBRMQHzukNF.new()
		back.size = Vector2(360, 365)
		__2rdl1YpQzYXJobnYMjl8amhK.add_child(back)
		__2rdl1YpQzYXJobnYMjl8amhK.label("自訂招募／成長分配", Vector2(14, 6), 332, 14, Color8(255, 214, 110))
		preset = OptionButton.new()
		preset.name = "MetiCustomPreset"
		preset.position = Vector2(14, 34)
		preset.size = Vector2(175, 25)
		preset.add_theme_font_size_override("font_size", 10)
		for points: int in [15, 20, 25]:
			preset.add_item("%d點｜%d海點" % [points, __M0ImV248NGNrBFXy9NCs5jwX.meti_custom_price(points)], points)
		__2rdl1YpQzYXJobnYMjl8amhK.add_child(preset)
		price = __2rdl1YpQzYXJobnYMjl8amhK.label("", Vector2(198, 39), 148, 10, Color8(255, 214, 110), HORIZONTAL_ALIGNMENT_RIGHT)
		__2rdl1YpQzYXJobnYMjl8amhK.label("初始能力各50；每項成長0～5，確認雇用才扣款。", Vector2(14, 65), 332, 10)
		for i: int in 11:
			var y: float = 85 + i * 18
			__2rdl1YpQzYXJobnYMjl8amhK.label(tr(__o4BlGoLwjfAD3TYKD8Kt7FzU.__nhIhJXV65hiKRA5xP5eP8UVS[i]), Vector2(14, y), 115, 11)
			amounts.append(__2rdl1YpQzYXJobnYMjl8amhK.label("0", Vector2(139, y), 50, 11, Color8(150, 220, 255), HORIZONTAL_ALIGNMENT_CENTER))
			var less = __yDUDnCjoYKMLR7KGcyuw646g("－", Rect2(205, y, 30, 16), "減少這項每級成長", 11)
			var more = __yDUDnCjoYKMLR7KGcyuw646g("＋", Rect2(245, y, 30, 16), "增加這項每級成長", 11)
			less.name = "MetiCustomMinus%d" % i
			more.name = "MetiCustomPlus%d" % i
			less.pressed.connect(meti_step.bind(i, -1))
			more.pressed.connect(meti_step.bind(i, 1))
			minuses.append(less)
			pluses.append(more)
		remaining = __2rdl1YpQzYXJobnYMjl8amhK.label("", Vector2(14, 287), 332, 11, Color8(255, 214, 110))
		status = __2rdl1YpQzYXJobnYMjl8amhK.label("", Vector2(14, 307), 332, 10)
		var reset = __yDUDnCjoYKMLR7KGcyuw646g("清空加點", Rect2(14, 330, 90, 22), "清空本次草稿，尚不扣款。", 10)
		reset.name = "MetiCustomReset"
		accept = __yDUDnCjoYKMLR7KGcyuw646g("套用候選人", Rect2(168, 330, 92, 22), "回到招募面板預覽，尚不扣款。", 10)
		accept.name = "MetiCustomApply"
		var cancel = __yDUDnCjoYKMLR7KGcyuw646g("取消", Rect2(274, 330, 72, 22), "放棄草稿，保留原候選人。", 10)
		cancel.name = "MetiCustomCancel"
		reset.pressed.connect( func() -> void : meti_choose(preset.selected))
		accept.pressed.connect(meti_apply)
		cancel.pressed.connect(close)
		preset.item_selected.connect(meti_choose)
		var current = recruit_panel.__bNpgT2BxiH3CD1iBFUUNwXbJ
		if current.has_meta("meti_custom_budget"):
			budget = __M0ImV248NGNrBFXy9NCs5jwX.meti_recruit_budget(current)
			preset.select([15, 20, 25].find(budget))
			meti_choose(preset.selected)
			values = current.__wC11jxHS1J5bzkNesfKgNncZ.duplicate()
			meti_refresh()
		else:
			meti_choose(0)
		get_viewport().gui_release_focus()
		preset.grab_focus()
	func meti_choose(index: int) -> void :
		budget = preset.get_item_id(index)
		draft = __M0ImV248NGNrBFXy9NCs5jwX.meti_custom_new(budget)
		values = draft.get_meta("meti_base_growth").duplicate()
		meti_refresh()
	func meti_left() -> int:
		var base: PackedInt32Array = draft.get_meta("meti_base_growth")
		var used: int = 0
		for i: int in 11: used += values[i] - base[i]
		return budget - used
	func meti_step(index: int, delta: int) -> void :
		var base: PackedInt32Array = draft.get_meta("meti_base_growth")
		var cap: int = int(__M0ImV248NGNrBFXy9NCs5jwX.meti_custom_rules().get("per_ability_cap", 5))
		if delta > 0 and (meti_left() <= 0 or values[index] - base[index] >= cap): return
		if delta < 0 and values[index] <= base[index]: return
		values[index] += delta
		meti_refresh()
	func meti_refresh() -> void :
		var base: PackedInt32Array = draft.get_meta("meti_base_growth")
		var cap: int = int(__M0ImV248NGNrBFXy9NCs5jwX.meti_custom_rules().get("per_ability_cap", 5))
		for i: int in 11:
			var bonus: int = values[i] - base[i]
			amounts[i].text = "+%d" % bonus
			minuses[i].disabled = bonus <= 0
			pluses[i].disabled = bonus >= cap or meti_left() <= 0
		remaining.text = "剩餘 %d／%d 點成長" % [meti_left(), budget]
		price.text = "總價 %d 海點" % __M0ImV248NGNrBFXy9NCs5jwX.meti_custom_price(budget)
		var err: String = __M0ImV248NGNrBFXy9NCs5jwX.meti_recruit_validate(draft, values)
		accept.disabled = err != ""
		status.text = err if err != "" else "分配完成，套用後可在招募面板確認雇用。"
	func meti_apply() -> void :
		var err: String = __M0ImV248NGNrBFXy9NCs5jwX.meti_recruit_apply(draft, values)
		if err != "":
			status.text = err
			return
		if is_instance_valid(recruit_panel):
			recruit_panel.__bNpgT2BxiH3CD1iBFUUNwXbJ = draft
			recruit_panel.__jEO474GcDRPRj7yr3P7HaOhQ()
		close()
