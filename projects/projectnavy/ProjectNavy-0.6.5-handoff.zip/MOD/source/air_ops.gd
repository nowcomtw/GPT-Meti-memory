class_name __cV1TfO9LYjqVJIVXjDHEK396
static func __1dgRsGPIPsXQaZxbuhptOoZB(__ZI9Y7wXuYpUDpZrzh1V0i60T: __aDswGCE4WWdmypkp3eC7rExn, a: __YCYnibBjVPRhMDf3YPwizbkN) -> void :
	a.__6ol9zXLNVbGS9s_iAdvMaxLC -= 1
	a.__skELt8hzOP5jTm2IrBPiYtZM = false
	var depth: int = __YCYnibBjVPRhMDf3YPwizbkN.__2OJpMwzaDeyLf0HK2_6FqBy2 - __YCYnibBjVPRhMDf3YPwizbkN.__2OJpMwzaDeyLf0HK2_6FqBy2 / 10
	var __v3PnUoJqSp1UMwdeKnTS_aKu: int = (__YCYnibBjVPRhMDf3YPwizbkN.__2OJpMwzaDeyLf0HK2_6FqBy2 - a.__aBKovnuyCiI63tVuI2prB5MN) * 50 / depth
	var __xYbTqdJMGRy3jGzquLhCO4Uq: int = mini(100, __v3PnUoJqSp1UMwdeKnTS_aKu + a.__Jm4tigCFJrJQiONUKEiO3ifi * __v3PnUoJqSp1UMwdeKnTS_aKu / 100)
	var w: int = a.__PIanP8EGD25AKu3PStByHFk6 / 10 - __xYbTqdJMGRy3jGzquLhCO4Uq + 105
	var __XxqT8rEx8q5ev32JHlH4x3Uj: int = __n2nqHf6Z4jNwkx3IA7Pe4Aon(__ZI9Y7wXuYpUDpZrzh1V0i60T, a.__w4KgbGj0JQyP8PGvp68qYP1F + __ZI9Y7wXuYpUDpZrzh1V0i60T.__t2UdGLb5AjoD9DJacXSIpDUA + __ZI9Y7wXuYpUDpZrzh1V0i60T.__EaiCL_s7Is8n8XhLMgCmd8bh) % 1000
	var h: int = w / 2 - (1000 - __TXCdoY85HWzo9E7Qcf9l8raZ.__O6YJHz7KUETC0vGPOoIPvREQ[__XxqT8rEx8q5ev32JHlH4x3Uj]) * w / 1000 + a.__vqYa6WuT8lqRfpObeEEtFMHG
	h = h + 3600 if h < 0 else h % 3600
	var s: int = a.__j77VIRoHY1FrfLlG18J11iYo / -50
	var __RugqgHlCerhVR_ilqr3iquxR: int = a.pitch
	var __oLi_AeCjtVURbNisgyabMfdx: int = __B6DoyQH00PkNqJSn1pOiTHd7(1, __RugqgHlCerhVR_ilqr3iquxR) * s / 100
	var __SX7U0Oymgndmaei2XSoGwpAc: int = __B6DoyQH00PkNqJSn1pOiTHd7(2, __RugqgHlCerhVR_ilqr3iquxR) * s / 1000
	var __v0SWc_Fm2uuTa34xJVs8oj6D: int = __TXCdoY85HWzo9E7Qcf9l8raZ.__9nHAKAsjPH38LR2tAezCTqd_[h] * __SX7U0Oymgndmaei2XSoGwpAc / 100
	var __yVf3xbh_T2yOGDuSVF6m1pCX: int = __TXCdoY85HWzo9E7Qcf9l8raZ.__7laIgLr3i8VN0D_tZnYT3p0D[h] * __SX7U0Oymgndmaei2XSoGwpAc / 100
	__ZI9Y7wXuYpUDpZrzh1V0i60T.__QydBfC_Rl2VPiev0QJQPMkN2(a, __v0SWc_Fm2uuTa34xJVs8oj6D, - __yVf3xbh_T2yOGDuSVF6m1pCX, 2 * __oLi_AeCjtVURbNisgyabMfdx, __ZI9Y7wXuYpUDpZrzh1V0i60T.__EaiCL_s7Is8n8XhLMgCmd8bh + __ZI9Y7wXuYpUDpZrzh1V0i60T.__t2UdGLb5AjoD9DJacXSIpDUA + (__v0SWc_Fm2uuTa34xJVs8oj6D + __yVf3xbh_T2yOGDuSVF6m1pCX))
	if not a.__eYCv0HeDvti_w5wj1jxJpmfT:
		a.__TlWqW0m63x0ks40OasJLgdcp = -1
		a.__auam0OiXATfV0FV2pOZQsnnt = -1
	else:
		a.__eYCv0HeDvti_w5wj1jxJpmfT = false
	a.__2cQt3I45k0XXwSr_0reYodT2 = __YCYnibBjVPRhMDf3YPwizbkN.__2OJpMwzaDeyLf0HK2_6FqBy2
	a.sub = 2
	var __Jy5YtAxhuACciQJJ6dFO2MhO: Vector2i = __XdcdSffYaN4csG29A7yc6Z3i(400, 0, a.__vqYa6WuT8lqRfpObeEEtFMHG)
	a.__3epXDNnmkHn9cpXlvNEl2W4g = a.__EsOQaggwtLEnMAHn6g7H_r7O() + __Jy5YtAxhuACciQJJ6dFO2MhO.x
	a.__C3JQvlRdH1p7kRdolXEDy8oi = a.__caDHon68LplNQ04cMl2MMJ71() - __Jy5YtAxhuACciQJJ6dFO2MhO.y
static func __oLlaFkqjhrYAT8tmulRumY2_(h: int, b: int) -> int:
	if h + 1800 > b:
		return b - h
	if h + 1800 == b:
		return 1800
	return b - h - 3600
static func scan(__iw6RgVvOHeZe08kNiBn34L8K: __aDswGCE4WWdmypkp3eC7rExn, a: __YCYnibBjVPRhMDf3YPwizbkN) -> void :
	if __iw6RgVvOHeZe08kNiBn34L8K.__u0nkAKG5lGiEsenIJI6PFvMF % __DLnqkjy7DeochoblNnDXHwIc != 0:
		return
	if not a.__H0IfsdkHBf2MPjU13h3e655G:
		if a.state == __YCYnibBjVPRhMDf3YPwizbkN.State.__8wDuFUkodt91vpp0l6j8TDd6 and a.type >= 2:
			return
		if a.type == __YCYnibBjVPRhMDf3YPwizbkN.__ggyV8HRje4QA4bJJmJOOyX87:
			a.__auam0OiXATfV0FV2pOZQsnnt = -1
			a.__TlWqW0m63x0ks40OasJLgdcp = -1
		var __J7g4KD7ar7JHDDFQk2KOvEcv: int = a.__lp5nMIOUyaTDuOPtUm4IpHRu / 2
		var __Lehaov3YgWGYS_BAJLEBYP7K: int = a.__KrKPdZs_d6uEOIuRq3UQy1fb()
		var __M1MZ5cO80J_jgL9oqk4KgbQ4: int = a.__EsOQaggwtLEnMAHn6g7H_r7O()
		for __ddwdkleCV0t7LtAyRUs2g9ju: __YdhZSn3k6BLtSITi5naOCb7n in __iw6RgVvOHeZe08kNiBn34L8K.__LYNzM9N3A8Dmo_1zq54GljKm:
			if __ddwdkleCV0t7LtAyRUs2g9ju.__g7JC3EJmfsOWnIyqLGGB93eB == null or __ddwdkleCV0t7LtAyRUs2g9ju.__7OKcEzdMfOdabzyMipWdSzWD == a.__7OKcEzdMfOdabzyMipWdSzWD:
				continue
			for __9UrpAyycW1JOxlpVkNcc9dAh: Dictionary in __ddwdkleCV0t7LtAyRUs2g9ju.__g7JC3EJmfsOWnIyqLGGB93eB.__MMezevmh2WzjfDPiLXmgyJbQ:
				for __lmOjtnpxC_9XpvMm0G9jEo6l: __YCYnibBjVPRhMDf3YPwizbkN in __9UrpAyycW1JOxlpVkNcc9dAh["members"]:
					if not __lmOjtnpxC_9XpvMm0G9jEo6l.active or not __lmOjtnpxC_9XpvMm0G9jEo6l.__dRotcb2ldVZQLm2YDYWTTU9J or __lmOjtnpxC_9XpvMm0G9jEo6l.__jKXPrtchy4v7fjo9Z9kJG9SX:
						continue
					var __7yCO4XLEMZTpxohkk7SLgY4H: int = (__Lehaov3YgWGYS_BAJLEBYP7K - __lmOjtnpxC_9XpvMm0G9jEo6l.__KrKPdZs_d6uEOIuRq3UQy1fb()) * 200 / 100
					var __2qx0iGAR109IMEj0f4dzFoIg: int = __M1MZ5cO80J_jgL9oqk4KgbQ4 - __lmOjtnpxC_9XpvMm0G9jEo6l.__EsOQaggwtLEnMAHn6g7H_r7O()
					var d: int = __Irz9hiGcyslSDsJT8BenfEt2.__f8g2PjfN7nwJbTHn9ePhmeZH(__dXppFYqETFUwGtUmhS9ups7R(__2qx0iGAR109IMEj0f4dzFoIg * __2qx0iGAR109IMEj0f4dzFoIg + __7yCO4XLEMZTpxohkk7SLgY4H * __7yCO4XLEMZTpxohkk7SLgY4H))
					if d < __J7g4KD7ar7JHDDFQk2KOvEcv and not a.__Q4PVEYDqIobYx26SsJ1Qdl3_:
						__J7g4KD7ar7JHDDFQk2KOvEcv = d
						if a.state == __YCYnibBjVPRhMDf3YPwizbkN.State.__SokrJF1aDQ6jidDRcP3EDMhC and a.__TlWqW0m63x0ks40OasJLgdcp >= 0:
							a.__hF5qCjy1NYsx4mlJR0VxACAc = a.__TlWqW0m63x0ks40OasJLgdcp
							a.__FLbMUbwRQZZKI9_42OkArD2b = a.__auam0OiXATfV0FV2pOZQsnnt
						a.__TlWqW0m63x0ks40OasJLgdcp = __ddwdkleCV0t7LtAyRUs2g9ju.index
						a.__auam0OiXATfV0FV2pOZQsnnt = __lmOjtnpxC_9XpvMm0G9jEo6l.__JCVAOijT_RUiAesgY0ay5TGW()
						a.state = __YCYnibBjVPRhMDf3YPwizbkN.State.__hak6wyuJcTfEInMyuQsTMwiM
						a.__H0IfsdkHBf2MPjU13h3e655G = true
						a.sub = 0
		return
	var __ZJmhDdDRERXkakmOsnHcdnWz: __YCYnibBjVPRhMDf3YPwizbkN = lock(__iw6RgVvOHeZe08kNiBn34L8K, a)
	if __ZJmhDdDRERXkakmOsnHcdnWz != null:
		var __zphuYjF9WnemnE4Yj3SrnPwO: int = (a.__KrKPdZs_d6uEOIuRq3UQy1fb() - __ZJmhDdDRERXkakmOsnHcdnWz.__KrKPdZs_d6uEOIuRq3UQy1fb()) * 200 / 100
		var __oNoLpgrJL1MAHf1Ur6RuswRb: int = a.__EsOQaggwtLEnMAHn6g7H_r7O() - __ZJmhDdDRERXkakmOsnHcdnWz.__EsOQaggwtLEnMAHn6g7H_r7O()
		if __Irz9hiGcyslSDsJT8BenfEt2.__f8g2PjfN7nwJbTHn9ePhmeZH(__dXppFYqETFUwGtUmhS9ups7R(__oNoLpgrJL1MAHf1Ur6RuswRb * __oNoLpgrJL1MAHf1Ur6RuswRb + __zphuYjF9WnemnE4Yj3SrnPwO * __zphuYjF9WnemnE4Yj3SrnPwO)) <= a.__lp5nMIOUyaTDuOPtUm4IpHRu:
			return
		if __iw6RgVvOHeZe08kNiBn34L8K.__Jp9a8_iVrNYpIRTSu22QxY8F.__Q5F7UgTOWZqLgC00z0YDk_N1(a.__7OKcEzdMfOdabzyMipWdSzWD, __ZJmhDdDRERXkakmOsnHcdnWz.__EsOQaggwtLEnMAHn6g7H_r7O(), __ZJmhDdDRERXkakmOsnHcdnWz.__KrKPdZs_d6uEOIuRq3UQy1fb()):
			return
	if a.state == __YCYnibBjVPRhMDf3YPwizbkN.State.__8wDuFUkodt91vpp0l6j8TDd6:
		return
	a.__H0IfsdkHBf2MPjU13h3e655G = false
	__s3CdyC_X7fMlYb9Wy35B8EuH(a)
static func __IN3hMRUqpUedXcAGl8i14Nzg(__EfW_XSl0kX2qoSnwCHTLT3P9: __aDswGCE4WWdmypkp3eC7rExn, a: __YCYnibBjVPRhMDf3YPwizbkN) -> void :
	match a.sub:
		0:
			if not __7PKcorN1UkwsuGN_0x6XXwuu(__EfW_XSl0kX2qoSnwCHTLT3P9, a.__TlWqW0m63x0ks40OasJLgdcp):
				a.sub = 2
				a.__TlWqW0m63x0ks40OasJLgdcp = -1
				a.__auam0OiXATfV0FV2pOZQsnnt = -1
				return
			__oYgWRLZfuRe6ZBKCkoPvchaA(__EfW_XSl0kX2qoSnwCHTLT3P9, a)
			a.__wK6c6xRBxB0Lka8tqK6RrNfH = a.__EHjU5UjAgmmddD5nyx49ar6j
			if a.__aBKovnuyCiI63tVuI2prB5MN / 1000 < 50 and a.pitch == 0:
				a.sub = 1
				a.__JI4CwjmddmH55Lrana1jZuVZ = 0
				return
			__ia_9EReh93gEhjQ5cfA7bGGr(a)
		1:
			var d: int = 500
			if not a.__Mwx0mipYOX_Do2pZ7_nf22Nm:
				if not __7PKcorN1UkwsuGN_0x6XXwuu(__EfW_XSl0kX2qoSnwCHTLT3P9, a.__TlWqW0m63x0ks40OasJLgdcp):
					a.sub = 2
					a.__2cQt3I45k0XXwSr_0reYodT2 = __YCYnibBjVPRhMDf3YPwizbkN.__2OJpMwzaDeyLf0HK2_6FqBy2
					__FuSLMR8YKlQfKdKZhdyY0zVV(a)
					return
				var __X1VydPc1BCQKmNSaLavUHU_m: __YdhZSn3k6BLtSITi5naOCb7n = __EfW_XSl0kX2qoSnwCHTLT3P9.__LYNzM9N3A8Dmo_1zq54GljKm[a.__TlWqW0m63x0ks40OasJLgdcp]
				var __B16lwWCS5XSSge2ulkDQrUqs: int = __X1VydPc1BCQKmNSaLavUHU_m.__5M2Kw9tr4U856gth8pKR0sL6()
				if __X1VydPc1BCQKmNSaLavUHU_m.__RZSGss6vMJxzvS6fmWkQMma8 == __Se4EsxPBCHX48h1ZS5MexaMl.__4cYyo29DcWFPcLdEsHACapS4 and (__B16lwWCS5XSSge2ulkDQrUqs == __qUuRE3qEzIGmcU0ysMMtWssY.__F_jqEWMCiinD78WMy2CvF0Vb
						or (__B16lwWCS5XSSge2ulkDQrUqs != 0 and not __qUuRE3qEzIGmcU0ysMMtWssY.__8IEEd4YfisAzI0KqKVXuIpeB(__EfW_XSl0kX2qoSnwCHTLT3P9, __X1VydPc1BCQKmNSaLavUHU_m, __EfW_XSl0kX2qoSnwCHTLT3P9.__LYNzM9N3A8Dmo_1zq54GljKm[a.owner].__7OKcEzdMfOdabzyMipWdSzWD))):
					a.sub = 2
					a.__2cQt3I45k0XXwSr_0reYodT2 = __YCYnibBjVPRhMDf3YPwizbkN.__2OJpMwzaDeyLf0HK2_6FqBy2
					__FuSLMR8YKlQfKdKZhdyY0zVV(a)
					a.__TlWqW0m63x0ks40OasJLgdcp = -1
					a.__auam0OiXATfV0FV2pOZQsnnt = -1
					return
				d = __oYgWRLZfuRe6ZBKCkoPvchaA(__EfW_XSl0kX2qoSnwCHTLT3P9, a)
				if d < 200:
					a.sub = 2
					a.__2cQt3I45k0XXwSr_0reYodT2 = __YCYnibBjVPRhMDf3YPwizbkN.__2OJpMwzaDeyLf0HK2_6FqBy2
					__FuSLMR8YKlQfKdKZhdyY0zVV(a)
					return
			if a.__skELt8hzOP5jTm2IrBPiYtZM:
				if a.__JI4CwjmddmH55Lrana1jZuVZ == 0:
					__hwV4z1BdS7rfQgXMdBv3YQZL(__EfW_XSl0kX2qoSnwCHTLT3P9, a)
				if not (a.__JI4CwjmddmH55Lrana1jZuVZ < d * 8 / 10 and not a.__Mwx0mipYOX_Do2pZ7_nf22Nm):
					__I_r7wb2SR_OxNxDjBfE2H7uI(__EfW_XSl0kX2qoSnwCHTLT3P9, a)
					a.sub = 2
					a.__2cQt3I45k0XXwSr_0reYodT2 = __YCYnibBjVPRhMDf3YPwizbkN.__2OJpMwzaDeyLf0HK2_6FqBy2
					if not a.__Mwx0mipYOX_Do2pZ7_nf22Nm:
						a.__TlWqW0m63x0ks40OasJLgdcp = -1
						a.__auam0OiXATfV0FV2pOZQsnnt = -1
					else:
						a.__Mwx0mipYOX_Do2pZ7_nf22Nm = false
			if a.__skELt8hzOP5jTm2IrBPiYtZM or a.sub == 2 or __EfW_XSl0kX2qoSnwCHTLT3P9.__LYNzM9N3A8Dmo_1zq54GljKm[a.owner].__KLxhKPISj_AUmBVDjcFeRqL7 != __ushpWjHKf10aqEBOMhDJvpD3.__URWKTY3u7lsDdP7hzHFPk3gJ:
				__FuSLMR8YKlQfKdKZhdyY0zVV(a)
		2:
			var __kn2Zv0YRpyStcOyY9O09CQoP: int = a.__2cQt3I45k0XXwSr_0reYodT2 * 9 / 10
			var __qblwVUgKJ3KxHNs37RYwmgwa: bool = false
			if a.__aBKovnuyCiI63tVuI2prB5MN < __kn2Zv0YRpyStcOyY9O09CQoP:
				a.pitch = a.pitch + 10 if a.pitch < 450 else 450
			elif a.__aBKovnuyCiI63tVuI2prB5MN > __kn2Zv0YRpyStcOyY9O09CQoP:
				if a.__aBKovnuyCiI63tVuI2prB5MN < a.__2cQt3I45k0XXwSr_0reYodT2:
					a.pitch = 100 if a.pitch - 10 <= 100 else a.pitch - 20
				else:
					__qblwVUgKJ3KxHNs37RYwmgwa = true
			elif a.__aBKovnuyCiI63tVuI2prB5MN >= a.__2cQt3I45k0XXwSr_0reYodT2:
				__qblwVUgKJ3KxHNs37RYwmgwa = true
			if __qblwVUgKJ3KxHNs37RYwmgwa:
				a.pitch = 0
				a.sub = 0
				a.state = __YCYnibBjVPRhMDf3YPwizbkN.State.__9wEd2skDnIT9b_VOjrri893n
				if a.__6ol9zXLNVbGS9s_iAdvMaxLC == 0:
					__CuIJeN7QnUx2qnczgpwyLaWy(__EfW_XSl0kX2qoSnwCHTLT3P9, a, __lAo0PsogaUvqHw4muTzPsHiR.__GRPnytew2Hz_p1DafRqWc4DS, PackedByteArray([97]))
			a.__TlWqW0m63x0ks40OasJLgdcp = -1
			a.__auam0OiXATfV0FV2pOZQsnnt = -1
static func __UpqVfDG7YzQDJ43BlpmOr5jQ(x: int, y: int) -> PackedByteArray:
	var d: = PackedByteArray()
	d.resize(4)
	d.encode_s16(0, x)
	d.encode_s16(2, y)
	return d
static func __CEvwo6Lc7rZnRVhGhxTvRjUf(__AqXn4vUhsBSUZzABfOWu0i4T: __aDswGCE4WWdmypkp3eC7rExn, a: __YCYnibBjVPRhMDf3YPwizbkN) -> void :
	var depth: int = __YCYnibBjVPRhMDf3YPwizbkN.__2OJpMwzaDeyLf0HK2_6FqBy2 - __YCYnibBjVPRhMDf3YPwizbkN.__2OJpMwzaDeyLf0HK2_6FqBy2 / 10
	var __EFRp1_U5RxUeYVdik6Q9R39p: int = 10000
	var __hxlnXWotaL8ftm6F2Ll2g7NX: int = 0
	if not a.__eYCv0HeDvti_w5wj1jxJpmfT:
		if not __7PKcorN1UkwsuGN_0x6XXwuu(__AqXn4vUhsBSUZzABfOWu0i4T, a.__TlWqW0m63x0ks40OasJLgdcp):
			a.__2cQt3I45k0XXwSr_0reYodT2 = __YCYnibBjVPRhMDf3YPwizbkN.__2OJpMwzaDeyLf0HK2_6FqBy2
			a.__TlWqW0m63x0ks40OasJLgdcp = -1
			a.__auam0OiXATfV0FV2pOZQsnnt = -1
			if a.sub == 0:
				a.sub = 3
			elif a.sub == 1:
				a.sub = 2
				var __h_WEd_V0xwRwhr8uGzKsb2xN: Vector2i = __XdcdSffYaN4csG29A7yc6Z3i(400, 0, a.__vqYa6WuT8lqRfpObeEEtFMHG)
				a.__3epXDNnmkHn9cpXlvNEl2W4g = a.__EsOQaggwtLEnMAHn6g7H_r7O() + __h_WEd_V0xwRwhr8uGzKsb2xN.x
				a.__C3JQvlRdH1p7kRdolXEDy8oi = a.__caDHon68LplNQ04cMl2MMJ71() - __h_WEd_V0xwRwhr8uGzKsb2xN.y
		elif a.sub != 2:
			var __GFodsuAcuMauyF4AhlJbwtVH: __YdhZSn3k6BLtSITi5naOCb7n = __AqXn4vUhsBSUZzABfOWu0i4T.__LYNzM9N3A8Dmo_1zq54GljKm[a.__TlWqW0m63x0ks40OasJLgdcp]
			a.__3epXDNnmkHn9cpXlvNEl2W4g = __GFodsuAcuMauyF4AhlJbwtVH.x()
			a.__C3JQvlRdH1p7kRdolXEDy8oi = __GFodsuAcuMauyF4AhlJbwtVH.y()
			__EFRp1_U5RxUeYVdik6Q9R39p = __dXppFYqETFUwGtUmhS9ups7R((__GFodsuAcuMauyF4AhlJbwtVH.y() - a.__KrKPdZs_d6uEOIuRq3UQy1fb()) * (__GFodsuAcuMauyF4AhlJbwtVH.y() - a.__KrKPdZs_d6uEOIuRq3UQy1fb()) + (__GFodsuAcuMauyF4AhlJbwtVH.x() - a.__EsOQaggwtLEnMAHn6g7H_r7O()) * (__GFodsuAcuMauyF4AhlJbwtVH.x() - a.__EsOQaggwtLEnMAHn6g7H_r7O()))
	else:
		a.__3epXDNnmkHn9cpXlvNEl2W4g = a.__fFJBY3GZMYP1LL3hAdQ6l9hb
		a.__C3JQvlRdH1p7kRdolXEDy8oi = a.__pQ7vBeCy3SKL6gdAUzA6Pyzc
		__EFRp1_U5RxUeYVdik6Q9R39p = __dXppFYqETFUwGtUmhS9ups7R((a.__pQ7vBeCy3SKL6gdAUzA6Pyzc - a.__KrKPdZs_d6uEOIuRq3UQy1fb()) * (a.__pQ7vBeCy3SKL6gdAUzA6Pyzc - a.__KrKPdZs_d6uEOIuRq3UQy1fb()) + (a.__fFJBY3GZMYP1LL3hAdQ6l9hb - a.__EsOQaggwtLEnMAHn6g7H_r7O()) * (a.__fFJBY3GZMYP1LL3hAdQ6l9hb - a.__EsOQaggwtLEnMAHn6g7H_r7O()))
	match a.sub:
		0:
			var r: int = (a.__aBKovnuyCiI63tVuI2prB5MN / 1000) * __TXCdoY85HWzo9E7Qcf9l8raZ.TAN[90] / 1000
			a.pitch = 0
			if not a.__eYCv0HeDvti_w5wj1jxJpmfT and a.__TlWqW0m63x0ks40OasJLgdcp >= 0 and __qUuRE3qEzIGmcU0ysMMtWssY.__rSOe2tW6vEivzf_W9hliUIsk(__AqXn4vUhsBSUZzABfOWu0i4T.__LYNzM9N3A8Dmo_1zq54GljKm[a.__TlWqW0m63x0ks40OasJLgdcp]):
				a.state = __YCYnibBjVPRhMDf3YPwizbkN.State.__9wEd2skDnIT9b_VOjrri893n
				a.sub = 0
				a.__TlWqW0m63x0ks40OasJLgdcp = -1
				a.__auam0OiXATfV0FV2pOZQsnnt = -1
				return
			if __EFRp1_U5RxUeYVdik6Q9R39p < r * r:
				a.__2cQt3I45k0XXwSr_0reYodT2 = __YCYnibBjVPRhMDf3YPwizbkN.__2OJpMwzaDeyLf0HK2_6FqBy2 / 10
				a.sub = 1
				__AqXn4vUhsBSUZzABfOWu0i4T.__wIebi2RHJicnHeiUm6xYwBpd(__QzfA1_MgHwBGTTBizdgA8rkk.__FSW4WCXpupwYSF0KaHCFCNKb.__DfOvQDlN2w3hUx1JM4n2YS4m, a, 0)
			elif a.__aBKovnuyCiI63tVuI2prB5MN < __YCYnibBjVPRhMDf3YPwizbkN.__2OJpMwzaDeyLf0HK2_6FqBy2:
				a.pitch = 100
				a.__2cQt3I45k0XXwSr_0reYodT2 = __YCYnibBjVPRhMDf3YPwizbkN.__2OJpMwzaDeyLf0HK2_6FqBy2
		1:
			var __zt2MQNwpNsDSDaCbsbqmoqxC: bool = true
			if a.pitch > -750:
				__hxlnXWotaL8ftm6F2Ll2g7NX = (a.__2cQt3I45k0XXwSr_0reYodT2 - a.__aBKovnuyCiI63tVuI2prB5MN) * 100 / depth
				if not a.__eYCv0HeDvti_w5wj1jxJpmfT:
					__zt2MQNwpNsDSDaCbsbqmoqxC = false
			if __zt2MQNwpNsDSDaCbsbqmoqxC:
				if a.__skELt8hzOP5jTm2IrBPiYtZM:
					__1dgRsGPIPsXQaZxbuhptOoZB(__AqXn4vUhsBSUZzABfOWu0i4T, a)
				elif a.__aBKovnuyCiI63tVuI2prB5MN <= a.__2cQt3I45k0XXwSr_0reYodT2:
					a.__2cQt3I45k0XXwSr_0reYodT2 = __YCYnibBjVPRhMDf3YPwizbkN.__2OJpMwzaDeyLf0HK2_6FqBy2
					a.sub = 2
					var __SHVtePbvQvaXJAlJ1jMjEAVf: Vector2i = __XdcdSffYaN4csG29A7yc6Z3i(400, 0, a.__vqYa6WuT8lqRfpObeEEtFMHG)
					a.__3epXDNnmkHn9cpXlvNEl2W4g = a.__EsOQaggwtLEnMAHn6g7H_r7O() + __SHVtePbvQvaXJAlJ1jMjEAVf.x
					a.__C3JQvlRdH1p7kRdolXEDy8oi = a.__caDHon68LplNQ04cMl2MMJ71() - __SHVtePbvQvaXJAlJ1jMjEAVf.y
					a.__eYCv0HeDvti_w5wj1jxJpmfT = false
		2:
			var __ue9EF7ud01P9MgGcam_6pcH8: int = a.__2cQt3I45k0XXwSr_0reYodT2 * 9 / 10
			if a.__aBKovnuyCiI63tVuI2prB5MN < __ue9EF7ud01P9MgGcam_6pcH8:
				if a.pitch >= 400:
					a.pitch = 400
				else:
					__hxlnXWotaL8ftm6F2Ll2g7NX = (a.__2cQt3I45k0XXwSr_0reYodT2 - a.__aBKovnuyCiI63tVuI2prB5MN) * 80 / depth
			elif a.__aBKovnuyCiI63tVuI2prB5MN > __ue9EF7ud01P9MgGcam_6pcH8:
				if a.__aBKovnuyCiI63tVuI2prB5MN >= a.__2cQt3I45k0XXwSr_0reYodT2:
					a.sub = 3
					a.pitch = 0
				elif a.pitch - 10 <= 100:
					a.pitch = 100
				else:
					__hxlnXWotaL8ftm6F2Ll2g7NX = -20
			elif a.__aBKovnuyCiI63tVuI2prB5MN >= a.__2cQt3I45k0XXwSr_0reYodT2:
				a.sub = 3
				a.pitch = 0
			a.__TlWqW0m63x0ks40OasJLgdcp = -1
			a.__auam0OiXATfV0FV2pOZQsnnt = -1
		3:
			if a.pitch > 0:
				a.pitch -= 100
			else:
				a.pitch = 0
				a.sub = 0
				if a.__6ol9zXLNVbGS9s_iAdvMaxLC != 0:
					a.state = __YCYnibBjVPRhMDf3YPwizbkN.State.__9wEd2skDnIT9b_VOjrri893n
				else:
					__CuIJeN7QnUx2qnczgpwyLaWy(__AqXn4vUhsBSUZzABfOWu0i4T, a, __lAo0PsogaUvqHw4muTzPsHiR.__GRPnytew2Hz_p1DafRqWc4DS, PackedByteArray([97]))
	a.pitch = clampi(a.pitch + __hxlnXWotaL8ftm6F2Ll2g7NX, -750, 750)
static func __ofWwEdxvI8i8VBIEnSlEVSjl(__m4fgIiRQQjh4xgTzM9LQODT9: __aDswGCE4WWdmypkp3eC7rExn, a: __YCYnibBjVPRhMDf3YPwizbkN, __Uyy9mOZgRCKhjFEjz21buK6t: int, __uyd2sr975igD0RHfFdPO1kJg: int) -> void :
	var __PQlsPZg046YgjTUiJZon80Zv: __bzxMmNAcE_RKMny5gklgDglw = __m4fgIiRQQjh4xgTzM9LQODT9.___qFCN2viGM2bPW1uGV9qys9h
	if a.type == __YCYnibBjVPRhMDf3YPwizbkN.__c6EMu0BarWqKqIAZLnyXweGZ and __Uyy9mOZgRCKhjFEjz21buK6t == 30:
		a.__E9mK1bVUpfbbeQc2wFvz9PTC = __vblY9TJL1GlRksTX9ledsBzT(__PQlsPZg046YgjTUiJZon80Zv, __uyd2sr975igD0RHfFdPO1kJg)
		a.__6ol9zXLNVbGS9s_iAdvMaxLC = 1
	elif a.type == __YCYnibBjVPRhMDf3YPwizbkN.__cqsRgbmsPf4IeAEKyNRkn9rz and __Uyy9mOZgRCKhjFEjz21buK6t == 31:
		a.__0VloNlBtp7lq4vh_B_l9Y2Ll = __2ZIL9u7_cM4KOmaAUAdneX5d.__P7mKJOdBkGLoHIrg0rZud0qO(__PQlsPZg046YgjTUiJZon80Zv, __uyd2sr975igD0RHfFdPO1kJg)
		a.__6ol9zXLNVbGS9s_iAdvMaxLC = 1
	elif a.type == __YCYnibBjVPRhMDf3YPwizbkN.__ggyV8HRje4QA4bJJmJOOyX87 and __Uyy9mOZgRCKhjFEjz21buK6t == 28:
		a.__0VloNlBtp7lq4vh_B_l9Y2Ll = __2ZIL9u7_cM4KOmaAUAdneX5d.__P7mKJOdBkGLoHIrg0rZud0qO(__PQlsPZg046YgjTUiJZon80Zv, __uyd2sr975igD0RHfFdPO1kJg)
		var __PdFV5NJqk7uxPaUbUvYxwYD2: int = __PQlsPZg046YgjTUiJZon80Zv.__vlQDTtuyQZ3KmvKohFfizJCm("Projectile", __uyd2sr975igD0RHfFdPO1kJg, 155) & 15
		a.__6ol9zXLNVbGS9s_iAdvMaxLC = 1 if __PdFV5NJqk7uxPaUbUvYxwYD2 == 4 else 0
static func __dXppFYqETFUwGtUmhS9ups7R(v: int) -> int:
	v &= 4294967295
	return v - 4294967296 if v >= 2147483648 else v
static func __klxfH4sf9TNRbMClsfcRuKkB(__L7q5dtwrTLihkfMy_eRrjJ04: int, __Kkm8srh3u96Ps1jjEyubM5eD: int, __ukNK4XMX50EFbbBDZ0TgMGMn: int, __nl8aB71mncI7KR7fVLEsWnte: int) -> int:
	var __zD6i9QfokYGvO6st06WeUQqG: int = (__Kkm8srh3u96Ps1jjEyubM5eD - __nl8aB71mncI7KR7fVLEsWnte) * 200 / 100
	var __RrpWPKwqz1AEauYmdniD36Qk: int = __ukNK4XMX50EFbbBDZ0TgMGMn - __L7q5dtwrTLihkfMy_eRrjJ04
	return __Po01OkJHCnci3a4IiBvYv08r(__RrpWPKwqz1AEauYmdniD36Qk, __zD6i9QfokYGvO6st06WeUQqG, __1UOXWwkIUXXOQQkOhWzmSkZZ(__dXppFYqETFUwGtUmhS9ups7R(__zD6i9QfokYGvO6st06WeUQqG * __zD6i9QfokYGvO6st06WeUQqG + __RrpWPKwqz1AEauYmdniD36Qk * __RrpWPKwqz1AEauYmdniD36Qk)) / 1000)
const __ahUDxvJMdWXrjs0umGF19kh5: = 16383
static func __apitD6L2wJGin9cDVFtGArTy(__WkofDhfuQCDdfYTSF1JAlZqm: int, __virEZeW8YQocSNa8mXI38g0W: int, __eOT8PgKDykoJnGTIPR520X_O: int, __6eFjv0oqYV2cLXrbUOjeplvB: int) -> int:
	var __hVXQ2xSGpQWk7lXJx4SBMovn: int = (__virEZeW8YQocSNa8mXI38g0W - __6eFjv0oqYV2cLXrbUOjeplvB) * 117 / 100
	var __lQuZOYKDfGmCz9vlYbfKA0x_: int = __eOT8PgKDykoJnGTIPR520X_O - __WkofDhfuQCDdfYTSF1JAlZqm
	return __Po01OkJHCnci3a4IiBvYv08r(__lQuZOYKDfGmCz9vlYbfKA0x_, __hVXQ2xSGpQWk7lXJx4SBMovn, __1UOXWwkIUXXOQQkOhWzmSkZZ(__dXppFYqETFUwGtUmhS9ups7R(__hVXQ2xSGpQWk7lXJx4SBMovn * __hVXQ2xSGpQWk7lXJx4SBMovn + __lQuZOYKDfGmCz9vlYbfKA0x_ * __lQuZOYKDfGmCz9vlYbfKA0x_)) / 1000)
static func __ZrbT7kYiRUNNS0DaW5bPeCHg(__YOPGnvLu2hewHos6XosyRbv9: __aDswGCE4WWdmypkp3eC7rExn, __Q1quIrn7KUaoaLM1TJop9RGQ: __YdhZSn3k6BLtSITi5naOCb7n, __v8Wr2WpaHyPiHvoVi5hvZmmh: PackedByteArray) -> void :
	var w: __1q0DwOCFFBOQDiHI3310K_lq = __Q1quIrn7KUaoaLM1TJop9RGQ.__g7JC3EJmfsOWnIyqLGGB93eB
	if w == null or __v8Wr2WpaHyPiHvoVi5hvZmmh.size() < 4 or __v8Wr2WpaHyPiHvoVi5hvZmmh[0] != 1:
		return
	var __QybNkqizVVBtdO0gwp9Od7Cn: int = mini(__v8Wr2WpaHyPiHvoVi5hvZmmh[3], __v8Wr2WpaHyPiHvoVi5hvZmmh.size())
	match __v8Wr2WpaHyPiHvoVi5hvZmmh[1]:
		1:
			if __v8Wr2WpaHyPiHvoVi5hvZmmh[2] == 1:
				if __QybNkqizVVBtdO0gwp9Od7Cn < 6:
					return
				var data: PackedByteArray = __v8Wr2WpaHyPiHvoVi5hvZmmh.slice(0, 6)
				for __Np13KvAeZJjfqYfEkk74akjH: int in range(6, __QybNkqizVVBtdO0gwp9Od7Cn):
					for a: __YCYnibBjVPRhMDf3YPwizbkN in __0zsl5g6R5DTe4QpmbZ0utSui(w, __v8Wr2WpaHyPiHvoVi5hvZmmh[__Np13KvAeZJjfqYfEkk74akjH]):
						__CuIJeN7QnUx2qnczgpwyLaWy(__YOPGnvLu2hewHos6XosyRbv9, a, __lAo0PsogaUvqHw4muTzPsHiR.__K4DW2sFEG4hDyZlDcv4ARdpS, data)
			else:
				if __QybNkqizVVBtdO0gwp9Od7Cn < 8:
					return
				var __ybuiFiSLQz2sKIJZHmt1P2AZ: PackedByteArray = __v8Wr2WpaHyPiHvoVi5hvZmmh.slice(4, 8)
				for __ERo0J_oTDTdqwzm77MUNyuJK: int in range(8, __QybNkqizVVBtdO0gwp9Od7Cn):
					for a: __YCYnibBjVPRhMDf3YPwizbkN in __0zsl5g6R5DTe4QpmbZ0utSui(w, __v8Wr2WpaHyPiHvoVi5hvZmmh[__ERo0J_oTDTdqwzm77MUNyuJK]):
						__CuIJeN7QnUx2qnczgpwyLaWy(__YOPGnvLu2hewHos6XosyRbv9, a, __lAo0PsogaUvqHw4muTzPsHiR.__RnlQu1RDsFqYtAt0lFaNrpF3, __ybuiFiSLQz2sKIJZHmt1P2AZ)
		2:
			if __QybNkqizVVBtdO0gwp9Od7Cn < 6:
				return
			for __d_DVaLJckwK9EcCNtHrOKhUh: int in range(6, __QybNkqizVVBtdO0gwp9Od7Cn):
				__5YqQWmD4f_Sna1pN9wrS9etk(__YOPGnvLu2hewHos6XosyRbv9, __Q1quIrn7KUaoaLM1TJop9RGQ, __lAo0PsogaUvqHw4muTzPsHiR.__9CvwwPmQifMMHqahfjKZlSCO, __v8Wr2WpaHyPiHvoVi5hvZmmh[__d_DVaLJckwK9EcCNtHrOKhUh], __v8Wr2WpaHyPiHvoVi5hvZmmh.slice(0, 6))
		5:
			for __OfALoxnMiukxxaCIMsN2myTY: int in range(4, __QybNkqizVVBtdO0gwp9Od7Cn):
				__5YqQWmD4f_Sna1pN9wrS9etk(__YOPGnvLu2hewHos6XosyRbv9, __Q1quIrn7KUaoaLM1TJop9RGQ, __lAo0PsogaUvqHw4muTzPsHiR.__hmsimVPA4ud9Y6ZQbS1iPIWF + clampi(__v8Wr2WpaHyPiHvoVi5hvZmmh[2], 0, 1), __v8Wr2WpaHyPiHvoVi5hvZmmh[__OfALoxnMiukxxaCIMsN2myTY], PackedByteArray())
		6:
			if __QybNkqizVVBtdO0gwp9Od7Cn < 8 or __v8Wr2WpaHyPiHvoVi5hvZmmh[2] != 0:
				return
			for __zaFf6ckHi1yJy9DqPN7KAwjz: int in range(8, __QybNkqizVVBtdO0gwp9Od7Cn):
				__5YqQWmD4f_Sna1pN9wrS9etk(__YOPGnvLu2hewHos6XosyRbv9, __Q1quIrn7KUaoaLM1TJop9RGQ, __lAo0PsogaUvqHw4muTzPsHiR.__tdzjWSWsv9G2KGQRcGI8AKgH, __v8Wr2WpaHyPiHvoVi5hvZmmh[__zaFf6ckHi1yJy9DqPN7KAwjz], __v8Wr2WpaHyPiHvoVi5hvZmmh.slice(4, 8))
		7:
			var code: int = __lAo0PsogaUvqHw4muTzPsHiR.__zdiUInmKof3OdZvmaHsrJwvr if __v8Wr2WpaHyPiHvoVi5hvZmmh[2] == 0 else (__lAo0PsogaUvqHw4muTzPsHiR.__ZnVoXQPJNvKUxzmIYXNvGBS2 if __v8Wr2WpaHyPiHvoVi5hvZmmh[2] == 3 else -1)
			if code < 0:
				return
			for __xuIo_c2dL7LxMO3akwyFTz9R: int in range(4, __QybNkqizVVBtdO0gwp9Od7Cn):
				__5YqQWmD4f_Sna1pN9wrS9etk(__YOPGnvLu2hewHos6XosyRbv9, __Q1quIrn7KUaoaLM1TJop9RGQ, code, __v8Wr2WpaHyPiHvoVi5hvZmmh[__xuIo_c2dL7LxMO3akwyFTz9R], PackedByteArray([1]))
const __M98e8yEUvS7d1fN7whAhFKnE: = 32
static func __F_qXl6Q5aLvlwWZs9gpUNk_q(x: int, y: int, a: int) -> Vector2i:
	var __fN2pTc6kGPMRladygB64z9AL: int = __B6DoyQH00PkNqJSn1pOiTHd7(1, a)
	var s: int = __B6DoyQH00PkNqJSn1pOiTHd7(0, a)
	return Vector2i((x * __fN2pTc6kGPMRladygB64z9AL - y * s) / 1000, (y * __fN2pTc6kGPMRladygB64z9AL + x * s) / 1000)
static func __hwV4z1BdS7rfQgXMdBv3YQZL(__s95J3kE9JIm54k8t6kikPWBB: __aDswGCE4WWdmypkp3eC7rExn, __7uSEgHXlZiNYAav17Uj6XARw: __YCYnibBjVPRhMDf3YPwizbkN) -> void :
	var w: __1q0DwOCFFBOQDiHI3310K_lq = __s95J3kE9JIm54k8t6kikPWBB.__LYNzM9N3A8Dmo_1zq54GljKm[__7uSEgHXlZiNYAav17Uj6XARw.owner].__g7JC3EJmfsOWnIyqLGGB93eB
	if w == null:
		return
	var __50JDDy6WZHLD83qOhO8PQUaI: int = 100000000
	for a: __YCYnibBjVPRhMDf3YPwizbkN in w.__knUj879QWUN8clA4_f5YGzfw(__7uSEgHXlZiNYAav17Uj6XARw.__knUj879QWUN8clA4_f5YGzfw)["members"]:
		if __50JDDy6WZHLD83qOhO8PQUaI > a.__zjyW8rAU_8pK0uXV_Zkdk_Kw:
			__50JDDy6WZHLD83qOhO8PQUaI = a.__zjyW8rAU_8pK0uXV_Zkdk_Kw
	for a: __YCYnibBjVPRhMDf3YPwizbkN in w.__knUj879QWUN8clA4_f5YGzfw(__7uSEgHXlZiNYAav17Uj6XARw.__knUj879QWUN8clA4_f5YGzfw)["members"]:
		a.__JI4CwjmddmH55Lrana1jZuVZ = __50JDDy6WZHLD83qOhO8PQUaI
static func __I_r7wb2SR_OxNxDjBfE2H7uI(__ojOiGi3q_KtPQrIsPhXQ7_Qo: __aDswGCE4WWdmypkp3eC7rExn, a: __YCYnibBjVPRhMDf3YPwizbkN) -> void :
	a.__6ol9zXLNVbGS9s_iAdvMaxLC -= 1
	a.__skELt8hzOP5jTm2IrBPiYtZM = false
	var __0SWnaYsr1vCcmU3OZyiQnbsE: int = __ojOiGi3q_KtPQrIsPhXQ7_Qo.__EaiCL_s7Is8n8XhLMgCmd8bh + __ojOiGi3q_KtPQrIsPhXQ7_Qo.__t2UdGLb5AjoD9DJacXSIpDUA
	var __zf9IuXd6m8xyKAJNPbWFaAl6: int = a.__PIanP8EGD25AKu3PStByHFk6 / 10
	var r: int = __n2nqHf6Z4jNwkx3IA7Pe4Aon(__ojOiGi3q_KtPQrIsPhXQ7_Qo, __0SWnaYsr1vCcmU3OZyiQnbsE) % maxi(1, __zf9IuXd6m8xyKAJNPbWFaAl6)
	var h: int = (a.__vqYa6WuT8lqRfpObeEEtFMHG + r) % 3600
	var __arUku5nIdOaF0llbBxyrq615: int = int(a.__E9mK1bVUpfbbeQc2wFvz9PTC["spd_fast"])
	var __yldZLzRBxvKWFk3soIoKrgai: int = int(a.__E9mK1bVUpfbbeQc2wFvz9PTC["r_fast"])
	var __oNnzQzYrbzZhW5WtZ9aNal40: int = a.__EsOQaggwtLEnMAHn6g7H_r7O()
	var __q6W1RPNnQOSeDfll_BqaKE5W: int = a.__KrKPdZs_d6uEOIuRq3UQy1fb()
	var __W0w_1LiDopt4PQpXpH7sToqw: int = int(a.__E9mK1bVUpfbbeQc2wFvz9PTC["splash_r"])
	var __HMNoFkSNvq9VkEAVSM03R2OB: = {
		"id": __ojOiGi3q_KtPQrIsPhXQ7_Qo.__JYxJx4zlqiQBArRmmnWoLfZB(), "owner": a.owner, "launcher": -1, 
		"ox": __oNnzQzYrbzZhW5WtZ9aNal40, "oy": __q6W1RPNnQOSeDfll_BqaKE5W, "ax": 0, "ay": 0, 
		"vx": __TXCdoY85HWzo9E7Qcf9l8raZ.__9nHAKAsjPH38LR2tAezCTqd_[h] * __arUku5nIdOaF0llbBxyrq615 / 1000, "vy": __TXCdoY85HWzo9E7Qcf9l8raZ.__7laIgLr3i8VN0D_tZnYT3p0D[h] * __arUku5nIdOaF0llbBxyrq615 / 1000, 
		"heading": posmod(h - 900, 3600), 
		"max2": (134 + __n2nqHf6Z4jNwkx3IA7Pe4Aon(__ojOiGi3q_KtPQrIsPhXQ7_Qo, __0SWnaYsr1vCcmU3OZyiQnbsE) % 22) * __yldZLzRBxvKWFk3soIoKrgai * __yldZLzRBxvKWFk3soIoKrgai / 100, 
		"arm2": a.__E9mK1bVUpfbbeQc2wFvz9PTC["arm2"], "armed": false, 
		"dmg": a.__E9mK1bVUpfbbeQc2wFvz9PTC["dmg"], "ms": a.__E9mK1bVUpfbbeQc2wFvz9PTC["ms"], "prox": a.__E9mK1bVUpfbbeQc2wFvz9PTC["prox"], "r": __W0w_1LiDopt4PQpXpH7sToqw, "near": __W0w_1LiDopt4PQpXpH7sToqw * __W0w_1LiDopt4PQpXpH7sToqw, 
		"ss": false, "passed": PackedInt32Array(), 
		"state": __0QiGqbYBLZEUENpkfN6eZqIr.State.__CsWEnkTf3yoEAdtPeN8oWH5K, "t": 0, "shore": 0, "cursor": __0SWnaYsr1vCcmU3OZyiQnbsE, 
		"p1": Vector2i(__oNnzQzYrbzZhW5WtZ9aNal40, __q6W1RPNnQOSeDfll_BqaKE5W), "p2": Vector2i(__oNnzQzYrbzZhW5WtZ9aNal40, __q6W1RPNnQOSeDfll_BqaKE5W), 
		"dir36": ((posmod(h - 900, 3600) + 50) / 100) % 36, "trail": PackedInt32Array(), "air": true, 
	}
	__HMNoFkSNvq9VkEAVSM03R2OB["x"] = __oNnzQzYrbzZhW5WtZ9aNal40
	__HMNoFkSNvq9VkEAVSM03R2OB["y"] = __q6W1RPNnQOSeDfll_BqaKE5W
	__ojOiGi3q_KtPQrIsPhXQ7_Qo.__PHRyUPhEHZ95rcQCVAqnc4Y6.append(__HMNoFkSNvq9VkEAVSM03R2OB)
	__ojOiGi3q_KtPQrIsPhXQ7_Qo.__wIebi2RHJicnHeiUm6xYwBpd(__QzfA1_MgHwBGTTBizdgA8rkk.__FSW4WCXpupwYSF0KaHCFCNKb.__13xdeilLgdjil6FE_cmvWKMm, a, 3)
static func __4vkwFQCb1YIrsLiCaaP3aBi4(__39sxgDVmUQp_Ju9wiL7cXI2B: __aDswGCE4WWdmypkp3eC7rExn, a: __YCYnibBjVPRhMDf3YPwizbkN, __mWhEvk6yDFqlFxFyRX5Fb7C7: int) -> void :
	var w: __1q0DwOCFFBOQDiHI3310K_lq = __39sxgDVmUQp_Ju9wiL7cXI2B.__LYNzM9N3A8Dmo_1zq54GljKm[a.owner].__g7JC3EJmfsOWnIyqLGGB93eB
	if w == null:
		return
	w.__ExRc2vcAyRkISXqe5ZZghf9A.erase(a)
	var s: Dictionary = w.__knUj879QWUN8clA4_f5YGzfw(a.__knUj879QWUN8clA4_f5YGzfw)
	if s.is_empty():
		return
	var __itK1myhHcaoY7YKpsxxKROtQ: Array = s["members"]
	var __v3BUczIDdBXbBJZCjLx7DhrT: int = -1
	for __xT5kW5fOTaA_sFvtK0V2vi53: int in __itK1myhHcaoY7YKpsxxKROtQ.size():
		if (__itK1myhHcaoY7YKpsxxKROtQ[__xT5kW5fOTaA_sFvtK0V2vi53] as __YCYnibBjVPRhMDf3YPwizbkN).__w4KgbGj0JQyP8PGvp68qYP1F == a.__w4KgbGj0JQyP8PGvp68qYP1F:
			__v3BUczIDdBXbBJZCjLx7DhrT = __xT5kW5fOTaA_sFvtK0V2vi53
			break
	if __v3BUczIDdBXbBJZCjLx7DhrT < 0:
		return
	__itK1myhHcaoY7YKpsxxKROtQ.remove_at(__v3BUczIDdBXbBJZCjLx7DhrT)
	s["aloft"] = maxi(0, int(s["aloft"]) - 1)
	if a.__2nVqHzJsE4wg_diKnctoD6kY:
		a.__2nVqHzJsE4wg_diKnctoD6kY = false
		if not __itK1myhHcaoY7YKpsxxKROtQ.is_empty():
			(__itK1myhHcaoY7YKpsxxKROtQ[0] as __YCYnibBjVPRhMDf3YPwizbkN).__2nVqHzJsE4wg_diKnctoD6kY = true
	var __yvSU3wtKFfM6dc5EUzaXeb4o: Dictionary = w.__0IiawbJUBQggkPsEIdPzmWda(a.type)
	if __mWhEvk6yDFqlFxFyRX5Fb7C7 == 0:
		__yvSU3wtKFfM6dc5EUzaXeb4o["hangar"] = int(__yvSU3wtKFfM6dc5EUzaXeb4o["hangar"]) + 1
		if a.__6ol9zXLNVbGS9s_iAdvMaxLC != 0:
			__yvSU3wtKFfM6dc5EUzaXeb4o["stock"] = int(__yvSU3wtKFfM6dc5EUzaXeb4o["stock"]) + 1
	else:
		w.__ovmWIjR9MK5E3k8GPT1QWt_B[a.type] = maxi(0, w.__ovmWIjR9MK5E3k8GPT1QWt_B[a.type] - 1)
static func __5YqQWmD4f_Sna1pN9wrS9etk(__59QdKtSpX7MNn_PhRBWGsPOY: __aDswGCE4WWdmypkp3eC7rExn, __1tSgBUaNDfa3d0wUHYB9IOpE: __YdhZSn3k6BLtSITi5naOCb7n, code: int, __KgQI1tiX1eLota_GLGzj_kDl: int, data: PackedByteArray) -> void :
	var w: __1q0DwOCFFBOQDiHI3310K_lq = __1tSgBUaNDfa3d0wUHYB9IOpE.__g7JC3EJmfsOWnIyqLGGB93eB
	var __DSYyIySdN0Ru82jDAeySPOgm: Array = __0zsl5g6R5DTe4QpmbZ0utSui(w, __KgQI1tiX1eLota_GLGzj_kDl)
	if code == __lAo0PsogaUvqHw4muTzPsHiR.__9CvwwPmQifMMHqahfjKZlSCO:
		for a: __YCYnibBjVPRhMDf3YPwizbkN in __DSYyIySdN0Ru82jDAeySPOgm:
			if a.type == __YCYnibBjVPRhMDf3YPwizbkN.__cqsRgbmsPf4IeAEKyNRkn9rz and a.__aBKovnuyCiI63tVuI2prB5MN < a.__2cQt3I45k0XXwSr_0reYodT2:
				__59QdKtSpX7MNn_PhRBWGsPOY.__wIebi2RHJicnHeiUm6xYwBpd(__QzfA1_MgHwBGTTBizdgA8rkk.__FSW4WCXpupwYSF0KaHCFCNKb.__7u4clDqtCMcaEbPT4aWekmiB, a, 21)
				return
	for a: __YCYnibBjVPRhMDf3YPwizbkN in __DSYyIySdN0Ru82jDAeySPOgm:
		if code == __lAo0PsogaUvqHw4muTzPsHiR.__ZnVoXQPJNvKUxzmIYXNvGBS2:
			if a.type == __YCYnibBjVPRhMDf3YPwizbkN.__ggyV8HRje4QA4bJJmJOOyX87 and a.__6ol9zXLNVbGS9s_iAdvMaxLC > 0:
				__CuIJeN7QnUx2qnczgpwyLaWy(__59QdKtSpX7MNn_PhRBWGsPOY, a, code, data)
				return
			continue
		__CuIJeN7QnUx2qnczgpwyLaWy(__59QdKtSpX7MNn_PhRBWGsPOY, a, code, data)
const __iXILOspsjYyClae5MSjyJvXl: = 12
static func __wGK_UQbzU1Hdj_uA5qiKTLE7(__uobVMnqsrNSslJT5vAMHQepg: __aDswGCE4WWdmypkp3eC7rExn, a: __YCYnibBjVPRhMDf3YPwizbkN, __ImbdUhrhZiacbkbBFcGM19MY: int, __L4qObIAcrwCEQNcg6DMdxFfZ: int) -> bool:
	if a.__jKXPrtchy4v7fjo9Z9kJG9SX:
		return false
	var d: int = __ImbdUhrhZiacbkbBFcGM19MY - a.__HqMti1TAnrtmLUJSJQBYdY_P
	var __uhCcUvlIJhw869NGioAAdPjJ: int = 2 * d if d > 0 else 1
	var __D3ig2lOxEBpAXczb2xdzYGhn: int = __n2nqHf6Z4jNwkx3IA7Pe4Aon(__uobVMnqsrNSslJT5vAMHQepg, __uobVMnqsrNSslJT5vAMHQepg.__EaiCL_s7Is8n8XhLMgCmd8bh + __uobVMnqsrNSslJT5vAMHQepg.__t2UdGLb5AjoD9DJacXSIpDUA) % __uhCcUvlIJhw869NGioAAdPjJ
	if __L4qObIAcrwCEQNcg6DMdxFfZ >= 0 and __L4qObIAcrwCEQNcg6DMdxFfZ < __uobVMnqsrNSslJT5vAMHQepg.__LYNzM9N3A8Dmo_1zq54GljKm.size() and __2ZIL9u7_cM4KOmaAUAdneX5d.meti_is_boosted(__uobVMnqsrNSslJT5vAMHQepg.__LYNzM9N3A8Dmo_1zq54GljKm[__L4qObIAcrwCEQNcg6DMdxFfZ]):
		__D3ig2lOxEBpAXczb2xdzYGhn = __2ZIL9u7_cM4KOmaAUAdneX5d.meti_gain(__D3ig2lOxEBpAXczb2xdzYGhn)
	if __D3ig2lOxEBpAXczb2xdzYGhn >= a.__F41ZT8z_0zKKqYDFwqS1WGTs:
		__0xzkFhYTZVOJgwELQBBwjBHu(__uobVMnqsrNSslJT5vAMHQepg, a, __L4qObIAcrwCEQNcg6DMdxFfZ)
	else:
		a.__F41ZT8z_0zKKqYDFwqS1WGTs -= __D3ig2lOxEBpAXczb2xdzYGhn
		__uobVMnqsrNSslJT5vAMHQepg.__wIebi2RHJicnHeiUm6xYwBpd(__QzfA1_MgHwBGTTBizdgA8rkk.__FSW4WCXpupwYSF0KaHCFCNKb.__tzxGAM8EoLr0AZV_0nEXQdWc, a, __D3ig2lOxEBpAXczb2xdzYGhn)
	if a.__PIanP8EGD25AKu3PStByHFk6 < 1000:
		a.__PIanP8EGD25AKu3PStByHFk6 += __D3ig2lOxEBpAXczb2xdzYGhn / 10
	return a.__jKXPrtchy4v7fjo9Z9kJG9SX
static func __68OzxQ805gxG9kwMAiombZFK(__zqC3yDRpkG4u_LgE9L0TDRLH: __aDswGCE4WWdmypkp3eC7rExn, __xzUdtdpAhMliLJVU3oCYn_5p: __YCYnibBjVPRhMDf3YPwizbkN, __wZG3rf59qKn3uk9N_bRce0SN: __YdhZSn3k6BLtSITi5naOCb7n) -> void :
	if __xzUdtdpAhMliLJVU3oCYn_5p.sub == 0:
		var __IjUx4Zfioi_QA2U3Ls84JFSw: int = (__zqC3yDRpkG4u_LgE9L0TDRLH.___qFCN2viGM2bPW1uGV9qys9h.__Jy2hcMM9emCF3iBBkLMyeUr7("Frame", __wZG3rf59qKn3uk9N_bRce0SN.__WeB9Hi0OxaFBUuwm2WU2qKEH, 6) >> 1) & 255
		if __xzUdtdpAhMliLJVU3oCYn_5p.__Grly1BvCsxoCuBf0E7OZOvtN < __IjUx4Zfioi_QA2U3Ls84JFSw:
			return
		__xzUdtdpAhMliLJVU3oCYn_5p.sub = 1
		__xzUdtdpAhMliLJVU3oCYn_5p.pitch = -200
		return
	if __xzUdtdpAhMliLJVU3oCYn_5p.sub != 1:
		return
	if __xzUdtdpAhMliLJVU3oCYn_5p.pitch < 100:
		__xzUdtdpAhMliLJVU3oCYn_5p.pitch += 30
		return
	__xzUdtdpAhMliLJVU3oCYn_5p.pitch = 100
	__xzUdtdpAhMliLJVU3oCYn_5p.state = __YCYnibBjVPRhMDf3YPwizbkN.State.__DdjO7licqxMK90434TaAU1qH
	__xzUdtdpAhMliLJVU3oCYn_5p.sub = 0
	__xzUdtdpAhMliLJVU3oCYn_5p.__2cQt3I45k0XXwSr_0reYodT2 = __YCYnibBjVPRhMDf3YPwizbkN.__2OJpMwzaDeyLf0HK2_6FqBy2
static func __KQ5P1mcH6yImypWFX7wGlM9T(__Dw5ocYCJaaIbFXEm33_u0JPy: __aDswGCE4WWdmypkp3eC7rExn, __2ZmUTuiMSUVREuxynTjt7PGQ: __YCYnibBjVPRhMDf3YPwizbkN, __L7y5KElesRb6apXX5MYeALy1: __YdhZSn3k6BLtSITi5naOCb7n) -> int:
	var __aZdijulvKPumkenUsC9wpFc_: int = 80
	if __L7y5KElesRb6apXX5MYeALy1.state != __lAo0PsogaUvqHw4muTzPsHiR.__pRO7nOY10o2GAU3KzWQvIvwY:
		__2ZmUTuiMSUVREuxynTjt7PGQ.state = __YCYnibBjVPRhMDf3YPwizbkN.State.__DdjO7licqxMK90434TaAU1qH
		__2ZmUTuiMSUVREuxynTjt7PGQ.sub = 0
		__2ZmUTuiMSUVREuxynTjt7PGQ.__3epXDNnmkHn9cpXlvNEl2W4g = __L7y5KElesRb6apXX5MYeALy1.x()
		__2ZmUTuiMSUVREuxynTjt7PGQ.__C3JQvlRdH1p7kRdolXEDy8oi = __L7y5KElesRb6apXX5MYeALy1.y()
		__2ZmUTuiMSUVREuxynTjt7PGQ.__2cQt3I45k0XXwSr_0reYodT2 = __YCYnibBjVPRhMDf3YPwizbkN.__2OJpMwzaDeyLf0HK2_6FqBy2
		__2ZmUTuiMSUVREuxynTjt7PGQ.pitch = 100 if __2ZmUTuiMSUVREuxynTjt7PGQ.__aBKovnuyCiI63tVuI2prB5MN < __YCYnibBjVPRhMDf3YPwizbkN.__2OJpMwzaDeyLf0HK2_6FqBy2 else 0
		__2ZmUTuiMSUVREuxynTjt7PGQ.__wK6c6xRBxB0Lka8tqK6RrNfH = __2ZmUTuiMSUVREuxynTjt7PGQ.__EHjU5UjAgmmddD5nyx49ar6j
		__2ZmUTuiMSUVREuxynTjt7PGQ.__sRdhcmPDkaBIPIzTf0y2eZwL = false
		return 30
	var __2_zM1j8q6qr4VY9g_yxTY_jp: int = __YCYnibBjVPRhMDf3YPwizbkN.__XNP5UhOp48fF9keZolufRgEY
	match __2ZmUTuiMSUVREuxynTjt7PGQ.sub:
		0:
			var __8TWEavfpHFbKvjH0EIjN5T4r: int = (__L7y5KElesRb6apXX5MYeALy1.__vqYa6WuT8lqRfpObeEEtFMHG() + 900) % 3600
			var __XJZ2Gl3KjIeqZhi8Au5Xsn8u: Vector2i = __XdcdSffYaN4csG29A7yc6Z3i(-240, 0, __8TWEavfpHFbKvjH0EIjN5T4r)
			__2ZmUTuiMSUVREuxynTjt7PGQ.__3epXDNnmkHn9cpXlvNEl2W4g = __L7y5KElesRb6apXX5MYeALy1.x() + __XJZ2Gl3KjIeqZhi8Au5Xsn8u.x
			__2ZmUTuiMSUVREuxynTjt7PGQ.__C3JQvlRdH1p7kRdolXEDy8oi = __L7y5KElesRb6apXX5MYeALy1.y() - __XJZ2Gl3KjIeqZhi8Au5Xsn8u.y
			if __2ZmUTuiMSUVREuxynTjt7PGQ.__2cQt3I45k0XXwSr_0reYodT2 != __2_zM1j8q6qr4VY9g_yxTY_jp and __2ZmUTuiMSUVREuxynTjt7PGQ.__zjyW8rAU_8pK0uXV_Zkdk_Kw < 80:
				__2ZmUTuiMSUVREuxynTjt7PGQ.__2cQt3I45k0XXwSr_0reYodT2 = __2_zM1j8q6qr4VY9g_yxTY_jp
				__2ZmUTuiMSUVREuxynTjt7PGQ.pitch = -150
			if __2ZmUTuiMSUVREuxynTjt7PGQ.__aBKovnuyCiI63tVuI2prB5MN > __2_zM1j8q6qr4VY9g_yxTY_jp * 2:
				return __aZdijulvKPumkenUsC9wpFc_
			__2ZmUTuiMSUVREuxynTjt7PGQ.__2cQt3I45k0XXwSr_0reYodT2 = __2_zM1j8q6qr4VY9g_yxTY_jp
			__2ZmUTuiMSUVREuxynTjt7PGQ.__wK6c6xRBxB0Lka8tqK6RrNfH = __2ZmUTuiMSUVREuxynTjt7PGQ.__wK6c6xRBxB0Lka8tqK6RrNfH * 8 / 10
			__2ZmUTuiMSUVREuxynTjt7PGQ.pitch = -50
			__2ZmUTuiMSUVREuxynTjt7PGQ.sub = 1
		1:
			__2ZmUTuiMSUVREuxynTjt7PGQ.__3epXDNnmkHn9cpXlvNEl2W4g = __L7y5KElesRb6apXX5MYeALy1.x()
			__2ZmUTuiMSUVREuxynTjt7PGQ.__C3JQvlRdH1p7kRdolXEDy8oi = __L7y5KElesRb6apXX5MYeALy1.y()
			if __2ZmUTuiMSUVREuxynTjt7PGQ.__aBKovnuyCiI63tVuI2prB5MN > __2_zM1j8q6qr4VY9g_yxTY_jp:
				return __aZdijulvKPumkenUsC9wpFc_
			__2ZmUTuiMSUVREuxynTjt7PGQ.sub = 2
			__2ZmUTuiMSUVREuxynTjt7PGQ.pitch = 0
		2:
			__2ZmUTuiMSUVREuxynTjt7PGQ.__3epXDNnmkHn9cpXlvNEl2W4g = __L7y5KElesRb6apXX5MYeALy1.x()
			__2ZmUTuiMSUVREuxynTjt7PGQ.__C3JQvlRdH1p7kRdolXEDy8oi = __L7y5KElesRb6apXX5MYeALy1.y()
			__aZdijulvKPumkenUsC9wpFc_ = 120
			if __2ZmUTuiMSUVREuxynTjt7PGQ.__zjyW8rAU_8pK0uXV_Zkdk_Kw >= 20:
				return __aZdijulvKPumkenUsC9wpFc_
			if __L7y5KElesRb6apXX5MYeALy1.__5M2Kw9tr4U856gth8pKR0sL6() != 0:
				__2ZmUTuiMSUVREuxynTjt7PGQ.state = __YCYnibBjVPRhMDf3YPwizbkN.State.__9wEd2skDnIT9b_VOjrri893n
				return __aZdijulvKPumkenUsC9wpFc_
			__2ZmUTuiMSUVREuxynTjt7PGQ.sub = 3
			__2ZmUTuiMSUVREuxynTjt7PGQ.__A5_5AardkQ9zpEEJuxY4GJPD = 0
			__2ZmUTuiMSUVREuxynTjt7PGQ.__jU9wrtQkEXyjLR8w6MfC7UNB = 0
			__2ZmUTuiMSUVREuxynTjt7PGQ.__j77VIRoHY1FrfLlG18J11iYo = 0
			__2ZmUTuiMSUVREuxynTjt7PGQ.__xYfnrbyY0rOYQimdsPnBBdEG = 0
			__2ZmUTuiMSUVREuxynTjt7PGQ.active = false
			__4vkwFQCb1YIrsLiCaaP3aBi4(__Dw5ocYCJaaIbFXEm33_u0JPy, __2ZmUTuiMSUVREuxynTjt7PGQ, 0)
			__2ZmUTuiMSUVREuxynTjt7PGQ.__dRotcb2ldVZQLm2YDYWTTU9J = false
			__Dw5ocYCJaaIbFXEm33_u0JPy.__wIebi2RHJicnHeiUm6xYwBpd(__QzfA1_MgHwBGTTBizdgA8rkk.__FSW4WCXpupwYSF0KaHCFCNKb.__45wf1EUrEd2h1nLzhl4r4KPt, __2ZmUTuiMSUVREuxynTjt7PGQ, 0)
	return __aZdijulvKPumkenUsC9wpFc_
static func __s3CdyC_X7fMlYb9Wy35B8EuH(a: __YCYnibBjVPRhMDf3YPwizbkN) -> void :
	if a.__hF5qCjy1NYsx4mlJR0VxACAc >= 0:
		a.__TlWqW0m63x0ks40OasJLgdcp = a.__hF5qCjy1NYsx4mlJR0VxACAc
		a.__auam0OiXATfV0FV2pOZQsnnt = a.__FLbMUbwRQZZKI9_42OkArD2b
		a.__hF5qCjy1NYsx4mlJR0VxACAc = -1
		a.state = __YCYnibBjVPRhMDf3YPwizbkN.State.__SokrJF1aDQ6jidDRcP3EDMhC
	else:
		a.__TlWqW0m63x0ks40OasJLgdcp = -1
		a.__auam0OiXATfV0FV2pOZQsnnt = -1
		a.state = __YCYnibBjVPRhMDf3YPwizbkN.State.__9wEd2skDnIT9b_VOjrri893n
static func __eYhC5U8lAaD_KlZfHZwwziBx(__uNxPaa9tXToXs0h735SGMTeV: __aDswGCE4WWdmypkp3eC7rExn, __JlReZjkkT0Q_lS9W1Ay_bo8f: __YCYnibBjVPRhMDf3YPwizbkN, __0IFjLWR29eKTgGHdUYqjQxM4: __YdhZSn3k6BLtSITi5naOCb7n) -> void :
	var __UvZoNzpgUChLSYUTXTPMbOPL: int = __0IFjLWR29eKTgGHdUYqjQxM4.x() - __JlReZjkkT0Q_lS9W1Ay_bo8f.__EsOQaggwtLEnMAHn6g7H_r7O()
	var __8SDubs78x_wYwU2ZCrdcAvZw: int = __0IFjLWR29eKTgGHdUYqjQxM4.y() - __JlReZjkkT0Q_lS9W1Ay_bo8f.__KrKPdZs_d6uEOIuRq3UQy1fb()
	__JlReZjkkT0Q_lS9W1Ay_bo8f.__LHXFh2KJbTtUtaDckBU0bXW0 = __Irz9hiGcyslSDsJT8BenfEt2.__f8g2PjfN7nwJbTHn9ePhmeZH(__dXppFYqETFUwGtUmhS9ups7R(__8SDubs78x_wYwU2ZCrdcAvZw * __8SDubs78x_wYwU2ZCrdcAvZw + __UvZoNzpgUChLSYUTXTPMbOPL * __UvZoNzpgUChLSYUTXTPMbOPL))
	if __JlReZjkkT0Q_lS9W1Ay_bo8f.__Q4PVEYDqIobYx26SsJ1Qdl3_:
		return
	if __tUnSLy1bkvGyKKeIrEiqbbcp(__JlReZjkkT0Q_lS9W1Ay_bo8f) < __JlReZjkkT0Q_lS9W1Ay_bo8f.__Grly1BvCsxoCuBf0E7OZOvtN:
		__JlReZjkkT0Q_lS9W1Ay_bo8f.__Q4PVEYDqIobYx26SsJ1Qdl3_ = true
		__JlReZjkkT0Q_lS9W1Ay_bo8f.state = __YCYnibBjVPRhMDf3YPwizbkN.State.__eEvXiwf2UW57C8JVEuywqlUc
		__JlReZjkkT0Q_lS9W1Ay_bo8f.sub = 0
		__JlReZjkkT0Q_lS9W1Ay_bo8f.__2cQt3I45k0XXwSr_0reYodT2 = 0
		__uNxPaa9tXToXs0h735SGMTeV.__wIebi2RHJicnHeiUm6xYwBpd(__QzfA1_MgHwBGTTBizdgA8rkk.__FSW4WCXpupwYSF0KaHCFCNKb.__Z4zb38Z0p0n5agncEYj9TLFK, __JlReZjkkT0Q_lS9W1Ay_bo8f, 2)
static func __vblY9TJL1GlRksTX9ledsBzT(__UQ5wzvL7xnOKV4GahCSn8Ipv: __bzxMmNAcE_RKMny5gklgDglw, __eZMQRCmsJEjsvOtFaOCQ44oy: int) -> Dictionary:
	var ___GX_ojk0pV_pJQVYBTja7Gvg: int = __UQ5wzvL7xnOKV4GahCSn8Ipv.__Jy2hcMM9emCF3iBBkLMyeUr7("Torpedo", __eZMQRCmsJEjsvOtFaOCQ44oy, 152)
	var __uWPNFXT1XdbQyg6J3e0XFtj_: int = __UQ5wzvL7xnOKV4GahCSn8Ipv.__Jy2hcMM9emCF3iBBkLMyeUr7("Torpedo", __eZMQRCmsJEjsvOtFaOCQ44oy, 160)
	var __d9sbkqeKJ_gD3EkKYPQZrgm0: int = __UQ5wzvL7xnOKV4GahCSn8Ipv.__Jy2hcMM9emCF3iBBkLMyeUr7("Torpedo", __eZMQRCmsJEjsvOtFaOCQ44oy, 170)
	return {"row": __eZMQRCmsJEjsvOtFaOCQ44oy, "spd_slow": (___GX_ojk0pV_pJQVYBTja7Gvg & 63) * 10, "spd_fast": ((___GX_ojk0pV_pJQVYBTja7Gvg >> 6) & 63) * 10, 
		"r_fast": __UQ5wzvL7xnOKV4GahCSn8Ipv.__Jy2hcMM9emCF3iBBkLMyeUr7("Torpedo", __eZMQRCmsJEjsvOtFaOCQ44oy, 168), "arm2": __uWPNFXT1XdbQyg6J3e0XFtj_ * __uWPNFXT1XdbQyg6J3e0XFtj_ * 144 / 100, "dmg": __d9sbkqeKJ_gD3EkKYPQZrgm0, 
		"ms": __UQ5wzvL7xnOKV4GahCSn8Ipv.__Jy2hcMM9emCF3iBBkLMyeUr7("Torpedo", __eZMQRCmsJEjsvOtFaOCQ44oy, 172), "prox": (__UQ5wzvL7xnOKV4GahCSn8Ipv.__Jy2hcMM9emCF3iBBkLMyeUr7("Torpedo", __eZMQRCmsJEjsvOtFaOCQ44oy, 154) & 256) != 0, 
		"splash_r": __0QiGqbYBLZEUENpkfN6eZqIr.__a5eYMyME8QPCU2zMlcPIPoKV(__d9sbkqeKJ_gD3EkKYPQZrgm0)}
static func __m7i06L624pXCCgFN5wWx5Wk_(sub: int, __w7qvk1JSb2R01ypbrYZds17R: int, data: PackedByteArray, __4tgLY57GBYtAhKiSUISm6xZt: PackedInt32Array) -> PackedByteArray:
	var __JQLeYJZqOjByh2hOSYqUomTU: = PackedByteArray([1, sub, __w7qvk1JSb2R01ypbrYZds17R, 0])
	__JQLeYJZqOjByh2hOSYqUomTU.append_array(data)
	for __mdfrwuhdLakRY1WUobAriPWN: int in __4tgLY57GBYtAhKiSUISm6xZt:
		__JQLeYJZqOjByh2hOSYqUomTU.append(__mdfrwuhdLakRY1WUobAriPWN & 255)
	__JQLeYJZqOjByh2hOSYqUomTU[3] = __JQLeYJZqOjByh2hOSYqUomTU.size()
	return __JQLeYJZqOjByh2hOSYqUomTU
static func __1UOXWwkIUXXOQQkOhWzmSkZZ(__n14dbpXvBpsAMCxz4XeFVUm2: int) -> int:
	var __8inKODgcfhZoBKsFyo66NCQU: int = 1
	var __yt4MyLAFhkcA8GCM_6xremRP: int = 0
	var __0dskuqvrrI8YRvGlZ3jVJKR2: int = 1
	var __1LQO7X5KY3JomjZpSrF54vsR: int = __n14dbpXvBpsAMCxz4XeFVUm2
	while __1LQO7X5KY3JomjZpSrF54vsR != 0:
		__1LQO7X5KY3JomjZpSrF54vsR = __1LQO7X5KY3JomjZpSrF54vsR / 10
		if __1LQO7X5KY3JomjZpSrF54vsR != 0:
			__yt4MyLAFhkcA8GCM_6xremRP += 1
		if __yt4MyLAFhkcA8GCM_6xremRP > 1:
			__0dskuqvrrI8YRvGlZ3jVJKR2 *= 10
			__yt4MyLAFhkcA8GCM_6xremRP = 0
			if __0dskuqvrrI8YRvGlZ3jVJKR2 >= 100:
				__8inKODgcfhZoBKsFyo66NCQU *= 100
	var __w0QIco90pHNjPhBtlwTUFkmI: int = __n14dbpXvBpsAMCxz4XeFVUm2 / __8inKODgcfhZoBKsFyo66NCQU
	if __w0QIco90pHNjPhBtlwTUFkmI < 0 or __w0QIco90pHNjPhBtlwTUFkmI >= __TXCdoY85HWzo9E7Qcf9l8raZ.__D4d3qKgKIsKFZZ7n5aDnyQtA.size():
		return 0
	return __TXCdoY85HWzo9E7Qcf9l8raZ.__D4d3qKgKIsKFZZ7n5aDnyQtA[__w0QIco90pHNjPhBtlwTUFkmI] * __0dskuqvrrI8YRvGlZ3jVJKR2
const __C35YbYHfttxTwUfuX7ZdwI3G: = 120
static func __BKEOJ1JAGQ2x2Yfo6T32v1Zk(h: int, b: int) -> int:
	if h - 1800 > b:
		return b - h + 3600
	if h - 1800 < b:
		return b - h
	return 1800
static func __c8MA39tm6BoC78N3GABrZORw(__ypnJWJR6_3PZRCFya0TGuCOy: __aDswGCE4WWdmypkp3eC7rExn, __k0nrexKFL323h0HTTkNFfKui: __YdhZSn3k6BLtSITi5naOCb7n) -> void :
	var w: __1q0DwOCFFBOQDiHI3310K_lq = __k0nrexKFL323h0HTTkNFfKui.__g7JC3EJmfsOWnIyqLGGB93eB
	if w == null:
		return
	for s: Dictionary in w.__MMezevmh2WzjfDPiLXmgyJbQ:
		for a: __YCYnibBjVPRhMDf3YPwizbkN in (s["members"] as Array).duplicate():
			if not a.active:
				__4vkwFQCb1YIrsLiCaaP3aBi4(__ypnJWJR6_3PZRCFya0TGuCOy, a, 1)
				a.__dRotcb2ldVZQLm2YDYWTTU9J = false
	w.queue.clear()
static func __o186_ra3zNm3Ad8CIwfp_bYk(__1oiyNn43lOIq7DdX7ZEi54fZ: __aDswGCE4WWdmypkp3eC7rExn, __HQzqzLxZ9arvC5P7olNHwCVP: __YCYnibBjVPRhMDf3YPwizbkN) -> void :
	var w: __1q0DwOCFFBOQDiHI3310K_lq = __1oiyNn43lOIq7DdX7ZEi54fZ.__LYNzM9N3A8Dmo_1zq54GljKm[__HQzqzLxZ9arvC5P7olNHwCVP.owner].__g7JC3EJmfsOWnIyqLGGB93eB
	if w == null:
		return
	var __TFxSEkR5J6fw3mvGtCKKrjam: __YCYnibBjVPRhMDf3YPwizbkN = w.__kVB4BR6zkcZM5875sCAu1tWK(__HQzqzLxZ9arvC5P7olNHwCVP.__knUj879QWUN8clA4_f5YGzfw)
	if __TFxSEkR5J6fw3mvGtCKKrjam == null:
		return
	var __IDvXoz6DJ_wZx4ncoOohf4zG: int = __HQzqzLxZ9arvC5P7olNHwCVP.__EHjU5UjAgmmddD5nyx49ar6j
	if __HQzqzLxZ9arvC5P7olNHwCVP.__zjyW8rAU_8pK0uXV_Zkdk_Kw > __TFxSEkR5J6fw3mvGtCKKrjam.__zjyW8rAU_8pK0uXV_Zkdk_Kw:
		var s: int = __HQzqzLxZ9arvC5P7olNHwCVP.__wK6c6xRBxB0Lka8tqK6RrNfH * 105 / 100
		var __VGX7oa4wsCzY5bm69ptZ5A1O: int = __IDvXoz6DJ_wZx4ncoOohf4zG * 12 / 10
		__HQzqzLxZ9arvC5P7olNHwCVP.__wK6c6xRBxB0Lka8tqK6RrNfH = __VGX7oa4wsCzY5bm69ptZ5A1O if s > __VGX7oa4wsCzY5bm69ptZ5A1O else s
	elif __HQzqzLxZ9arvC5P7olNHwCVP.__zjyW8rAU_8pK0uXV_Zkdk_Kw < __TFxSEkR5J6fw3mvGtCKKrjam.__zjyW8rAU_8pK0uXV_Zkdk_Kw:
		var s: int = __HQzqzLxZ9arvC5P7olNHwCVP.__wK6c6xRBxB0Lka8tqK6RrNfH * 95 / 100
		var __EmknyjzW7RiRfFpO_SD6RAJj: int = __IDvXoz6DJ_wZx4ncoOohf4zG * 7 / 10
		__HQzqzLxZ9arvC5P7olNHwCVP.__wK6c6xRBxB0Lka8tqK6RrNfH = __EmknyjzW7RiRfFpO_SD6RAJj if s < __EmknyjzW7RiRfFpO_SD6RAJj else s
static func __JHfBMoJnymDc9RLYmyT8NR73(__sPloG94nIBM6fSikMndnrd1m: __aDswGCE4WWdmypkp3eC7rExn, __M4bRXrD_GvU3Wqz9gcKlNyOp: __YCYnibBjVPRhMDf3YPwizbkN, __2dkDLNmER2inKORVL4oS7wj4: __YdhZSn3k6BLtSITi5naOCb7n) -> void :
	if __2dkDLNmER2inKORVL4oS7wj4.state != __lAo0PsogaUvqHw4muTzPsHiR.__pRO7nOY10o2GAU3KzWQvIvwY:
		return
	var w: int = __sPloG94nIBM6fSikMndnrd1m.terrain.__9Zy5NwQKLR2WXbpStDOauEMz
	var h: int = __sPloG94nIBM6fSikMndnrd1m.terrain.__0xMwoIVfT_j6GZoLP_HkB6nE
	var x: int = __M4bRXrD_GvU3Wqz9gcKlNyOp.__EsOQaggwtLEnMAHn6g7H_r7O()
	var y: int = __M4bRXrD_GvU3Wqz9gcKlNyOp.__caDHon68LplNQ04cMl2MMJ71()
	if x < __R57y5g_HdP5oW23rah6hKG8x[0] or x > w - __R57y5g_HdP5oW23rah6hKG8x[1] or y < __R57y5g_HdP5oW23rah6hKG8x[2] or y > h - __R57y5g_HdP5oW23rah6hKG8x[3]:
		if not __M4bRXrD_GvU3Wqz9gcKlNyOp.__jKXPrtchy4v7fjo9Z9kJG9SX:
			__4vkwFQCb1YIrsLiCaaP3aBi4(__sPloG94nIBM6fSikMndnrd1m, __M4bRXrD_GvU3Wqz9gcKlNyOp, 1)
			__M4bRXrD_GvU3Wqz9gcKlNyOp.__F41ZT8z_0zKKqYDFwqS1WGTs = 0
			__M4bRXrD_GvU3Wqz9gcKlNyOp.__jKXPrtchy4v7fjo9Z9kJG9SX = true
			__M4bRXrD_GvU3Wqz9gcKlNyOp.sub = 0
			__M4bRXrD_GvU3Wqz9gcKlNyOp.state = __YCYnibBjVPRhMDf3YPwizbkN.State.__eEvXiwf2UW57C8JVEuywqlUc
			__M4bRXrD_GvU3Wqz9gcKlNyOp.__2cQt3I45k0XXwSr_0reYodT2 = 0
			if __M4bRXrD_GvU3Wqz9gcKlNyOp.pitch >= 0:
				__M4bRXrD_GvU3Wqz9gcKlNyOp.pitch = -150
			__sPloG94nIBM6fSikMndnrd1m.__wIebi2RHJicnHeiUm6xYwBpd(__QzfA1_MgHwBGTTBizdgA8rkk.__FSW4WCXpupwYSF0KaHCFCNKb.__Z4zb38Z0p0n5agncEYj9TLFK, __M4bRXrD_GvU3Wqz9gcKlNyOp, 1)
static func __HiW9bSV2jhRblIaGALPU__g9(__XSOWZUOKrjB1eLD0I9ZTh3JK: __YCYnibBjVPRhMDf3YPwizbkN) -> int:
	var __gbClHAuFsbrUa1M4ZFMNII4S: int = __XSOWZUOKrjB1eLD0I9ZTh3JK.__zcQSNSE8gcZixJwEAvw9gtcc / __YCYnibBjVPRhMDf3YPwizbkN.__MA8wP1gT_dP2gLlCd9pUKLCo
	var __2ZuacmEAd3kfcwZ6LtTzcHco: int = __XSOWZUOKrjB1eLD0I9ZTh3JK.__EsOQaggwtLEnMAHn6g7H_r7O()
	var __r6Zq8vWYcA679v9FEw5CWCBq: int = __XSOWZUOKrjB1eLD0I9ZTh3JK.__caDHon68LplNQ04cMl2MMJ71()
	var b: int = __klxfH4sf9TNRbMClsfcRuKkB(__2ZuacmEAd3kfcwZ6LtTzcHco, __gbClHAuFsbrUa1M4ZFMNII4S, __XSOWZUOKrjB1eLD0I9ZTh3JK.__3epXDNnmkHn9cpXlvNEl2W4g, __XSOWZUOKrjB1eLD0I9ZTh3JK.__C3JQvlRdH1p7kRdolXEDy8oi) * 10
	var __1_8F89SBqISaIbfprwqiiWaD: int = __XSOWZUOKrjB1eLD0I9ZTh3JK.__3epXDNnmkHn9cpXlvNEl2W4g - __2ZuacmEAd3kfcwZ6LtTzcHco
	var __NlUKB5o5OrA5pwfmN8WZh0cu: int = __XSOWZUOKrjB1eLD0I9ZTh3JK.__C3JQvlRdH1p7kRdolXEDy8oi - __gbClHAuFsbrUa1M4ZFMNII4S
	__XSOWZUOKrjB1eLD0I9ZTh3JK.__zjyW8rAU_8pK0uXV_Zkdk_Kw = __Irz9hiGcyslSDsJT8BenfEt2.__f8g2PjfN7nwJbTHn9ePhmeZH(__dXppFYqETFUwGtUmhS9ups7R(__NlUKB5o5OrA5pwfmN8WZh0cu * __NlUKB5o5OrA5pwfmN8WZh0cu + __1_8F89SBqISaIbfprwqiiWaD * __1_8F89SBqISaIbfprwqiiWaD))
	var h: int = __XSOWZUOKrjB1eLD0I9ZTh3JK.__vqYa6WuT8lqRfpObeEEtFMHG
	var __z7f24VRrEQhgKEfPJzBnGa92: int = h / 900
	var __0mi8oAZzsoaE1QucYzEFSt6G: int = b / 900
	match __z7f24VRrEQhgKEfPJzBnGa92:
		0:
			if __0mi8oAZzsoaE1QucYzEFSt6G == 0 or __0mi8oAZzsoaE1QucYzEFSt6G == 1:
				return b - h
			if __0mi8oAZzsoaE1QucYzEFSt6G == 2:
				return __oLlaFkqjhrYAT8tmulRumY2_(h, b)
			if __0mi8oAZzsoaE1QucYzEFSt6G == 3:
				return b - h - 3600
			return 0
		1:
			if __0mi8oAZzsoaE1QucYzEFSt6G < 0:
				return 0
			if __0mi8oAZzsoaE1QucYzEFSt6G <= 2:
				return b - h
			if __0mi8oAZzsoaE1QucYzEFSt6G == 3:
				return __oLlaFkqjhrYAT8tmulRumY2_(h, b)
			return 0
		2:
			if __0mi8oAZzsoaE1QucYzEFSt6G == 0:
				return __BKEOJ1JAGQ2x2Yfo6T32v1Zk(h, b)
			if __0mi8oAZzsoaE1QucYzEFSt6G >= 1 and __0mi8oAZzsoaE1QucYzEFSt6G <= 3:
				return b - h
			return 0
		3:
			if __0mi8oAZzsoaE1QucYzEFSt6G == 0:
				return b - h + 3600
			if __0mi8oAZzsoaE1QucYzEFSt6G >= 1 and __0mi8oAZzsoaE1QucYzEFSt6G <= 3:
				return b - h
			return 0
	return 0
static func __7PKcorN1UkwsuGN_0x6XXwuu(__6RCxhRgtWCyTL0ZPaYDS8CEF: __aDswGCE4WWdmypkp3eC7rExn, __ulw0gUzslRhVea1bKJWXWOJq: int) -> bool:
	return __ulw0gUzslRhVea1bKJWXWOJq >= 0 and __ulw0gUzslRhVea1bKJWXWOJq < __6RCxhRgtWCyTL0ZPaYDS8CEF.__LYNzM9N3A8Dmo_1zq54GljKm.size() and __6RCxhRgtWCyTL0ZPaYDS8CEF.__LYNzM9N3A8Dmo_1zq54GljKm[__ulw0gUzslRhVea1bKJWXWOJq].state == __lAo0PsogaUvqHw4muTzPsHiR.__pRO7nOY10o2GAU3KzWQvIvwY
static func __YZg0i9AduOgyDQKnH5G2AtsB(a: __YCYnibBjVPRhMDf3YPwizbkN, __rEp_EuKxPG7VJ_nbrm0lEy2m: __YCYnibBjVPRhMDf3YPwizbkN) -> void :
	var __IpCwg5GyqHxLOYhL6g1WDQvh: int = __YCYnibBjVPRhMDf3YPwizbkN.__2OJpMwzaDeyLf0HK2_6FqBy2
	var __Wd8XCCbHTQqQLYHW0NZgg4II: int = a.__aBKovnuyCiI63tVuI2prB5MN / 1000
	if __Wd8XCCbHTQqQLYHW0NZgg4II > __IpCwg5GyqHxLOYhL6g1WDQvh:
		a.__2cQt3I45k0XXwSr_0reYodT2 = __IpCwg5GyqHxLOYhL6g1WDQvh
	elif __Wd8XCCbHTQqQLYHW0NZgg4II < 20:
		a.__2cQt3I45k0XXwSr_0reYodT2 = 20
	if __rEp_EuKxPG7VJ_nbrm0lEy2m != null:
		var __25uClBo1tZvHvD0HL7TtfLeO: int = __rEp_EuKxPG7VJ_nbrm0lEy2m.__aBKovnuyCiI63tVuI2prB5MN / 1000
		if __Wd8XCCbHTQqQLYHW0NZgg4II == __25uClBo1tZvHvD0HL7TtfLeO:
			return
		var __vfXHg095R1KTiYE9E6RCxRHW: int = __25uClBo1tZvHvD0HL7TtfLeO * 1000
		var ___0eFcKlwT1grW2kXg2YkPqfG: int = __vfXHg095R1KTiYE9E6RCxRHW - a.__aBKovnuyCiI63tVuI2prB5MN
		a.__2cQt3I45k0XXwSr_0reYodT2 = __vfXHg095R1KTiYE9E6RCxRHW
		if a.pitch < 0:
			if __vfXHg095R1KTiYE9E6RCxRHW >= a.__aBKovnuyCiI63tVuI2prB5MN:
				a.pitch = 0
		elif __vfXHg095R1KTiYE9E6RCxRHW <= a.__aBKovnuyCiI63tVuI2prB5MN:
			a.pitch = 0
		var __jAIwK4s96vyGCAxKShRACVfd: int = a.pitch
		a.pitch = __jAIwK4s96vyGCAxKShRACVfd + ___0eFcKlwT1grW2kXg2YkPqfG * 10 / __IpCwg5GyqHxLOYhL6g1WDQvh
		if absi(a.pitch) > 400:
			a.pitch = __jAIwK4s96vyGCAxKShRACVfd
		return
	if a.sub == 0:
		a.__H0IfsdkHBf2MPjU13h3e655G = false
		a.__2cQt3I45k0XXwSr_0reYodT2 = __IpCwg5GyqHxLOYhL6g1WDQvh
		a.sub = 1
		return
	if a.sub == 1:
		a.pitch += (a.__2cQt3I45k0XXwSr_0reYodT2 - a.__aBKovnuyCiI63tVuI2prB5MN) * 10 / __IpCwg5GyqHxLOYhL6g1WDQvh
		if a.pitch > 400:
			a.pitch = 400
		if a.__2cQt3I45k0XXwSr_0reYodT2 <= a.__aBKovnuyCiI63tVuI2prB5MN:
			a.pitch = 0
			a.sub = 0
			if a.__hF5qCjy1NYsx4mlJR0VxACAc >= 0:
				a.__TlWqW0m63x0ks40OasJLgdcp = a.__hF5qCjy1NYsx4mlJR0VxACAc
				a.__auam0OiXATfV0FV2pOZQsnnt = a.__FLbMUbwRQZZKI9_42OkArD2b
				a.state = __YCYnibBjVPRhMDf3YPwizbkN.State.__SokrJF1aDQ6jidDRcP3EDMhC
			else:
				a.state = __YCYnibBjVPRhMDf3YPwizbkN.State.__9wEd2skDnIT9b_VOjrri893n
static func ___ifkpkcx4U2OpwQGcnHHye7Z(__cSGub4jrYZNcacVucWuhTrBk: __YdhZSn3k6BLtSITi5naOCb7n) -> void :
	var w: __1q0DwOCFFBOQDiHI3310K_lq = __cSGub4jrYZNcacVucWuhTrBk.__g7JC3EJmfsOWnIyqLGGB93eB
	if w == null:
		return
	if w.__4xREaDvbh74nCbB3paXnMRd1 > 0:
		w.__4xREaDvbh74nCbB3paXnMRd1 -= 1
		return
	w.__4xREaDvbh74nCbB3paXnMRd1 = __3Q04ZY09Jmx3SsmRkFW1hxSK
	for s: Dictionary in w.__MMezevmh2WzjfDPiLXmgyJbQ:
		var __ep2SzruZ7jTcJOaOP3SPU5dV: Array = s["members"]
		for a: __YCYnibBjVPRhMDf3YPwizbkN in __ep2SzruZ7jTcJOaOP3SPU5dV:
			if not a.active:
				if a == __ep2SzruZ7jTcJOaOP3SPU5dV[0]:
					a.__2nVqHzJsE4wg_diKnctoD6kY = true
				a.active = true
				w.queue.erase(a)
				return
static func __oYgWRLZfuRe6ZBKCkoPvchaA(__czapVOZORsENTNLFOXu2aNDP: __aDswGCE4WWdmypkp3eC7rExn, a: __YCYnibBjVPRhMDf3YPwizbkN) -> int:
	var __UUgf6c002P9virBYViPYZMxh: __YdhZSn3k6BLtSITi5naOCb7n = __czapVOZORsENTNLFOXu2aNDP.__LYNzM9N3A8Dmo_1zq54GljKm[a.__TlWqW0m63x0ks40OasJLgdcp]
	var __e7ilBM7bpvg1GoN7Z20L5XdF: int = a.__EsOQaggwtLEnMAHn6g7H_r7O()
	var __KEbXDAWUc8Xery24NMRxbMr6: int = a.__KrKPdZs_d6uEOIuRq3UQy1fb()
	var __3jYdoRolbyhDddPejTtVgnyC: int = __UUgf6c002P9virBYViPYZMxh.x()
	var __jDDGXuNARfsn0V4QNnj8eN_Y: int = __UUgf6c002P9virBYViPYZMxh.y()
	var __ZGi1DTGHWcIljEgydYXfMlug: int = (__jDDGXuNARfsn0V4QNnj8eN_Y - __KEbXDAWUc8Xery24NMRxbMr6) * 200 / 100
	var __ru84lp3fkQRNNPWR220TGN3X: int = __3jYdoRolbyhDddPejTtVgnyC - __e7ilBM7bpvg1GoN7Z20L5XdF
	var d: int = __Irz9hiGcyslSDsJT8BenfEt2.__f8g2PjfN7nwJbTHn9ePhmeZH(__dXppFYqETFUwGtUmhS9ups7R(__ru84lp3fkQRNNPWR220TGN3X * __ru84lp3fkQRNNPWR220TGN3X + __ZGi1DTGHWcIljEgydYXfMlug * __ZGi1DTGHWcIljEgydYXfMlug))
	var __4b09XgCIXT2VUEUHjw7QJDJW: int = int(a.__E9mK1bVUpfbbeQc2wFvz9PTC.get("spd_slow", 10))
	var __bLIGggQ8IKXG9ksFQiI3sga_: int = d * 200 / maxi(1, __4b09XgCIXT2VUEUHjw7QJDJW) + a.__P1rs6m_7HtwjQNs9Q4TnQzBo
	__3jYdoRolbyhDddPejTtVgnyC += int(__UUgf6c002P9virBYViPYZMxh.__gz4iZzIm1ic26sbX2dyDa0Lg["dx"]) * __bLIGggQ8IKXG9ksFQiI3sga_ / 240
	__jDDGXuNARfsn0V4QNnj8eN_Y -= int(__UUgf6c002P9virBYViPYZMxh.__gz4iZzIm1ic26sbX2dyDa0Lg["dy"]) * __bLIGggQ8IKXG9ksFQiI3sga_ / 480
	var b: int = __apitD6L2wJGin9cDVFtGArTy(__e7ilBM7bpvg1GoN7Z20L5XdF, __KEbXDAWUc8Xery24NMRxbMr6, __3jYdoRolbyhDddPejTtVgnyC, __jDDGXuNARfsn0V4QNnj8eN_Y) * 10 % 3600
	var __2_vR3UDlDfmmeA69h7PacGUH: int = a.__w4KgbGj0JQyP8PGvp68qYP1F
	var ___q65Bj9rw4PX9JQL0irT0hQ0: int = (__2_vR3UDlDfmmeA69h7PacGUH + 1 if __2_vR3UDlDfmmeA69h7PacGUH % 2 != 0 else __2_vR3UDlDfmmeA69h7PacGUH) / 2
	var s: int = - ___q65Bj9rw4PX9JQL0irT0hQ0 if __2_vR3UDlDfmmeA69h7PacGUH % 2 != 0 else ___q65Bj9rw4PX9JQL0irT0hQ0
	a.__P1rs6m_7HtwjQNs9Q4TnQzBo = -24 * s
	var __Ow5na3mnvCiJL9QcbN9L98uV: Vector2i = __XdcdSffYaN4csG29A7yc6Z3i(-6 * ___q65Bj9rw4PX9JQL0irT0hQ0, -24 * s, b)
	a.__3epXDNnmkHn9cpXlvNEl2W4g = __Ow5na3mnvCiJL9QcbN9L98uV.x + __3jYdoRolbyhDddPejTtVgnyC
	a.__C3JQvlRdH1p7kRdolXEDy8oi = __Ow5na3mnvCiJL9QcbN9L98uV.y * 86 / 100 + __jDDGXuNARfsn0V4QNnj8eN_Y
	return d
const __DLnqkjy7DeochoblNnDXHwIc: = 25
static func __L5HR6YCW7VZBKEE4q3BherRG(__Qpx_a0UyKJkwexJ6cdM9p874: __aDswGCE4WWdmypkp3eC7rExn, __oJ06uYByboVW2gByzM8dVnJD: Dictionary) -> bool:
	var __gkJJhhAQ__YpY9zB7DLIkN0Do: int = 2 * __cBlWh6sEMsRhPxWHZtRo3q8T()
	if __gkJJhhAQ__YpY9zB7DLIkN0Do == 0:
		return false
	var __4IPbX1t33qRPDvOTq8ykPWO7: int = int(__oJ06uYByboVW2gByzM8dVnJD["x"]) / __a3Qlrip4DI7L5IkLGkgxE5xK.__jSHCPDm8k9O9CtctnqkQJ6b2
	var __xJekZmNDNSPuXvjF8DcF4XwE: int = int(__oJ06uYByboVW2gByzM8dVnJD["y"]) / __a3Qlrip4DI7L5IkLGkgxE5xK.__W_7fSiIVO80l6wn6KwvCuoPH
	var __rLbj3nSJRE3tv0WHAmnh_hrf: int = int(__oJ06uYByboVW2gByzM8dVnJD["h"]) / 400
	for __N6EAcLxFNI_n4kM69zO0g0Or: __YdhZSn3k6BLtSITi5naOCb7n in __Qpx_a0UyKJkwexJ6cdM9p874.__LYNzM9N3A8Dmo_1zq54GljKm:
		if __N6EAcLxFNI_n4kM69zO0g0Or.__g7JC3EJmfsOWnIyqLGGB93eB == null:
			continue
		for ___tpk8nuAoKqehnu_3hFcPmp8: Dictionary in __N6EAcLxFNI_n4kM69zO0g0Or.__g7JC3EJmfsOWnIyqLGGB93eB.__MMezevmh2WzjfDPiLXmgyJbQ:
			var __AaHZcsJYibQKgma1Ya7EsJCx: Array = (___tpk8nuAoKqehnu_3hFcPmp8["members"] as Array).duplicate()
			for __nans1D9Coh_z2JInOL8UyNz7: int in __AaHZcsJYibQKgma1Ya7EsJCx.size():
				var a: __YCYnibBjVPRhMDf3YPwizbkN = __AaHZcsJYibQKgma1Ya7EsJCx[__nans1D9Coh_z2JInOL8UyNz7]
				if not a.active or a.__jKXPrtchy4v7fjo9Z9kJG9SX or not a.__dRotcb2ldVZQLm2YDYWTTU9J:
					continue
				if absi(__rLbj3nSJRE3tv0WHAmnh_hrf - a.__aBKovnuyCiI63tVuI2prB5MN / 1000) >= __gkJJhhAQ__YpY9zB7DLIkN0Do:
					continue
				var __qnFPMx_BaAZ9GZOj5tSzp9OL: int = __4IPbX1t33qRPDvOTq8ykPWO7 - a.__EsOQaggwtLEnMAHn6g7H_r7O()
				var __nJJzKg6yconLptqnicDjQmzJ: int = __xJekZmNDNSPuXvjF8DcF4XwE - a.__KrKPdZs_d6uEOIuRq3UQy1fb()
				var __CmJHJO88o0BglI2lkyAA1ECt: int = __qnFPMx_BaAZ9GZOj5tSzp9OL * __qnFPMx_BaAZ9GZOj5tSzp9OL + __nJJzKg6yconLptqnicDjQmzJ * __nJJzKg6yconLptqnicDjQmzJ
				if not (__gkJJhhAQ__YpY9zB7DLIkN0Do * __gkJJhhAQ__YpY9zB7DLIkN0Do > __CmJHJO88o0BglI2lkyAA1ECt):
					continue
				var __ys_5TWEJrPMrfTFeKm1y2Xao: int = int(__oJ06uYByboVW2gByzM8dVnJD["HE"]) * 7 / 4
				var ___A4DxDNd_ogatx0OQifAXT58: int = __ys_5TWEJrPMrfTFeKm1y2Xao - __ys_5TWEJrPMrfTFeKm1y2Xao * __Irz9hiGcyslSDsJT8BenfEt2.__f8g2PjfN7nwJbTHn9ePhmeZH(__CmJHJO88o0BglI2lkyAA1ECt) / __gkJJhhAQ__YpY9zB7DLIkN0Do
				if not __wGK_UQbzU1Hdj_uA5qiKTLE7(__Qpx_a0UyKJkwexJ6cdM9p874, a, ___A4DxDNd_ogatx0OQifAXT58, int(__oJ06uYByboVW2gByzM8dVnJD["owner"])):
					return true
				if __nans1D9Coh_z2JInOL8UyNz7 + 1 < __AaHZcsJYibQKgma1Ya7EsJCx.size():
					return true
				break
	return false
static func __XdcdSffYaN4csG29A7yc6Z3i(x: int, y: int, a: int) -> Vector2i:
	return Vector2i((x * __TXCdoY85HWzo9E7Qcf9l8raZ.__9nHAKAsjPH38LR2tAezCTqd_[a] - y * __TXCdoY85HWzo9E7Qcf9l8raZ.__7laIgLr3i8VN0D_tZnYT3p0D[a]) / 1000, (y * __TXCdoY85HWzo9E7Qcf9l8raZ.__9nHAKAsjPH38LR2tAezCTqd_[a] + x * __TXCdoY85HWzo9E7Qcf9l8raZ.__7laIgLr3i8VN0D_tZnYT3p0D[a]) / 1000)
static func __ahUHZ6OQiJ8y86PS5PExnHiy(__v1w3Bl5MoqnEyzIjm6PdYlWz: __aDswGCE4WWdmypkp3eC7rExn, __fdIp10iC4pxOzAA4zSRbTWnm: __YdhZSn3k6BLtSITi5naOCb7n, __icSfcMATuDqYMZJCt58uFd5c: int, __tOb_RHcMcP9MP65IAV7AdVCm: int, __DSjTl7utdoD2sMX_o74OhqzG: int, v: int) -> __YCYnibBjVPRhMDf3YPwizbkN:
	var __ZAk1me79cneckaMLlSAqwTMb: __bzxMmNAcE_RKMny5gklgDglw = __v1w3Bl5MoqnEyzIjm6PdYlWz.___qFCN2viGM2bPW1uGV9qys9h
	var a: = __YCYnibBjVPRhMDf3YPwizbkN.new()
	a.id = __v1w3Bl5MoqnEyzIjm6PdYlWz.__hTfETy1GbJqN6AkV7BYpZilZ()
	a.owner = __fdIp10iC4pxOzAA4zSRbTWnm.index
	a.__7OKcEzdMfOdabzyMipWdSzWD = __fdIp10iC4pxOzAA4zSRbTWnm.__7OKcEzdMfOdabzyMipWdSzWD
	a.__knUj879QWUN8clA4_f5YGzfw = __tOb_RHcMcP9MP65IAV7AdVCm
	a.__w4KgbGj0JQyP8PGvp68qYP1F = __DSjTl7utdoD2sMX_o74OhqzG
	a.__2JrSVwNu3iuGLA6jYvTAWmt6 = __icSfcMATuDqYMZJCt58uFd5c
	a.type = __ZAk1me79cneckaMLlSAqwTMb.__Jy2hcMM9emCF3iBBkLMyeUr7("Aircraft", __icSfcMATuDqYMZJCt58uFd5c, 152)
	a.__sKr62cCOgUldNWyZFY0fWlbB = __ZAk1me79cneckaMLlSAqwTMb.__Jy2hcMM9emCF3iBBkLMyeUr7("Aircraft", __icSfcMATuDqYMZJCt58uFd5c, 4)
	a.__CYx_P43ujHK1YF5Dtz9hb_PN = __fdIp10iC4pxOzAA4zSRbTWnm.x() * __YCYnibBjVPRhMDf3YPwizbkN.__cHG7uqwSsi61Yy3Vsde0Xm71
	a.__zcQSNSE8gcZixJwEAvw9gtcc = __fdIp10iC4pxOzAA4zSRbTWnm.y() * __YCYnibBjVPRhMDf3YPwizbkN.__MA8wP1gT_dP2gLlCd9pUKLCo
	a.__3epXDNnmkHn9cpXlvNEl2W4g = __fdIp10iC4pxOzAA4zSRbTWnm.x()
	a.__C3JQvlRdH1p7kRdolXEDy8oi = __fdIp10iC4pxOzAA4zSRbTWnm.y()
	a.__Yp_qPJiGc1SjsM8_KRc4rLwV = 1
	a.__ZCQBCv36ysTHU0iBaYX6GvwS = 16
	a.__TAmrKd8UPGcQuUSyqvAAVdWm = true
	a.__PIanP8EGD25AKu3PStByHFk6 = 10
	a.__P1rs6m_7HtwjQNs9Q4TnQzBo = 0
	a.state = __YCYnibBjVPRhMDf3YPwizbkN.State.__cqei2U9gqm0EDzpnZTAB5gor
	a.sub = 0
	a.pitch = 0
	a.__Grly1BvCsxoCuBf0E7OZOvtN = 0
	a.__LHXFh2KJbTtUtaDckBU0bXW0 = 0
	var __pA7TKQTm0DkzLSbz7RXQDYD_: int = __ZAk1me79cneckaMLlSAqwTMb.__Jy2hcMM9emCF3iBBkLMyeUr7("Aircraft", __icSfcMATuDqYMZJCt58uFd5c, 170)
	var __YBHxrNatvgfcJHpfI3G9RTGL: int = __ZAk1me79cneckaMLlSAqwTMb.__Jy2hcMM9emCF3iBBkLMyeUr7("Aircraft", __icSfcMATuDqYMZJCt58uFd5c, 154)
	if a.type == __YCYnibBjVPRhMDf3YPwizbkN.__HfDM_LLOojFsxcJHISElCfPi:
		__pA7TKQTm0DkzLSbz7RXQDYD_ = __pA7TKQTm0DkzLSbz7RXQDYD_ * 110 / 100
		__YBHxrNatvgfcJHpfI3G9RTGL = __YBHxrNatvgfcJHpfI3G9RTGL * 110 / 100
	var __LamaFaAQ75JrboARtD73riBM: int = __ZAk1me79cneckaMLlSAqwTMb.__Jy2hcMM9emCF3iBBkLMyeUr7("Aircraft", __icSfcMATuDqYMZJCt58uFd5c, 164)
	if a.type >= 1 and a.type <= 4:
		__YBHxrNatvgfcJHpfI3G9RTGL = (__YBHxrNatvgfcJHpfI3G9RTGL * (v + 100) / 100) & 65535
		__LamaFaAQ75JrboARtD73riBM = (__LamaFaAQ75JrboARtD73riBM * (v + 100) / 100) & 65535
		a.__Jm4tigCFJrJQiONUKEiO3ifi = v
	a.__405kukUhPFu5e4xu_Qs1ihtC = __YBHxrNatvgfcJHpfI3G9RTGL
	a.__MVPWKWAdbVfRM4oRuvTXhfBA = __LamaFaAQ75JrboARtD73riBM
	a.__HqMti1TAnrtmLUJSJQBYdY_P = __ZAk1me79cneckaMLlSAqwTMb.__Jy2hcMM9emCF3iBBkLMyeUr7("Aircraft", __icSfcMATuDqYMZJCt58uFd5c, 166)
	a.__F41ZT8z_0zKKqYDFwqS1WGTs = __ZAk1me79cneckaMLlSAqwTMb.__Jy2hcMM9emCF3iBBkLMyeUr7("Aircraft", __icSfcMATuDqYMZJCt58uFd5c, 168)
	a.__iWPWvu2E2PGZ_Ugxj5W2EIIM = a.__F41ZT8z_0zKKqYDFwqS1WGTs
	a.__6auOgykzrXOLund23PvUaifY = __ZAk1me79cneckaMLlSAqwTMb.__Jy2hcMM9emCF3iBBkLMyeUr7("Aircraft", __icSfcMATuDqYMZJCt58uFd5c, 172)
	a.__lp5nMIOUyaTDuOPtUm4IpHRu = __ZAk1me79cneckaMLlSAqwTMb.__Jy2hcMM9emCF3iBBkLMyeUr7("Aircraft", __icSfcMATuDqYMZJCt58uFd5c, 174)
	a.__X_Fl452m4tgbk58uIKgF1dCV = __ZAk1me79cneckaMLlSAqwTMb.__Jy2hcMM9emCF3iBBkLMyeUr7("Aircraft", __icSfcMATuDqYMZJCt58uFd5c, 176)
	a.value = __ZAk1me79cneckaMLlSAqwTMb.__pGLr1ud1V6XsMMJoSyeTRFjY("Aircraft", __icSfcMATuDqYMZJCt58uFd5c, 112)
	a.__FiUAjtJlUwX6oDIWxrerhOV4 = __ZAk1me79cneckaMLlSAqwTMb.__Jy2hcMM9emCF3iBBkLMyeUr7("Aircraft", __icSfcMATuDqYMZJCt58uFd5c, 158)
	a.__6ol9zXLNVbGS9s_iAdvMaxLC = 0
	a.__EHjU5UjAgmmddD5nyx49ar6j = (__pA7TKQTm0DkzLSbz7RXQDYD_ * 15) & 65535
	a.__vqYa6WuT8lqRfpObeEEtFMHG = (__fdIp10iC4pxOzAA4zSRbTWnm.__vqYa6WuT8lqRfpObeEEtFMHG() + 900) % 3600
	a.__wK6c6xRBxB0Lka8tqK6RrNfH = a.__EHjU5UjAgmmddD5nyx49ar6j
	a.__w87XrXWtBktdMVowYWiePwsm = a.__FiUAjtJlUwX6oDIWxrerhOV4
	a.__TlWqW0m63x0ks40OasJLgdcp = -1
	a.__H0IfsdkHBf2MPjU13h3e655G = false
	a.__hF5qCjy1NYsx4mlJR0VxACAc = -1
	a.__aBKovnuyCiI63tVuI2prB5MN = __YCYnibBjVPRhMDf3YPwizbkN.__XNP5UhOp48fF9keZolufRgEY
	a.__2cQt3I45k0XXwSr_0reYodT2 = __YCYnibBjVPRhMDf3YPwizbkN.__XNP5UhOp48fF9keZolufRgEY
	a.__JI4CwjmddmH55Lrana1jZuVZ = 0
	__2ZIL9u7_cM4KOmaAUAdneX5d.meti_apply_aircraft_boost(__fdIp10iC4pxOzAA4zSRbTWnm, a)
	return a
static func __0xzkFhYTZVOJgwELQBBwjBHu(__vQR3fqtDYfmr7cG4SS87tVNP: __aDswGCE4WWdmypkp3eC7rExn, a: __YCYnibBjVPRhMDf3YPwizbkN, __xP0zJwL9sO46TkfmuJFfPyyU: int) -> void :
	__4vkwFQCb1YIrsLiCaaP3aBi4(__vQR3fqtDYfmr7cG4SS87tVNP, a, 1)
	a.__F41ZT8z_0zKKqYDFwqS1WGTs = 0
	a.__jKXPrtchy4v7fjo9Z9kJG9SX = true
	a.sub = 0
	a.state = __YCYnibBjVPRhMDf3YPwizbkN.State.__eEvXiwf2UW57C8JVEuywqlUc
	a.__2cQt3I45k0XXwSr_0reYodT2 = 0
	if a.pitch >= 0:
		a.pitch = -150
	__vQR3fqtDYfmr7cG4SS87tVNP.__wIebi2RHJicnHeiUm6xYwBpd(__QzfA1_MgHwBGTTBizdgA8rkk.__FSW4WCXpupwYSF0KaHCFCNKb.__Z4zb38Z0p0n5agncEYj9TLFK, a, 0, __xP0zJwL9sO46TkfmuJFfPyyU)
	__caiJN7usYIEMNh51fTf1ETV8.__vxGmtOE9j_vSL7XL4CEHYqNe(__vQR3fqtDYfmr7cG4SS87tVNP, __xP0zJwL9sO46TkfmuJFfPyyU, a.__7OKcEzdMfOdabzyMipWdSzWD, a.id)
static func __ia_9EReh93gEhjQ5cfA7bGGr(a: __YCYnibBjVPRhMDf3YPwizbkN) -> void :
	if a.__aBKovnuyCiI63tVuI2prB5MN / 1000 > 50:
		a.pitch = a.pitch - 15 if a.pitch > -300 else -300
	elif a.pitch >= 0:
		a.pitch = 0
	else:
		a.pitch += 15
		if a.__aBKovnuyCiI63tVuI2prB5MN / 1000 <= 15:
			a.pitch = 0
const __t9NB2N0Ed8Fq8yjbUpdXL9N8: = 100
static func __v48U0So26gp9fuKCktN7vwEn(__sBWdiwqjOmR8WopqgXYkzcMs: __aDswGCE4WWdmypkp3eC7rExn, __xpI9DmU7dgtdFogLyeNKeWyR: __YdhZSn3k6BLtSITi5naOCb7n) -> void :
	var __BpJ623VmLPvHuBW1uKouewdu: int = __sBWdiwqjOmR8WopqgXYkzcMs.___qFCN2viGM2bPW1uGV9qys9h.__Jy2hcMM9emCF3iBBkLMyeUr7("Frame", __xpI9DmU7dgtdFogLyeNKeWyR.__WeB9Hi0OxaFBUuwm2WU2qKEH, 12) & 1023
	if __BpJ623VmLPvHuBW1uKouewdu == 0:
		return
	var ___EyIKjowxB2ghitEQYJBaxUj: int = __BpJ623VmLPvHuBW1uKouewdu / 40 + 1
	var __uvp9owRrDSZLjv40MqAFDtWu: int = __sBWdiwqjOmR8WopqgXYkzcMs.__VtC8pLMhL6BfWWcFD6bsOCll[__xpI9DmU7dgtdFogLyeNKeWyR.index]
	if __uvp9owRrDSZLjv40MqAFDtWu < 0 or __uvp9owRrDSZLjv40MqAFDtWu >= ___EyIKjowxB2ghitEQYJBaxUj:
		if __uvp9owRrDSZLjv40MqAFDtWu == ___EyIKjowxB2ghitEQYJBaxUj:
			__uvp9owRrDSZLjv40MqAFDtWu = - ___EyIKjowxB2ghitEQYJBaxUj
		__sBWdiwqjOmR8WopqgXYkzcMs.__VtC8pLMhL6BfWWcFD6bsOCll[__xpI9DmU7dgtdFogLyeNKeWyR.index] = __uvp9owRrDSZLjv40MqAFDtWu + 1
		return
	var r: int = __y2Z0bOYbBSy5wGDKN0sTGGkc[__xpI9DmU7dgtdFogLyeNKeWyR.__RZSGss6vMJxzvS6fmWkQMma8] if __xpI9DmU7dgtdFogLyeNKeWyR.__RZSGss6vMJxzvS6fmWkQMma8 < __y2Z0bOYbBSy5wGDKN0sTGGkc.size() else 620
	var __gphsLoZ1sivN9EMnSZZq5_mW: int = ___EyIKjowxB2ghitEQYJBaxUj
	for __m3zcVxN4fD0R0ifRkzR3Cgbw: __YdhZSn3k6BLtSITi5naOCb7n in __sBWdiwqjOmR8WopqgXYkzcMs.__LYNzM9N3A8Dmo_1zq54GljKm:
		if __m3zcVxN4fD0R0ifRkzR3Cgbw.__g7JC3EJmfsOWnIyqLGGB93eB == null or __m3zcVxN4fD0R0ifRkzR3Cgbw.__7OKcEzdMfOdabzyMipWdSzWD == __xpI9DmU7dgtdFogLyeNKeWyR.__7OKcEzdMfOdabzyMipWdSzWD:
			continue
		for __PU_ecpaZ8gkoZ4hfs7bgaCCV: Dictionary in __m3zcVxN4fD0R0ifRkzR3Cgbw.__g7JC3EJmfsOWnIyqLGGB93eB.__MMezevmh2WzjfDPiLXmgyJbQ:
			for a: __YCYnibBjVPRhMDf3YPwizbkN in (__PU_ecpaZ8gkoZ4hfs7bgaCCV["members"] as Array).duplicate():
				if not a.active or not a.__dRotcb2ldVZQLm2YDYWTTU9J or a.__jKXPrtchy4v7fjo9Z9kJG9SX:
					continue
				var __y94fkMTlVsyxiBWswJcu3KuB: int = (__xpI9DmU7dgtdFogLyeNKeWyR.y() - a.__KrKPdZs_d6uEOIuRq3UQy1fb()) * 200 / 100
				var __1ay6LskIEYe4IXjHdxTrY7xb: int = __xpI9DmU7dgtdFogLyeNKeWyR.x() - a.__EsOQaggwtLEnMAHn6g7H_r7O()
				if absi(__1ay6LskIEYe4IXjHdxTrY7xb) >= r or absi(__y94fkMTlVsyxiBWswJcu3KuB) >= r:
					continue
				var d: int = __Irz9hiGcyslSDsJT8BenfEt2.__f8g2PjfN7nwJbTHn9ePhmeZH(__dXppFYqETFUwGtUmhS9ups7R(__1ay6LskIEYe4IXjHdxTrY7xb * __1ay6LskIEYe4IXjHdxTrY7xb + __y94fkMTlVsyxiBWswJcu3KuB * __y94fkMTlVsyxiBWswJcu3KuB))
				var h: int = a.__aBKovnuyCiI63tVuI2prB5MN / 1000
				if not (d * d + h * h < r * r):
					continue
				var __BpJ1f8Zzaipc1IdP_pMTr_kb: int = __Irz9hiGcyslSDsJT8BenfEt2.__f8g2PjfN7nwJbTHn9ePhmeZH(9 * (d * d + 4 * h * h)) / 5
				var __YGeO0QtJdfpnztN3nZqdjlhJ: int = maxi(0, (r - __BpJ1f8Zzaipc1IdP_pMTr_kb) * 180 / r)
				var __yUr4GqiPtVKmOkvQNBNjAOC1: int = maxi(0, (350 - h) * 70 / 350 + 30)
				var __tWJwtKZvsyIw69sKTYhPXuf0: int = __YGeO0QtJdfpnztN3nZqdjlhJ * __yUr4GqiPtVKmOkvQNBNjAOC1 / 100
				var __ufR_4RMCay1BcaeNTDuVCFz6: int = __n2nqHf6Z4jNwkx3IA7Pe4Aon(__sBWdiwqjOmR8WopqgXYkzcMs, __sBWdiwqjOmR8WopqgXYkzcMs.__EaiCL_s7Is8n8XhLMgCmd8bh + __sBWdiwqjOmR8WopqgXYkzcMs.__t2UdGLb5AjoD9DJacXSIpDUA + a.__w4KgbGj0JQyP8PGvp68qYP1F) % 100
				if __tWJwtKZvsyIw69sKTYhPXuf0 > __ufR_4RMCay1BcaeNTDuVCFz6:
					__lp9a83prKhwZT3buHctAqfaG(__sBWdiwqjOmR8WopqgXYkzcMs, a, maxi(1, (__BpJ623VmLPvHuBW1uKouewdu / 3) * __tWJwtKZvsyIw69sKTYhPXuf0 / 100), __xpI9DmU7dgtdFogLyeNKeWyR.index)
				if __gphsLoZ1sivN9EMnSZZq5_mW == 0:
					__sBWdiwqjOmR8WopqgXYkzcMs.__VtC8pLMhL6BfWWcFD6bsOCll[__xpI9DmU7dgtdFogLyeNKeWyR.index] = __uvp9owRrDSZLjv40MqAFDtWu + 1
					return
				__gphsLoZ1sivN9EMnSZZq5_mW -= 1
				__sBWdiwqjOmR8WopqgXYkzcMs.__2nLQ763tFkgAwvH1QSmnnqh3(__QzfA1_MgHwBGTTBizdgA8rkk.__FSW4WCXpupwYSF0KaHCFCNKb.__yLeQXXHqUQDNCFn5DfoXXafu, __xpI9DmU7dgtdFogLyeNKeWyR.index, __xpI9DmU7dgtdFogLyeNKeWyR.x(), __xpI9DmU7dgtdFogLyeNKeWyR.y(), 0, 
					PackedInt32Array([a.__EsOQaggwtLEnMAHn6g7H_r7O(), a.__caDHon68LplNQ04cMl2MMJ71()]))
	__sBWdiwqjOmR8WopqgXYkzcMs.__VtC8pLMhL6BfWWcFD6bsOCll[__xpI9DmU7dgtdFogLyeNKeWyR.index] = __uvp9owRrDSZLjv40MqAFDtWu + 1
static func __cBlWh6sEMsRhPxWHZtRo3q8T() -> int:
	if __TXCdoY85HWzo9E7Qcf9l8raZ.__ztB2fBnXLqKMIQ0Nub8JQJwo.is_empty():
		return 0
	return __TXCdoY85HWzo9E7Qcf9l8raZ.__ztB2fBnXLqKMIQ0Nub8JQJwo[mini(__AQPrKNzFszo0KH8WZUn0RUl9, __ahUDxvJMdWXrjs0umGF19kh5) * 1000 / __ahUDxvJMdWXrjs0umGF19kh5] * __C35YbYHfttxTwUfuX7ZdwI3G / __TXCdoY85HWzo9E7Qcf9l8raZ.__ztB2fBnXLqKMIQ0Nub8JQJwo[999] + 1
static func __B6DoyQH00PkNqJSn1pOiTHd7(__fDDlF6WOE9JD86LS9cadeppc: int, __IzMaSOwSW1Vl1Y2mUPjIWHla: int) -> int:
	var flat: int = __fDDlF6WOE9JD86LS9cadeppc * 3600 + __IzMaSOwSW1Vl1Y2mUPjIWHla
	match flat / 3600 if flat >= 0 else -1:
		0:
			return __TXCdoY85HWzo9E7Qcf9l8raZ.__7laIgLr3i8VN0D_tZnYT3p0D[flat]
		1:
			return __TXCdoY85HWzo9E7Qcf9l8raZ.__9nHAKAsjPH38LR2tAezCTqd_[flat - 3600]
		2:
			return __TXCdoY85HWzo9E7Qcf9l8raZ.TAN[flat - 7200]
	return 0
static func __n2nqHf6Z4jNwkx3IA7Pe4Aon(__SdCZNcUgxD4A34fpNDr4j_6n: __aDswGCE4WWdmypkp3eC7rExn, __eH15X5_y0xth3nNB_hwDMlmf: int) -> int:
	return __SdCZNcUgxD4A34fpNDr4j_6n.__T3MhJL9nMTQaWMJrYSTIXXqi[(__eH15X5_y0xth3nNB_hwDMlmf & 4294967295) % __SdCZNcUgxD4A34fpNDr4j_6n.__T3MhJL9nMTQaWMJrYSTIXXqi.size()]
static func __HaVhLGB5f_1B_Ja6JYFTAty6(__jo_0o9yMyV_Ys3iVK_Big1u6: __aDswGCE4WWdmypkp3eC7rExn, a: __YCYnibBjVPRhMDf3YPwizbkN) -> int:
	var __TBoEofMp9GS_CAheM65A11xz: __YCYnibBjVPRhMDf3YPwizbkN = lock(__jo_0o9yMyV_Ys3iVK_Big1u6, a)
	var __tj5aLAFiRITLCQk9BCqaH_15: int = 65
	if a.type == __YCYnibBjVPRhMDf3YPwizbkN.__HfDM_LLOojFsxcJHISElCfPi:
		__YZg0i9AduOgyDQKnH5G2AtsB(a, __TBoEofMp9GS_CAheM65A11xz)
		__tj5aLAFiRITLCQk9BCqaH_15 = 70 if a.sub == 1 else 120
	if __TBoEofMp9GS_CAheM65A11xz == null:
		return __tj5aLAFiRITLCQk9BCqaH_15
	a.__3epXDNnmkHn9cpXlvNEl2W4g = __TBoEofMp9GS_CAheM65A11xz.__EsOQaggwtLEnMAHn6g7H_r7O()
	a.__C3JQvlRdH1p7kRdolXEDy8oi = __TBoEofMp9GS_CAheM65A11xz.__KrKPdZs_d6uEOIuRq3UQy1fb()
	var __3618CeHiHxnjTQl77X3cruH8: int = a.__EHjU5UjAgmmddD5nyx49ar6j
	if a.delta > 50:
		a.__wK6c6xRBxB0Lka8tqK6RrNfH = a.__wK6c6xRBxB0Lka8tqK6RrNfH * 8 / 10 if a.__wK6c6xRBxB0Lka8tqK6RrNfH > __3618CeHiHxnjTQl77X3cruH8 * 8 / 10 else __3618CeHiHxnjTQl77X3cruH8 * 8 / 10
	else:
		a.__wK6c6xRBxB0Lka8tqK6RrNfH = __3618CeHiHxnjTQl77X3cruH8 if a.__wK6c6xRBxB0Lka8tqK6RrNfH >= __3618CeHiHxnjTQl77X3cruH8 else a.__wK6c6xRBxB0Lka8tqK6RrNfH * 12 / 10
	if not (a.__zjyW8rAU_8pK0uXV_Zkdk_Kw < 80 or (a.delta >= 0 and a.delta < 50)):
		return __tj5aLAFiRITLCQk9BCqaH_15
	if a.__w87XrXWtBktdMVowYWiePwsm != 0:
		return __tj5aLAFiRITLCQk9BCqaH_15
	a.__ZCQBCv36ysTHU0iBaYX6GvwS -= 1
	a.__Dv2h8kHCCCo1xWufpe7wW0vt = 10
	var __ZJIqPuhOENFqzKvTMt2wNxIw: int = (a.__KrKPdZs_d6uEOIuRq3UQy1fb() - __TBoEofMp9GS_CAheM65A11xz.__KrKPdZs_d6uEOIuRq3UQy1fb()) * 200 / 100
	var __04EMniqsdT2X12GqbgLgBthU: int = a.__EsOQaggwtLEnMAHn6g7H_r7O() - __TBoEofMp9GS_CAheM65A11xz.__EsOQaggwtLEnMAHn6g7H_r7O()
	var __2atYqo6S3P4pfbC_ttq0QYtc: int = a.__aBKovnuyCiI63tVuI2prB5MN / 1000 - __TBoEofMp9GS_CAheM65A11xz.__aBKovnuyCiI63tVuI2prB5MN / 1000
	var __OHJyZ8sEjH77hPyonXn0u7eu: int = __Irz9hiGcyslSDsJT8BenfEt2.__f8g2PjfN7nwJbTHn9ePhmeZH(__dXppFYqETFUwGtUmhS9ups7R(__04EMniqsdT2X12GqbgLgBthU * __04EMniqsdT2X12GqbgLgBthU + __ZJIqPuhOENFqzKvTMt2wNxIw * __ZJIqPuhOENFqzKvTMt2wNxIw))
	var ___MjJOSik7wOyiIU72lvReWkj: int = __Irz9hiGcyslSDsJT8BenfEt2.__f8g2PjfN7nwJbTHn9ePhmeZH(__dXppFYqETFUwGtUmhS9ups7R(__OHJyZ8sEjH77hPyonXn0u7eu * __OHJyZ8sEjH77hPyonXn0u7eu + __2atYqo6S3P4pfbC_ttq0QYtc * __2atYqo6S3P4pfbC_ttq0QYtc))
	a.__w87XrXWtBktdMVowYWiePwsm = a.__FiUAjtJlUwX6oDIWxrerhOV4
	__jo_0o9yMyV_Ys3iVK_Big1u6.__wIebi2RHJicnHeiUm6xYwBpd(__QzfA1_MgHwBGTTBizdgA8rkk.__FSW4WCXpupwYSF0KaHCFCNKb.__OEs2rl5a4IVtprvMaboTyP0_, a, ___MjJOSik7wOyiIU72lvReWkj)
	if ___MjJOSik7wOyiIU72lvReWkj >= 100:
		return __tj5aLAFiRITLCQk9BCqaH_15
	if __TBoEofMp9GS_CAheM65A11xz.__jKXPrtchy4v7fjo9Z9kJG9SX:
		a.__H0IfsdkHBf2MPjU13h3e655G = false
		return __tj5aLAFiRITLCQk9BCqaH_15
	if __lp9a83prKhwZT3buHctAqfaG(__jo_0o9yMyV_Ys3iVK_Big1u6, __TBoEofMp9GS_CAheM65A11xz, a.__405kukUhPFu5e4xu_Qs1ihtC * (120 - ___MjJOSik7wOyiIU72lvReWkj) / 100, a.owner):
		a.__H0IfsdkHBf2MPjU13h3e655G = false
	return __tj5aLAFiRITLCQk9BCqaH_15
static func __uU1Ja3PG9KT7fTWexG_8vWbA(__1eooc18Nqp8onH41zLujWNB9: __aDswGCE4WWdmypkp3eC7rExn, __WHkc5aYH0yKY_pa9G6CL6Z8i: __YdhZSn3k6BLtSITi5naOCb7n, __UAjE40rShyqxzmY_8S6OdLYf: PackedByteArray) -> void :
	var w: __1q0DwOCFFBOQDiHI3310K_lq = __WHkc5aYH0yKY_pa9G6CL6Z8i.__g7JC3EJmfsOWnIyqLGGB93eB
	if w == null or __UAjE40rShyqxzmY_8S6OdLYf.size() < 3:
		return
	var __YCYl3NLYrb25nb2bXk_A9BO3: int = __UAjE40rShyqxzmY_8S6OdLYf[0] & 31
	var sub: int = __UAjE40rShyqxzmY_8S6OdLYf[0] >> 5
	var __ViNdAOqHCLHoP92mq57jzHPw: int = __UAjE40rShyqxzmY_8S6OdLYf[1]
	var __odSVvj9qGPiMVOck2MkF5vCG: int = __UAjE40rShyqxzmY_8S6OdLYf[2]
	var __av9Lbd2bCyLQDv3z96IAyED4: Dictionary = w.__h1TPJFPsc5Cmf4yb__CP1xgP(__YCYl3NLYrb25nb2bXk_A9BO3)
	if __av9Lbd2bCyLQDv3z96IAyED4.is_empty() or int(__av9Lbd2bCyLQDv3z96IAyED4["plane_row"]) < 0:
		return
	match sub:
		0:
			__lWuahpWVNpSTiO1pFrDGM69k(__1eooc18Nqp8onH41zLujWNB9, __WHkc5aYH0yKY_pa9G6CL6Z8i, w, __av9Lbd2bCyLQDv3z96IAyED4, __odSVvj9qGPiMVOck2MkF5vCG, __ViNdAOqHCLHoP92mq57jzHPw)
		1:
			for a: __YCYnibBjVPRhMDf3YPwizbkN in __0zsl5g6R5DTe4QpmbZ0utSui(w, __odSVvj9qGPiMVOck2MkF5vCG):
				if a.active:
					__CuIJeN7QnUx2qnczgpwyLaWy(__1eooc18Nqp8onH41zLujWNB9, a, __lAo0PsogaUvqHw4muTzPsHiR.__GRPnytew2Hz_p1DafRqWc4DS, PackedByteArray())
			for __H9YRfbFPh1l25uxef2iEW62R: int in __1q0DwOCFFBOQDiHI3310K_lq.__4RH5nYSLL1iROnlR683UMJ_c:
				if __H9YRfbFPh1l25uxef2iEW62R == __odSVvj9qGPiMVOck2MkF5vCG or (__ViNdAOqHCLHoP92mq57jzHPw & (1 << __H9YRfbFPh1l25uxef2iEW62R)) == 0:
					continue
				for a: __YCYnibBjVPRhMDf3YPwizbkN in __0zsl5g6R5DTe4QpmbZ0utSui(w, __H9YRfbFPh1l25uxef2iEW62R):
					if a.active:
						__CuIJeN7QnUx2qnczgpwyLaWy(__1eooc18Nqp8onH41zLujWNB9, a, __lAo0PsogaUvqHw4muTzPsHiR.__GRPnytew2Hz_p1DafRqWc4DS, PackedByteArray())
		2:
			for a: __YCYnibBjVPRhMDf3YPwizbkN in __0zsl5g6R5DTe4QpmbZ0utSui(w, __odSVvj9qGPiMVOck2MkF5vCG):
				if a.active:
					__CuIJeN7QnUx2qnczgpwyLaWy(__1eooc18Nqp8onH41zLujWNB9, a, __lAo0PsogaUvqHw4muTzPsHiR.__GRPnytew2Hz_p1DafRqWc4DS, PackedByteArray([97]))
static func update(__4PIcGgua230trhSnpDGz9X0z: __aDswGCE4WWdmypkp3eC7rExn, __1qGDPt0fDb0MDNWpqvOzs5Ml: __YCYnibBjVPRhMDf3YPwizbkN) -> void :
	if not __1qGDPt0fDb0MDNWpqvOzs5Ml.active:
		return
	var __Y0n48nkSHhDPGCh80fWj6our: __YdhZSn3k6BLtSITi5naOCb7n = __4PIcGgua230trhSnpDGz9X0z.__LYNzM9N3A8Dmo_1zq54GljKm[__1qGDPt0fDb0MDNWpqvOzs5Ml.owner]
	motion(__4PIcGgua230trhSnpDGz9X0z, __1qGDPt0fDb0MDNWpqvOzs5Ml)
	if not __1qGDPt0fDb0MDNWpqvOzs5Ml.__dRotcb2ldVZQLm2YDYWTTU9J:
		return
	__1qGDPt0fDb0MDNWpqvOzs5Ml.__Grly1BvCsxoCuBf0E7OZOvtN = __dXppFYqETFUwGtUmhS9ups7R(__1qGDPt0fDb0MDNWpqvOzs5Ml.__EHjU5UjAgmmddD5nyx49ar6j * __1qGDPt0fDb0MDNWpqvOzs5Ml.__Yp_qPJiGc1SjsM8_KRc4rLwV) / 1500
	if __1qGDPt0fDb0MDNWpqvOzs5Ml.__Dv2h8kHCCCo1xWufpe7wW0vt > 0:
		__1qGDPt0fDb0MDNWpqvOzs5Ml.__Dv2h8kHCCCo1xWufpe7wW0vt -= 1
	if __1qGDPt0fDb0MDNWpqvOzs5Ml.__vmBc6KJ66MRp7LRerMondIJN.size() != __M98e8yEUvS7d1fN7whAhFKnE * 2:
		__1qGDPt0fDb0MDNWpqvOzs5Ml.__vmBc6KJ66MRp7LRerMondIJN.resize(__M98e8yEUvS7d1fN7whAhFKnE * 2)
		for __42oLSdL7XmEoVUljR_982gYX: int in __M98e8yEUvS7d1fN7whAhFKnE:
			__1qGDPt0fDb0MDNWpqvOzs5Ml.__vmBc6KJ66MRp7LRerMondIJN[2 * __42oLSdL7XmEoVUljR_982gYX] = __1qGDPt0fDb0MDNWpqvOzs5Ml.__EsOQaggwtLEnMAHn6g7H_r7O()
			__1qGDPt0fDb0MDNWpqvOzs5Ml.__vmBc6KJ66MRp7LRerMondIJN[2 * __42oLSdL7XmEoVUljR_982gYX + 1] = __1qGDPt0fDb0MDNWpqvOzs5Ml.__caDHon68LplNQ04cMl2MMJ71()
	var __GaXOdKZ9QSadT9P0WUwTA63Q: int = __1qGDPt0fDb0MDNWpqvOzs5Ml.__Yp_qPJiGc1SjsM8_KRc4rLwV % __M98e8yEUvS7d1fN7whAhFKnE
	__1qGDPt0fDb0MDNWpqvOzs5Ml.__vmBc6KJ66MRp7LRerMondIJN[2 * __GaXOdKZ9QSadT9P0WUwTA63Q] = __1qGDPt0fDb0MDNWpqvOzs5Ml.__EsOQaggwtLEnMAHn6g7H_r7O()
	__1qGDPt0fDb0MDNWpqvOzs5Ml.__vmBc6KJ66MRp7LRerMondIJN[2 * __GaXOdKZ9QSadT9P0WUwTA63Q + 1] = __1qGDPt0fDb0MDNWpqvOzs5Ml.__caDHon68LplNQ04cMl2MMJ71()
	var __GSKhMRwwyHbspS_S_H7tYJeT: int = __1qGDPt0fDb0MDNWpqvOzs5Ml.state
	if not __1qGDPt0fDb0MDNWpqvOzs5Ml.__jKXPrtchy4v7fjo9Z9kJG9SX:
		if __1qGDPt0fDb0MDNWpqvOzs5Ml.__405kukUhPFu5e4xu_Qs1ihtC != 0:
			if __1qGDPt0fDb0MDNWpqvOzs5Ml.__ZCQBCv36ysTHU0iBaYX6GvwS > 0:
				if __1qGDPt0fDb0MDNWpqvOzs5Ml.__w87XrXWtBktdMVowYWiePwsm > 0:
					__1qGDPt0fDb0MDNWpqvOzs5Ml.__w87XrXWtBktdMVowYWiePwsm -= 1
				if __1qGDPt0fDb0MDNWpqvOzs5Ml.type == __YCYnibBjVPRhMDf3YPwizbkN.__HfDM_LLOojFsxcJHISElCfPi or __1qGDPt0fDb0MDNWpqvOzs5Ml.__sRdhcmPDkaBIPIzTf0y2eZwL:
					scan(__4PIcGgua230trhSnpDGz9X0z, __1qGDPt0fDb0MDNWpqvOzs5Ml)
			elif __1qGDPt0fDb0MDNWpqvOzs5Ml.__ZCQBCv36ysTHU0iBaYX6GvwS == 0:
				__1qGDPt0fDb0MDNWpqvOzs5Ml.__ZCQBCv36ysTHU0iBaYX6GvwS = -1
				__CuIJeN7QnUx2qnczgpwyLaWy(__4PIcGgua230trhSnpDGz9X0z, __1qGDPt0fDb0MDNWpqvOzs5Ml, __lAo0PsogaUvqHw4muTzPsHiR.__GRPnytew2Hz_p1DafRqWc4DS, PackedByteArray([97]))
				__4PIcGgua230trhSnpDGz9X0z.__wIebi2RHJicnHeiUm6xYwBpd(__QzfA1_MgHwBGTTBizdgA8rkk.__FSW4WCXpupwYSF0KaHCFCNKb.__yHmb2E8eufNCblP8NvDELVKl, __1qGDPt0fDb0MDNWpqvOzs5Ml, 1)
		__GSKhMRwwyHbspS_S_H7tYJeT = __1qGDPt0fDb0MDNWpqvOzs5Ml.state
		if __1qGDPt0fDb0MDNWpqvOzs5Ml.__sRdhcmPDkaBIPIzTf0y2eZwL:
			__KkOhDMfVDHjlZhgNLzvw2Sf0(__1qGDPt0fDb0MDNWpqvOzs5Ml)
		elif not __1qGDPt0fDb0MDNWpqvOzs5Ml.__2nVqHzJsE4wg_diKnctoD6kY and (__GSKhMRwwyHbspS_S_H7tYJeT == __YCYnibBjVPRhMDf3YPwizbkN.State.__9wEd2skDnIT9b_VOjrri893n or __GSKhMRwwyHbspS_S_H7tYJeT == __YCYnibBjVPRhMDf3YPwizbkN.State.__8wDuFUkodt91vpp0l6j8TDd6
				or __GSKhMRwwyHbspS_S_H7tYJeT == __YCYnibBjVPRhMDf3YPwizbkN.State.__SokrJF1aDQ6jidDRcP3EDMhC):
			__o186_ra3zNm3Ad8CIwfp_bYk(__4PIcGgua230trhSnpDGz9X0z, __1qGDPt0fDb0MDNWpqvOzs5Ml)
		if (__4PIcGgua230trhSnpDGz9X0z.__EaiCL_s7Is8n8XhLMgCmd8bh + __4PIcGgua230trhSnpDGz9X0z.__t2UdGLb5AjoD9DJacXSIpDUA) % __iXILOspsjYyClae5MSjyJvXl == 0:
			__eYhC5U8lAaD_KlZfHZwwziBx(__4PIcGgua230trhSnpDGz9X0z, __1qGDPt0fDb0MDNWpqvOzs5Ml, __Y0n48nkSHhDPGCh80fWj6our)
	if __1qGDPt0fDb0MDNWpqvOzs5Ml.__aBKovnuyCiI63tVuI2prB5MN > __YCYnibBjVPRhMDf3YPwizbkN.__2OJpMwzaDeyLf0HK2_6FqBy2:
		__1qGDPt0fDb0MDNWpqvOzs5Ml.__aBKovnuyCiI63tVuI2prB5MN = __YCYnibBjVPRhMDf3YPwizbkN.__2OJpMwzaDeyLf0HK2_6FqBy2
	__JHfBMoJnymDc9RLYmyT8NR73(__4PIcGgua230trhSnpDGz9X0z, __1qGDPt0fDb0MDNWpqvOzs5Ml, __Y0n48nkSHhDPGCh80fWj6our)
	__1qGDPt0fDb0MDNWpqvOzs5Ml.__Yp_qPJiGc1SjsM8_KRc4rLwV += 1
const __AQPrKNzFszo0KH8WZUn0RUl9: = 80
static func __qjgNztHVRNc_Pbnf4VqDosil(___ZEjKh69XOixoPDCVU1vKW9o: __aDswGCE4WWdmypkp3eC7rExn, a: __YCYnibBjVPRhMDf3YPwizbkN) -> void :
	if not a.__skELt8hzOP5jTm2IrBPiYtZM:
		return
	a.__6ol9zXLNVbGS9s_iAdvMaxLC -= 1
	a.__skELt8hzOP5jTm2IrBPiYtZM = false
	___ZEjKh69XOixoPDCVU1vKW9o.__QydBfC_Rl2VPiev0QJQPMkN2(a, 0, 0, -120, ___ZEjKh69XOixoPDCVU1vKW9o.__EaiCL_s7Is8n8XhLMgCmd8bh + ___ZEjKh69XOixoPDCVU1vKW9o.__t2UdGLb5AjoD9DJacXSIpDUA)
static func lock(__GIjwzhPcSRiaGqMCQl4HJUwJ: __aDswGCE4WWdmypkp3eC7rExn, a: __YCYnibBjVPRhMDf3YPwizbkN) -> __YCYnibBjVPRhMDf3YPwizbkN:
	if not a.__H0IfsdkHBf2MPjU13h3e655G or a.__TlWqW0m63x0ks40OasJLgdcp < 0 or a.__auam0OiXATfV0FV2pOZQsnnt < 0:
		return null
	var __Wlakh3Dzq8vJwVAJNDmNUZCV: __YdhZSn3k6BLtSITi5naOCb7n = __GIjwzhPcSRiaGqMCQl4HJUwJ.__LYNzM9N3A8Dmo_1zq54GljKm[a.__TlWqW0m63x0ks40OasJLgdcp]
	if __Wlakh3Dzq8vJwVAJNDmNUZCV.__g7JC3EJmfsOWnIyqLGGB93eB == null:
		return null
	var s: Dictionary = __Wlakh3Dzq8vJwVAJNDmNUZCV.__g7JC3EJmfsOWnIyqLGGB93eB.__knUj879QWUN8clA4_f5YGzfw((a.__auam0OiXATfV0FV2pOZQsnnt >> 16) & 15)
	if s.is_empty():
		return null
	var __OJuiiF_0wmHVnwEyvVMzdJN_: int = a.__auam0OiXATfV0FV2pOZQsnnt & 255
	var __YRrduLlD4peHvmpGZeA1DviJ: int = 100000000
	var __Hvp0D92pua_dGI_jFVbDL6nb: __YCYnibBjVPRhMDf3YPwizbkN = null
	for __jv8M_QIAq7WEBAJ4dU8KWoHl: __YCYnibBjVPRhMDf3YPwizbkN in s["members"]:
		if not __jv8M_QIAq7WEBAJ4dU8KWoHl.active or not __jv8M_QIAq7WEBAJ4dU8KWoHl.__dRotcb2ldVZQLm2YDYWTTU9J or __jv8M_QIAq7WEBAJ4dU8KWoHl.__jKXPrtchy4v7fjo9Z9kJG9SX or __jv8M_QIAq7WEBAJ4dU8KWoHl.__w4KgbGj0JQyP8PGvp68qYP1F != __OJuiiF_0wmHVnwEyvVMzdJN_:
			continue
		var __IBaztDuYYSBoN0H2FRKnbNfH: int = (a.__KrKPdZs_d6uEOIuRq3UQy1fb() - __jv8M_QIAq7WEBAJ4dU8KWoHl.__KrKPdZs_d6uEOIuRq3UQy1fb()) * 200 / 100
		var __f1i0BNR3eOzRIXf5E7SfObAI: int = a.__EsOQaggwtLEnMAHn6g7H_r7O() - __jv8M_QIAq7WEBAJ4dU8KWoHl.__EsOQaggwtLEnMAHn6g7H_r7O()
		var d: int = __Irz9hiGcyslSDsJT8BenfEt2.__f8g2PjfN7nwJbTHn9ePhmeZH(__dXppFYqETFUwGtUmhS9ups7R(__f1i0BNR3eOzRIXf5E7SfObAI * __f1i0BNR3eOzRIXf5E7SfObAI + __IBaztDuYYSBoN0H2FRKnbNfH * __IBaztDuYYSBoN0H2FRKnbNfH))
		if d < __YRrduLlD4peHvmpGZeA1DviJ:
			__YRrduLlD4peHvmpGZeA1DviJ = d
			__Hvp0D92pua_dGI_jFVbDL6nb = __jv8M_QIAq7WEBAJ4dU8KWoHl
	return __Hvp0D92pua_dGI_jFVbDL6nb
static func __lWuahpWVNpSTiO1pFrDGM69k(__KGHMlZbHHvHCaMjlBufjciDk: __aDswGCE4WWdmypkp3eC7rExn, __YETMnirS4XtWieU5kwvD6dhI: __YdhZSn3k6BLtSITi5naOCb7n, w: __1q0DwOCFFBOQDiHI3310K_lq, __tZOx1TVxzOFvzo0arBE253mc: Dictionary, __9IScXMWH9Epd9Z9V4ehavO3_: int, __XUeolac4HURXfl2JxFQJZBkv: int) -> void :
	var s: Dictionary = w.__knUj879QWUN8clA4_f5YGzfw(__9IScXMWH9Epd9Z9V4ehavO3_)
	if s.is_empty() or __XUeolac4HURXfl2JxFQJZBkv <= 0 or int(s["slot"]) != int(__tZOx1TVxzOFvzo0arBE253mc["slot"]):
		return
	var type: int = int(__tZOx1TVxzOFvzo0arBE253mc["type"])
	if __XUeolac4HURXfl2JxFQJZBkv > w.__fCoTKIcCDY8Ah5gNVkV9hfeL or __XUeolac4HURXfl2JxFQJZBkv > int(s["size"]) or __XUeolac4HURXfl2JxFQJZBkv > int(__tZOx1TVxzOFvzo0arBE253mc["hangar"]):
		return
	if not (s["members"] as Array).is_empty():
		return
	if w.__4pxUHeRLXEE4d8uLkxhTWd3E(type) >= w.__GmLgHYimns7eaIzmMroXnOqG[type]:
		return
	var __6YztseGaCbrfg9KC460YbmB8: Array = s["members"]
	for __YDyQpbKg9WBbhhpAsxgeb6rE: int in __XUeolac4HURXfl2JxFQJZBkv:
		var a: __YCYnibBjVPRhMDf3YPwizbkN = __ahUHZ6OQiJ8y86PS5PExnHiy(__KGHMlZbHHvHCaMjlBufjciDk, __YETMnirS4XtWieU5kwvD6dhI, int(__tZOx1TVxzOFvzo0arBE253mc["plane_row"]), __9IScXMWH9Epd9Z9V4ehavO3_, __YDyQpbKg9WBbhhpAsxgeb6rE, int(s["pilot_v"]))
		if int(__tZOx1TVxzOFvzo0arBE253mc["stock"]) > 0 and int(__tZOx1TVxzOFvzo0arBE253mc["ammo_row"]) >= 0:
			__ofWwEdxvI8i8VBIEnSlEVSjl(__KGHMlZbHHvHCaMjlBufjciDk, a, int(__tZOx1TVxzOFvzo0arBE253mc["slot"]), int(__tZOx1TVxzOFvzo0arBE253mc["ammo_row"]))
			if a.__6ol9zXLNVbGS9s_iAdvMaxLC > 0:
				__tZOx1TVxzOFvzo0arBE253mc["stock"] = int(__tZOx1TVxzOFvzo0arBE253mc["stock"]) - 1
		if __YDyQpbKg9WBbhhpAsxgeb6rE == 0:
			w.__ExRc2vcAyRkISXqe5ZZghf9A.append(a)
		__6YztseGaCbrfg9KC460YbmB8.append(a)
		w.queue.append(a)
		__KGHMlZbHHvHCaMjlBufjciDk.__gobxGwIVlftvCfJ1fsNzSlj7.append(a)
	__tZOx1TVxzOFvzo0arBE253mc["hangar"] = int(__tZOx1TVxzOFvzo0arBE253mc["hangar"]) - __XUeolac4HURXfl2JxFQJZBkv
	s["aloft"] = int(s["aloft"]) + __XUeolac4HURXfl2JxFQJZBkv
	w.__4xREaDvbh74nCbB3paXnMRd1 = 0
	__KGHMlZbHHvHCaMjlBufjciDk.__wIebi2RHJicnHeiUm6xYwBpd(__QzfA1_MgHwBGTTBizdgA8rkk.__FSW4WCXpupwYSF0KaHCFCNKb.__P9cFBk_3FslN6JJuhJMb1tym, __6YztseGaCbrfg9KC460YbmB8[0], __XUeolac4HURXfl2JxFQJZBkv)
static func __pMiCouh0jcltI1aLSxpyjfv7(__zuc35Cz27UHPSTULmow03D_L: int) -> PackedByteArray:
	var d: = PackedByteArray()
	d.resize(2)
	d.encode_u16(0, __zuc35Cz27UHPSTULmow03D_L)
	return d
static func crash(__sBWdiwqjOmR8WopqgXYkzcMs: __aDswGCE4WWdmypkp3eC7rExn, a: __YCYnibBjVPRhMDf3YPwizbkN, __hUQRMxWmaOQFkYMpugXJyfYs: __YdhZSn3k6BLtSITi5naOCb7n) -> void :
	if a.pitch >= -900:
		a.pitch -= 10
	else:
		a.pitch = -900
	if a.__aBKovnuyCiI63tVuI2prB5MN > 0:
		return
	a.active = false
	a.sub = 3
	a.state = __YCYnibBjVPRhMDf3YPwizbkN.State.__a6v6b1ezzKda4xyS4CpY5J5O
	a.__dRotcb2ldVZQLm2YDYWTTU9J = false
	var __WnU4ok5AY4mHYkx0bs2hAyOs: __YdhZSn3k6BLtSITi5naOCb7n = null
	for s: __YdhZSn3k6BLtSITi5naOCb7n in __sBWdiwqjOmR8WopqgXYkzcMs.__LYNzM9N3A8Dmo_1zq54GljKm:
		if s.state == 0:
			continue
		if __a3Qlrip4DI7L5IkLGkgxE5xK.hit_test(s.__xp5_QDRUZ8Q1w94JJafc_35N, s.x(), s.y(), s.__Bbtqn2iLah0_TnXXrRodcN9S(), a.__EsOQaggwtLEnMAHn6g7H_r7O(), a.__caDHon68LplNQ04cMl2MMJ71()) != 0:
			__WnU4ok5AY4mHYkx0bs2hAyOs = s
			break
	if __WnU4ok5AY4mHYkx0bs2hAyOs != null:
		var __0PZs_b7gg2pivjGi7gTbudrE: int = __sBWdiwqjOmR8WopqgXYkzcMs.__EaiCL_s7Is8n8XhLMgCmd8bh + __sBWdiwqjOmR8WopqgXYkzcMs.__t2UdGLb5AjoD9DJacXSIpDUA
		var __NbBki2dmwjqsT3QzAxEC3nuh: int = __n2nqHf6Z4jNwkx3IA7Pe4Aon(__sBWdiwqjOmR8WopqgXYkzcMs, __0PZs_b7gg2pivjGi7gTbudrE) % 200 + 100
		var __GFFORq0AVV1aJP0RNq8q8kyl: Array[int] = __nZxK7u5JB3kHTF7XC5Hr9MHe.__iLUTtdlJz90LVGliQf9aQ68R(__WnU4ok5AY4mHYkx0bs2hAyOs.target, __sBWdiwqjOmR8WopqgXYkzcMs.__T3MhJL9nMTQaWMJrYSTIXXqi, __0PZs_b7gg2pivjGi7gTbudrE, __nZxK7u5JB3kHTF7XC5Hr9MHe.__QwgmygJgLOwF0NNH73DbKFn4, 0, __NbBki2dmwjqsT3QzAxEC3nuh, 1, -1, 0)
		var __qEuNYFob9YLaRbsOXSaqYAxn: Array[int] = __sBWdiwqjOmR8WopqgXYkzcMs.__TyBlH2mrRyRh1_U5lXYpPSlQ(__WnU4ok5AY4mHYkx0bs2hAyOs, __GFFORq0AVV1aJP0RNq8q8kyl, __nZxK7u5JB3kHTF7XC5Hr9MHe.__QwgmygJgLOwF0NNH73DbKFn4, 1, -1, 0, a.owner)
		__sBWdiwqjOmR8WopqgXYkzcMs.__5qXTJOmsZn24MQnA1EmYdcbg(a, __WnU4ok5AY4mHYkx0bs2hAyOs, __NbBki2dmwjqsT3QzAxEC3nuh, __GFFORq0AVV1aJP0RNq8q8kyl, __qEuNYFob9YLaRbsOXSaqYAxn[0])
	else:
		__sBWdiwqjOmR8WopqgXYkzcMs.__wIebi2RHJicnHeiUm6xYwBpd(__QzfA1_MgHwBGTTBizdgA8rkk.__FSW4WCXpupwYSF0KaHCFCNKb.__wBFzqH0oguKloVIpkgTloaEN, a, 0)
	if not a.__jKXPrtchy4v7fjo9Z9kJG9SX and a.__Q4PVEYDqIobYx26SsJ1Qdl3_:
		a.__Q4PVEYDqIobYx26SsJ1Qdl3_ = false
		__4vkwFQCb1YIrsLiCaaP3aBi4(__sBWdiwqjOmR8WopqgXYkzcMs, a, 1)
const __y2Z0bOYbBSy5wGDKN0sTGGkc: Array[int] = [0, 670, 670, 700, 700, 620, 620, 620, 620, 620]
static func __KkOhDMfVDHjlZhgNLzvw2Sf0(__KXkgUSfJ7eB6GNx_i031E5WK: __YCYnibBjVPRhMDf3YPwizbkN) -> void :
	var __sX_5LWDCfx8IqNEv7nDTPjpS: int = __KXkgUSfJ7eB6GNx_i031E5WK.__EHjU5UjAgmmddD5nyx49ar6j
	var s: int = __KXkgUSfJ7eB6GNx_i031E5WK.__wK6c6xRBxB0Lka8tqK6RrNfH
	s = s * 99 / 100 if s > __sX_5LWDCfx8IqNEv7nDTPjpS else __sX_5LWDCfx8IqNEv7nDTPjpS
	s = s * 101 / 100 if s < __sX_5LWDCfx8IqNEv7nDTPjpS else __sX_5LWDCfx8IqNEv7nDTPjpS
	__KXkgUSfJ7eB6GNx_i031E5WK.__wK6c6xRBxB0Lka8tqK6RrNfH = s
static func __0zsl5g6R5DTe4QpmbZ0utSui(w: __1q0DwOCFFBOQDiHI3310K_lq, __t4woutfGf7qN2M71gNriYkQe: int) -> Array:
	var s: Dictionary = w.__knUj879QWUN8clA4_f5YGzfw(__t4woutfGf7qN2M71gNriYkQe)
	return (s["members"] as Array).duplicate() if not s.is_empty() else []
static func __7J3MBVv8_3OV5JFiEQbECIkJ(__qCtsYJK_Y9K7tHvOUm7IAdho: int, sub: int, __L0lciwcJK0RtDYdrjGqW6H_3: int, __IjCsSs9cS4p1yTfO7wnJxgvG: int) -> PackedByteArray:
	return PackedByteArray([(__qCtsYJK_Y9K7tHvOUm7IAdho & 31) | (sub << 5), __L0lciwcJK0RtDYdrjGqW6H_3 & 255, __IjCsSs9cS4p1yTfO7wnJxgvG & 255, 0])
static func motion(__AIioFBfHteuA0lZbabUlTa_A: __aDswGCE4WWdmypkp3eC7rExn, __sXn8lLtuWaHSYwOq5Nwnpq_a: __YCYnibBjVPRhMDf3YPwizbkN) -> void :
	__sXn8lLtuWaHSYwOq5Nwnpq_a.delta = __HiW9bSV2jhRblIaGALPU__g9(__sXn8lLtuWaHSYwOq5Nwnpq_a)
	var __rWFExLztUShO9tc3YdQM78Gd: int = __sXn8lLtuWaHSYwOq5Nwnpq_a.pitch
	__sXn8lLtuWaHSYwOq5Nwnpq_a.__xYfnrbyY0rOYQimdsPnBBdEG = __TXCdoY85HWzo9E7Qcf9l8raZ.__9nHAKAsjPH38LR2tAezCTqd_[absi(__rWFExLztUShO9tc3YdQM78Gd)] * __sXn8lLtuWaHSYwOq5Nwnpq_a.__wK6c6xRBxB0Lka8tqK6RrNfH / 1000
	var __LpkKCGeFbcE5E0p89o_NkDgO: int = __sXn8lLtuWaHSYwOq5Nwnpq_a.state
	var __exBJTTqhhm4tRhABfWG1oD6H: int = __t9NB2N0Ed8Fq8yjbUpdXL9N8
	if not (__LpkKCGeFbcE5E0p89o_NkDgO == __YCYnibBjVPRhMDf3YPwizbkN.State.__hak6wyuJcTfEInMyuQsTMwiM and __sXn8lLtuWaHSYwOq5Nwnpq_a.type == __YCYnibBjVPRhMDf3YPwizbkN.__HfDM_LLOojFsxcJHISElCfPi)\
	and __LpkKCGeFbcE5E0p89o_NkDgO != __YCYnibBjVPRhMDf3YPwizbkN.State.__8wDuFUkodt91vpp0l6j8TDd6 and __LpkKCGeFbcE5E0p89o_NkDgO != __YCYnibBjVPRhMDf3YPwizbkN.State.__cqei2U9gqm0EDzpnZTAB5gor:
		if __rWFExLztUShO9tc3YdQM78Gd > 0:
			if __sXn8lLtuWaHSYwOq5Nwnpq_a.__aBKovnuyCiI63tVuI2prB5MN > __sXn8lLtuWaHSYwOq5Nwnpq_a.__2cQt3I45k0XXwSr_0reYodT2:
				__sXn8lLtuWaHSYwOq5Nwnpq_a.pitch = 0
		elif __rWFExLztUShO9tc3YdQM78Gd < 0:
			if __sXn8lLtuWaHSYwOq5Nwnpq_a.__aBKovnuyCiI63tVuI2prB5MN < __sXn8lLtuWaHSYwOq5Nwnpq_a.__2cQt3I45k0XXwSr_0reYodT2:
				__sXn8lLtuWaHSYwOq5Nwnpq_a.pitch = 0
	var __zPXDRrrV8S52WTdn9ULGrU8j: __YdhZSn3k6BLtSITi5naOCb7n = __AIioFBfHteuA0lZbabUlTa_A.__LYNzM9N3A8Dmo_1zq54GljKm[__sXn8lLtuWaHSYwOq5Nwnpq_a.owner]
	match __LpkKCGeFbcE5E0p89o_NkDgO:
		__YCYnibBjVPRhMDf3YPwizbkN.State.__cqei2U9gqm0EDzpnZTAB5gor:
			__exBJTTqhhm4tRhABfWG1oD6H = 0
			__68OzxQ805gxG9kwMAiombZFK(__AIioFBfHteuA0lZbabUlTa_A, __sXn8lLtuWaHSYwOq5Nwnpq_a, __zPXDRrrV8S52WTdn9ULGrU8j)
		__YCYnibBjVPRhMDf3YPwizbkN.State.__9wEd2skDnIT9b_VOjrri893n:
			__exBJTTqhhm4tRhABfWG1oD6H = 50
			__KkOhDMfVDHjlZhgNLzvw2Sf0(__sXn8lLtuWaHSYwOq5Nwnpq_a)
			if __sXn8lLtuWaHSYwOq5Nwnpq_a.__zjyW8rAU_8pK0uXV_Zkdk_Kw < 100:
				__sXn8lLtuWaHSYwOq5Nwnpq_a.__sRdhcmPDkaBIPIzTf0y2eZwL = true
		__YCYnibBjVPRhMDf3YPwizbkN.State.__DdjO7licqxMK90434TaAU1qH:
			__exBJTTqhhm4tRhABfWG1oD6H = 30
			__sXn8lLtuWaHSYwOq5Nwnpq_a.__3epXDNnmkHn9cpXlvNEl2W4g = __zPXDRrrV8S52WTdn9ULGrU8j.x()
			__sXn8lLtuWaHSYwOq5Nwnpq_a.__C3JQvlRdH1p7kRdolXEDy8oi = __zPXDRrrV8S52WTdn9ULGrU8j.y()
			if __sXn8lLtuWaHSYwOq5Nwnpq_a.__zjyW8rAU_8pK0uXV_Zkdk_Kw < 100:
				__sXn8lLtuWaHSYwOq5Nwnpq_a.__sRdhcmPDkaBIPIzTf0y2eZwL = true
		__YCYnibBjVPRhMDf3YPwizbkN.State.__SokrJF1aDQ6jidDRcP3EDMhC:
			__exBJTTqhhm4tRhABfWG1oD6H = 30
			if __sXn8lLtuWaHSYwOq5Nwnpq_a.__TlWqW0m63x0ks40OasJLgdcp >= 0:
				var __DSEn8e_kD_HqAdv8TQKgueIU: __YdhZSn3k6BLtSITi5naOCb7n = __AIioFBfHteuA0lZbabUlTa_A.__LYNzM9N3A8Dmo_1zq54GljKm[__sXn8lLtuWaHSYwOq5Nwnpq_a.__TlWqW0m63x0ks40OasJLgdcp]
				__sXn8lLtuWaHSYwOq5Nwnpq_a.__3epXDNnmkHn9cpXlvNEl2W4g = __DSEn8e_kD_HqAdv8TQKgueIU.x()
				__sXn8lLtuWaHSYwOq5Nwnpq_a.__C3JQvlRdH1p7kRdolXEDy8oi = __DSEn8e_kD_HqAdv8TQKgueIU.y()
			else:
				__sXn8lLtuWaHSYwOq5Nwnpq_a.state = __YCYnibBjVPRhMDf3YPwizbkN.State.__9wEd2skDnIT9b_VOjrri893n
				__sXn8lLtuWaHSYwOq5Nwnpq_a.__auam0OiXATfV0FV2pOZQsnnt = -1
			if __sXn8lLtuWaHSYwOq5Nwnpq_a.__zjyW8rAU_8pK0uXV_Zkdk_Kw < 100:
				__sXn8lLtuWaHSYwOq5Nwnpq_a.__sRdhcmPDkaBIPIzTf0y2eZwL = true
		__YCYnibBjVPRhMDf3YPwizbkN.State.__hak6wyuJcTfEInMyuQsTMwiM:
			__exBJTTqhhm4tRhABfWG1oD6H = __HaVhLGB5f_1B_Ja6JYFTAty6(__AIioFBfHteuA0lZbabUlTa_A, __sXn8lLtuWaHSYwOq5Nwnpq_a)
		__YCYnibBjVPRhMDf3YPwizbkN.State.__8wDuFUkodt91vpp0l6j8TDd6:
			__exBJTTqhhm4tRhABfWG1oD6H = 120
			if __sXn8lLtuWaHSYwOq5Nwnpq_a.type == __YCYnibBjVPRhMDf3YPwizbkN.__c6EMu0BarWqKqIAZLnyXweGZ:
				__IN3hMRUqpUedXcAGl8i14Nzg(__AIioFBfHteuA0lZbabUlTa_A, __sXn8lLtuWaHSYwOq5Nwnpq_a)
			elif __sXn8lLtuWaHSYwOq5Nwnpq_a.type == __YCYnibBjVPRhMDf3YPwizbkN.__cqsRgbmsPf4IeAEKyNRkn9rz:
				__CEvwo6Lc7rZnRVhGhxTvRjUf(__AIioFBfHteuA0lZbabUlTa_A, __sXn8lLtuWaHSYwOq5Nwnpq_a)
				if __sXn8lLtuWaHSYwOq5Nwnpq_a.sub == 1:
					__exBJTTqhhm4tRhABfWG1oD6H = 20
		__YCYnibBjVPRhMDf3YPwizbkN.State.__a6v6b1ezzKda4xyS4CpY5J5O:
			__exBJTTqhhm4tRhABfWG1oD6H = __KQ5P1mcH6yImypWFX7wGlM9T(__AIioFBfHteuA0lZbabUlTa_A, __sXn8lLtuWaHSYwOq5Nwnpq_a, __zPXDRrrV8S52WTdn9ULGrU8j)
		__YCYnibBjVPRhMDf3YPwizbkN.State.__eEvXiwf2UW57C8JVEuywqlUc:
			__exBJTTqhhm4tRhABfWG1oD6H = 0
			crash(__AIioFBfHteuA0lZbabUlTa_A, __sXn8lLtuWaHSYwOq5Nwnpq_a, __zPXDRrrV8S52WTdn9ULGrU8j)
	if absi(__sXn8lLtuWaHSYwOq5Nwnpq_a.pitch) >= 3600:
		__sXn8lLtuWaHSYwOq5Nwnpq_a.pitch = 0
	var h: int = __sXn8lLtuWaHSYwOq5Nwnpq_a.__vqYa6WuT8lqRfpObeEEtFMHG + __sXn8lLtuWaHSYwOq5Nwnpq_a.delta * __exBJTTqhhm4tRhABfWG1oD6H / 1800
	h = h + 3600 if h < 0 else h % 3600
	__sXn8lLtuWaHSYwOq5Nwnpq_a.__vqYa6WuT8lqRfpObeEEtFMHG = h
	var __GaWRelKMC2MSwoLPGYCFcTTo: int = __sXn8lLtuWaHSYwOq5Nwnpq_a.__xYfnrbyY0rOYQimdsPnBBdEG
	__sXn8lLtuWaHSYwOq5Nwnpq_a.__A5_5AardkQ9zpEEJuxY4GJPD = __TXCdoY85HWzo9E7Qcf9l8raZ.__9nHAKAsjPH38LR2tAezCTqd_[h] * __GaWRelKMC2MSwoLPGYCFcTTo / 1000
	__sXn8lLtuWaHSYwOq5Nwnpq_a.__jU9wrtQkEXyjLR8w6MfC7UNB = __TXCdoY85HWzo9E7Qcf9l8raZ.__7laIgLr3i8VN0D_tZnYT3p0D[h] * __GaWRelKMC2MSwoLPGYCFcTTo / 1000
	var __wCiyFSePHCKXSbSHgwdpETBQ: int = __sXn8lLtuWaHSYwOq5Nwnpq_a.pitch
	var __4uHnymkqMUZNMiF4R2FieYwR: int = __TXCdoY85HWzo9E7Qcf9l8raZ.__7laIgLr3i8VN0D_tZnYT3p0D[absi(__wCiyFSePHCKXSbSHgwdpETBQ)] * __sXn8lLtuWaHSYwOq5Nwnpq_a.__wK6c6xRBxB0Lka8tqK6RrNfH / 1000
	if __sXn8lLtuWaHSYwOq5Nwnpq_a.state == __YCYnibBjVPRhMDf3YPwizbkN.State.__8wDuFUkodt91vpp0l6j8TDd6 and __sXn8lLtuWaHSYwOq5Nwnpq_a.type == __YCYnibBjVPRhMDf3YPwizbkN.__cqsRgbmsPf4IeAEKyNRkn9rz and __sXn8lLtuWaHSYwOq5Nwnpq_a.sub == 1:
		__4uHnymkqMUZNMiF4R2FieYwR = __TXCdoY85HWzo9E7Qcf9l8raZ.__7laIgLr3i8VN0D_tZnYT3p0D[absi(__wCiyFSePHCKXSbSHgwdpETBQ)] * __sXn8lLtuWaHSYwOq5Nwnpq_a.__wK6c6xRBxB0Lka8tqK6RrNfH / 1400
	if __wCiyFSePHCKXSbSHgwdpETBQ < 0:
		__4uHnymkqMUZNMiF4R2FieYwR = - __4uHnymkqMUZNMiF4R2FieYwR
	__sXn8lLtuWaHSYwOq5Nwnpq_a.__zcQSNSE8gcZixJwEAvw9gtcc -= __sXn8lLtuWaHSYwOq5Nwnpq_a.__jU9wrtQkEXyjLR8w6MfC7UNB
	__sXn8lLtuWaHSYwOq5Nwnpq_a.__CYx_P43ujHK1YF5Dtz9hb_PN += __sXn8lLtuWaHSYwOq5Nwnpq_a.__A5_5AardkQ9zpEEJuxY4GJPD
	__sXn8lLtuWaHSYwOq5Nwnpq_a.__aBKovnuyCiI63tVuI2prB5MN += __4uHnymkqMUZNMiF4R2FieYwR
	__sXn8lLtuWaHSYwOq5Nwnpq_a.__j77VIRoHY1FrfLlG18J11iYo = __4uHnymkqMUZNMiF4R2FieYwR
static func __tUnSLy1bkvGyKKeIrEiqbbcp(__YdVmubkDOZJoOFM_nUrRg8RX: __YCYnibBjVPRhMDf3YPwizbkN) -> int:
	return __dXppFYqETFUwGtUmhS9ups7R(__YdVmubkDOZJoOFM_nUrRg8RX.__EHjU5UjAgmmddD5nyx49ar6j * __YdVmubkDOZJoOFM_nUrRg8RX.__6auOgykzrXOLund23PvUaifY * 25) / 1500
static func __lp9a83prKhwZT3buHctAqfaG(__uobVMnqsrNSslJT5vAMHQepg: __aDswGCE4WWdmypkp3eC7rExn, a: __YCYnibBjVPRhMDf3YPwizbkN, __dvV8zME2hbsrOlXfrmQwK2N9: int, __bL8Od9qcNrEq1wFy_BHg4k1S: int) -> bool:
	if a.__jKXPrtchy4v7fjo9Z9kJG9SX:
		return false
	var __jOBJjPvlygeX7Y_n5FdhCRIU: int = maxi(2, __dvV8zME2hbsrOlXfrmQwK2N9 - a.__MVPWKWAdbVfRM4oRuvTXhfBA)
	var __A8zISOOeko88vD9UEqSRlxXd: int = __n2nqHf6Z4jNwkx3IA7Pe4Aon(__uobVMnqsrNSslJT5vAMHQepg, __uobVMnqsrNSslJT5vAMHQepg.__EaiCL_s7Is8n8XhLMgCmd8bh + __uobVMnqsrNSslJT5vAMHQepg.__t2UdGLb5AjoD9DJacXSIpDUA) % __jOBJjPvlygeX7Y_n5FdhCRIU
	if __A8zISOOeko88vD9UEqSRlxXd >= a.__F41ZT8z_0zKKqYDFwqS1WGTs:
		__0xzkFhYTZVOJgwELQBBwjBHu(__uobVMnqsrNSslJT5vAMHQepg, a, __bL8Od9qcNrEq1wFy_BHg4k1S)
	else:
		a.__F41ZT8z_0zKKqYDFwqS1WGTs -= __A8zISOOeko88vD9UEqSRlxXd
		__uobVMnqsrNSslJT5vAMHQepg.__wIebi2RHJicnHeiUm6xYwBpd(__QzfA1_MgHwBGTTBizdgA8rkk.__FSW4WCXpupwYSF0KaHCFCNKb.__tzxGAM8EoLr0AZV_0nEXQdWc, a, __A8zISOOeko88vD9UEqSRlxXd)
	return a.__jKXPrtchy4v7fjo9Z9kJG9SX
static func __0f1r8SiQLI3ebWYtL1J1yrAk(__FWR664ZvtBdHLzBk7pIyl3ti: int, __CbVvxWYDDO6Ix815mcm13neH: int, r: int) -> int:
	var __RmJ2QncaGntHnVv3U5DAqRA_: int = 0
	var __iVnwc0RdG349fqcejpA6SKww: int = 100000000
	for __8PqFvabdFiMQ5Efu6BvN09GX: int in 360:
		var __lv4W1__WfbhFhk9zZGVmg3uX: int
		var __F8Lr5uWrlMpFxQ2NGM_c4qjq: int
		if __8PqFvabdFiMQ5Efu6BvN09GX == 0:
			__lv4W1__WfbhFhk9zZGVmg3uX = r
			__F8Lr5uWrlMpFxQ2NGM_c4qjq = 0
		else:
			__lv4W1__WfbhFhk9zZGVmg3uX = __TXCdoY85HWzo9E7Qcf9l8raZ.__9nHAKAsjPH38LR2tAezCTqd_[(__8PqFvabdFiMQ5Efu6BvN09GX - 1) * 10] * r / 1000
			__F8Lr5uWrlMpFxQ2NGM_c4qjq = __TXCdoY85HWzo9E7Qcf9l8raZ.__7laIgLr3i8VN0D_tZnYT3p0D[(__8PqFvabdFiMQ5Efu6BvN09GX - 1) * 10] * r / 1000
		var d: int = __dXppFYqETFUwGtUmhS9ups7R((__FWR664ZvtBdHLzBk7pIyl3ti - __lv4W1__WfbhFhk9zZGVmg3uX) * (__FWR664ZvtBdHLzBk7pIyl3ti - __lv4W1__WfbhFhk9zZGVmg3uX) + (__CbVvxWYDDO6Ix815mcm13neH - __F8Lr5uWrlMpFxQ2NGM_c4qjq) * (__CbVvxWYDDO6Ix815mcm13neH - __F8Lr5uWrlMpFxQ2NGM_c4qjq))
		if d < __iVnwc0RdG349fqcejpA6SKww:
			__iVnwc0RdG349fqcejpA6SKww = d
			__RmJ2QncaGntHnVv3U5DAqRA_ = __8PqFvabdFiMQ5Efu6BvN09GX
	return __RmJ2QncaGntHnVv3U5DAqRA_
static func __YYZnqeqcW24r4NHVJSm4X6pk(__nXbEHi_ibMm_0dQ1_99XLLpD: __YdhZSn3k6BLtSITi5naOCb7n) -> void :
	var w: __1q0DwOCFFBOQDiHI3310K_lq = __nXbEHi_ibMm_0dQ1_99XLLpD.__g7JC3EJmfsOWnIyqLGGB93eB
	if w == null:
		return
	for s: Dictionary in w.__MMezevmh2WzjfDPiLXmgyJbQ:
		for a: __YCYnibBjVPRhMDf3YPwizbkN in s["members"]:
			a.active = false
			a.state = __YCYnibBjVPRhMDf3YPwizbkN.State.__a6v6b1ezzKda4xyS4CpY5J5O
			a.sub = 3
			a.__dRotcb2ldVZQLm2YDYWTTU9J = false
		(s["members"] as Array).clear()
		s["aloft"] = 0
	w.queue.clear()
	w.__ExRc2vcAyRkISXqe5ZZghf9A.clear()
static func __Po01OkJHCnci3a4IiBvYv08r(__F0qGAJ4X7RBcbbeTXVhyjm_o: int, __UykMtpTgwByMNjKczUtsxgZ6: int, r: int) -> int:
	if r == 0:
		return 0
	var __uwb1ZF_u_Kipz5YASBNrGxl6: int = 0
	var __wnAOCmtExLNDou1E1MOsyreI: int = 100000000
	var __FJ3XYncSirdFbwPiQH7ySMaZ: int = __Irz9hiGcyslSDsJT8BenfEt2.__f8g2PjfN7nwJbTHn9ePhmeZH(__dXppFYqETFUwGtUmhS9ups7R(__F0qGAJ4X7RBcbbeTXVhyjm_o * __F0qGAJ4X7RBcbbeTXVhyjm_o + __UykMtpTgwByMNjKczUtsxgZ6 * __UykMtpTgwByMNjKczUtsxgZ6))
	var __hJaikpLkukq2oDoS4ChZN8sL: int = 3 + (2 * r + 999) / 1000
	var __ZsNQFVAn0_9QNqEPzTDZMlqg: int = __TXCdoY85HWzo9E7Qcf9l8raZ.__KboCFqRH_Lt6RKsZGS_Zbtl9(absi(__UykMtpTgwByMNjKczUtsxgZ6), absi(__F0qGAJ4X7RBcbbeTXVhyjm_o))
	var __bECKZ5VI7pxroTI7gjdU5Jt2: int = __ZsNQFVAn0_9QNqEPzTDZMlqg if __F0qGAJ4X7RBcbbeTXVhyjm_o >= 0 and __UykMtpTgwByMNjKczUtsxgZ6 >= 0 else (1800 - __ZsNQFVAn0_9QNqEPzTDZMlqg if __F0qGAJ4X7RBcbbeTXVhyjm_o < 0 and __UykMtpTgwByMNjKczUtsxgZ6 >= 0 else (1800 + __ZsNQFVAn0_9QNqEPzTDZMlqg if __F0qGAJ4X7RBcbbeTXVhyjm_o < 0 else 3600 - __ZsNQFVAn0_9QNqEPzTDZMlqg))
	var __20biXCxyWl6qd5hiFdfR1huu: int = ((__bECKZ5VI7pxroTI7gjdU5Jt2 + 5) / 10) % 360
	for __dgJCaiN9Busn1KhtVhDjAn5M: int in 181:
		if __dgJCaiN9Busn1KhtVhDjAn5M >= 3:
			var __76FBLZBaqg9MPBXCMGDJpa6b: int = __TXCdoY85HWzo9E7Qcf9l8raZ.__9nHAKAsjPH38LR2tAezCTqd_[(__dgJCaiN9Busn1KhtVhDjAn5M - 2) * 10] + 1
			var __a6rJl8umBc2KO4OySxLW89HK: int = __FJ3XYncSirdFbwPiQH7ySMaZ * __FJ3XYncSirdFbwPiQH7ySMaZ + r * r
			if __76FBLZBaqg9MPBXCMGDJpa6b > 0:
				__a6rJl8umBc2KO4OySxLW89HK -= (2 * r * (__FJ3XYncSirdFbwPiQH7ySMaZ + 1) * __76FBLZBaqg9MPBXCMGDJpa6b + 999) / 1000
			var __nkC_x_z01JPvbNXNmfqKlZjo: int = __Irz9hiGcyslSDsJT8BenfEt2.__f8g2PjfN7nwJbTHn9ePhmeZH(maxi(0, __a6rJl8umBc2KO4OySxLW89HK)) - __hJaikpLkukq2oDoS4ChZN8sL
			if __nkC_x_z01JPvbNXNmfqKlZjo > 0 and __nkC_x_z01JPvbNXNmfqKlZjo * __nkC_x_z01JPvbNXNmfqKlZjo > __wnAOCmtExLNDou1E1MOsyreI + 4:
				break
		for __0AHY94y_tQlSPZbMbefZ1fyX: int in ([1] if __dgJCaiN9Busn1KhtVhDjAn5M == 0 or __dgJCaiN9Busn1KhtVhDjAn5M == 180 else [1, -1]):
			var a: int = posmod(__20biXCxyWl6qd5hiFdfR1huu + __0AHY94y_tQlSPZbMbefZ1fyX * __dgJCaiN9Busn1KhtVhDjAn5M, 360)
			if a == 359:
				continue
			var __O1oz2dg5YeOaktkkmQuoFipH: int = __TXCdoY85HWzo9E7Qcf9l8raZ.__9nHAKAsjPH38LR2tAezCTqd_[a * 10] * r / 1000
			var __rkI8lL4ugq2GuYYnvlgM8f7a: int = __TXCdoY85HWzo9E7Qcf9l8raZ.__7laIgLr3i8VN0D_tZnYT3p0D[a * 10] * r / 1000
			var d: int = __dXppFYqETFUwGtUmhS9ups7R((__F0qGAJ4X7RBcbbeTXVhyjm_o - __O1oz2dg5YeOaktkkmQuoFipH) * (__F0qGAJ4X7RBcbbeTXVhyjm_o - __O1oz2dg5YeOaktkkmQuoFipH) + (__UykMtpTgwByMNjKczUtsxgZ6 - __rkI8lL4ugq2GuYYnvlgM8f7a) * (__UykMtpTgwByMNjKczUtsxgZ6 - __rkI8lL4ugq2GuYYnvlgM8f7a))
			var __jS2cKASoFG1nW3HXK1XIkQEJ: int = a + 1
			if a == 0:
				var __tDXr02eBE__E0BUXRss6XuA5: int = __dXppFYqETFUwGtUmhS9ups7R((__F0qGAJ4X7RBcbbeTXVhyjm_o - r) * (__F0qGAJ4X7RBcbbeTXVhyjm_o - r) + __UykMtpTgwByMNjKczUtsxgZ6 * __UykMtpTgwByMNjKczUtsxgZ6)
				if __tDXr02eBE__E0BUXRss6XuA5 < __wnAOCmtExLNDou1E1MOsyreI or (__tDXr02eBE__E0BUXRss6XuA5 == __wnAOCmtExLNDou1E1MOsyreI and 0 < __uwb1ZF_u_Kipz5YASBNrGxl6):
					__wnAOCmtExLNDou1E1MOsyreI = __tDXr02eBE__E0BUXRss6XuA5
					__uwb1ZF_u_Kipz5YASBNrGxl6 = 0
			if d < __wnAOCmtExLNDou1E1MOsyreI or (d == __wnAOCmtExLNDou1E1MOsyreI and __jS2cKASoFG1nW3HXK1XIkQEJ < __uwb1ZF_u_Kipz5YASBNrGxl6):
				__wnAOCmtExLNDou1E1MOsyreI = d
				__uwb1ZF_u_Kipz5YASBNrGxl6 = __jS2cKASoFG1nW3HXK1XIkQEJ
	return __uwb1ZF_u_Kipz5YASBNrGxl6
static func __rSeWubmCkTD1q6sm0STXBtV3(__BxnoP3DHpULd5TmW4BddHUzM: __YCYnibBjVPRhMDf3YPwizbkN) -> bool:
	var __iOlri6yKIfpmCLTSwnA8D3ga: int = __dXppFYqETFUwGtUmhS9ups7R(__BxnoP3DHpULd5TmW4BddHUzM.__EHjU5UjAgmmddD5nyx49ar6j * __BxnoP3DHpULd5TmW4BddHUzM.__6auOgykzrXOLund23PvUaifY * 25) / 2000
	return __BxnoP3DHpULd5TmW4BddHUzM.active and __BxnoP3DHpULd5TmW4BddHUzM.__dRotcb2ldVZQLm2YDYWTTU9J and not __BxnoP3DHpULd5TmW4BddHUzM.__jKXPrtchy4v7fjo9Z9kJG9SX and not __BxnoP3DHpULd5TmW4BddHUzM.__Q4PVEYDqIobYx26SsJ1Qdl3_ and __BxnoP3DHpULd5TmW4BddHUzM.__TAmrKd8UPGcQuUSyqvAAVdWm\
	and (__iOlri6yKIfpmCLTSwnA8D3ga - __BxnoP3DHpULd5TmW4BddHUzM.__Grly1BvCsxoCuBf0E7OZOvtN) < (__iOlri6yKIfpmCLTSwnA8D3ga / 10 + __BxnoP3DHpULd5TmW4BddHUzM.__LHXFh2KJbTtUtaDckBU0bXW0)\
	and (__BxnoP3DHpULd5TmW4BddHUzM.state == __YCYnibBjVPRhMDf3YPwizbkN.State.__9wEd2skDnIT9b_VOjrri893n or __BxnoP3DHpULd5TmW4BddHUzM.state == __YCYnibBjVPRhMDf3YPwizbkN.State.__DdjO7licqxMK90434TaAU1qH
		or __BxnoP3DHpULd5TmW4BddHUzM.state == __YCYnibBjVPRhMDf3YPwizbkN.State.__SokrJF1aDQ6jidDRcP3EDMhC)
static func __CuIJeN7QnUx2qnczgpwyLaWy(__JTS7lRESa5PCulya8piHkbeR: __aDswGCE4WWdmypkp3eC7rExn, a: __YCYnibBjVPRhMDf3YPwizbkN, code: int, data: PackedByteArray) -> void :
	if a.state == __YCYnibBjVPRhMDf3YPwizbkN.State.__eEvXiwf2UW57C8JVEuywqlUc:
		return
	if a.__eYCv0HeDvti_w5wj1jxJpmfT and code != __lAo0PsogaUvqHw4muTzPsHiR.__zdiUInmKof3OdZvmaHsrJwvr:
		a.__eYCv0HeDvti_w5wj1jxJpmfT = false
	a.__Mwx0mipYOX_Do2pZ7_nf22Nm = false
	var s: int = a.state
	match code:
		__lAo0PsogaUvqHw4muTzPsHiR.__RnlQu1RDsFqYtAt0lFaNrpF3:
			if data.size() < 4:
				return
			if s == __YCYnibBjVPRhMDf3YPwizbkN.State.__8wDuFUkodt91vpp0l6j8TDd6:
				if a.type == __YCYnibBjVPRhMDf3YPwizbkN.__c6EMu0BarWqKqIAZLnyXweGZ:
					a.sub = 2
				elif a.type == __YCYnibBjVPRhMDf3YPwizbkN.__cqsRgbmsPf4IeAEKyNRkn9rz:
					if a.sub > 0:
						a.sub = 2
					else:
						a.state = __YCYnibBjVPRhMDf3YPwizbkN.State.__9wEd2skDnIT9b_VOjrri893n
				else:
					a.state = __YCYnibBjVPRhMDf3YPwizbkN.State.__9wEd2skDnIT9b_VOjrri893n
			elif s != __YCYnibBjVPRhMDf3YPwizbkN.State.__cqei2U9gqm0EDzpnZTAB5gor:
				a.state = __YCYnibBjVPRhMDf3YPwizbkN.State.__9wEd2skDnIT9b_VOjrri893n
			a.__2cQt3I45k0XXwSr_0reYodT2 = __YCYnibBjVPRhMDf3YPwizbkN.__2OJpMwzaDeyLf0HK2_6FqBy2
			a.__TlWqW0m63x0ks40OasJLgdcp = -1
			a.__auam0OiXATfV0FV2pOZQsnnt = -1
			a.__H0IfsdkHBf2MPjU13h3e655G = false
			a.__sRdhcmPDkaBIPIzTf0y2eZwL = false
			a.__skELt8hzOP5jTm2IrBPiYtZM = false
			var x: int = data.decode_s16(0)
			var y: int = data.decode_s16(2)
			if a.__2nVqHzJsE4wg_diKnctoD6kY:
				a.__3epXDNnmkHn9cpXlvNEl2W4g = x
				a.__C3JQvlRdH1p7kRdolXEDy8oi = y
			else:
				var __UwVFIb1PnzPs0ZfGL9ty417f: __YCYnibBjVPRhMDf3YPwizbkN = __JTS7lRESa5PCulya8piHkbeR.__LYNzM9N3A8Dmo_1zq54GljKm[a.owner].__g7JC3EJmfsOWnIyqLGGB93eB.__kVB4BR6zkcZM5875sCAu1tWK(a.__knUj879QWUN8clA4_f5YGzfw)
				var __Yv_zkb5uULJsAsFWifQEWf6N: int = __UwVFIb1PnzPs0ZfGL9ty417f.__EsOQaggwtLEnMAHn6g7H_r7O() if __UwVFIb1PnzPs0ZfGL9ty417f != null else a.__EsOQaggwtLEnMAHn6g7H_r7O()
				var __799ie0lQ2rudyWsdyDY5LxNA: int = __UwVFIb1PnzPs0ZfGL9ty417f.__caDHon68LplNQ04cMl2MMJ71() if __UwVFIb1PnzPs0ZfGL9ty417f != null else a.__caDHon68LplNQ04cMl2MMJ71()
				var __EEUh7CisSqG4g1_1SXgsbPNv: int = __apitD6L2wJGin9cDVFtGArTy(__Yv_zkb5uULJsAsFWifQEWf6N, __799ie0lQ2rudyWsdyDY5LxNA, x, y) * 10 % 3600
				var id: int = a.__w4KgbGj0JQyP8PGvp68qYP1F
				var __T8nZRAQRX6tffc6q6KkyRCsi: int = (id + 1) / 2
				var __bFKlQUrg48UITiTZ_AbMn_fG: int = __T8nZRAQRX6tffc6q6KkyRCsi if id % 2 == 0 else (id - 2 * __T8nZRAQRX6tffc6q6KkyRCsi) * __T8nZRAQRX6tffc6q6KkyRCsi
				var __9PyRhEvyJyTdgpJCQNfLkUeI: Vector2i = __XdcdSffYaN4csG29A7yc6Z3i(-8 * __T8nZRAQRX6tffc6q6KkyRCsi, 16 * __bFKlQUrg48UITiTZ_AbMn_fG, __EEUh7CisSqG4g1_1SXgsbPNv)
				a.__3epXDNnmkHn9cpXlvNEl2W4g = x + __9PyRhEvyJyTdgpJCQNfLkUeI.x
				a.__C3JQvlRdH1p7kRdolXEDy8oi = y + __9PyRhEvyJyTdgpJCQNfLkUeI.y * 86 / 100
			__JTS7lRESa5PCulya8piHkbeR.__wIebi2RHJicnHeiUm6xYwBpd(__QzfA1_MgHwBGTTBizdgA8rkk.__FSW4WCXpupwYSF0KaHCFCNKb.__aKIjQZbR2pEkicWL4C8LnNVM, a, code)
		__lAo0PsogaUvqHw4muTzPsHiR.__K4DW2sFEG4hDyZlDcv4ARdpS:
			if data.size() < 6:
				return
			var __tylvIc4pBf7J7GVfV4mnPoJh: int = data.decode_u16(4)
			if __tylvIc4pBf7J7GVfV4mnPoJh >= __JTS7lRESa5PCulya8piHkbeR.__LYNzM9N3A8Dmo_1zq54GljKm.size():
				return
			a.__TlWqW0m63x0ks40OasJLgdcp = __tylvIc4pBf7J7GVfV4mnPoJh
			a.__3epXDNnmkHn9cpXlvNEl2W4g = __JTS7lRESa5PCulya8piHkbeR.__LYNzM9N3A8Dmo_1zq54GljKm[__tylvIc4pBf7J7GVfV4mnPoJh].x()
			a.__C3JQvlRdH1p7kRdolXEDy8oi = __JTS7lRESa5PCulya8piHkbeR.__LYNzM9N3A8Dmo_1zq54GljKm[__tylvIc4pBf7J7GVfV4mnPoJh].y()
			a.state = __YCYnibBjVPRhMDf3YPwizbkN.State.__SokrJF1aDQ6jidDRcP3EDMhC
			__JTS7lRESa5PCulya8piHkbeR.__wIebi2RHJicnHeiUm6xYwBpd(__QzfA1_MgHwBGTTBizdgA8rkk.__FSW4WCXpupwYSF0KaHCFCNKb.__aKIjQZbR2pEkicWL4C8LnNVM, a, code)
		__lAo0PsogaUvqHw4muTzPsHiR.__9CvwwPmQifMMHqahfjKZlSCO:
			if s == __YCYnibBjVPRhMDf3YPwizbkN.State.__cqei2U9gqm0EDzpnZTAB5gor:
				return
			if a.type != __YCYnibBjVPRhMDf3YPwizbkN.__c6EMu0BarWqKqIAZLnyXweGZ and a.type != __YCYnibBjVPRhMDf3YPwizbkN.__cqsRgbmsPf4IeAEKyNRkn9rz:
				return
			if a.__6ol9zXLNVbGS9s_iAdvMaxLC == 0:
				return
			a.__H0IfsdkHBf2MPjU13h3e655G = false
			a.__sRdhcmPDkaBIPIzTf0y2eZwL = false
			if data.size() < 6:
				return
			var id: int = data.decode_u16(4)
			if s == __YCYnibBjVPRhMDf3YPwizbkN.State.__8wDuFUkodt91vpp0l6j8TDd6:
				if a.sub == 1:
					if a.__TlWqW0m63x0ks40OasJLgdcp == id:
						a.__skELt8hzOP5jTm2IrBPiYtZM = true
					return
				a.__skELt8hzOP5jTm2IrBPiYtZM = false
				return
			if a.__aBKovnuyCiI63tVuI2prB5MN < a.__2cQt3I45k0XXwSr_0reYodT2:
				a.__skELt8hzOP5jTm2IrBPiYtZM = false
				return
			if id >= __JTS7lRESa5PCulya8piHkbeR.__LYNzM9N3A8Dmo_1zq54GljKm.size():
				return
			a.pitch = 0
			a.state = __YCYnibBjVPRhMDf3YPwizbkN.State.__8wDuFUkodt91vpp0l6j8TDd6
			a.__TlWqW0m63x0ks40OasJLgdcp = id
			a.__3epXDNnmkHn9cpXlvNEl2W4g = __JTS7lRESa5PCulya8piHkbeR.__LYNzM9N3A8Dmo_1zq54GljKm[id].x()
			a.__C3JQvlRdH1p7kRdolXEDy8oi = __JTS7lRESa5PCulya8piHkbeR.__LYNzM9N3A8Dmo_1zq54GljKm[id].y()
			__JTS7lRESa5PCulya8piHkbeR.__wIebi2RHJicnHeiUm6xYwBpd(__QzfA1_MgHwBGTTBizdgA8rkk.__FSW4WCXpupwYSF0KaHCFCNKb.__aKIjQZbR2pEkicWL4C8LnNVM, a, code)
		__lAo0PsogaUvqHw4muTzPsHiR.__GRPnytew2Hz_p1DafRqWc4DS:
			if s != __YCYnibBjVPRhMDf3YPwizbkN.State.__a6v6b1ezzKda4xyS4CpY5J5O:
				a.state = __YCYnibBjVPRhMDf3YPwizbkN.State.__a6v6b1ezzKda4xyS4CpY5J5O
				a.sub = 0
				a.__sRdhcmPDkaBIPIzTf0y2eZwL = false
				var __dHX1x0FZsu6vuqae5IlTLUFd: __YdhZSn3k6BLtSITi5naOCb7n = __JTS7lRESa5PCulya8piHkbeR.__LYNzM9N3A8Dmo_1zq54GljKm[a.owner]
				var __CoIOuw_AOPqDj9jv5ftL5g8m: Vector2i = __XdcdSffYaN4csG29A7yc6Z3i(-200, 0, (__dHX1x0FZsu6vuqae5IlTLUFd.__vqYa6WuT8lqRfpObeEEtFMHG() + 900) % 3600)
				a.__3epXDNnmkHn9cpXlvNEl2W4g = __dHX1x0FZsu6vuqae5IlTLUFd.x() + __CoIOuw_AOPqDj9jv5ftL5g8m.x
				a.__C3JQvlRdH1p7kRdolXEDy8oi = __dHX1x0FZsu6vuqae5IlTLUFd.y() - __CoIOuw_AOPqDj9jv5ftL5g8m.y
				__JTS7lRESa5PCulya8piHkbeR.__wIebi2RHJicnHeiUm6xYwBpd(__QzfA1_MgHwBGTTBizdgA8rkk.__FSW4WCXpupwYSF0KaHCFCNKb.__yHmb2E8eufNCblP8NvDELVKl, a, 0 if data.is_empty() else 1)
			a.__skELt8hzOP5jTm2IrBPiYtZM = false
		__lAo0PsogaUvqHw4muTzPsHiR.__hmsimVPA4ud9Y6ZQbS1iPIWF:
			if s != __YCYnibBjVPRhMDf3YPwizbkN.State.__9wEd2skDnIT9b_VOjrri893n and s != __YCYnibBjVPRhMDf3YPwizbkN.State.__DdjO7licqxMK90434TaAU1qH and s != __YCYnibBjVPRhMDf3YPwizbkN.State.__SokrJF1aDQ6jidDRcP3EDMhC:
				return
			if a.__aBKovnuyCiI63tVuI2prB5MN >= __YCYnibBjVPRhMDf3YPwizbkN.__2OJpMwzaDeyLf0HK2_6FqBy2:
				return
			a.__2cQt3I45k0XXwSr_0reYodT2 = a.__aBKovnuyCiI63tVuI2prB5MN + 400
			a.pitch = 100
		__lAo0PsogaUvqHw4muTzPsHiR.__HTyDgV1cQ3EEPT4rdcYB988f:
			if s != __YCYnibBjVPRhMDf3YPwizbkN.State.__9wEd2skDnIT9b_VOjrri893n and s != __YCYnibBjVPRhMDf3YPwizbkN.State.__DdjO7licqxMK90434TaAU1qH and s != __YCYnibBjVPRhMDf3YPwizbkN.State.__SokrJF1aDQ6jidDRcP3EDMhC:
				return
			var __pfkSr94y7TAyDAa1k0K5gjE4: int = a.__aBKovnuyCiI63tVuI2prB5MN - 400
			if __pfkSr94y7TAyDAa1k0K5gjE4 <= __YCYnibBjVPRhMDf3YPwizbkN.__XNP5UhOp48fF9keZolufRgEY:
				return
			a.__2cQt3I45k0XXwSr_0reYodT2 = __pfkSr94y7TAyDAa1k0K5gjE4
			a.pitch = -100
		__lAo0PsogaUvqHw4muTzPsHiR.__tdzjWSWsv9G2KGQRcGI8AKgH:
			if s == __YCYnibBjVPRhMDf3YPwizbkN.State.__8wDuFUkodt91vpp0l6j8TDd6 or a.__6ol9zXLNVbGS9s_iAdvMaxLC == 0 or a.type != __YCYnibBjVPRhMDf3YPwizbkN.__cqsRgbmsPf4IeAEKyNRkn9rz or data.size() < 4:
				return
			a.__eYCv0HeDvti_w5wj1jxJpmfT = true
			a.__fFJBY3GZMYP1LL3hAdQ6l9hb = data.decode_s16(0)
			a.__pQ7vBeCy3SKL6gdAUzA6Pyzc = data.decode_s16(2)
			a.__H0IfsdkHBf2MPjU13h3e655G = false
			a.__sRdhcmPDkaBIPIzTf0y2eZwL = false
			a.pitch = 0
			a.state = __YCYnibBjVPRhMDf3YPwizbkN.State.__8wDuFUkodt91vpp0l6j8TDd6
			a.sub = 0
			__JTS7lRESa5PCulya8piHkbeR.__wIebi2RHJicnHeiUm6xYwBpd(__QzfA1_MgHwBGTTBizdgA8rkk.__FSW4WCXpupwYSF0KaHCFCNKb.__aKIjQZbR2pEkicWL4C8LnNVM, a, code)
		__lAo0PsogaUvqHw4muTzPsHiR.__zdiUInmKof3OdZvmaHsrJwvr:
			if s == __YCYnibBjVPRhMDf3YPwizbkN.State.__8wDuFUkodt91vpp0l6j8TDd6 and a.sub == 1 and a.type == __YCYnibBjVPRhMDf3YPwizbkN.__cqsRgbmsPf4IeAEKyNRkn9rz and a.__eYCv0HeDvti_w5wj1jxJpmfT:
				a.__skELt8hzOP5jTm2IrBPiYtZM = true
				return
			if a.type != __YCYnibBjVPRhMDf3YPwizbkN.__c6EMu0BarWqKqIAZLnyXweGZ or a.__aBKovnuyCiI63tVuI2prB5MN / 1000 >= 50 or a.__6ol9zXLNVbGS9s_iAdvMaxLC == 0:
				return
			a.state = __YCYnibBjVPRhMDf3YPwizbkN.State.__8wDuFUkodt91vpp0l6j8TDd6
			a.sub = 1
			a.__Mwx0mipYOX_Do2pZ7_nf22Nm = true
			a.__skELt8hzOP5jTm2IrBPiYtZM = true
		__lAo0PsogaUvqHw4muTzPsHiR.__ZnVoXQPJNvKUxzmIYXNvGBS2:
			a.__skELt8hzOP5jTm2IrBPiYtZM = true
			__qjgNztHVRNc_Pbnf4VqDosil(__JTS7lRESa5PCulya8piHkbeR, a)
static func __FuSLMR8YKlQfKdKZhdyY0zVV(a: __YCYnibBjVPRhMDf3YPwizbkN) -> void :
	if a.sub != 2:
		return
	var h: int = a.__vqYa6WuT8lqRfpObeEEtFMHG
	if h - 900 < 0:
		h += 3600
	var __RvwYXvpwqeTSb8Yl_VRU1O9J: Vector2i = __F_qXl6Q5aLvlwWZs9gpUNk_q(400, 0, h)
	a.__3epXDNnmkHn9cpXlvNEl2W4g = a.__EsOQaggwtLEnMAHn6g7H_r7O() + __RvwYXvpwqeTSb8Yl_VRU1O9J.x
	a.__C3JQvlRdH1p7kRdolXEDy8oi = a.__caDHon68LplNQ04cMl2MMJ71() - __RvwYXvpwqeTSb8Yl_VRU1O9J.y
const __3Q04ZY09Jmx3SsmRkFW1hxSK: = 12
const __R57y5g_HdP5oW23rah6hKG8x: = [40, 90, 20, 100]
