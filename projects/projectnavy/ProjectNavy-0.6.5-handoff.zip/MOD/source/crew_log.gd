class_name __Bsl33jE0VgUtGf0ZDYkuZAkg
const __oxEN0ma_5PMnWmKeSO6Aarw4: = 1
const __ySHjbuycEkZsOAVzZD5V5Ht4: = 6
static func __AsuxRxt4dxvQLRqG_txm2_Cq(__yiEqMtMZA9s1ag_FOzzrB2wS: int) -> PackedByteArray:
	return __VIgqbuKG4yGJ9ext2i7dK6BX(__cOSPeWooT0bO7h8VvPzjZShH).__Jy2hcMM9emCF3iBBkLMyeUr7(__yiEqMtMZA9s1ag_FOzzrB2wS).data
static func __EeeOnAaW3x79G4evvLjbMh4l(__BEuYSZWKuGoin3Anku5YTHEO: PackedInt32Array) -> PackedByteArray:
	var w: ___HSJtJROYvDLx1pHFzP6FQy7 = __VIgqbuKG4yGJ9ext2i7dK6BX(__pEwqP98vfeosJd7UxRd4OIXx)
	for __551b8tIbiK2zW4HbWlOdX4HB: int in __dezk9V9PLI6B97K9LxPYJmJ3:
		w.__R8EBxRBQac1wukJKPScUj3_n(__BEuYSZWKuGoin3Anku5YTHEO[__551b8tIbiK2zW4HbWlOdX4HB])
	return w.data
static func __M4OyqPFV6qn2_rUaK3d8VgYJ(__z7oPWiXbjvOETHIEP5Zfac7T: int) -> PackedByteArray:
	return __VIgqbuKG4yGJ9ext2i7dK6BX(__JIE1FCXp_8sL_9eHCpmkUZn7).__pGLr1ud1V6XsMMJoSyeTRFjY(__z7oPWiXbjvOETHIEP5Zfac7T).data
const __3IxiYgOF74g2qW6il82D8V5P: = 9
static func __v56w0nDh5mq2I0MTm9draNQd(__u4LTJ3UeTvhYkvClOgLw6HY_: int, __z9WDkPICZwc_5f20cD8c9dK1: int) -> PackedByteArray:
	return __VIgqbuKG4yGJ9ext2i7dK6BX(__18bpP1embJkkAvfItoxDsZ1O).__pGLr1ud1V6XsMMJoSyeTRFjY(__u4LTJ3UeTvhYkvClOgLw6HY_).__TpSdeHcFBcJ91Kb7d42DsKVx(__z9WDkPICZwc_5f20cD8c9dK1).data
const __18bpP1embJkkAvfItoxDsZ1O: = 6
static func __1Je8u9PYZcbPOmrX1CKIPrnS(s: Dictionary, __98il4h0iWZSuZI6L7sFmnLg2: __CgOl36_UCxYZW5PzufCcS4dS) -> bool:
	return int(s["class_row"]) == __98il4h0iWZSuZI6L7sFmnLg2.__mpLpovabZnp87HNkreW4pWJY and int(s["level"]) == __98il4h0iWZSuZI6L7sFmnLg2.__zMZVCIoyJu5zkEI6YyKqPDoG and int(s["exp"]) == __98il4h0iWZSuZI6L7sFmnLg2.exp and s["ab"] == __98il4h0iWZSuZI6L7sFmnLg2.__4ObdBYhtKkHScUayTPgiYzH_ and s["growth"] == __98il4h0iWZSuZI6L7sFmnLg2.__wC11jxHS1J5bzkNesfKgNncZ and s["men"] == __98il4h0iWZSuZI6L7sFmnLg2.__pY661vwzoRY0D6Y5ORWYVaB_ and int(s["route_node"]) == __98il4h0iWZSuZI6L7sFmnLg2.__hJTRC1qsUs9T0VQkseYzTT2f and s["route"] == __98il4h0iWZSuZI6L7sFmnLg2.__1U0d7dXiK8nppclbz5xhDxaz
static func __MOlINPJ4rQitdShzA4Rmk2jR(data: PackedByteArray) -> Variant:
	var __kODPGXwjRMi2haYSQYniucfi: Array[Dictionary] = []
	var r: = __2qo9vfpnxQybzUL4GHGzcXBB.new(data)
	while r.__g0MBgfYiqCb6SBmlLlXYetmr and not r.__Hh5VEmu_h1YTJUqGyrQl3apM():
		var __sNFO_ZJflMKXxCSSztTvnaEd: Dictionary = {"kind": r.__vlQDTtuyQZ3KmvKohFfizJCm(), "time": r.__pGLr1ud1V6XsMMJoSyeTRFjY()}
		match int(__sNFO_ZJflMKXxCSSztTvnaEd["kind"]):
			__oxEN0ma_5PMnWmKeSO6Aarw4:
				__sNFO_ZJflMKXxCSSztTvnaEd["class_row"] = r.__Jy2hcMM9emCF3iBBkLMyeUr7()
				r.__vlQDTtuyQZ3KmvKohFfizJCm();r.__pGLr1ud1V6XsMMJoSyeTRFjY()
				for __P_WG2aIj1SXoNvdcZyPV_jfY: int in 2 * __dezk9V9PLI6B97K9LxPYJmJ3:
					r.__Jy2hcMM9emCF3iBBkLMyeUr7()
				for __S7Igurj18j5LvQafc1vkTtoZ: int in 3:
					r.__vlQDTtuyQZ3KmvKohFfizJCm()
				r.__Jy2hcMM9emCF3iBBkLMyeUr7()
				for __6ZETlJGa0DDPzXCHY1tkww5P: int in r.__vlQDTtuyQZ3KmvKohFfizJCm():
					r.__Jy2hcMM9emCF3iBBkLMyeUr7()
			__CVGI5VRieG3AtLLmAeCFQ3Yb:
				__sNFO_ZJflMKXxCSSztTvnaEd["class_row"] = r.__Jy2hcMM9emCF3iBBkLMyeUr7()
				for __RH3fWq3l2PCj6kZQuEj2CCF7: int in __dezk9V9PLI6B97K9LxPYJmJ3:
					r.__R8EBxRBQac1wukJKPScUj3_n()
			__ABX7yZI0t3m37kDmVC21lNHn:
				__sNFO_ZJflMKXxCSSztTvnaEd["men"] = PackedInt32Array([r.__R8EBxRBQac1wukJKPScUj3_n(), r.__R8EBxRBQac1wukJKPScUj3_n(), r.__R8EBxRBQac1wukJKPScUj3_n()])
			__YHNawEwNiFQafbUvUp_P22KW:
				r.__Jy2hcMM9emCF3iBBkLMyeUr7()
			__8VTO_lMeYHRN85MasuaZKDaa:
				pass
			__18bpP1embJkkAvfItoxDsZ1O:
				__sNFO_ZJflMKXxCSSztTvnaEd["bid"] = r.__pGLr1ud1V6XsMMJoSyeTRFjY()
				__sNFO_ZJflMKXxCSSztTvnaEd["d"] = r.__TpSdeHcFBcJ91Kb7d42DsKVx()
			__to1RnkCM6tCWcqGeJyvIbHRj:
				var __6hUHl6IbANWYQLVdM8zzKbh_: = PackedInt32Array()
				for __UvMh51o3OEcP41MEZj8Ce1rp: int in __dezk9V9PLI6B97K9LxPYJmJ3:
					__6hUHl6IbANWYQLVdM8zzKbh_.append(r.__R8EBxRBQac1wukJKPScUj3_n())
				__sNFO_ZJflMKXxCSSztTvnaEd["ab"] = __6hUHl6IbANWYQLVdM8zzKbh_
				__sNFO_ZJflMKXxCSSztTvnaEd["men"] = PackedInt32Array([r.__R8EBxRBQac1wukJKPScUj3_n(), r.__R8EBxRBQac1wukJKPScUj3_n(), r.__R8EBxRBQac1wukJKPScUj3_n()])
			__tVoLM8mN5NA4yIruqllXDFJQ:
				r.__TpSdeHcFBcJ91Kb7d42DsKVx()
			__pEwqP98vfeosJd7UxRd4OIXx:
				for __rCIqWyduDBIDlljzCEWzqPDO: int in __dezk9V9PLI6B97K9LxPYJmJ3:
					r.__R8EBxRBQac1wukJKPScUj3_n()
			__lg4e2O1X2Ott2RcmIQHC1Z_P:
				__sNFO_ZJflMKXxCSSztTvnaEd["bid"] = r.__pGLr1ud1V6XsMMJoSyeTRFjY()
				__sNFO_ZJflMKXxCSSztTvnaEd["dl"] = r.__R8EBxRBQac1wukJKPScUj3_n()
				__sNFO_ZJflMKXxCSSztTvnaEd["de"] = r.__TpSdeHcFBcJ91Kb7d42DsKVx()
				var __DBvTaTgqkfEaJ3DKKFbNxl1W: = PackedInt32Array()
				for __jj0tFDP79T0nOGbljVFC9jF2: int in __dezk9V9PLI6B97K9LxPYJmJ3:
					__DBvTaTgqkfEaJ3DKKFbNxl1W.append(r.__R8EBxRBQac1wukJKPScUj3_n())
				__sNFO_ZJflMKXxCSSztTvnaEd["ab"] = __DBvTaTgqkfEaJ3DKKFbNxl1W
				__sNFO_ZJflMKXxCSSztTvnaEd["men"] = PackedInt32Array([r.__R8EBxRBQac1wukJKPScUj3_n(), r.__R8EBxRBQac1wukJKPScUj3_n(), r.__R8EBxRBQac1wukJKPScUj3_n()])
			__JIE1FCXp_8sL_9eHCpmkUZn7:
				__sNFO_ZJflMKXxCSSztTvnaEd["bid"] = r.__pGLr1ud1V6XsMMJoSyeTRFjY()
			__BktNMbcDT5ERxTizPvCM7ygc:
				r.__zmCjpae15knxucHXlz9SyJdh();r.__pGLr1ud1V6XsMMJoSyeTRFjY();r.__TpSdeHcFBcJ91Kb7d42DsKVx();r.__pGLr1ud1V6XsMMJoSyeTRFjY();r.__4cmRuFi2awggMlqipWIopsZZ(48)
			__RRekR6AvjD06_XRWV84u74OQ.__jTEMBbFjGqle8Qav6p5hZzf7:
				var __s55xGZJT2gldnMqvNorxewo1: int = r.__pGLr1ud1V6XsMMJoSyeTRFjY()
				if __s55xGZJT2gldnMqvNorxewo1 > 16384:
					return null
				r.__4cmRuFi2awggMlqipWIopsZZ(__s55xGZJT2gldnMqvNorxewo1 + 16)
			_:
				return null
		__kODPGXwjRMi2haYSQYniucfi.append(__sNFO_ZJflMKXxCSSztTvnaEd)
	return __kODPGXwjRMi2haYSQYniucfi if r.__g0MBgfYiqCb6SBmlLlXYetmr else null
static func __oiM_iYX5Oqbb4gAx9EC1NYQC(__HbOIAoMqodMUZmBCzrsTEsaS: int, __7gxGsAS5Ou60yGkWe5d_J9qF: PackedInt32Array) -> PackedByteArray:
	var w: ___HSJtJROYvDLx1pHFzP6FQy7 = __VIgqbuKG4yGJ9ext2i7dK6BX(__CVGI5VRieG3AtLLmAeCFQ3Yb).__Jy2hcMM9emCF3iBBkLMyeUr7(__HbOIAoMqodMUZmBCzrsTEsaS)
	for __cN24OfDj0Qf0ZOu8cqr0ea9J: int in __dezk9V9PLI6B97K9LxPYJmJ3:
		w.__R8EBxRBQac1wukJKPScUj3_n(__7gxGsAS5Ou60yGkWe5d_J9qF[__cN24OfDj0Qf0ZOu8cqr0ea9J] if __cN24OfDj0Qf0ZOu8cqr0ea9J < __7gxGsAS5Ou60yGkWe5d_J9qF.size() else 0)
	return w.data
static func __mTkeaLQ8nnA_H7U6F81oq2fj(data: PackedByteArray, __7hvm5gL_Qaqzo3E8WvOTF3KH: Array) -> Variant:
	var __aX8psJAAHeUj_lUT2cJepcuq: Dictionary = {}
	var __LRHT4w6kMJFOFS5A40GvrKTa: Dictionary = {}
	var __6oRS4xQE9qlJjYF0VKxC3dM9: Dictionary = {}
	var r: = __2qo9vfpnxQybzUL4GHGzcXBB.new(data)
	while r.__g0MBgfYiqCb6SBmlLlXYetmr and not r.__Hh5VEmu_h1YTJUqGyrQl3apM():
		var __5MlWL2wZB848aZc_9rQ290bf: int = r.__vlQDTtuyQZ3KmvKohFfizJCm()
		r.__pGLr1ud1V6XsMMJoSyeTRFjY()
		match __5MlWL2wZB848aZc_9rQ290bf:
			__CdV0n6xWgKGDNjI9uUDUqWPZ:
				r.__TpSdeHcFBcJ91Kb7d42DsKVx();r.__TpSdeHcFBcJ91Kb7d42DsKVx()
				for __pM7lduVM1BghO8fyVbOWJkDo: int in r.__vlQDTtuyQZ3KmvKohFfizJCm():
					r.__Jy2hcMM9emCF3iBBkLMyeUr7()
			__ZWd6BeQKciN3ZxA9r5jxHDSU:
				var __kqyuZSVjVDicg2KomJAiuqLB: int = r.__vlQDTtuyQZ3KmvKohFfizJCm()
				var __bVec1WVXZucS9bOvP7_Qg33C: int = r.__TpSdeHcFBcJ91Kb7d42DsKVx()
				var __JuNtMRD3LhVXmGOuDpvm3kOI: int = r.__TpSdeHcFBcJ91Kb7d42DsKVx()
				var __dMDWfqtMKhddwPalxDnDD1wx: int = r.__pGLr1ud1V6XsMMJoSyeTRFjY()
				if __kqyuZSVjVDicg2KomJAiuqLB == __UIv2WzsH9TzMENAvL2h37Lud:
					var a: Array = __aX8psJAAHeUj_lUT2cJepcuq.get(__dMDWfqtMKhddwPalxDnDD1wx, [0, 0])
					__aX8psJAAHeUj_lUT2cJepcuq[__dMDWfqtMKhddwPalxDnDD1wx] = [int(a[0]) + __bVec1WVXZucS9bOvP7_Qg33C, int(a[1]) + __JuNtMRD3LhVXmGOuDpvm3kOI]
				elif __kqyuZSVjVDicg2KomJAiuqLB == __sYsLt_iqlSFqM8rk1xUCFz2O:
					__LRHT4w6kMJFOFS5A40GvrKTa[__dMDWfqtMKhddwPalxDnDD1wx] = [__bVec1WVXZucS9bOvP7_Qg33C, __JuNtMRD3LhVXmGOuDpvm3kOI]
				elif __kqyuZSVjVDicg2KomJAiuqLB == __EsH2TfqGPeBfLiPNtFoEY8mb:
					__6oRS4xQE9qlJjYF0VKxC3dM9[__dMDWfqtMKhddwPalxDnDD1wx] = true
			__mK7oBZcPnhugpfhYpY16F7AV, __cOSPeWooT0bO7h8VvPzjZShH:
				r.__Jy2hcMM9emCF3iBBkLMyeUr7()
			__RRekR6AvjD06_XRWV84u74OQ.__MMk4LUcowF7aoOQMXVnZKRN7:
				var __Y3pE6Bo75B01kygWmn1f0ssp: int = r.__pGLr1ud1V6XsMMJoSyeTRFjY()
				if __Y3pE6Bo75B01kygWmn1f0ssp > 16384:
					return null
				r.__4cmRuFi2awggMlqipWIopsZZ(__Y3pE6Bo75B01kygWmn1f0ssp + 16)
			__KpqgwsMhEOgLcO0EPeItguvS:
				r.__Jy2hcMM9emCF3iBBkLMyeUr7()
				__s8yZigV26lPAvEmbOWzMbnjE.read(r, false, false, false)
			__ySHjbuycEkZsOAVzZD5V5Ht4:
				r.__Jy2hcMM9emCF3iBBkLMyeUr7()
				__s8yZigV26lPAvEmbOWzMbnjE.read(r, false, true, false)
			__Yl6qbOCG3_uVKgD5oyvpktfk:
				r.__Jy2hcMM9emCF3iBBkLMyeUr7()
				__s8yZigV26lPAvEmbOWzMbnjE.read(r, false)
			_:
				return null
	return {"settle": __aX8psJAAHeUj_lUT2cJepcuq, "voided": __LRHT4w6kMJFOFS5A40GvrKTa, "unvoided": __6oRS4xQE9qlJjYF0VKxC3dM9} if r.__g0MBgfYiqCb6SBmlLlXYetmr else null
static func __6csr_ynrgSUFwXCaON0hFF2J(data: PackedByteArray, __XGPEVWczA8OseBtiZvOvwPs7: Array) -> Dictionary:
	var r: = __2qo9vfpnxQybzUL4GHGzcXBB.new(data)
	var s: Dictionary = {}
	var __1ej2hbWbbb5Loyo_5r709Kk4: Dictionary = {}
	var __KH6I9NJ0EqlEjFm9IYLNLOoK: Dictionary = {}
	while r.__g0MBgfYiqCb6SBmlLlXYetmr and not r.__Hh5VEmu_h1YTJUqGyrQl3apM():
		var __piBCIz0pO5nnMErlUeRmLNx5: int = r.___GSUqzER9puey3LaUebBJamO
		var __iWFI92scroN8VCfOygpAunRG: int = r.__vlQDTtuyQZ3KmvKohFfizJCm()
		r.__pGLr1ud1V6XsMMJoSyeTRFjY()
		if s.is_empty() and __iWFI92scroN8VCfOygpAunRG != __CdV0n6xWgKGDNjI9uUDUqWPZ:
			return {"err": "NO_GENESIS"}
		match __iWFI92scroN8VCfOygpAunRG:
			__CdV0n6xWgKGDNjI9uUDUqWPZ:
				if not s.is_empty():
					return {"err": "BAD_FORMAT"}
				s = {"credits": r.__TpSdeHcFBcJ91Kb7d42DsKVx(), "points": r.__TpSdeHcFBcJ91Kb7d42DsKVx(), "ships": {}, "loadouts": {}, "debug": false}
				for __QEdNB90Vkr02b2EB8f8aOSe8: int in r.__vlQDTtuyQZ3KmvKohFfizJCm():
					s["ships"][r.__Jy2hcMM9emCF3iBBkLMyeUr7()] = true
			__RRekR6AvjD06_XRWV84u74OQ.__MMk4LUcowF7aoOQMXVnZKRN7:
				var __BWtwNZHMbJrhuHkqdABKP5I6: Dictionary = __RRekR6AvjD06_XRWV84u74OQ.__I8n5BdvDVHXKg6dp2D9fSBXL(r, data, __piBCIz0pO5nnMErlUeRmLNx5, "ledger")
				if __BWtwNZHMbJrhuHkqdABKP5I6.is_empty():
					return {"err": "BAD_RECEIPT"}
				var __Wf7l6voyZPEGd32XVMeVBlIP: Dictionary = __BWtwNZHMbJrhuHkqdABKP5I6["body"]
				if s.get("state_repairs", {}).has(str(__Wf7l6voyZPEGd32XVMeVBlIP["id"])):
					return {"err": "BAD_RECEIPT"}
				var __D0feHFY_h9eP_dZZsySyWWhv: Dictionary = __6csr_ynrgSUFwXCaON0hFF2J(data.slice(0, int(__Wf7l6voyZPEGd32XVMeVBlIP["prefix_bytes"])), __XGPEVWczA8OseBtiZvOvwPs7)
				if __D0feHFY_h9eP_dZZsySyWWhv.has("err") or __D0feHFY_h9eP_dZZsySyWWhv.get("state_repairs", {}).has(str(__Wf7l6voyZPEGd32XVMeVBlIP["id"])) or int(__D0feHFY_h9eP_dZZsySyWWhv["credits"]) != int(__Wf7l6voyZPEGd32XVMeVBlIP["before_credits"]) or int(__D0feHFY_h9eP_dZZsySyWWhv["points"]) != int(__Wf7l6voyZPEGd32XVMeVBlIP["before_points"]):
					return {"err": "BAD_RECEIPT"}
				if not s.has("state_repairs"):
					s["state_repairs"] = {}
				s["state_repairs"][str(__Wf7l6voyZPEGd32XVMeVBlIP["id"])] = __BWtwNZHMbJrhuHkqdABKP5I6
				s["credits"] += int(__Wf7l6voyZPEGd32XVMeVBlIP["credits"]) - int(__Wf7l6voyZPEGd32XVMeVBlIP["before_credits"])
				s["points"] += int(__Wf7l6voyZPEGd32XVMeVBlIP["points"]) - int(__Wf7l6voyZPEGd32XVMeVBlIP["before_points"])
			__ZWd6BeQKciN3ZxA9r5jxHDSU:
				var __2tzONlTnE0yqcuYrdZYuxoZs: int = r.__vlQDTtuyQZ3KmvKohFfizJCm()
				var __tpvm4xf3wjvjzUXACc8Jk5bG: int = r.__TpSdeHcFBcJ91Kb7d42DsKVx()
				var __mG2IA8JGmW61AlnthWGAXnaG: int = r.__TpSdeHcFBcJ91Kb7d42DsKVx()
				var __FnA6q2GQejhn17SLETnK0NpV: int = r.__pGLr1ud1V6XsMMJoSyeTRFjY()
				s["credits"] += __tpvm4xf3wjvjzUXACc8Jk5bG
				s["points"] += __mG2IA8JGmW61AlnthWGAXnaG
				if __2tzONlTnE0yqcuYrdZYuxoZs == __SqQACpn7NvvJhPhBxGiVO55D:
					s["debug"] = true
				elif __2tzONlTnE0yqcuYrdZYuxoZs == __UIv2WzsH9TzMENAvL2h37Lud:
					if __FnA6q2GQejhn17SLETnK0NpV >= __XGPEVWczA8OseBtiZvOvwPs7.size():
						return {"err": "BAD_REF"}
					var b: Dictionary = __XGPEVWczA8OseBtiZvOvwPs7[__FnA6q2GQejhn17SLETnK0NpV]
					if __tpvm4xf3wjvjzUXACc8Jk5bG < 0 or __mG2IA8JGmW61AlnthWGAXnaG < 0 or __tpvm4xf3wjvjzUXACc8Jk5bG > int(b["credits"]) or __mG2IA8JGmW61AlnthWGAXnaG > int(b["points"]):
						return {"err": "SUM_MISMATCH"}
				elif __2tzONlTnE0yqcuYrdZYuxoZs == __sYsLt_iqlSFqM8rk1xUCFz2O:
					if __FnA6q2GQejhn17SLETnK0NpV >= __XGPEVWczA8OseBtiZvOvwPs7.size() or __tpvm4xf3wjvjzUXACc8Jk5bG > 0 or __mG2IA8JGmW61AlnthWGAXnaG > 0 or __KH6I9NJ0EqlEjFm9IYLNLOoK.has(__FnA6q2GQejhn17SLETnK0NpV):
						return {"err": "SUM_MISMATCH"}
					__KH6I9NJ0EqlEjFm9IYLNLOoK[__FnA6q2GQejhn17SLETnK0NpV] = [__tpvm4xf3wjvjzUXACc8Jk5bG, __mG2IA8JGmW61AlnthWGAXnaG]
				elif __2tzONlTnE0yqcuYrdZYuxoZs == __EsH2TfqGPeBfLiPNtFoEY8mb:
					if not (__KH6I9NJ0EqlEjFm9IYLNLOoK.get(__FnA6q2GQejhn17SLETnK0NpV) is Array) or __tpvm4xf3wjvjzUXACc8Jk5bG != - int(__KH6I9NJ0EqlEjFm9IYLNLOoK[__FnA6q2GQejhn17SLETnK0NpV][0]) or __mG2IA8JGmW61AlnthWGAXnaG != - int(__KH6I9NJ0EqlEjFm9IYLNLOoK[__FnA6q2GQejhn17SLETnK0NpV][1]):
						return {"err": "SUM_MISMATCH"}
					__KH6I9NJ0EqlEjFm9IYLNLOoK[__FnA6q2GQejhn17SLETnK0NpV] = true
				elif __2tzONlTnE0yqcuYrdZYuxoZs == __dA5oug57cA2Y8McJNk8ERx32 and __tpvm4xf3wjvjzUXACc8Jk5bG < 0:
					__1ej2hbWbbb5Loyo_5r709Kk4[__FnA6q2GQejhn17SLETnK0NpV] = int(__1ej2hbWbbb5Loyo_5r709Kk4.get(__FnA6q2GQejhn17SLETnK0NpV, 0)) + 1
			__mK7oBZcPnhugpfhYpY16F7AV:
				var __oHcfvlpHgGzjkNy0osGoTlzl: int = r.__Jy2hcMM9emCF3iBBkLMyeUr7()
				if int(__1ej2hbWbbb5Loyo_5r709Kk4.get(__oHcfvlpHgGzjkNy0osGoTlzl, 0)) <= 0:
					return {"err": "NO_PURCHASE"}
				__1ej2hbWbbb5Loyo_5r709Kk4[__oHcfvlpHgGzjkNy0osGoTlzl] = int(__1ej2hbWbbb5Loyo_5r709Kk4[__oHcfvlpHgGzjkNy0osGoTlzl]) - 1
				s["ships"][__oHcfvlpHgGzjkNy0osGoTlzl] = true
			__cOSPeWooT0bO7h8VvPzjZShH:
				s["ships"].erase(r.__Jy2hcMM9emCF3iBBkLMyeUr7())
			__KpqgwsMhEOgLcO0EPeItguvS:
				var __Tk4ye8EAzSYzv2sqj1ewmtv0: int = r.__Jy2hcMM9emCF3iBBkLMyeUr7()
				var __kuix27K5sAH5zei30eQSHZYT: __s8yZigV26lPAvEmbOWzMbnjE = __s8yZigV26lPAvEmbOWzMbnjE.read(r, false, false, false)
				s["loadouts"][__Tk4ye8EAzSYzv2sqj1ewmtv0] = __qdukOh2DzNTxYj4hEUz8zVEX(__kuix27K5sAH5zei30eQSHZYT)
			__ySHjbuycEkZsOAVzZD5V5Ht4:
				var __frCgk6U5njVVcBR6SN15mZ_V: int = r.__Jy2hcMM9emCF3iBBkLMyeUr7()
				var __EqXsVyuFphcK51M_vJCOoXmG: __s8yZigV26lPAvEmbOWzMbnjE = __s8yZigV26lPAvEmbOWzMbnjE.read(r, false, true, false)
				s["loadouts"][__frCgk6U5njVVcBR6SN15mZ_V] = __qdukOh2DzNTxYj4hEUz8zVEX(__EqXsVyuFphcK51M_vJCOoXmG)
			__Yl6qbOCG3_uVKgD5oyvpktfk:
				var __SU2CDlaciAn7SseRnoG0Txmm: int = r.__Jy2hcMM9emCF3iBBkLMyeUr7()
				var __njHWVr45Zkqc_9mnWhKzb2nO: int = r.___GSUqzER9puey3LaUebBJamO
				var __C8FIIjHYxOgTHNIpyzxC3PDu: __s8yZigV26lPAvEmbOWzMbnjE = __s8yZigV26lPAvEmbOWzMbnjE.read(r, false)
				s["loadouts"][__SU2CDlaciAn7SseRnoG0Txmm] = r.data.slice(__njHWVr45Zkqc_9mnWhKzb2nO, r.___GSUqzER9puey3LaUebBJamO)
			_:
				return {"err": "BAD_FORMAT"}
	if not r.__g0MBgfYiqCb6SBmlLlXYetmr:
		return {"err": "BAD_FORMAT"}
	if s.is_empty():
		return {"err": "NO_GENESIS"}
	return s
const __NHGmOa6wEbOnfJHXuBNjmrw3: = 2
static func __3Ww2CyubyGZATCihjDN2tN2l(__35IbOzMxpDFq0yYWQTcvHCm9: int, __Bsu7NvfEt7uMcEC0nfWz7N1D: int, __zzSQCJA1q2U8VjK1AcqrNZgW: int, __GZMpifqkzqa9p_FXYLofHrP5: PackedInt32Array, __nukgdb9mF_ClcwizLrPG1DAp: PackedInt32Array) -> PackedByteArray:
	var w: ___HSJtJROYvDLx1pHFzP6FQy7 = __VIgqbuKG4yGJ9ext2i7dK6BX(__lg4e2O1X2Ott2RcmIQHC1Z_P).__pGLr1ud1V6XsMMJoSyeTRFjY(__35IbOzMxpDFq0yYWQTcvHCm9).__R8EBxRBQac1wukJKPScUj3_n(__Bsu7NvfEt7uMcEC0nfWz7N1D).__TpSdeHcFBcJ91Kb7d42DsKVx(__zzSQCJA1q2U8VjK1AcqrNZgW)
	for __tFOAYyqokJX5bD9gqg9pl4Tf: int in __dezk9V9PLI6B97K9LxPYJmJ3:
		w.__R8EBxRBQac1wukJKPScUj3_n(__GZMpifqkzqa9p_FXYLofHrP5[__tFOAYyqokJX5bD9gqg9pl4Tf])
	for __3vvcl3n8i2FNatyXatH16OV4: int in 3:
		w.__R8EBxRBQac1wukJKPScUj3_n(__nukgdb9mF_ClcwizLrPG1DAp[__3vvcl3n8i2FNatyXatH16OV4])
	return w.data
const __lg4e2O1X2Ott2RcmIQHC1Z_P: = 10
const __mK7oBZcPnhugpfhYpY16F7AV: = 3
static func __Jtifg3uTCyMJvjtHgVtGl8WD() -> PackedByteArray:
	return __VIgqbuKG4yGJ9ext2i7dK6BX(__8VTO_lMeYHRN85MasuaZKDaa).data
static func __ulOyzeridQn9EcS2r8quda4K(__Qkt0Y3e6_Svu27ZksolICNP9: int) -> PackedByteArray:
	return __VIgqbuKG4yGJ9ext2i7dK6BX(__YHNawEwNiFQafbUvUp_P22KW).__Jy2hcMM9emCF3iBBkLMyeUr7(__Qkt0Y3e6_Svu27ZksolICNP9).data
static func __xKkZyV3GXBurOzC5GJoFVkM_(data: PackedByteArray) -> Variant:
	var __OH08n_8fR4LGLlMxjGGughG1: Array[Dictionary] = []
	var r: = __2qo9vfpnxQybzUL4GHGzcXBB.new(data)
	while r.__g0MBgfYiqCb6SBmlLlXYetmr and not r.__Hh5VEmu_h1YTJUqGyrQl3apM():
		var __FkoOlvYm9acqrhTLHX2kOUyw: Dictionary = {"kind": r.__vlQDTtuyQZ3KmvKohFfizJCm(), "time": r.__pGLr1ud1V6XsMMJoSyeTRFjY()}
		match int(__FkoOlvYm9acqrhTLHX2kOUyw["kind"]):
			__df8fetATDWAgvQuavb_nDw3I:
				__FkoOlvYm9acqrhTLHX2kOUyw.merge({"frame_row": r.__Jy2hcMM9emCF3iBBkLMyeUr7(), "total_exp": r.__pGLr1ud1V6XsMMJoSyeTRFjY(), "credits": r.__TpSdeHcFBcJ91Kb7d42DsKVx(), "points": r.__TpSdeHcFBcJ91Kb7d42DsKVx(), "ticks": r.__Jy2hcMM9emCF3iBBkLMyeUr7()})
			__OQk6FJzj8wtiAWpVt9lO1ZEk:
				__FkoOlvYm9acqrhTLHX2kOUyw.merge({"frame_row": r.__Jy2hcMM9emCF3iBBkLMyeUr7(), "match_id": r.__pGLr1ud1V6XsMMJoSyeTRFjY(), "total_exp": r.__pGLr1ud1V6XsMMJoSyeTRFjY(), "credits": r.__TpSdeHcFBcJ91Kb7d42DsKVx(), "points": r.__TpSdeHcFBcJ91Kb7d42DsKVx(), "server_time": r.__pGLr1ud1V6XsMMJoSyeTRFjY(), "sig": r.__4cmRuFi2awggMlqipWIopsZZ(__rL7VKSz1y8IFIypaSGotMkmB)})
			_:
				return null
		__OH08n_8fR4LGLlMxjGGughG1.append(__FkoOlvYm9acqrhTLHX2kOUyw)
	return __OH08n_8fR4LGLlMxjGGughG1 if r.__g0MBgfYiqCb6SBmlLlXYetmr else null
const __dA5oug57cA2Y8McJNk8ERx32: = 8
const __8VTO_lMeYHRN85MasuaZKDaa: = 5
const __jsHKcANVTDoh22Fdmruyj1ja: = 11
const __SqQACpn7NvvJhPhBxGiVO55D: = 255
const __KpqgwsMhEOgLcO0EPeItguvS: = 5
const __ZWd6BeQKciN3ZxA9r5jxHDSU: = 2
static func __4Ru6nQhfQM3V8TFwZzShiQgn(__eC5IK8wOJYFP6iifeUX8UjTj: __CgOl36_UCxYZW5PzufCcS4dS) -> PackedByteArray:
	var w: ___HSJtJROYvDLx1pHFzP6FQy7 = __VIgqbuKG4yGJ9ext2i7dK6BX(__oxEN0ma_5PMnWmKeSO6Aarw4).__Jy2hcMM9emCF3iBBkLMyeUr7(__eC5IK8wOJYFP6iifeUX8UjTj.__mpLpovabZnp87HNkreW4pWJY).__vlQDTtuyQZ3KmvKohFfizJCm(__eC5IK8wOJYFP6iifeUX8UjTj.__zMZVCIoyJu5zkEI6YyKqPDoG).__pGLr1ud1V6XsMMJoSyeTRFjY(__eC5IK8wOJYFP6iifeUX8UjTj.exp)
	var __U5hatG3xL_HCVFFx_1Ef_BXz: PackedInt32Array = __eC5IK8wOJYFP6iifeUX8UjTj.__4ObdBYhtKkHScUayTPgiYzH_
	var __EYayJLLPJ4vOp547asGFHYKb: PackedInt32Array = __eC5IK8wOJYFP6iifeUX8UjTj.__wC11jxHS1J5bzkNesfKgNncZ
	var __EL9SJL_UaOL70dcCL6Cqfsce: PackedInt32Array = __eC5IK8wOJYFP6iifeUX8UjTj.__pY661vwzoRY0D6Y5ORWYVaB_
	for ___SWlsKpX1ShzYlYGNSgLdnhe: int in __dezk9V9PLI6B97K9LxPYJmJ3:
		w.__Jy2hcMM9emCF3iBBkLMyeUr7(__U5hatG3xL_HCVFFx_1Ef_BXz[___SWlsKpX1ShzYlYGNSgLdnhe])
	for __osjXntx0nnAH4SMcrvGFXn6c: int in __dezk9V9PLI6B97K9LxPYJmJ3:
		w.__R8EBxRBQac1wukJKPScUj3_n(__EYayJLLPJ4vOp547asGFHYKb[__osjXntx0nnAH4SMcrvGFXn6c])
	for ___rZrEVfi_KWUQM1OUKkHognj: int in 3:
		w.__vlQDTtuyQZ3KmvKohFfizJCm(__EL9SJL_UaOL70dcCL6Cqfsce[___rZrEVfi_KWUQM1OUKkHognj])
	w.__Jy2hcMM9emCF3iBBkLMyeUr7(__eC5IK8wOJYFP6iifeUX8UjTj.__hJTRC1qsUs9T0VQkseYzTT2f).__vlQDTtuyQZ3KmvKohFfizJCm(__eC5IK8wOJYFP6iifeUX8UjTj.__1U0d7dXiK8nppclbz5xhDxaz.size())
	for __YqW1gp9vgaP1lpI1X2dRFjfK: int in __eC5IK8wOJYFP6iifeUX8UjTj.__1U0d7dXiK8nppclbz5xhDxaz:
		w.__Jy2hcMM9emCF3iBBkLMyeUr7(__YqW1gp9vgaP1lpI1X2dRFjfK)
	return w.data
const __Yl6qbOCG3_uVKgD5oyvpktfk: = 7
const __pEwqP98vfeosJd7UxRd4OIXx: = 9
const __jXTZH_Ija8TZywRECMkziNYF: = 3
const __MAuObtKplQF6qga2KCMkBh19: = 10
const __CdV0n6xWgKGDNjI9uUDUqWPZ: = 1
const __BktNMbcDT5ERxTizPvCM7ygc: = 12
static func __lC6p3UAKK6Xhdp7WnzDqTIA8(text: String) -> PackedByteArray:
	if text == "":
		return PackedByteArray()
	return Marshalls.base64_to_raw(text).decompress_dynamic(-1, FileAccess.COMPRESSION_GZIP)
const __rL7VKSz1y8IFIypaSGotMkmB: = 16
static func __qdukOh2DzNTxYj4hEUz8zVEX(__vkLyHyQsFyVjbY57hHPg6DFN: __s8yZigV26lPAvEmbOWzMbnjE) -> PackedByteArray:
	var w: = ___HSJtJROYvDLx1pHFzP6FQy7.new()
	__vkLyHyQsFyVjbY57hHPg6DFN.__yGAhLY9oHuNBozHNMES_YhCF().__E9luCfORIzdEy2gXLGgeAad2(w, false)
	return w.data
static func __jqrpAP5Ufi5CUtUDTkl21WOq(__JTP6Nznu9j8fFEOM_S8RIfPQ: int, __YpN8QUGBdSvXVkk6Bkflwuc4: int, __sdx9iGp9bVGb9noIrR2uYH2J: int, points: int, __MCx4xPA9oqnAuvRmB9U8VMBN: int) -> PackedByteArray:
	return __VIgqbuKG4yGJ9ext2i7dK6BX(__df8fetATDWAgvQuavb_nDw3I).__Jy2hcMM9emCF3iBBkLMyeUr7(__JTP6Nznu9j8fFEOM_S8RIfPQ).__pGLr1ud1V6XsMMJoSyeTRFjY(maxi(__YpN8QUGBdSvXVkk6Bkflwuc4, 0)).__TpSdeHcFBcJ91Kb7d42DsKVx(__sdx9iGp9bVGb9noIrR2uYH2J).__TpSdeHcFBcJ91Kb7d42DsKVx(points).__Jy2hcMM9emCF3iBBkLMyeUr7(clampi(__MCx4xPA9oqnAuvRmB9U8VMBN, 0, 65535)).data
const __to1RnkCM6tCWcqGeJyvIbHRj: = 7
const __YHNawEwNiFQafbUvUp_P22KW: = 4
const __df8fetATDWAgvQuavb_nDw3I: = 1
const __dezk9V9PLI6B97K9LxPYJmJ3: = 11
static func pack(data: PackedByteArray) -> String:
	if data.is_empty():
		return ""
	return Marshalls.raw_to_base64(data.compress(FileAccess.COMPRESSION_GZIP))
const __XiEb4ye1ZKK5O4qAb053JFLI: = 5
static func __Tl3K9uGGfZgXD8Imy6YbNG1L(__2jQ2VRpoJTBjlpjYteVAJt3W: __s8yZigV26lPAvEmbOWzMbnjE) -> PackedByteArray:
	return __VIgqbuKG4yGJ9ext2i7dK6BX(__Yl6qbOCG3_uVKgD5oyvpktfk).__Jy2hcMM9emCF3iBBkLMyeUr7(__2jQ2VRpoJTBjlpjYteVAJt3W.__WeB9Hi0OxaFBUuwm2WU2qKEH).__4cmRuFi2awggMlqipWIopsZZ(__qdukOh2DzNTxYj4hEUz8zVEX(__2jQ2VRpoJTBjlpjYteVAJt3W)).data
static func __pY661vwzoRY0D6Y5ORWYVaB_(__aiHeyLZ2_hLAPtjbvM3sb0BZ: int, __qaoCYZLg9gozapwiaoSGaJQG: int, __EDcFV9ikYs2wdOPUXFMkZI8A: int) -> PackedByteArray:
	return __VIgqbuKG4yGJ9ext2i7dK6BX(__ABX7yZI0t3m37kDmVC21lNHn).__R8EBxRBQac1wukJKPScUj3_n(__aiHeyLZ2_hLAPtjbvM3sb0BZ).__R8EBxRBQac1wukJKPScUj3_n(__qaoCYZLg9gozapwiaoSGaJQG).__R8EBxRBQac1wukJKPScUj3_n(__EDcFV9ikYs2wdOPUXFMkZI8A).data
const __EsH2TfqGPeBfLiPNtFoEY8mb: = 13
const __JIE1FCXp_8sL_9eHCpmkUZn7: = 11
static func __2WcXt43cd12t3Ju7LqI11H80(__eYQWd9qIWJo9SJa1aETWPnfS: int, __mOde1Ey83KQ9N7UNJNwyaNQ9: int, __xJnhkVSY2qGS2t4DgbrV6rYZ: int, __V1ztLDCPtWwbCnwkTVgqC3Hs: int, points: int, __1gnzZEoBR1xtNgHohNA3nZL1: int, __90w_TfN6pGSx1l9cIKKgHKbw: PackedByteArray) -> PackedByteArray:
	var w: ___HSJtJROYvDLx1pHFzP6FQy7 = __VIgqbuKG4yGJ9ext2i7dK6BX(__OQk6FJzj8wtiAWpVt9lO1ZEk).__Jy2hcMM9emCF3iBBkLMyeUr7(__eYQWd9qIWJo9SJa1aETWPnfS).__pGLr1ud1V6XsMMJoSyeTRFjY(__mOde1Ey83KQ9N7UNJNwyaNQ9).__pGLr1ud1V6XsMMJoSyeTRFjY(maxi(__xJnhkVSY2qGS2t4DgbrV6rYZ, 0)).__TpSdeHcFBcJ91Kb7d42DsKVx(__V1ztLDCPtWwbCnwkTVgqC3Hs).__TpSdeHcFBcJ91Kb7d42DsKVx(points).__pGLr1ud1V6XsMMJoSyeTRFjY(__1gnzZEoBR1xtNgHohNA3nZL1)
	var s: PackedByteArray = __90w_TfN6pGSx1l9cIKKgHKbw.slice(0, __rL7VKSz1y8IFIypaSGotMkmB)
	s.resize(__rL7VKSz1y8IFIypaSGotMkmB)
	return w.__4cmRuFi2awggMlqipWIopsZZ(s).data
const __sHonv71pRuEn82ajAXfAug6Z: = 0
static func __VIgqbuKG4yGJ9ext2i7dK6BX(__feMVMMcNOt68rlr4xNP6Ebws: int) -> ___HSJtJROYvDLx1pHFzP6FQy7:
	return ___HSJtJROYvDLx1pHFzP6FQy7.new().__vlQDTtuyQZ3KmvKohFfizJCm(__feMVMMcNOt68rlr4xNP6Ebws).__pGLr1ud1V6XsMMJoSyeTRFjY(int(Time.get_unix_time_from_system()))
const __5PtJNefDe19NzOk_RhsGCA9a: = 7
static func __C515wFpFrWEK5NdcSsTKRWJT(__72QpeeikF094LkzVCSON5oXU: PackedInt32Array, __cGXnYxVxpI2YbzfhOdlsPdYE: PackedInt32Array) -> PackedByteArray:
	var w: ___HSJtJROYvDLx1pHFzP6FQy7 = __VIgqbuKG4yGJ9ext2i7dK6BX(__to1RnkCM6tCWcqGeJyvIbHRj)
	for __cUUkQTA2EXsqwXM9iAEeLrcp: int in __dezk9V9PLI6B97K9LxPYJmJ3:
		w.__R8EBxRBQac1wukJKPScUj3_n(__72QpeeikF094LkzVCSON5oXU[__cUUkQTA2EXsqwXM9iAEeLrcp])
	for __rxtOl7173rjjICdCOmH7iVOu: int in 3:
		w.__R8EBxRBQac1wukJKPScUj3_n(__cGXnYxVxpI2YbzfhOdlsPdYE[__rxtOl7173rjjICdCOmH7iVOu])
	return w.data
const __tVoLM8mN5NA4yIruqllXDFJQ: = 8
const __UIv2WzsH9TzMENAvL2h37Lud: = 1
const __OQk6FJzj8wtiAWpVt9lO1ZEk: = 2
static func __pxT2tKjeuXkgu_c5zstK_k3d(__YMwjBBRaIwRzh3x1hmJxRflL: int) -> PackedByteArray:
	return __VIgqbuKG4yGJ9ext2i7dK6BX(__tVoLM8mN5NA4yIruqllXDFJQ).__TpSdeHcFBcJ91Kb7d42DsKVx(__YMwjBBRaIwRzh3x1hmJxRflL).data
static func __VEKKZRxT994YvA78REAOoYY7(__as8UkWllis26kI6_u7seLVOv: int) -> PackedByteArray:
	return __VIgqbuKG4yGJ9ext2i7dK6BX(__mK7oBZcPnhugpfhYpY16F7AV).__Jy2hcMM9emCF3iBBkLMyeUr7(__as8UkWllis26kI6_u7seLVOv).data
const __ABX7yZI0t3m37kDmVC21lNHn: = 3
const __sYsLt_iqlSFqM8rk1xUCFz2O: = 12
static func __zLZOWi0uesM3Z8mNp1Sx_PHX(data: PackedByteArray, __RZpE7GeJ5npey0pkl4Cxm9e7: Array) -> Dictionary:
	var r: = __2qo9vfpnxQybzUL4GHGzcXBB.new(data)
	var s: Dictionary = {}
	var __J4HxELPaJ5K6GerfE5PgcLJh: int = -1
	var __umJBYKP5ZY0A8Xz7qrOuZMZH: Dictionary = {}
	var __WkUlDU388EqhcusVYDKpeZUc: Dictionary = {}
	while r.__g0MBgfYiqCb6SBmlLlXYetmr and not r.__Hh5VEmu_h1YTJUqGyrQl3apM():
		var __JFxtQVTvQ5vGAe27xS5dh3rH: int = r.___GSUqzER9puey3LaUebBJamO
		var __U75r6i7Bz_1s2sz07jhfyGdQ: int = r.__vlQDTtuyQZ3KmvKohFfizJCm()
		r.__pGLr1ud1V6XsMMJoSyeTRFjY()
		if s.is_empty() and __U75r6i7Bz_1s2sz07jhfyGdQ != __oxEN0ma_5PMnWmKeSO6Aarw4:
			return {"err": "NO_BORN"}
		match __U75r6i7Bz_1s2sz07jhfyGdQ:
			__oxEN0ma_5PMnWmKeSO6Aarw4:
				if not s.is_empty():
					return {"err": "BAD_FORMAT"}
				s = {"class_row": r.__Jy2hcMM9emCF3iBBkLMyeUr7(), "level": r.__vlQDTtuyQZ3KmvKohFfizJCm(), "exp": r.__pGLr1ud1V6XsMMJoSyeTRFjY(), "debug": false}
				var __q_ZawilkA0jQa9XudEDNmAcn: = PackedInt32Array()
				var __2g5KgkCb79EAee_iR0YYveRE: = PackedInt32Array()
				var __enlxQnR4ctg_YYp3Oz7ejMjQ: = PackedInt32Array()
				var __nlQ3WrMFACGE1LWUjxKb6bKl: = PackedInt32Array()
				for __lNMQ6A6gt5qKKYRHIlY9a1h9: int in __dezk9V9PLI6B97K9LxPYJmJ3:
					__q_ZawilkA0jQa9XudEDNmAcn.append(r.__Jy2hcMM9emCF3iBBkLMyeUr7())
				for __SsZJVD6UNtgPXRLnfGLWTp19: int in __dezk9V9PLI6B97K9LxPYJmJ3:
					__2g5KgkCb79EAee_iR0YYveRE.append(r.__R8EBxRBQac1wukJKPScUj3_n())
				for __iURz0rv_QuvVGK0RaQjKWCN2: int in 3:
					__enlxQnR4ctg_YYp3Oz7ejMjQ.append(r.__vlQDTtuyQZ3KmvKohFfizJCm())
				s["route_node"] = r.__Jy2hcMM9emCF3iBBkLMyeUr7()
				for __BMF7xvnm5IbTb62r673gtOxD: int in r.__vlQDTtuyQZ3KmvKohFfizJCm():
					__nlQ3WrMFACGE1LWUjxKb6bKl.append(r.__Jy2hcMM9emCF3iBBkLMyeUr7())
				s["ab"] = __q_ZawilkA0jQa9XudEDNmAcn
				s["growth"] = __2g5KgkCb79EAee_iR0YYveRE
				s["men"] = __enlxQnR4ctg_YYp3Oz7ejMjQ
				s["route"] = __nlQ3WrMFACGE1LWUjxKb6bKl
			__CVGI5VRieG3AtLLmAeCFQ3Yb:
				s["class_row"] = r.__Jy2hcMM9emCF3iBBkLMyeUr7()
				var __XePvXoS63ZgRkxGzG6gANjf4: PackedInt32Array = s["growth"]
				for __O1qFQjyNSAatL4lasLan2Mif: int in __dezk9V9PLI6B97K9LxPYJmJ3:
					__XePvXoS63ZgRkxGzG6gANjf4[__O1qFQjyNSAatL4lasLan2Mif] += r.__R8EBxRBQac1wukJKPScUj3_n()
				s["growth"] = __XePvXoS63ZgRkxGzG6gANjf4
			__ABX7yZI0t3m37kDmVC21lNHn:
				var __xkJs668CwytGyBO3DgCDzrpw: PackedInt32Array = s["men"]
				for __bQWKVSa2frLGG8hgUvx5tbqa: int in 3:
					__xkJs668CwytGyBO3DgCDzrpw[__bQWKVSa2frLGG8hgUvx5tbqa] += r.__R8EBxRBQac1wukJKPScUj3_n()
				s["men"] = __xkJs668CwytGyBO3DgCDzrpw
			__YHNawEwNiFQafbUvUp_P22KW:
				var __0RgBAbm86HbSPfJ3T90Dz1nV: int = r.__Jy2hcMM9emCF3iBBkLMyeUr7()
				var __zhUwz96vXbezf5OgxzuL4KjB: PackedInt32Array = s["route"]
				if not __zhUwz96vXbezf5OgxzuL4KjB.has(int(s["route_node"])) and __zhUwz96vXbezf5OgxzuL4KjB.size() < __1OkQgYNA0NkvkBligBeQgZWC.__3fKBPF8xIVn7LnRIBUmAHIz6:
					__zhUwz96vXbezf5OgxzuL4KjB.append(int(s["route_node"]))
				s["route"] = __zhUwz96vXbezf5OgxzuL4KjB
				s["route_node"] = __0RgBAbm86HbSPfJ3T90Dz1nV
			__8VTO_lMeYHRN85MasuaZKDaa:
				s["route_node"] = __1OkQgYNA0NkvkBligBeQgZWC.__R2X7seLnTY5XT91Rew6aCtxr
				s["route"] = PackedInt32Array()
			__18bpP1embJkkAvfItoxDsZ1O:
				var ___CNM_tRWwtXmKjpNOpu_RpMR: int = r.__pGLr1ud1V6XsMMJoSyeTRFjY()
				var d: int = r.__TpSdeHcFBcJ91Kb7d42DsKVx()
				if ___CNM_tRWwtXmKjpNOpu_RpMR >= __RZpE7GeJ5npey0pkl4Cxm9e7.size() or ___CNM_tRWwtXmKjpNOpu_RpMR <= __J4HxELPaJ5K6GerfE5PgcLJh:
					return {"err": "BAD_REF"}
				__J4HxELPaJ5K6GerfE5PgcLJh = ___CNM_tRWwtXmKjpNOpu_RpMR
				s["exp"] += d
			__to1RnkCM6tCWcqGeJyvIbHRj:
				s["level"] += 1
				var __mpeN74zimdjh96A6kqIAJFJO: PackedInt32Array = s["ab"]
				var __ZlamE4iDqn0Fnf7x8TlYkLab: PackedInt32Array = s["men"]
				for __vdQ3VFbcOtAr8JlK1sr9L3Hf: int in __dezk9V9PLI6B97K9LxPYJmJ3:
					__mpeN74zimdjh96A6kqIAJFJO[__vdQ3VFbcOtAr8JlK1sr9L3Hf] += r.__R8EBxRBQac1wukJKPScUj3_n()
				for __JtYui8VpqbfnUootKL4mEgnk: int in 3:
					__ZlamE4iDqn0Fnf7x8TlYkLab[__JtYui8VpqbfnUootKL4mEgnk] += r.__R8EBxRBQac1wukJKPScUj3_n()
				s["ab"] = __mpeN74zimdjh96A6kqIAJFJO
				s["men"] = __ZlamE4iDqn0Fnf7x8TlYkLab
			__tVoLM8mN5NA4yIruqllXDFJQ:
				s["exp"] += r.__TpSdeHcFBcJ91Kb7d42DsKVx()
				s["debug"] = true
			__pEwqP98vfeosJd7UxRd4OIXx:
				var __fA70YhHcPOnr_0OybDd70DPO: PackedInt32Array = s["ab"]
				for __C4AwEEhQaQoEoFFPd9PVZOVc: int in __dezk9V9PLI6B97K9LxPYJmJ3:
					__fA70YhHcPOnr_0OybDd70DPO[__C4AwEEhQaQoEoFFPd9PVZOVc] += r.__R8EBxRBQac1wukJKPScUj3_n()
				s["ab"] = __fA70YhHcPOnr_0OybDd70DPO
			__RRekR6AvjD06_XRWV84u74OQ.__jTEMBbFjGqle8Qav6p5hZzf7:
				var __FJ9SKAtK20EBFvjeFm8lqeL6: Dictionary = __RRekR6AvjD06_XRWV84u74OQ.__I8n5BdvDVHXKg6dp2D9fSBXL(r, data, __JFxtQVTvQ5vGAe27xS5dh3rH, "member")
				if __FJ9SKAtK20EBFvjeFm8lqeL6.is_empty() or __WkUlDU388EqhcusVYDKpeZUc.has(str(__FJ9SKAtK20EBFvjeFm8lqeL6["body"]["id"])):
					return {"err": "BAD_RECEIPT"}
				__WkUlDU388EqhcusVYDKpeZUc[str(__FJ9SKAtK20EBFvjeFm8lqeL6["body"]["id"])] = __FJ9SKAtK20EBFvjeFm8lqeL6
				var __2lHsIkzhdQUGMVgCdUleo5qg: Dictionary = __RRekR6AvjD06_XRWV84u74OQ.__xX03SuYfii5VUiofYLhsglw2(__FJ9SKAtK20EBFvjeFm8lqeL6["body"], data.slice(int(__FJ9SKAtK20EBFvjeFm8lqeL6["body"]["prefix_bytes"]), __JFxtQVTvQ5vGAe27xS5dh3rH), __RZpE7GeJ5npey0pkl4Cxm9e7)
				if __2lHsIkzhdQUGMVgCdUleo5qg.is_empty():
					return {"err": "BAD_RECEIPT"}
				for __rpOBbHDjwotC6NDsTWHJG7Pi: String in __2lHsIkzhdQUGMVgCdUleo5qg:
					s[__rpOBbHDjwotC6NDsTWHJG7Pi] = __2lHsIkzhdQUGMVgCdUleo5qg[__rpOBbHDjwotC6NDsTWHJG7Pi]
			__BktNMbcDT5ERxTizPvCM7ygc:
				var id: String = r.__zmCjpae15knxucHXlz9SyJdh()
				var __0ScBQHjs7IHEMyJW3Rpe28IB: int = r.__pGLr1ud1V6XsMMJoSyeTRFjY()
				var delta: int = r.__TpSdeHcFBcJ91Kb7d42DsKVx()
				var __KGaUeWnS9tITHwlffKgM3FHi: int = r.__pGLr1ud1V6XsMMJoSyeTRFjY()
				var __Jgl7G5fsNshKGoA9ZHfHvoj8: PackedByteArray = r.__4cmRuFi2awggMlqipWIopsZZ(32)
				var __Q7QeCtTKfLnkbznaunIcX3mz: PackedByteArray = r.__4cmRuFi2awggMlqipWIopsZZ(16)
				if not r.__g0MBgfYiqCb6SBmlLlXYetmr or not __DJubHAbResvPb2i6NZEYPW6D.__u3dMnYbF_CC29zu5v5FdsiKn(id) or __0ScBQHjs7IHEMyJW3Rpe28IB <= 0 or delta == 0 or absi(delta) > 135600 or __KGaUeWnS9tITHwlffKgM3FHi <= 0 or __KGaUeWnS9tITHwlffKgM3FHi > __JFxtQVTvQ5vGAe27xS5dh3rH or __WkUlDU388EqhcusVYDKpeZUc.has(id) or __DJubHAbResvPb2i6NZEYPW6D.__9_o15zpXPQEfsdggE3LOrNLo(data.slice(0, __KGaUeWnS9tITHwlffKgM3FHi)) != __Jgl7G5fsNshKGoA9ZHfHvoj8:
					return {"err": "BAD_RECEIPT"}
				__WkUlDU388EqhcusVYDKpeZUc[id] = {"member_id": __0ScBQHjs7IHEMyJW3Rpe28IB, "delta": delta, "sig": __Q7QeCtTKfLnkbznaunIcX3mz.hex_encode()}
				s["exp"] += delta
			__lg4e2O1X2Ott2RcmIQHC1Z_P:
				var __iVHCxwuBUc_RMrsIs1QNve8C: int = r.__pGLr1ud1V6XsMMJoSyeTRFjY()
				var __ifUyGBD53IY5rM2v_sNMAFiH: int = r.__R8EBxRBQac1wukJKPScUj3_n()
				var __losiJVU8ZROe7VMzhzOKQXRD: int = r.__TpSdeHcFBcJ91Kb7d42DsKVx()
				var __3YJ39TkvZfLDzbQHtstO3qZK: = PackedInt32Array()
				var __ZryZv2KtGYyte27Ox41B4ftg: = PackedInt32Array()
				for __LG5MkT5Zquk30WclLC6wVDWp: int in __dezk9V9PLI6B97K9LxPYJmJ3:
					__3YJ39TkvZfLDzbQHtstO3qZK.append(r.__R8EBxRBQac1wukJKPScUj3_n())
				for __lciloLcLWeWKDKtxG_WLZAMl: int in 3:
					__ZryZv2KtGYyte27Ox41B4ftg.append(r.__R8EBxRBQac1wukJKPScUj3_n())
				if __iVHCxwuBUc_RMrsIs1QNve8C >= __RZpE7GeJ5npey0pkl4Cxm9e7.size() or __umJBYKP5ZY0A8Xz7qrOuZMZH.has(__iVHCxwuBUc_RMrsIs1QNve8C):
					return {"err": "BAD_REF"}
				__umJBYKP5ZY0A8Xz7qrOuZMZH[__iVHCxwuBUc_RMrsIs1QNve8C] = [__ifUyGBD53IY5rM2v_sNMAFiH, __losiJVU8ZROe7VMzhzOKQXRD, __3YJ39TkvZfLDzbQHtstO3qZK, __ZryZv2KtGYyte27Ox41B4ftg]
				s["level"] += __ifUyGBD53IY5rM2v_sNMAFiH
				s["exp"] += __losiJVU8ZROe7VMzhzOKQXRD
				var __X4bY_iPQpmlBgpgLrbj8LyQK: PackedInt32Array = s["ab"]
				var __eQA2IVEvZMrh0nVrZUQ_TWdB: PackedInt32Array = s["men"]
				for __z9UeWUVvnIMypmWK4yAhBiKu: int in __dezk9V9PLI6B97K9LxPYJmJ3:
					__X4bY_iPQpmlBgpgLrbj8LyQK[__z9UeWUVvnIMypmWK4yAhBiKu] += __3YJ39TkvZfLDzbQHtstO3qZK[__z9UeWUVvnIMypmWK4yAhBiKu]
				for __NcAxbL8G4R24OwvYYT_WVBcI: int in 3:
					__eQA2IVEvZMrh0nVrZUQ_TWdB[__NcAxbL8G4R24OwvYYT_WVBcI] += __ZryZv2KtGYyte27Ox41B4ftg[__NcAxbL8G4R24OwvYYT_WVBcI]
				s["ab"] = __X4bY_iPQpmlBgpgLrbj8LyQK
				s["men"] = __eQA2IVEvZMrh0nVrZUQ_TWdB
			__JIE1FCXp_8sL_9eHCpmkUZn7:
				var __GfTfcx3YnTmMGeNq5uOdmY84: int = r.__pGLr1ud1V6XsMMJoSyeTRFjY()
				if not __umJBYKP5ZY0A8Xz7qrOuZMZH.has(__GfTfcx3YnTmMGeNq5uOdmY84) or not (__umJBYKP5ZY0A8Xz7qrOuZMZH[__GfTfcx3YnTmMGeNq5uOdmY84] is Array):
					return {"err": "BAD_REF"}
				var v: Array = __umJBYKP5ZY0A8Xz7qrOuZMZH[__GfTfcx3YnTmMGeNq5uOdmY84]
				__umJBYKP5ZY0A8Xz7qrOuZMZH[__GfTfcx3YnTmMGeNq5uOdmY84] = true
				s["level"] -= int(v[0])
				s["exp"] -= int(v[1])
				var __nhxkEn_nohlQUjnNdZf0cAx5: PackedInt32Array = s["ab"]
				var __YFCxlqTdhWLsKABBx6zUZrSX: PackedInt32Array = s["men"]
				for __xPe3v86WaXChvoJDTLGhbXuy: int in __dezk9V9PLI6B97K9LxPYJmJ3:
					__nhxkEn_nohlQUjnNdZf0cAx5[__xPe3v86WaXChvoJDTLGhbXuy] -= (v[2] as PackedInt32Array)[__xPe3v86WaXChvoJDTLGhbXuy]
				for __l022Lb8Cmbf0Mpqbb9jfVMqt: int in 3:
					__YFCxlqTdhWLsKABBx6zUZrSX[__l022Lb8Cmbf0Mpqbb9jfVMqt] -= (v[3] as PackedInt32Array)[__l022Lb8Cmbf0Mpqbb9jfVMqt]
				s["ab"] = __nhxkEn_nohlQUjnNdZf0cAx5
				s["men"] = __YFCxlqTdhWLsKABBx6zUZrSX
			_:
				return {"err": "BAD_FORMAT"}
	if not r.__g0MBgfYiqCb6SBmlLlXYetmr:
		return {"err": "BAD_FORMAT"}
	if s.is_empty():
		return {"err": "NO_LOG"}
	if not __WkUlDU388EqhcusVYDKpeZUc.is_empty():
		s["repairs"] = __WkUlDU388EqhcusVYDKpeZUc
	return s
static func __5f0RrQR56jqvrh4Tz8mXvqyN(__38kxWbJXPaeQ9qXeXrbRkWTy: int, points: int, __J7Qu5tP0Q9nZ4HEaUImAa6b8: PackedInt32Array) -> PackedByteArray:
	var w: ___HSJtJROYvDLx1pHFzP6FQy7 = __VIgqbuKG4yGJ9ext2i7dK6BX(__CdV0n6xWgKGDNjI9uUDUqWPZ).__TpSdeHcFBcJ91Kb7d42DsKVx(__38kxWbJXPaeQ9qXeXrbRkWTy).__TpSdeHcFBcJ91Kb7d42DsKVx(points).__vlQDTtuyQZ3KmvKohFfizJCm(__J7Qu5tP0Q9nZ4HEaUImAa6b8.size())
	for r: int in __J7Qu5tP0Q9nZ4HEaUImAa6b8:
		w.__Jy2hcMM9emCF3iBBkLMyeUr7(r)
	return w.data
const __CVGI5VRieG3AtLLmAeCFQ3Yb: = 2
const __Bub326MOLqfVGhpPwJu0keSE: = 4
const __EaNyg5Yg3rjJDbZsQnJHnegM: = 6
const __cOSPeWooT0bO7h8VvPzjZShH: = 4
static func __jx52K0fsGItWa4CN83U1DY2k(source: int, __0RiJ6O1RiMKr23y9VDSSBDB8: int, __wZo10zpzSPgYKFaF2bTZvf08: int, __G_0F7tS7WQtO1sE1gketMHdv: int) -> PackedByteArray:
	return __VIgqbuKG4yGJ9ext2i7dK6BX(__ZWd6BeQKciN3ZxA9r5jxHDSU).__vlQDTtuyQZ3KmvKohFfizJCm(source).__TpSdeHcFBcJ91Kb7d42DsKVx(__0RiJ6O1RiMKr23y9VDSSBDB8).__TpSdeHcFBcJ91Kb7d42DsKVx(__wZo10zpzSPgYKFaF2bTZvf08).__pGLr1ud1V6XsMMJoSyeTRFjY(maxi(__G_0F7tS7WQtO1sE1gketMHdv, 0)).data
