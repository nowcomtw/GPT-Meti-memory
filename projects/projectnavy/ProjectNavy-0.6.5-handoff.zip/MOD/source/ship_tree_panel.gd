class_name __EpTvmaXol3cFft69bdnVvE47
extends __F4kscdCfLUw02HL8Nfie7uTc
const __yO1Lglqk7J7DUp9DxXfB8fWD: = {1: {1005: Vector2(1242, 263), 
		1024: Vector2(1633, 126), 
		1010: Vector2(1902, 191), 1011: Vector2(2049, 191), 1015: Vector2(2246, 191), 1041: Vector2(2440, 191), 1016: Vector2(1444, 326), 1017: Vector2(1556, 326), }, 2: __Hjm6R1jtaT1xwCmhpATRuATr, 3: {3006: Vector2(1869, 72), 
		3007: Vector2(2076, 144), 3008: Vector2(2205, 144), 3025: Vector2(2331, 72), 3040: Vector2(2500, 72), 3024: Vector2(2331, 216), 3041: Vector2(2500, 216), 3042: Vector2(1226, 0), 
		3043: Vector2(1346, 0), 3044: Vector2(1466, 0), 3046: Vector2(1586, 0), 3051: Vector2(1706, 0), 3054: Vector2(1826, 0), 3017: Vector2(1750, 216), 3018: Vector2(1950, 216), 3020: Vector2(1336, 318), 3021: Vector2(1642, 318), 3023: Vector2(2139, 318), 
	}, 4: {4014: Vector2(613, 267), 4003: Vector2(1240, 194), 4004: Vector2(1736, 194), 4005: Vector2(2021, 194), 4008: Vector2(1861, 259), 4009: Vector2(2180, 259), 
		4010: Vector2(2340, 259), 4031: Vector2(2500, 259), }, 5: {5000: Vector2(497, 137), 5023: Vector2(637, 0), 
		5007: Vector2(1101, 93), 5008: Vector2(1261, 93), 5006: Vector2(1101, 230), 5009: Vector2(1261, 230), 5005: Vector2(1101, 320), }, 6: {6011: Vector2(1744, 219), 6013: Vector2(1897, 219), 6018: Vector2(1439, 310), 
		6019: Vector2(1592, 310), 6020: Vector2(1744, 310), 6021: Vector2(1897, 310), 6022: Vector2(2067, 310), }, 7: {7011: Vector2(1483, 147), 
		7012: Vector2(1483, 233), 7013: Vector2(1631, 147), 7014: Vector2(1631, 233), 7015: Vector2(1780, 147), 7016: Vector2(1780, 233), 7017: Vector2(1963, 190), 7018: Vector2(2132, 190), 7019: Vector2(2364, 190), 7049: Vector2(1930, 330), }, }
var __CGNfsMUE0GnabGdpfqGSyfob: Dictionary = {}
const __IQdZWyyEixvFK0W8OAKH2ZWL: = 160.0
var __7zFAVsma_zV8RCsKHzdxREnM: Dictionary = {}
func __aSyxp1KfG4MofAl18eMn6YzO(__b60EkgVKrxRWRRbup1ax0t3n: float) -> void :
	__uYGIcMTFEyeAwDQb5Sc2Eqcf(__8jHhFIzUAr5Qh3zT3ac5EgAx + __b60EkgVKrxRWRRbup1ax0t3n)
var __8jHhFIzUAr5Qh3zT3ac5EgAx: float = 0.0
func __9H0f41jrKizr8pP6nX5m8H_P(__8rx19rxJ1h6QF6GW_x4f3GZ7: PackedInt32Array, __BMECNXGSV4KVpz0mXWaD1JRD: String) -> String:
	var __ur4UkZBiNAUs6uDxwQdYf0Ix: PackedStringArray = []
	for __VJI7FUCpewbqjyuj7g_FYheK: int in __8rx19rxJ1h6QF6GW_x4f3GZ7:
		__ur4UkZBiNAUs6uDxwQdYf0Ix.append("%s(Lv%d)" % [__oT6dYNbiolyPa0Da4Lqb2xbg(__VJI7FUCpewbqjyuj7g_FYheK) if __oT6dYNbiolyPa0Da4Lqb2xbg(__VJI7FUCpewbqjyuj7g_FYheK) != "—" else tr("UI_SHIPTYPE_%d" % __tA3YJLknlQFRzbdlkSywAVMu.__4ZkPKa8dk6pXR1groh01Zac6(__VJI7FUCpewbqjyuj7g_FYheK).get("kind", 0)), __tA3YJLknlQFRzbdlkSywAVMu.__zMZVCIoyJu5zkEI6YyKqPDoG(__VJI7FUCpewbqjyuj7g_FYheK)])
	return "、".join(__ur4UkZBiNAUs6uDxwQdYf0Ix) if not __ur4UkZBiNAUs6uDxwQdYf0Ix.is_empty() else __BMECNXGSV4KVpz0mXWaD1JRD
const __6UjHK0F4IBugLhD7xP6fOnQi: Array[int] = [70, 500 + __UPKvaWL4ubJihOsi1A7J9jvQ, int(__kD5MpGbGI03ItQXuZAiXJBoV.y) - 42]
func __CZA8UWgsopmsIeXICgIcqX4g(__7PmcWSRi14ewkju8OfUPWQcV: Dictionary) -> String:
	var __Q3y2WW0UkYU7lVF_wkpqlFQz: PackedInt32Array = __7PmcWSRi14ewkju8OfUPWQcV["rows"]
	var __0B2LaQ4m2cAaURVmKZYkZIvc: int = 999
	var __qtauS4nVZpiz__2C0SN4bcXc: int = 0
	for r: int in __Q3y2WW0UkYU7lVF_wkpqlFQz:
		var __R2Vbk29AkAPWPgOO3u_8km0J: int = App.___qFCN2viGM2bPW1uGV9qys9h().__Jy2hcMM9emCF3iBBkLMyeUr7("Frame", r, 14) >> 4
		__0B2LaQ4m2cAaURVmKZYkZIvc = mini(__0B2LaQ4m2cAaURVmKZYkZIvc, __R2Vbk29AkAPWPgOO3u_8km0J)
		__qtauS4nVZpiz__2C0SN4bcXc = maxi(__qtauS4nVZpiz__2C0SN4bcXc, __R2Vbk29AkAPWPgOO3u_8km0J)
	return tr("UI_TREE_INFO_VARIANTS") % [__Q3y2WW0UkYU7lVF_wkpqlFQz.size(), __0B2LaQ4m2cAaURVmKZYkZIvc, __qtauS4nVZpiz__2C0SN4bcXc] if __Q3y2WW0UkYU7lVF_wkpqlFQz.size() > 1 else tr("UI_TREE_INFO_ONE")
const __RqTDnwyecWbU0bDNzK56lunq: = 470.0 + __UPKvaWL4ubJihOsi1A7J9jvQ
var __3G2EleNncFbT73ABKxzc2Abl: int = -1
const __9XLl9ikm8uBv78Rf3vp5xt28: = 14.0
func __Q9Oc30iMofjH1buwGLb7yblN() -> void :
	var __v0T2l_Nxw3HrwWCPJEuolYL0: = ColorRect.new()
	__v0T2l_Nxw3HrwWCPJEuolYL0.color = __l0ljxOzuGuAaMAg0E9tYqY8N.__uM0syOiZSyAoYRI1egXEgPRF
	__v0T2l_Nxw3HrwWCPJEuolYL0.position = Vector2(14, 512 + __UPKvaWL4ubJihOsi1A7J9jvQ)
	__v0T2l_Nxw3HrwWCPJEuolYL0.size = Vector2(230, 112)
	__v0T2l_Nxw3HrwWCPJEuolYL0.mouse_filter = Control.MOUSE_FILTER_IGNORE
	__2rdl1YpQzYXJobnYMjl8amhK.add_child(__v0T2l_Nxw3HrwWCPJEuolYL0)
	__i02B4nCpLC9xuqT7msHCjvDL = TextureRect.new()
	__i02B4nCpLC9xuqT7msHCjvDL.position = __v0T2l_Nxw3HrwWCPJEuolYL0.position + Vector2(8, 8)
	__i02B4nCpLC9xuqT7msHCjvDL.size = __v0T2l_Nxw3HrwWCPJEuolYL0.size - Vector2(16, 16)
	__i02B4nCpLC9xuqT7msHCjvDL.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	__i02B4nCpLC9xuqT7msHCjvDL.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	__i02B4nCpLC9xuqT7msHCjvDL.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	__i02B4nCpLC9xuqT7msHCjvDL.mouse_filter = Control.MOUSE_FILTER_IGNORE
	__2rdl1YpQzYXJobnYMjl8amhK.add_child(__i02B4nCpLC9xuqT7msHCjvDL)
	__gC1zPlqz5v_1L5pliw4Z0Svb = __2rdl1YpQzYXJobnYMjl8amhK.label("", Vector2(14, 630 + __UPKvaWL4ubJihOsi1A7J9jvQ), 230, 15, __eBt5HIxcCIYFCRhcyd21idU2.__pCUi6LToFPukNiGDrBwJ7It8, HORIZONTAL_ALIGNMENT_CENTER)
	__XDKYfcjLQpvmicqs5TqW3O8u = __2rdl1YpQzYXJobnYMjl8amhK.label("", Vector2(262, 508 + __UPKvaWL4ubJihOsi1A7J9jvQ), 1000, 18, __eBt5HIxcCIYFCRhcyd21idU2.GOLD)
	__peoLgTGuzvWj0WDw7zAm_HI7 = __2rdl1YpQzYXJobnYMjl8amhK.label("", Vector2(262, 536 + __UPKvaWL4ubJihOsi1A7J9jvQ), 1000, 15, __eBt5HIxcCIYFCRhcyd21idU2.__kVYXi_NVoyPvuzc3ek8hOGFd)
	for __uGYbOBgzaQ35WAW7tOlPBoa2: int in 3:
		__Nbd3H6lvD8lJBjV8qBcfTFCD.append(__2rdl1YpQzYXJobnYMjl8amhK.label("", Vector2(262 + 250 * __uGYbOBgzaQ35WAW7tOlPBoa2, 566 + __UPKvaWL4ubJihOsi1A7J9jvQ), 240, 15, __eBt5HIxcCIYFCRhcyd21idU2.__pCUi6LToFPukNiGDrBwJ7It8))
	__oj4mqFhi5A5BWAaWJQgKSsN7 = __2rdl1YpQzYXJobnYMjl8amhK.label("", Vector2(262, 592 + __UPKvaWL4ubJihOsi1A7J9jvQ), 1000, 15, __eBt5HIxcCIYFCRhcyd21idU2.__pCUi6LToFPukNiGDrBwJ7It8)
	__s_dp1PV1ZQeq_9bUR65dXRdy = __2rdl1YpQzYXJobnYMjl8amhK.label("", Vector2(262, 618 + __UPKvaWL4ubJihOsi1A7J9jvQ), 1000, 15, __eBt5HIxcCIYFCRhcyd21idU2.__kVYXi_NVoyPvuzc3ek8hOGFd)
	__oB2yEFEuGibCQxo2ytnKyADt = __2rdl1YpQzYXJobnYMjl8amhK.label("", Vector2(262, 644 + __UPKvaWL4ubJihOsi1A7J9jvQ), 1000, 15, __eBt5HIxcCIYFCRhcyd21idU2.__kVYXi_NVoyPvuzc3ek8hOGFd)
	__zWQiX_2p5LKJRSHBdJUzf4QG = __2rdl1YpQzYXJobnYMjl8amhK.label("", Vector2(262, 676 + __UPKvaWL4ubJihOsi1A7J9jvQ), 1000, 16, __eBt5HIxcCIYFCRhcyd21idU2.__kVYXi_NVoyPvuzc3ek8hOGFd)
var __0fHPzMlQv27ABFeQyDnKFBaV: = PackedInt32Array()
func __NOoHQWeQstODfJ4ytv2640a7(id: int) -> String:
	var __fa_Vd5HZrnG7YlQbD3mJArUm: int = __rFOA9iuI1K5SHwXmfDjEJczZ(id)
	return App.__pfG_u2ARk43BVzB84_fO3y03(__fa_Vd5HZrnG7YlQbD3mJArUm) if __fa_Vd5HZrnG7YlQbD3mJArUm >= 0 else "%s Lv%d" % [tr("UI_SHIPTYPE_%d" % __tA3YJLknlQFRzbdlkSywAVMu.__4ZkPKa8dk6pXR1groh01Zac6(id).get("kind", 0)), __tA3YJLknlQFRzbdlkSywAVMu.__zMZVCIoyJu5zkEI6YyKqPDoG(id)]
const __kD5MpGbGI03ItQXuZAiXJBoV: = Vector2(1280, 848)
var __bqK_idCcXGYTI0P2vgfE8IQ0: float = 0.0
var __G36KpkVfWAyk3hXY8SQmwGZB: Callable
var __zWQiX_2p5LKJRSHBdJUzf4QG: Label
var __uuuxgupqkgEzxTpoE6SdwwKh: float = 0.0
func __YNjSGlrkuU4xu5LIhzsrDpM7() -> void :
	zoom = 1.0
	__2rdl1YpQzYXJobnYMjl8amhK.size = __kD5MpGbGI03ItQXuZAiXJBoV
	__tA3YJLknlQFRzbdlkSywAVMu = __1OkQgYNA0NkvkBligBeQgZWC.__x4dRhV0emeOXyfnjujX6iOAP()
	var back: = __Yhtjf6iNuuOlPMKYYcWPcH_E.__z3gRH6PysI2uTsBRMQHzukNF.new()
	back.size = __kD5MpGbGI03ItQXuZAiXJBoV
	back.__GD_Tb7il6TQtKgcYWL0lZFKw = __6UjHK0F4IBugLhD7xP6fOnQi
	__2rdl1YpQzYXJobnYMjl8amhK.add_child(back)
	__2rdl1YpQzYXJobnYMjl8amhK.label(tr("UI_TREE_HEAD"), Vector2(12, 2), 400, 17, __eBt5HIxcCIYFCRhcyd21idU2.GOLD)
	var x: Button = __yDUDnCjoYKMLR7KGcyuw646g("×", Rect2(__kD5MpGbGI03ItQXuZAiXJBoV.x - 30, 3, 22, 20), tr("UI_CLOSE"), 13)
	x.pressed.connect(close)
	__PudGT1yEyP_Y9pRFG9XhUyqX()
	var __MQyRSqwwzX0eb59jBleZT7uH: String = tr("UI_TREE_BROWSE")
	if __V0pOn5Sa7N2eQmRM4kwRkT34 != null:
		__MQyRSqwwzX0eb59jBleZT7uH = tr("UI_TREE_CAPTAIN") % [__V0pOn5Sa7N2eQmRM4kwRkT34.name, __V0pOn5Sa7N2eQmRM4kwRkT34.__zMZVCIoyJu5zkEI6YyKqPDoG, tr(__o4BlGoLwjfAD3TYKD8Kt7FzU.__yDkbANaLPj6K2iCfn8NT3Pwn[__PKRImGY1KxWU8ghmieSZj6XL()])]
	__QLqCezf568KTQKD49yiUs15p = __2rdl1YpQzYXJobnYMjl8amhK.label(__MQyRSqwwzX0eb59jBleZT7uH, Vector2(__kD5MpGbGI03ItQXuZAiXJBoV.x - 480, 40), 466, 15, __eBt5HIxcCIYFCRhcyd21idU2.__pCUi6LToFPukNiGDrBwJ7It8, HORIZONTAL_ALIGNMENT_RIGHT)
	__CgtEZnFtJYvrLjlSjFnhNN9n = __XYg83Yy22e04t4nKLwvserEn.new()
	__CgtEZnFtJYvrLjlSjFnhNN9n.__HXU7Jlkt8AqP8lBeKYq6ifHH = self
	__CgtEZnFtJYvrLjlSjFnhNN9n.position = __Mbvrjae1TMaO7yDyLz1guDIf.position
	__CgtEZnFtJYvrLjlSjFnhNN9n.size = __Mbvrjae1TMaO7yDyLz1guDIf.size
	__2rdl1YpQzYXJobnYMjl8amhK.add_child(__CgtEZnFtJYvrLjlSjFnhNN9n)
	__wdwmWtKigWF9FpVnmu4AABfx = __KTjsDKKpwmVdZOgY6u7Cvm6L.new()
	__wdwmWtKigWF9FpVnmu4AABfx.__HXU7Jlkt8AqP8lBeKYq6ifHH = self
	__wdwmWtKigWF9FpVnmu4AABfx.position = __uZsUn6KOOVv_qJLmAUYOaxgm.position
	__wdwmWtKigWF9FpVnmu4AABfx.size = __uZsUn6KOOVv_qJLmAUYOaxgm.size
	__2rdl1YpQzYXJobnYMjl8amhK.add_child(__wdwmWtKigWF9FpVnmu4AABfx)
	__1MChwptsDlw4DM2mqLlPoJF9()
	__Q9Oc30iMofjH1buwGLb7yblN()
	__9FBW8FJ6Zu6TagX2GoAtj_GJ = __2rdl1YpQzYXJobnYMjl8amhK.label("", Vector2(14, __kD5MpGbGI03ItQXuZAiXJBoV.y - 30), 640, 15, __eBt5HIxcCIYFCRhcyd21idU2.__kVYXi_NVoyPvuzc3ek8hOGFd)
	if __V0pOn5Sa7N2eQmRM4kwRkT34 != null:
		_reset = __yDUDnCjoYKMLR7KGcyuw646g("重置／轉籍（%d 海點）" % __M0ImV248NGNrBFXy9NCs5jwX.meti_nation_fee(), Rect2(__kD5MpGbGI03ItQXuZAiXJBoV.x - 520, __kD5MpGbGI03ItQXuZAiXJBoV.y - 35, 220, 28), "", 15)
		_reset.pressed.connect(__bnnbkfyQ1qeZ69UBa61Bbm8y)
	__KeZdsKW86rRuZW68Ov4YLv1z = __yDUDnCjoYKMLR7KGcyuw646g(tr("UI_TREE_SET_NEXT") if __V0pOn5Sa7N2eQmRM4kwRkT34 != null else tr("UI_OK"), Rect2(__kD5MpGbGI03ItQXuZAiXJBoV.x - 290, __kD5MpGbGI03ItQXuZAiXJBoV.y - 35, 136, 28), "", 15)
	__KeZdsKW86rRuZW68Ov4YLv1z.pressed.connect(__mbOiCnB2RrUGG8KxpVIpv81O)
	var __UcKHtktAtntvsmZIWWhvgqYT: Button = __yDUDnCjoYKMLR7KGcyuw646g(tr("UI_CANCEL"), Rect2(__kD5MpGbGI03ItQXuZAiXJBoV.x - 146, __kD5MpGbGI03ItQXuZAiXJBoV.y - 35, 132, 28), "", 15)
	__UcKHtktAtntvsmZIWWhvgqYT.pressed.connect(close)
	var page: int = 0
	if __V0pOn5Sa7N2eQmRM4kwRkT34 != null:
		page = __tA3YJLknlQFRzbdlkSywAVMu.__V9nPx6hwHXTjiZSit4R51eP0(__V0pOn5Sa7N2eQmRM4kwRkT34.__hJTRC1qsUs9T0VQkseYzTT2f)
	elif __1AYlOkDoqEZYtnyO5Wh7izOL >= 0 and __tA3YJLknlQFRzbdlkSywAVMu.__egBhFKhVbnr7KydxNtWKHc9D(__1AYlOkDoqEZYtnyO5Wh7izOL) >= 0:
		page = __tA3YJLknlQFRzbdlkSywAVMu.__V9nPx6hwHXTjiZSit4R51eP0(__tA3YJLknlQFRzbdlkSywAVMu.__egBhFKhVbnr7KydxNtWKHc9D(__1AYlOkDoqEZYtnyO5Wh7izOL))
		__3G2EleNncFbT73ABKxzc2Abl = __tA3YJLknlQFRzbdlkSywAVMu.__egBhFKhVbnr7KydxNtWKHc9D(__1AYlOkDoqEZYtnyO5Wh7izOL) if __tA3YJLknlQFRzbdlkSywAVMu.__ODueSvGeVnWggM8WyoKBoh4p(__tA3YJLknlQFRzbdlkSywAVMu.__egBhFKhVbnr7KydxNtWKHc9D(__1AYlOkDoqEZYtnyO5Wh7izOL)) else -1
	if __Se4EsxPBCHX48h1ZS5MexaMl.__G8VgBybQlmXf2sdRasT3PwJT(page) and __V0pOn5Sa7N2eQmRM4kwRkT34 == null:
		page = 0
	__7iPv3fagAvvFQM0udNBU4yIt(page if __tA3YJLknlQFRzbdlkSywAVMu.__nU_ZBSdegePOEAGC3cjQdjId.has(page) else 0)
var __peoLgTGuzvWj0WDw7zAm_HI7: Label
var __XDKYfcjLQpvmicqs5TqW3O8u: Label
var __Rhhlz0qFeRa29QobnY5FwhOB: Dictionary = {}
var __kZRo5hLw1Xzbj2_k4lru7KaM: Array[Dictionary] = []
class __XYg83Yy22e04t4nKLwvserEn extends Control:
	const __FZypoysBpi4L67LAu9AxsRfZ: = Color(0.02, 0.05, 0.09, 0.9)
	const __4TXNQmPmL58fqy3BNfVpq4qa: = Color(0.4, 0.52, 0.64, 0.55)
	const __8qgH9KwiSxrsf_ErSjLXcqrI: = Color(0.47, 0.86, 0.55, 0.75)
	const __MoNdwUZ8Zh5mwyI_LVIPrg7B: = Color(0.35, 0.67, 1.0, 0.95)
	var __HXU7Jlkt8AqP8lBeKYq6ifHH: __EpTvmaXol3cFft69bdnVvE47
	var __6il7SLQy3wj5Gpk7gV2XUC8q: Dictionary = {}
	func _init() -> void :
		mouse_filter = Control.MOUSE_FILTER_STOP
		clip_contents = true
	func _gui_input(__14fCL4uMErFd82lFHTH5uFYB: InputEvent) -> void :
		__HXU7Jlkt8AqP8lBeKYq6ifHH.__ajlrd4qrcydchG4hnZxhyWxS(__14fCL4uMErFd82lFHTH5uFYB)
		accept_event()
	func _notification(__jPrJGVErK3v5rfzptOhCGUPN: int) -> void :
		if __jPrJGVErK3v5rfzptOhCGUPN == NOTIFICATION_MOUSE_EXIT and __HXU7Jlkt8AqP8lBeKYq6ifHH != null:
			__HXU7Jlkt8AqP8lBeKYq6ifHH.__0K3boQo4jAjlTlUv_yvA7nWV(-1)
	func _draw() -> void :
		var __s1EGrCUvJu2mw1EcidjH3Mj7: __EpTvmaXol3cFft69bdnVvE47 = __HXU7Jlkt8AqP8lBeKYq6ifHH
		draw_rect(Rect2(Vector2.ZERO, size), __FZypoysBpi4L67LAu9AxsRfZ)
		var __zgWqhRvPrgu6zxgCFtRvs95l: = Vector2( - __s1EGrCUvJu2mw1EcidjH3Mj7.__8jHhFIzUAr5Qh3zT3ac5EgAx, 0)
		var __4C4NYhFKxqiHIJ79od7fLQQ0: int = __s1EGrCUvJu2mw1EcidjH3Mj7.__V0pOn5Sa7N2eQmRM4kwRkT34.__hJTRC1qsUs9T0VQkseYzTT2f if __s1EGrCUvJu2mw1EcidjH3Mj7.__V0pOn5Sa7N2eQmRM4kwRkT34 != null else -1
		for __lpq7ERJlAE0Ia_GYHr8q84O5: int in 2:
			for __V1Q4GtJJsejRBMcF4wgYdclE: Vector2i in __s1EGrCUvJu2mw1EcidjH3Mj7.__5yBGFNKsDRQDr1cjLAgOjNbs:
				var __LYLPC_DSOBXJ0rRK2UuMse5b: Color = __4TXNQmPmL58fqy3BNfVpq4qa
				if __V1Q4GtJJsejRBMcF4wgYdclE.x == __4C4NYhFKxqiHIJ79od7fLQQ0 and __s1EGrCUvJu2mw1EcidjH3Mj7.__ZVOE41xwJRsjhrjTSZFfXxdK.has(__V1Q4GtJJsejRBMcF4wgYdclE.y):
					__LYLPC_DSOBXJ0rRK2UuMse5b = __MoNdwUZ8Zh5mwyI_LVIPrg7B
				elif __s1EGrCUvJu2mw1EcidjH3Mj7.__0fHPzMlQv27ABFeQyDnKFBaV.has(__V1Q4GtJJsejRBMcF4wgYdclE.x) and __s1EGrCUvJu2mw1EcidjH3Mj7.__0fHPzMlQv27ABFeQyDnKFBaV.has(__V1Q4GtJJsejRBMcF4wgYdclE.y):
					__LYLPC_DSOBXJ0rRK2UuMse5b = __8qgH9KwiSxrsf_ErSjLXcqrI
				if (__LYLPC_DSOBXJ0rRK2UuMse5b == __4TXNQmPmL58fqy3BNfVpq4qa) != (__lpq7ERJlAE0Ia_GYHr8q84O5 == 0):
					continue
				var a: Rect2 = __s1EGrCUvJu2mw1EcidjH3Mj7.__CGNfsMUE0GnabGdpfqGSyfob[__V1Q4GtJJsejRBMcF4wgYdclE.x]
				var b: Rect2 = __s1EGrCUvJu2mw1EcidjH3Mj7.__CGNfsMUE0GnabGdpfqGSyfob[__V1Q4GtJJsejRBMcF4wgYdclE.y]
				a.position += __zgWqhRvPrgu6zxgCFtRvs95l
				b.position += __zgWqhRvPrgu6zxgCFtRvs95l
				var __pD_bVujDUEvxUBnkHN38ppe7: float = floorf(a.get_center().y) + 0.5
				var __iHeFtt_WO3MOsPMJZ0lI9RWt: float = floorf(b.get_center().y) + 0.5
				if b.position.x < a.end.x + 8:
					var __jURDzjmHOIOSEUqcsNBQGJCM: float = floorf(a.get_center().x) + 0.5
					if __jURDzjmHOIOSEUqcsNBQGJCM < b.position.x:
						var __bBGPaaLHNXbFJPteNwS1yM4k: float = a.end.y if __iHeFtt_WO3MOsPMJZ0lI9RWt > __pD_bVujDUEvxUBnkHN38ppe7 else a.position.y
						draw_polyline(PackedVector2Array([Vector2(__jURDzjmHOIOSEUqcsNBQGJCM, __bBGPaaLHNXbFJPteNwS1yM4k), Vector2(__jURDzjmHOIOSEUqcsNBQGJCM, __iHeFtt_WO3MOsPMJZ0lI9RWt), Vector2(b.position.x, __iHeFtt_WO3MOsPMJZ0lI9RWt)]), __LYLPC_DSOBXJ0rRK2UuMse5b, 1.0 if __LYLPC_DSOBXJ0rRK2UuMse5b == __4TXNQmPmL58fqy3BNfVpq4qa else 2.0)
					else:
						draw_line(Vector2(a.end.x, __pD_bVujDUEvxUBnkHN38ppe7), Vector2(b.position.x, __iHeFtt_WO3MOsPMJZ0lI9RWt), __LYLPC_DSOBXJ0rRK2UuMse5b, 1.0)
					continue
				var __kjFVsuUDNkOrZQhbWPG6bjHs: float = floorf(a.end.x + minf(14.0, (b.position.x - a.end.x) / 2)) + 0.5
				draw_polyline(PackedVector2Array([Vector2(a.end.x, __pD_bVujDUEvxUBnkHN38ppe7), Vector2(__kjFVsuUDNkOrZQhbWPG6bjHs, __pD_bVujDUEvxUBnkHN38ppe7), Vector2(__kjFVsuUDNkOrZQhbWPG6bjHs, __iHeFtt_WO3MOsPMJZ0lI9RWt), Vector2(b.position.x, __iHeFtt_WO3MOsPMJZ0lI9RWt)]), __LYLPC_DSOBXJ0rRK2UuMse5b, 1.0 if __LYLPC_DSOBXJ0rRK2UuMse5b == __4TXNQmPmL58fqy3BNfVpq4qa else 2.0)
		var font: Font = get_theme_default_font()
		for __pGxIA615zSWrec6W13vGwA8W: Dictionary in __s1EGrCUvJu2mw1EcidjH3Mj7.__kZRo5hLw1Xzbj2_k4lru7KaM:
			var id: int = int(__pGxIA615zSWrec6W13vGwA8W["id"])
			var r: Rect2 = __s1EGrCUvJu2mw1EcidjH3Mj7.__CGNfsMUE0GnabGdpfqGSyfob[id]
			r.position += __zgWqhRvPrgu6zxgCFtRvs95l
			if r.end.x < 0 or r.position.x > size.x:
				continue
			__A_PYbcqVqKcQrhFITwK2vCS9(__s1EGrCUvJu2mw1EcidjH3Mj7, __pGxIA615zSWrec6W13vGwA8W, id, r, font)
	func __A_PYbcqVqKcQrhFITwK2vCS9(__ycss0Jl8ybWmxJID6q72iFke: __EpTvmaXol3cFft69bdnVvE47, __ukCNLo5ZS7ZHKu8GvRs2Km4O: Dictionary, id: int, r: Rect2, font: Font) -> void :
		var __p4dsTz_kZpAeuJKhZV1u8QFz: String = __ycss0Jl8ybWmxJID6q72iFke.__rW1zPp1wrYbIT7iDk7RnW7x3(id)
		var fill: Color = __l0ljxOzuGuAaMAg0E9tYqY8N.__uM0syOiZSyAoYRI1egXEgPRF
		var __PMW7ZZKUq9JhCMnMpPSrs29q: Color = __l0ljxOzuGuAaMAg0E9tYqY8N.__IBVvKw1yASSe7F4G5OVPjjdj
		var a: float = 1.0
		match __p4dsTz_kZpAeuJKhZV1u8QFz:
			"current":
				fill = Color(0.3, 0.24, 0.08, 0.97)
				__PMW7ZZKUq9JhCMnMpPSrs29q = __eBt5HIxcCIYFCRhcyd21idU2.GOLD
			"next":
				fill = Color(0.06, 0.17, 0.32, 0.97)
				__PMW7ZZKUq9JhCMnMpPSrs29q = __EpTvmaXol3cFft69bdnVvE47.__tYvQyGhsF2ohufSvuEcdidli
			"next_low":
				__PMW7ZZKUq9JhCMnMpPSrs29q = __eBt5HIxcCIYFCRhcyd21idU2.__PDJ2eYH1RM56AXV47Yaop2B3
				a = __EpTvmaXol3cFft69bdnVvE47.__2OOf0uypilGWVcnMsh8itBxn
			"past":
				fill = Color(0.06, 0.16, 0.13, 0.97)
				__PMW7ZZKUq9JhCMnMpPSrs29q = Color(__eBt5HIxcCIYFCRhcyd21idU2.__RIF_kToydsL5hGiT2p5OxAaC, 0.8)
			"far":
				a = __EpTvmaXol3cFft69bdnVvE47.__2OOf0uypilGWVcnMsh8itBxn
			"low":
				a = __EpTvmaXol3cFft69bdnVvE47.__aAniHMGtVitdrxNvLzWjqy24
		if id == __ycss0Jl8ybWmxJID6q72iFke.__iDNkCPxPojBek41rxB5M2Fvi or id == __ycss0Jl8ybWmxJID6q72iFke._pressed:
			fill = fill.lightened(0.15 if id == __ycss0Jl8ybWmxJID6q72iFke._pressed else 0.1)
			a = maxf(a, 0.85)
		draw_rect(r, Color(fill, fill.a * a))
		var __BxoI5bD1Lo8QcaFtuhWno3Bw: int = clampi(int(__ukCNLo5ZS7ZHKu8GvRs2Km4O["kind"]), 0, 9)
		draw_rect(Rect2(r.position + Vector2(1, 1), Vector2(r.size.x - 2, 3)), Color(__EpTvmaXol3cFft69bdnVvE47.__K9vaL9H9LmLR9lVcAl1yRVrG[__BxoI5bD1Lo8QcaFtuhWno3Bw], a))
		var __FurSq_HhJSZlHQNTBDSQIuP8: = Color(__eBt5HIxcCIYFCRhcyd21idU2.__pCUi6LToFPukNiGDrBwJ7It8, a)
		var __ReWfvZ1vYDUGzN5bZfrsCz9a: = Color(__eBt5HIxcCIYFCRhcyd21idU2.GOLD if __p4dsTz_kZpAeuJKhZV1u8QFz == "current" else __eBt5HIxcCIYFCRhcyd21idU2.__PDJ2eYH1RM56AXV47Yaop2B3 if __p4dsTz_kZpAeuJKhZV1u8QFz in ["next_low", "low"]
			else __eBt5HIxcCIYFCRhcyd21idU2.__pCUi6LToFPukNiGDrBwJ7It8, a)
		draw_string(font, r.position + Vector2(5, 17), "Lv%d" % int(__ukCNLo5ZS7ZHKu8GvRs2Km4O["level"]), HORIZONTAL_ALIGNMENT_LEFT, -1, 12, __ReWfvZ1vYDUGzN5bZfrsCz9a)
		var __grZ6ijiXnGq9sunqndOAPwiR: String = tr("UI_SHIPTYPE_%d" % __BxoI5bD1Lo8QcaFtuhWno3Bw) + ("·" + tr("UI_TREE_PORT_TAG") if bool(__ukCNLo5ZS7ZHKu8GvRs2Km4O.get("port", false)) else "")
		draw_string(font, r.position + Vector2(5, 17), __grZ6ijiXnGq9sunqndOAPwiR, HORIZONTAL_ALIGNMENT_RIGHT, r.size.x - 10, 12, Color(__eBt5HIxcCIYFCRhcyd21idU2.__kVYXi_NVoyPvuzc3ek8hOGFd, a))
		var __WfRvKr3Puh8GOY3KYJjpUYI1: Texture2D = __ycss0Jl8ybWmxJID6q72iFke.__NrwWzMvqR4x5MGvM5VpzVYE9(id)
		if __WfRvKr3Puh8GOY3KYJjpUYI1 != null:
			var __tdhbiEqiveBwA5x9Fwa_Vc3s: = Rect2(r.position + Vector2(4, 21), Vector2(r.size.x - 8, 17))
			var s: float = minf(__tdhbiEqiveBwA5x9Fwa_Vc3s.size.x / __WfRvKr3Puh8GOY3KYJjpUYI1.get_width(), __tdhbiEqiveBwA5x9Fwa_Vc3s.size.y / __WfRvKr3Puh8GOY3KYJjpUYI1.get_height())
			var __p62DAymjmlPsvwo_pB6E1_T1: Vector2 = __WfRvKr3Puh8GOY3KYJjpUYI1.get_size() * s
			draw_texture_rect(__WfRvKr3Puh8GOY3KYJjpUYI1, Rect2((__tdhbiEqiveBwA5x9Fwa_Vc3s.get_center() - __p62DAymjmlPsvwo_pB6E1_T1 / 2).round(), __p62DAymjmlPsvwo_pB6E1_T1.round()), false, Color(1, 1, 1, a))
		var __fe_DuDXG76my4EUv61oJ0hv1: Array = __gALi6M4QxSI1xID5jLbvDgl3(__ycss0Jl8ybWmxJID6q72iFke.__oT6dYNbiolyPa0Da4Lqb2xbg(id), r.size.x - 6, font)
		draw_string(font, Vector2(r.position.x + 3, r.end.y - 6), __fe_DuDXG76my4EUv61oJ0hv1[0], HORIZONTAL_ALIGNMENT_CENTER, r.size.x - 6, int(__fe_DuDXG76my4EUv61oJ0hv1[1]), __FurSq_HhJSZlHQNTBDSQIuP8)
		draw_rect(Rect2(r.position + Vector2(0.5, 0.5), r.size - Vector2.ONE), Color(__PMW7ZZKUq9JhCMnMpPSrs29q, __PMW7ZZKUq9JhCMnMpPSrs29q.a * maxf(a, 0.6)), false, 2.0 if __p4dsTz_kZpAeuJKhZV1u8QFz in ["current", "next"] else 1.0)
		if id == __ycss0Jl8ybWmxJID6q72iFke.__3G2EleNncFbT73ABKxzc2Abl:
			draw_rect(Rect2(r.position - Vector2(2.5, 2.5), r.size + Vector2(5, 5)), Color(1, 1, 1, 0.9), false, 1.0)
	func __gALi6M4QxSI1xID5jLbvDgl3(name: String, w: float, font: Font) -> Array:
		if __6il7SLQy3wj5Gpk7gV2XUC8q.has(name):
			return __6il7SLQy3wj5Gpk7gV2XUC8q[name]
		var __rviv18gjk02MEQrrk1qmjf4H: Array = []
		for __gqcmL8U0qIBl7vE7UmmmJjNk: int in [13, 12, 11]:
			if font.get_string_size(name, HORIZONTAL_ALIGNMENT_LEFT, -1, __gqcmL8U0qIBl7vE7UmmmJjNk).x <= w:
				__rviv18gjk02MEQrrk1qmjf4H = [name, __gqcmL8U0qIBl7vE7UmmmJjNk]
				break
		if __rviv18gjk02MEQrrk1qmjf4H.is_empty():
			var s: String = name
			while s.length() > 1 and font.get_string_size(s + "…", HORIZONTAL_ALIGNMENT_LEFT, -1, 11).x > w:
				s = s.left(-1)
			__rviv18gjk02MEQrrk1qmjf4H = [s + "…", 11]
		__6il7SLQy3wj5Gpk7gV2XUC8q[name] = __rviv18gjk02MEQrrk1qmjf4H
		return __rviv18gjk02MEQrrk1qmjf4H
func __mbOiCnB2RrUGG8KxpVIpv81O() -> void :
	if __KeZdsKW86rRuZW68Ov4YLv1z.disabled or __3G2EleNncFbT73ABKxzc2Abl < 0:
		return
	if __V0pOn5Sa7N2eQmRM4kwRkT34 == null:
		var __XXdHwbKI3Tg5OEVmDzQIf_13: int = __rFOA9iuI1K5SHwXmfDjEJczZ(__3G2EleNncFbT73ABKxzc2Abl)
		if __XXdHwbKI3Tg5OEVmDzQIf_13 >= 0:
			if __G36KpkVfWAyk3hXY8SQmwGZB.is_valid():
				__G36KpkVfWAyk3hXY8SQmwGZB.call(__XXdHwbKI3Tg5OEVmDzQIf_13)
			close()
		return
	var text: String = tr("UI_TREE_CONFIRM_PORT") if bool(__tA3YJLknlQFRzbdlkSywAVMu.__4ZkPKa8dk6pXR1groh01Zac6(__3G2EleNncFbT73ABKxzc2Abl).get("port", false)) else tr("UI_TREE_CONFIRM") % __NOoHQWeQstODfJ4ytv2640a7(__3G2EleNncFbT73ABKxzc2Abl)
	var __FKPPjMjFhVrqmttu1vkUlmB8: int = await UI.__Dzq5SbxUBHUUe7FLUyy2rI_S(tr("UI_TREE_TITLE"), text, [tr("UI_OK"), tr("UI_CANCEL")])
	if __FKPPjMjFhVrqmttu1vkUlmB8 != 0:
		return
	var __Z2t298tPBliVC15Iz5QgTdvG: String = __M0ImV248NGNrBFXy9NCs5jwX.__qcnliMKio6fmDg5_jGjLaiay(__V0pOn5Sa7N2eQmRM4kwRkT34, __3G2EleNncFbT73ABKxzc2Abl)
	if __Z2t298tPBliVC15Iz5QgTdvG != "":
		UI.__FZyGB2TVbKGb1g8kgT4bm_x4(__ZOmjUz5oVls_0xzdcfM71poi(__Z2t298tPBliVC15Iz5QgTdvG, __3G2EleNncFbT73ABKxzc2Abl))
		return
	__wr6C8oBxKi3NsqbLhFXJNUAz()
	UI.__Qyp4Js7J9ejl5FSF4pVpfEi5(tr("UI_TREE_DONE") % __NOoHQWeQstODfJ4ytv2640a7(__V0pOn5Sa7N2eQmRM4kwRkT34.__hJTRC1qsUs9T0VQkseYzTT2f))
	__3G2EleNncFbT73ABKxzc2Abl = -1
	__7iPv3fagAvvFQM0udNBU4yIt(__tA3YJLknlQFRzbdlkSywAVMu.__V9nPx6hwHXTjiZSit4R51eP0(__V0pOn5Sa7N2eQmRM4kwRkT34.__hJTRC1qsUs9T0VQkseYzTT2f))
func __2eaXVHyk6dOhJDgiYOaTJSj9(__3YRPQNx1XlimcmTcVNZwsh3b: Vector2) -> int:
	var __YXJVOmfXp9O92G7K7s3hHztT: Vector2 = __3YRPQNx1XlimcmTcVNZwsh3b + Vector2(__8jHhFIzUAr5Qh3zT3ac5EgAx, 0)
	for id: int in __CGNfsMUE0GnabGdpfqGSyfob:
		if (__CGNfsMUE0GnabGdpfqGSyfob[id] as Rect2).has_point(__YXJVOmfXp9O92G7K7s3hHztT):
			return id
	return -1
var __wdwmWtKigWF9FpVnmu4AABfx: __KTjsDKKpwmVdZOgY6u7Cvm6L
const __UPKvaWL4ubJihOsi1A7J9jvQ: = 96
func __NrwWzMvqR4x5MGvM5VpzVYE9(id: int) -> Texture2D:
	if not __Rhhlz0qFeRa29QobnY5FwhOB.has(id):
		var __mga9zv8iheZiMvZ1cfl2N50i: int = __rFOA9iuI1K5SHwXmfDjEJczZ(id)
		__Rhhlz0qFeRa29QobnY5FwhOB[id] = Assets.__IZAfEbUXBEkI6HaT7eD7v301(int(App.__PtNURh2PaYHMgsPlkLtni90Y().__ofKSCLcCg7jWtqacDa153ehk(__mga9zv8iheZiMvZ1cfl2N50i)["n_pack"])) if __mga9zv8iheZiMvZ1cfl2N50i >= 0 else null
	return __Rhhlz0qFeRa29QobnY5FwhOB[id]
var __V0pOn5Sa7N2eQmRM4kwRkT34: __CgOl36_UCxYZW5PzufCcS4dS
func __z70Po0o6tXuNL3BrNthR_Wkb(id: int) -> bool:
	return __CGNfsMUE0GnabGdpfqGSyfob.has(id)
func __rW1zPp1wrYbIT7iDk7RnW7x3(id: int) -> String:
	if __V0pOn5Sa7N2eQmRM4kwRkT34 == null:
		return "none"
	if id == __V0pOn5Sa7N2eQmRM4kwRkT34.__hJTRC1qsUs9T0VQkseYzTT2f:
		return "current"
	if __0fHPzMlQv27ABFeQyDnKFBaV.has(id):
		return "past"
	if __ZVOE41xwJRsjhrjTSZFfXxdK.has(id):
		return "next" if __V0pOn5Sa7N2eQmRM4kwRkT34.__zMZVCIoyJu5zkEI6YyKqPDoG >= __tA3YJLknlQFRzbdlkSywAVMu.__zMZVCIoyJu5zkEI6YyKqPDoG(id) else "next_low"
	return "low" if __V0pOn5Sa7N2eQmRM4kwRkT34.__zMZVCIoyJu5zkEI6YyKqPDoG < __tA3YJLknlQFRzbdlkSywAVMu.__zMZVCIoyJu5zkEI6YyKqPDoG(id) else "far"
const __gdQTgB7lPAjiJZcvOV5IkXj2: = 106
func __ZOmjUz5oVls_0xzdcfM71poi(__je7DvP0Wf56a4JhgDRmLVZF1: String, id: int) -> String:
	return tr(__je7DvP0Wf56a4JhgDRmLVZF1) % __tA3YJLknlQFRzbdlkSywAVMu.__zMZVCIoyJu5zkEI6YyKqPDoG(id) if __je7DvP0Wf56a4JhgDRmLVZF1 == "UI_TREE_ERR_LEVEL" else tr(__je7DvP0Wf56a4JhgDRmLVZF1)
func __XnKRKIBD2_wT4flMtUKPYgTB() -> PackedInt32Array:
	var __4t4DEdFS55Ef_1_X54trvIzI: = PackedInt32Array()
	if __V0pOn5Sa7N2eQmRM4kwRkT34 == null:
		return __4t4DEdFS55Ef_1_X54trvIzI
	for ___ZNhy_Tzpxn1_jx2RqemCgaS: int in __ZVOE41xwJRsjhrjTSZFfXxdK:
		if __V0pOn5Sa7N2eQmRM4kwRkT34.__zMZVCIoyJu5zkEI6YyKqPDoG >= __tA3YJLknlQFRzbdlkSywAVMu.__zMZVCIoyJu5zkEI6YyKqPDoG(___ZNhy_Tzpxn1_jx2RqemCgaS):
			__4t4DEdFS55Ef_1_X54trvIzI.append(___ZNhy_Tzpxn1_jx2RqemCgaS)
	return __4t4DEdFS55Ef_1_X54trvIzI
var __KeZdsKW86rRuZW68Ov4YLv1z: Button
var __i02B4nCpLC9xuqT7msHCjvDL: TextureRect
func __PudGT1yEyP_Y9pRFG9XhUyqX() -> void :
	for __5BLgEmUhBl8LazJpkoByMIDU: int in 9:
		if __Se4EsxPBCHX48h1ZS5MexaMl.__G8VgBybQlmXf2sdRasT3PwJT(__5BLgEmUhBl8LazJpkoByMIDU):
			continue
		var b: Button = __yDUDnCjoYKMLR7KGcyuw646g(tr("UI_TREE_OVERVIEW") if __5BLgEmUhBl8LazJpkoByMIDU == 0 else "      " + tr(__o4BlGoLwjfAD3TYKD8Kt7FzU.__yDkbANaLPj6K2iCfn8NT3Pwn[__5BLgEmUhBl8LazJpkoByMIDU]), Rect2(14 + __5BLgEmUhBl8LazJpkoByMIDU * 86, 36, 80, 28), "", 15)
		b.toggle_mode = true
		if __5BLgEmUhBl8LazJpkoByMIDU > 0:
			var __Sni0eGJ2QZRQlqW97jH5cAwp: __3CVc7kD6yGCHSiBfO0OphMVd = __3CVc7kD6yGCHSiBfO0OphMVd.new()
			__Sni0eGJ2QZRQlqW97jH5cAwp.__5SRgdq4kqUc88lslGOc_6RxY = Assets.frame(__SsYRYYrbeP8tPWeIt75IpL02, __gdQTgB7lPAjiJZcvOV5IkXj2 + __5BLgEmUhBl8LazJpkoByMIDU - 1)
			__Sni0eGJ2QZRQlqW97jH5cAwp.position = Vector2(8, 4)
			__Sni0eGJ2QZRQlqW97jH5cAwp.mouse_filter = Control.MOUSE_FILTER_IGNORE
			b.add_child(__Sni0eGJ2QZRQlqW97jH5cAwp)
		var page: int = __5BLgEmUhBl8LazJpkoByMIDU
		b.pressed.connect( func() -> void : __7iPv3fagAvvFQM0udNBU4yIt(page))
		__J27UvWwLXTali9zOZ5_GhM2s.append(b)
func __YGNUnSdEvBsIrEnjUiDfJt1N() -> float:
	return maxf(0.0, __uuuxgupqkgEzxTpoE6SdwwKh - __Mbvrjae1TMaO7yDyLz1guDIf.size.x)
var __QLqCezf568KTQKD49yiUs15p: Label
func __rFOA9iuI1K5SHwXmfDjEJczZ(id: int) -> int:
	if id < 0:
		return -1
	for r: int in __tA3YJLknlQFRzbdlkSywAVMu.__4ZkPKa8dk6pXR1groh01Zac6(id).get("rows", PackedInt32Array()):
		if App.__PtNURh2PaYHMgsPlkLtni90Y().__S427rIy8YAPI_7NTPBneiPZH(r):
			return r
	return -1
var __j60jHH8xZV0FPX_Jw8cSICSX: int = 0
var __9FBW8FJ6Zu6TagX2GoAtj_GJ: Label
var __1AYlOkDoqEZYtnyO5Wh7izOL: int = -1
func __7iPv3fagAvvFQM0udNBU4yIt(page: int) -> void :
	__j60jHH8xZV0FPX_Jw8cSICSX = page
	for __JSodlgICBoGXslh__oWg8qcr: int in __J27UvWwLXTali9zOZ5_GhM2s.size():
		__J27UvWwLXTali9zOZ5_GhM2s[__JSodlgICBoGXslh__oWg8qcr].button_pressed = __JSodlgICBoGXslh__oWg8qcr == page
		__J27UvWwLXTali9zOZ5_GhM2s[__JSodlgICBoGXslh__oWg8qcr].add_theme_color_override("font_color", __eBt5HIxcCIYFCRhcyd21idU2.GOLD if __V0pOn5Sa7N2eQmRM4kwRkT34 != null and __JSodlgICBoGXslh__oWg8qcr > 0 and __JSodlgICBoGXslh__oWg8qcr == __tA3YJLknlQFRzbdlkSywAVMu.__V9nPx6hwHXTjiZSit4R51eP0(__V0pOn5Sa7N2eQmRM4kwRkT34.__hJTRC1qsUs9T0VQkseYzTT2f) else __eBt5HIxcCIYFCRhcyd21idU2.__pCUi6LToFPukNiGDrBwJ7It8)
	__kZRo5hLw1Xzbj2_k4lru7KaM = __tA3YJLknlQFRzbdlkSywAVMu.__Uh316NjDP_K5Eeg6HjVfUgN1(page)
	var __ARRo46WSPLzcYhZPSezvKOay: Dictionary = __tA3YJLknlQFRzbdlkSywAVMu.__nU_ZBSdegePOEAGC3cjQdjId.get(page, {})
	var ___kd0shAPcn7VTOyT9LLARKyJ: float = float(__ARRo46WSPLzcYhZPSezvKOay.get("w", __Mbvrjae1TMaO7yDyLz1guDIf.size.x)) * __3QkcpPHPjKRRj4NlrtOICC5S.x
	var __i6tYy7k68YPY5AIDf9nIrTyB: float = float(__ARRo46WSPLzcYhZPSezvKOay.get("h", __Mbvrjae1TMaO7yDyLz1guDIf.size.y)) * __3QkcpPHPjKRRj4NlrtOICC5S.y
	var origin: = Vector2(__9XLl9ikm8uBv78Rf3vp5xt28, floorf((__Mbvrjae1TMaO7yDyLz1guDIf.size.y - __i6tYy7k68YPY5AIDf9nIrTyB) / 2))
	if ___kd0shAPcn7VTOyT9LLARKyJ + 2 * __9XLl9ikm8uBv78Rf3vp5xt28 < __Mbvrjae1TMaO7yDyLz1guDIf.size.x:
		origin.x = floorf((__Mbvrjae1TMaO7yDyLz1guDIf.size.x - ___kd0shAPcn7VTOyT9LLARKyJ) / 2)
	__uuuxgupqkgEzxTpoE6SdwwKh = maxf(__Mbvrjae1TMaO7yDyLz1guDIf.size.x, ___kd0shAPcn7VTOyT9LLARKyJ + 2 * __9XLl9ikm8uBv78Rf3vp5xt28)
	__CGNfsMUE0GnabGdpfqGSyfob.clear()
	var __C2GefA4S_vIRBNIpTrcavz2Q: Dictionary = __yO1Lglqk7J7DUp9DxXfB8fWD.get(page, {})
	for __Do83xsF0nDPvE4zwrspeJDhb: Dictionary in __kZRo5hLw1Xzbj2_k4lru7KaM:
		var id: int = int(__Do83xsF0nDPvE4zwrspeJDhb["id"])
		var __GWwEnKShnXY_uZqAt5zHb0Hq: Vector2 = __C2GefA4S_vIRBNIpTrcavz2Q.get(id, __Do83xsF0nDPvE4zwrspeJDhb["pos"])
		__CGNfsMUE0GnabGdpfqGSyfob[id] = Rect2((origin + __GWwEnKShnXY_uZqAt5zHb0Hq * __3QkcpPHPjKRRj4NlrtOICC5S + (__jWohe0A1qko0s_BICi5kZE4j - __PPXS_MnZQmU5lEfQ3QLAVwGm) / 2).round(), __PPXS_MnZQmU5lEfQ3QLAVwGm)
	__5yBGFNKsDRQDr1cjLAgOjNbs.clear()
	__7zFAVsma_zV8RCsKHzdxREnM.clear()
	for __3LY7guBwabY8dXDrcyR2rTty: Dictionary in __kZRo5hLw1Xzbj2_k4lru7KaM:
		var id: int = int(__3LY7guBwabY8dXDrcyR2rTty["id"])
		for __zfeH5k34PyASMU96EPLa3fqa: int in __tA3YJLknlQFRzbdlkSywAVMu.children(id):
			if __CGNfsMUE0GnabGdpfqGSyfob.has(__zfeH5k34PyASMU96EPLa3fqa):
				__5yBGFNKsDRQDr1cjLAgOjNbs.append(Vector2i(id, __zfeH5k34PyASMU96EPLa3fqa))
				if not __7zFAVsma_zV8RCsKHzdxREnM.has(__zfeH5k34PyASMU96EPLa3fqa):
					__7zFAVsma_zV8RCsKHzdxREnM[__zfeH5k34PyASMU96EPLa3fqa] = PackedInt32Array()
				(__7zFAVsma_zV8RCsKHzdxREnM[__zfeH5k34PyASMU96EPLa3fqa] as PackedInt32Array).append(id)
	__iDNkCPxPojBek41rxB5M2Fvi = -1
	var __ftRhDcZjZvmixrtbjdIRvNKd: int = -1
	if __3G2EleNncFbT73ABKxzc2Abl >= 0 and __CGNfsMUE0GnabGdpfqGSyfob.has(__3G2EleNncFbT73ABKxzc2Abl):
		__ftRhDcZjZvmixrtbjdIRvNKd = __3G2EleNncFbT73ABKxzc2Abl
	elif __V0pOn5Sa7N2eQmRM4kwRkT34 != null and __CGNfsMUE0GnabGdpfqGSyfob.has(__V0pOn5Sa7N2eQmRM4kwRkT34.__hJTRC1qsUs9T0VQkseYzTT2f):
		__ftRhDcZjZvmixrtbjdIRvNKd = __V0pOn5Sa7N2eQmRM4kwRkT34.__hJTRC1qsUs9T0VQkseYzTT2f
	__8jHhFIzUAr5Qh3zT3ac5EgAx = 0.0
	if __ftRhDcZjZvmixrtbjdIRvNKd >= 0:
		__8jHhFIzUAr5Qh3zT3ac5EgAx = (__CGNfsMUE0GnabGdpfqGSyfob[__ftRhDcZjZvmixrtbjdIRvNKd] as Rect2).get_center().x - __Mbvrjae1TMaO7yDyLz1guDIf.size.x / 2
	__uYGIcMTFEyeAwDQb5Sc2Eqcf(__8jHhFIzUAr5Qh3zT3ac5EgAx)
	__Rp0BlCS6jBaRK7BPcqggc2zT()
var __iDNkCPxPojBek41rxB5M2Fvi: int = -1
func __1MChwptsDlw4DM2mqLlPoJF9() -> void :
	var __acUmIr8ZDKsYRdxo5Lkt1Pct: float = 14.0
	for __27fIU7GCz_UYI0_n1hfeM0nx: int in range(1, 10):
		__OM8L7uOD2ossIbfuMjbStOER(Rect2(__acUmIr8ZDKsYRdxo5Lkt1Pct, __RqTDnwyecWbU0bDNzK56lunq + 5, 5, 15), __K9vaL9H9LmLR9lVcAl1yRVrG[__27fIU7GCz_UYI0_n1hfeM0nx], false)
		__2rdl1YpQzYXJobnYMjl8amhK.label(tr("UI_SHIPTYPE_%d" % __27fIU7GCz_UYI0_n1hfeM0nx), Vector2(__acUmIr8ZDKsYRdxo5Lkt1Pct + 9, __RqTDnwyecWbU0bDNzK56lunq + 1), 52, 14, __eBt5HIxcCIYFCRhcyd21idU2.__kVYXi_NVoyPvuzc3ek8hOGFd)
		__acUmIr8ZDKsYRdxo5Lkt1Pct += 62.0
	if __V0pOn5Sa7N2eQmRM4kwRkT34 == null:
		return
	__acUmIr8ZDKsYRdxo5Lkt1Pct = __kD5MpGbGI03ItQXuZAiXJBoV.x - 560.0
	for __8BqlSIdWeOPQkoZ5CmLQvYwh: Array in [[__eBt5HIxcCIYFCRhcyd21idU2.GOLD, "UI_TREE_LG_CURRENT"], [__tYvQyGhsF2ohufSvuEcdidli, "UI_TREE_LG_NEXT"], [__eBt5HIxcCIYFCRhcyd21idU2.__PDJ2eYH1RM56AXV47Yaop2B3, "UI_TREE_LG_LOW"], [__eBt5HIxcCIYFCRhcyd21idU2.__RIF_kToydsL5hGiT2p5OxAaC, "UI_TREE_LG_VISITED"]]:
		__OM8L7uOD2ossIbfuMjbStOER(Rect2(__acUmIr8ZDKsYRdxo5Lkt1Pct, __RqTDnwyecWbU0bDNzK56lunq + 4, 22, 16), __8BqlSIdWeOPQkoZ5CmLQvYwh[0], true)
		__2rdl1YpQzYXJobnYMjl8amhK.label(tr(__8BqlSIdWeOPQkoZ5CmLQvYwh[1]), Vector2(__acUmIr8ZDKsYRdxo5Lkt1Pct + 28, __RqTDnwyecWbU0bDNzK56lunq + 1), 104, 14, __eBt5HIxcCIYFCRhcyd21idU2.__kVYXi_NVoyPvuzc3ek8hOGFd)
		__acUmIr8ZDKsYRdxo5Lkt1Pct += 138.0
func __76u5qcZrFpLRULbMlHC_Gxke(id: int) -> Color:
	match __rW1zPp1wrYbIT7iDk7RnW7x3(id):
		"current":
			return __eBt5HIxcCIYFCRhcyd21idU2.GOLD
		"past":
			return __eBt5HIxcCIYFCRhcyd21idU2.__RIF_kToydsL5hGiT2p5OxAaC
		"next":
			return __tYvQyGhsF2ohufSvuEcdidli
		"next_low", "low":
			return __eBt5HIxcCIYFCRhcyd21idU2.__PDJ2eYH1RM56AXV47Yaop2B3
	return __eBt5HIxcCIYFCRhcyd21idU2.__kVYXi_NVoyPvuzc3ek8hOGFd
var __gC1zPlqz5v_1L5pliw4Z0Svb: Label
var __J27UvWwLXTali9zOZ5_GhM2s: Array[Button] = []
const __Mbvrjae1TMaO7yDyLz1guDIf: = Rect2(10, 78, 1260, 372 + __UPKvaWL4ubJihOsi1A7J9jvQ)
const __3QkcpPHPjKRRj4NlrtOICC5S: = Vector2(0.9, 1.04)
const __tYvQyGhsF2ohufSvuEcdidli: = Color8(90, 170, 255)
const __K9vaL9H9LmLR9lVcAl1yRVrG: Array[Color] = [Color8(170, 180, 190), Color8(170, 180, 190), Color8(110, 150, 255), Color8(150, 230, 230), Color8(120, 220, 140), Color8(200, 170, 110), Color8(255, 150, 80), Color8(240, 110, 100), Color8(230, 140, 220), Color8(160, 130, 255), ]
class __KTjsDKKpwmVdZOgY6u7Cvm6L extends Control:
	var __HXU7Jlkt8AqP8lBeKYq6ifHH: __EpTvmaXol3cFft69bdnVvE47
	var __ydFN87oh8mpGfq5X81oQhUNF: float = NAN
	func _init() -> void :
		mouse_filter = Control.MOUSE_FILTER_STOP
	func __oAdr6FVkVftJ_szUC7Z6ZgDK() -> Rect2:
		var __wluyN9g2UjWGHEeZ0ooVosvG: __EpTvmaXol3cFft69bdnVvE47 = __HXU7Jlkt8AqP8lBeKYq6ifHH
		var ratio: float = clampf(__EpTvmaXol3cFft69bdnVvE47.__Mbvrjae1TMaO7yDyLz1guDIf.size.x / maxf(1.0, __wluyN9g2UjWGHEeZ0ooVosvG.__uuuxgupqkgEzxTpoE6SdwwKh), 0.0, 1.0)
		var w: float = maxf(24.0, size.x * ratio)
		var __PEd3WVJ3JRorm4_eRdS0Vnxg: float = __wluyN9g2UjWGHEeZ0ooVosvG.__YGNUnSdEvBsIrEnjUiDfJt1N()
		return Rect2((size.x - w) * (__wluyN9g2UjWGHEeZ0ooVosvG.__8jHhFIzUAr5Qh3zT3ac5EgAx / __PEd3WVJ3JRorm4_eRdS0Vnxg if __PEd3WVJ3JRorm4_eRdS0Vnxg > 0 else 0.0), 0, w, size.y)
	func _gui_input(__k0K9denRMOJ5zOoGdxWwBgkh: InputEvent) -> void :
		var __zfMZVr5Euw3g2uOlMbFAG3tC: __EpTvmaXol3cFft69bdnVvE47 = __HXU7Jlkt8AqP8lBeKYq6ifHH
		var __SrBPTyX46O9dP4vwWouTiwL2: Rect2 = __oAdr6FVkVftJ_szUC7Z6ZgDK()
		if __k0K9denRMOJ5zOoGdxWwBgkh is InputEventMouseButton and (__k0K9denRMOJ5zOoGdxWwBgkh as InputEventMouseButton).button_index == MOUSE_BUTTON_LEFT:
			var ___SdDoC_DfqIjcaNuL0yPeKMz: InputEventMouseButton = __k0K9denRMOJ5zOoGdxWwBgkh
			if ___SdDoC_DfqIjcaNuL0yPeKMz.pressed:
				__ydFN87oh8mpGfq5X81oQhUNF = ___SdDoC_DfqIjcaNuL0yPeKMz.position.x - __SrBPTyX46O9dP4vwWouTiwL2.position.x if __SrBPTyX46O9dP4vwWouTiwL2.has_point(___SdDoC_DfqIjcaNuL0yPeKMz.position) else __SrBPTyX46O9dP4vwWouTiwL2.size.x / 2
				__2Hz2JOrT8zZYpgeIXfRIBhUE(___SdDoC_DfqIjcaNuL0yPeKMz.position.x)
			else:
				__ydFN87oh8mpGfq5X81oQhUNF = NAN
			accept_event()
		elif __k0K9denRMOJ5zOoGdxWwBgkh is InputEventMouseMotion and not is_nan(__ydFN87oh8mpGfq5X81oQhUNF):
			__2Hz2JOrT8zZYpgeIXfRIBhUE((__k0K9denRMOJ5zOoGdxWwBgkh as InputEventMouseMotion).position.x)
			accept_event()
		elif __k0K9denRMOJ5zOoGdxWwBgkh is InputEventMouseButton and (__k0K9denRMOJ5zOoGdxWwBgkh as InputEventMouseButton).pressed:
			__zfMZVr5Euw3g2uOlMbFAG3tC.__ajlrd4qrcydchG4hnZxhyWxS(__k0K9denRMOJ5zOoGdxWwBgkh)
	func __2Hz2JOrT8zZYpgeIXfRIBhUE(x: float) -> void :
		var __9eGKJ394TlopDeyYgbmgppR_: Rect2 = __oAdr6FVkVftJ_szUC7Z6ZgDK()
		var __Ba2JbIL1zOO1aJTghij2Lbj9: float = size.x - __9eGKJ394TlopDeyYgbmgppR_.size.x
		if __Ba2JbIL1zOO1aJTghij2Lbj9 > 0:
			__HXU7Jlkt8AqP8lBeKYq6ifHH.__uYGIcMTFEyeAwDQb5Sc2Eqcf((x - __ydFN87oh8mpGfq5X81oQhUNF) / __Ba2JbIL1zOO1aJTghij2Lbj9 * __HXU7Jlkt8AqP8lBeKYq6ifHH.__YGNUnSdEvBsIrEnjUiDfJt1N())
	func _draw() -> void :
		if __HXU7Jlkt8AqP8lBeKYq6ifHH.__YGNUnSdEvBsIrEnjUiDfJt1N() <= 0:
			return
		draw_rect(Rect2(Vector2.ZERO, size), Color(0.01, 0.03, 0.05, 1))
		draw_rect(__oAdr6FVkVftJ_szUC7Z6ZgDK(), __l0ljxOzuGuAaMAg0E9tYqY8N.__5BdrvxK7qD5BiVk_0jPZ4czq if not is_nan(__ydFN87oh8mpGfq5X81oQhUNF) else __l0ljxOzuGuAaMAg0E9tYqY8N.__IBVvKw1yASSe7F4G5OVPjjdj)
const __aAniHMGtVitdrxNvLzWjqy24: = 1.0 - 180.0 / 256.0
var __ZVOE41xwJRsjhrjTSZFfXxdK: = PackedInt32Array()
var __CgtEZnFtJYvrLjlSjFnhNN9n: __XYg83Yy22e04t4nKLwvserEn
var __Iwu8Hj5PTGtwa2aIq_AdkCa7: float = NAN
func __OM8L7uOD2ossIbfuMjbStOER(r: Rect2, __LK5P7VIs7Ed4UGSmOkNUjgXG: Color, frame: bool) -> void :
	var s: = ColorRect.new()
	s.color = Color(__LK5P7VIs7Ed4UGSmOkNUjgXG, 0.25) if frame else __LK5P7VIs7Ed4UGSmOkNUjgXG
	s.position = r.position
	s.size = r.size
	s.mouse_filter = Control.MOUSE_FILTER_IGNORE
	__2rdl1YpQzYXJobnYMjl8amhK.add_child(s)
	if frame:
		var __p1F1sA9P3iSioyiSGrWieIYU: = ReferenceRect.new()
		__p1F1sA9P3iSioyiSGrWieIYU.border_color = __LK5P7VIs7Ed4UGSmOkNUjgXG
		__p1F1sA9P3iSioyiSGrWieIYU.editor_only = false
		__p1F1sA9P3iSioyiSGrWieIYU.position = r.position
		__p1F1sA9P3iSioyiSGrWieIYU.size = r.size
		__p1F1sA9P3iSioyiSGrWieIYU.mouse_filter = Control.MOUSE_FILTER_IGNORE
		__2rdl1YpQzYXJobnYMjl8amhK.add_child(__p1F1sA9P3iSioyiSGrWieIYU)
var __oj4mqFhi5A5BWAaWJQgKSsN7: Label
var _pressed: int = -1
const __SsYRYYrbeP8tPWeIt75IpL02: = "ITPNST"
const __jWohe0A1qko0s_BICi5kZE4j: = Vector2(115, 71) * __3QkcpPHPjKRRj4NlrtOICC5S
var __Nbd3H6lvD8lJBjV8qBcfTFCD: Array[Label] = []
func __ZiW0if6K_EfjE4HoLtAO75Ln(id: int) -> String:
	match __rW1zPp1wrYbIT7iDk7RnW7x3(id):
		"none":
			return tr("UI_TREE_ST_BROWSE") if __rFOA9iuI1K5SHwXmfDjEJczZ(id) >= 0 else tr("UI_TREE_NOT_IN_CATALOG")
		"current":
			return tr("UI_TREE_ST_CURRENT")
		"past":
			return tr("UI_TREE_ST_VISITED")
		"next":
			return tr("UI_TREE_ST_NEXT")
		"next_low", "low":
			return tr("UI_TREE_ST_LEVEL") % __tA3YJLknlQFRzbdlkSywAVMu.__zMZVCIoyJu5zkEI6YyKqPDoG(id)
	return tr("UI_TREE_ST_LOCKED")
func __0K3boQo4jAjlTlUv_yvA7nWV(id: int) -> void :
	if id == __iDNkCPxPojBek41rxB5M2Fvi:
		return
	__iDNkCPxPojBek41rxB5M2Fvi = id
	__w8540MqY99cqLfqv4eq1nx1X(__mUlPYHTsShQc4ES_nFChbIiS())
	__CgtEZnFtJYvrLjlSjFnhNN9n.queue_redraw()
func __Rp0BlCS6jBaRK7BPcqggc2zT() -> void :
	if __V0pOn5Sa7N2eQmRM4kwRkT34 != null:
		__0fHPzMlQv27ABFeQyDnKFBaV = __M0ImV248NGNrBFXy9NCs5jwX.__30bFo4mrG0v_5UuwZqMhzIBK(__V0pOn5Sa7N2eQmRM4kwRkT34)
		__ZVOE41xwJRsjhrjTSZFfXxdK = __M0ImV248NGNrBFXy9NCs5jwX.__Sn0Tcqw1tUdVUvraDQFCbHi2(__V0pOn5Sa7N2eQmRM4kwRkT34)
		if __3G2EleNncFbT73ABKxzc2Abl >= 0:
			var __UERJc8QE7AgwyxOgLO3P04g0: String = __M0ImV248NGNrBFXy9NCs5jwX.__IlwOWmYpiy_XUpD8gVj6YoPh(__V0pOn5Sa7N2eQmRM4kwRkT34, __3G2EleNncFbT73ABKxzc2Abl)
			__KeZdsKW86rRuZW68Ov4YLv1z.disabled = __UERJc8QE7AgwyxOgLO3P04g0 != ""
			__9FBW8FJ6Zu6TagX2GoAtj_GJ.text = tr("UI_TREE_PICKED") % __NOoHQWeQstODfJ4ytv2640a7(__3G2EleNncFbT73ABKxzc2Abl) if __UERJc8QE7AgwyxOgLO3P04g0 == "" else __ZOmjUz5oVls_0xzdcfM71poi(__UERJc8QE7AgwyxOgLO3P04g0, __3G2EleNncFbT73ABKxzc2Abl)
		else:
			__KeZdsKW86rRuZW68Ov4YLv1z.disabled = true
			__9FBW8FJ6Zu6TagX2GoAtj_GJ.text = tr("UI_TREE_NOW") % [__NOoHQWeQstODfJ4ytv2640a7(__V0pOn5Sa7N2eQmRM4kwRkT34.__hJTRC1qsUs9T0VQkseYzTT2f), __XnKRKIBD2_wT4flMtUKPYgTB().size()]
		if __V0pOn5Sa7N2eQmRM4kwRkT34.__JMsr0yCjBlwnkO_7FV9gE93o():
			__9FBW8FJ6Zu6TagX2GoAtj_GJ.text = tr("UI_TREE_ERR_ON_SHIP")
		_reset.disabled = __V0pOn5Sa7N2eQmRM4kwRkT34.__JMsr0yCjBlwnkO_7FV9gE93o() or __M0ImV248NGNrBFXy9NCs5jwX.points < __M0ImV248NGNrBFXy9NCs5jwX.__cy8MlQEbWMnDn0W8brML_OIf()
	else:
		var __ICRySD4kQc9vT9Uq0wikAvJu: int = __rFOA9iuI1K5SHwXmfDjEJczZ(__3G2EleNncFbT73ABKxzc2Abl)
		__KeZdsKW86rRuZW68Ov4YLv1z.disabled = __ICRySD4kQc9vT9Uq0wikAvJu < 0
		if __3G2EleNncFbT73ABKxzc2Abl < 0:
			__9FBW8FJ6Zu6TagX2GoAtj_GJ.text = tr("UI_TREE_BROWSE_HINT")
		else:
			__9FBW8FJ6Zu6TagX2GoAtj_GJ.text = tr("UI_TREE_PICKED") % __NOoHQWeQstODfJ4ytv2640a7(__3G2EleNncFbT73ABKxzc2Abl) if __ICRySD4kQc9vT9Uq0wikAvJu >= 0 else tr("UI_TREE_NOT_IN_CATALOG")
	__9FBW8FJ6Zu6TagX2GoAtj_GJ.add_theme_color_override("font_color", __eBt5HIxcCIYFCRhcyd21idU2.__kVYXi_NVoyPvuzc3ek8hOGFd)
	__w8540MqY99cqLfqv4eq1nx1X(__mUlPYHTsShQc4ES_nFChbIiS())
	__CgtEZnFtJYvrLjlSjFnhNN9n.queue_redraw()
func __bnnbkfyQ1qeZ69UBa61Bbm8y() -> void :
	await meti_nation_dialog()
const __uZsUn6KOOVv_qJLmAUYOaxgm: = Rect2(10, 454 + __UPKvaWL4ubJihOsi1A7J9jvQ, 1260, 8)
var __D9brDwaa29kAcS1ksGx8WE8A: float = NAN
func __w8540MqY99cqLfqv4eq1nx1X(id: int) -> void :
	var __3aTG0l5ipRD81JzmABZgGB0D: Array[Label] = [__gC1zPlqz5v_1L5pliw4Z0Svb, __XDKYfcjLQpvmicqs5TqW3O8u, __peoLgTGuzvWj0WDw7zAm_HI7, __oj4mqFhi5A5BWAaWJQgKSsN7, __s_dp1PV1ZQeq_9bUR65dXRdy, __oB2yEFEuGibCQxo2ytnKyADt, __zWQiX_2p5LKJRSHBdJUzf4QG]
	__3aTG0l5ipRD81JzmABZgGB0D.append_array(__Nbd3H6lvD8lJBjV8qBcfTFCD)
	if id < 0 or not __tA3YJLknlQFRzbdlkSywAVMu.has(id):
		for __zcQK0GW5tgk82E5NEV5x6TOy: Label in __3aTG0l5ipRD81JzmABZgGB0D:
			__zcQK0GW5tgk82E5NEV5x6TOy.text = ""
		__i02B4nCpLC9xuqT7msHCjvDL.texture = null
		__XDKYfcjLQpvmicqs5TqW3O8u.text = tr("UI_TREE_PICK_HINT")
		return
	var __IIsAw_Rl95wr04qBNrLoLTqw: Dictionary = __tA3YJLknlQFRzbdlkSywAVMu.__4ZkPKa8dk6pXR1groh01Zac6(id)
	var __to_ItyV6cZwZi18F34KRJLXJ: int = __tA3YJLknlQFRzbdlkSywAVMu.__84QboWNqU89o1KDNdzkM79hn(id)
	var __ojoJp2ChC6K0UPDnBqUC7wM6: __bzxMmNAcE_RKMny5gklgDglw = App.___qFCN2viGM2bPW1uGV9qys9h()
	__i02B4nCpLC9xuqT7msHCjvDL.texture = __NrwWzMvqR4x5MGvM5VpzVYE9(id)
	__gC1zPlqz5v_1L5pliw4Z0Svb.text = "Lv%d　%s　%s" % [__tA3YJLknlQFRzbdlkSywAVMu.__zMZVCIoyJu5zkEI6YyKqPDoG(id), tr("UI_SHIPTYPE_%d" % int(__IIsAw_Rl95wr04qBNrLoLTqw["kind"])), tr(__o4BlGoLwjfAD3TYKD8Kt7FzU.__yDkbANaLPj6K2iCfn8NT3Pwn[clampi(__tA3YJLknlQFRzbdlkSywAVMu.__V9nPx6hwHXTjiZSit4R51eP0(id), 0, 8)])]
	__XDKYfcjLQpvmicqs5TqW3O8u.text = __NOoHQWeQstODfJ4ytv2640a7(id)
	var __b1_gMrM6DX3rlpcvPRDiGBn7: String = __CZA8UWgsopmsIeXICgIcqX4g(__IIsAw_Rl95wr04qBNrLoLTqw)
	if bool(__IIsAw_Rl95wr04qBNrLoLTqw.get("port", false)):
		__b1_gMrM6DX3rlpcvPRDiGBn7 += "　·　" + tr("UI_TREE_ST_PORT")
	__peoLgTGuzvWj0WDw7zAm_HI7.text = __b1_gMrM6DX3rlpcvPRDiGBn7
	__Nbd3H6lvD8lJBjV8qBcfTFCD[0].text = tr("UI_TREE_INFO_COST") % __ojoJp2ChC6K0UPDnBqUC7wM6.__pGLr1ud1V6XsMMJoSyeTRFjY("Frame", __to_ItyV6cZwZi18F34KRJLXJ, 112)
	__Nbd3H6lvD8lJBjV8qBcfTFCD[1].text = tr("UI_TREE_INFO_HP") % __ojoJp2ChC6K0UPDnBqUC7wM6.__pGLr1ud1V6XsMMJoSyeTRFjY("Frame", __to_ItyV6cZwZi18F34KRJLXJ, 104)
	__Nbd3H6lvD8lJBjV8qBcfTFCD[2].text = tr("UI_TREE_INFO_DISP_FULL") % __ojoJp2ChC6K0UPDnBqUC7wM6.__pGLr1ud1V6XsMMJoSyeTRFjY("Frame", __to_ItyV6cZwZi18F34KRJLXJ, 120)
	__oj4mqFhi5A5BWAaWJQgKSsN7.text = tr("UI_TREE_INFO_GUNS") % __EjrkkKgSC388MHg1ZU9x12fm(__rFOA9iuI1K5SHwXmfDjEJczZ(id))
	__s_dp1PV1ZQeq_9bUR65dXRdy.text = tr("UI_TREE_INFO_PREV") % __9H0f41jrKizr8pP6nX5m8H_P(__7zFAVsma_zV8RCsKHzdxREnM.get(id, PackedInt32Array()), "—")
	var __pORoVpYJDe0npt8H5LJTAoQ9: = PackedInt32Array()
	for __ASnUVMBOe3h5v6pKM56DBRDp: int in __tA3YJLknlQFRzbdlkSywAVMu.children(id):
		if __tA3YJLknlQFRzbdlkSywAVMu.__ODueSvGeVnWggM8WyoKBoh4p(__ASnUVMBOe3h5v6pKM56DBRDp) and (__j60jHH8xZV0FPX_Jw8cSICSX == 0 or __CGNfsMUE0GnabGdpfqGSyfob.has(__ASnUVMBOe3h5v6pKM56DBRDp)):
			__pORoVpYJDe0npt8H5LJTAoQ9.append(__ASnUVMBOe3h5v6pKM56DBRDp)
	__oB2yEFEuGibCQxo2ytnKyADt.text = tr("UI_TREE_INFO_NEXT") % __9H0f41jrKizr8pP6nX5m8H_P(__pORoVpYJDe0npt8H5LJTAoQ9, tr("UI_TREE_INFO_LEAF"))
	__zWQiX_2p5LKJRSHBdJUzf4QG.text = __ZiW0if6K_EfjE4HoLtAO75Ln(id)
	__zWQiX_2p5LKJRSHBdJUzf4QG.add_theme_color_override("font_color", __76u5qcZrFpLRULbMlHC_Gxke(id))
	__A16Bf5XHDci9_3J6mm37sq7o()
const __Hjm6R1jtaT1xwCmhpATRuATr: = {2009: Vector2(1197, 117), 
	2010: Vector2(1662, 117), 
	2011: Vector2(1842, 49), 
	2012: Vector2(1842, 117), 
	2007: Vector2(1842, 181), 
	2013: Vector2(2076, 71), 
	2014: Vector2(2076, 181), 
}
func __EjrkkKgSC388MHg1ZU9x12fm(__W_prXWRKat7H_A3vlfRfZ6aj: int) -> String:
	if not App.__PtNURh2PaYHMgsPlkLtni90Y().__S427rIy8YAPI_7NTPBneiPZH(__W_prXWRKat7H_A3vlfRfZ6aj):
		return "—"
	var count: Dictionary = {}
	var __zojjlCMxpM_thKEMk_lg4ZJb: Array[int] = []
	for g: int in App.__PtNURh2PaYHMgsPlkLtni90Y().__vTRMq3igRP2hTt2npyhiJ5UU(__W_prXWRKat7H_A3vlfRfZ6aj).__dOsDavODOasdfPxqce2DEBC3:
		if not count.has(g):
			__zojjlCMxpM_thKEMk_lg4ZJb.append(g)
		count[g] = int(count.get(g, 0)) + 1
	var __kxku9l0DJUquEn0yrnGXWaGZ: PackedStringArray = []
	for g: int in __zojjlCMxpM_thKEMk_lg4ZJb:
		var __FFzy66zDnLkMwyNIxk8H4pFf: Dictionary = App.__PtNURh2PaYHMgsPlkLtni90Y().__Y7oNU_MxqAazQR74RzaCuaOa(g)
		__kxku9l0DJUquEn0yrnGXWaGZ.append("%.1f\"×%d ×%d" % [int(__FFzy66zDnLkMwyNIxk8H4pFf.get("caliber", 0)) / 100.0, int(__FFzy66zDnLkMwyNIxk8H4pFf.get("barrels", 1)), int(count[g])])
	return "　".join(__kxku9l0DJUquEn0yrnGXWaGZ) if not __kxku9l0DJUquEn0yrnGXWaGZ.is_empty() else "—"
const __PPXS_MnZQmU5lEfQ3QLAVwGm: = Vector2(90, 54)
var _reset: Button
func __ajlrd4qrcydchG4hnZxhyWxS(__wvbXxADyadAyYytk5otNs7Cv: InputEvent) -> void :
	if __wvbXxADyadAyYytk5otNs7Cv is InputEventMouseMotion:
		var __orMhK2QECocjpqeQpVUlOPmO: InputEventMouseMotion = __wvbXxADyadAyYytk5otNs7Cv
		if is_nan(__D9brDwaa29kAcS1ksGx8WE8A) and not is_nan(__Iwu8Hj5PTGtwa2aIq_AdkCa7) and absf(__orMhK2QECocjpqeQpVUlOPmO.position.x - __bqK_idCcXGYTI0P2vgfE8IQ0) > __zAonDaqWAlH50azKWdFPcpra:
			__D9brDwaa29kAcS1ksGx8WE8A = __Iwu8Hj5PTGtwa2aIq_AdkCa7
			_pressed = -1
			__0K3boQo4jAjlTlUv_yvA7nWV(-1)
		if not is_nan(__D9brDwaa29kAcS1ksGx8WE8A):
			__uYGIcMTFEyeAwDQb5Sc2Eqcf(__D9brDwaa29kAcS1ksGx8WE8A - __orMhK2QECocjpqeQpVUlOPmO.position.x)
			return
		__0K3boQo4jAjlTlUv_yvA7nWV(__2eaXVHyk6dOhJDgiYOaTJSj9(__orMhK2QECocjpqeQpVUlOPmO.position))
	elif __wvbXxADyadAyYytk5otNs7Cv is InputEventMouseButton:
		var __r39Ruom_227x8SB38Paql0YJ: InputEventMouseButton = __wvbXxADyadAyYytk5otNs7Cv
		match __r39Ruom_227x8SB38Paql0YJ.button_index:
			MOUSE_BUTTON_WHEEL_UP, MOUSE_BUTTON_WHEEL_LEFT:
				if __r39Ruom_227x8SB38Paql0YJ.pressed:
					__aSyxp1KfG4MofAl18eMn6YzO( - __IQdZWyyEixvFK0W8OAKH2ZWL / 2)
			MOUSE_BUTTON_WHEEL_DOWN, MOUSE_BUTTON_WHEEL_RIGHT:
				if __r39Ruom_227x8SB38Paql0YJ.pressed:
					__aSyxp1KfG4MofAl18eMn6YzO(__IQdZWyyEixvFK0W8OAKH2ZWL / 2)
			MOUSE_BUTTON_RIGHT, MOUSE_BUTTON_MIDDLE:
				__D9brDwaa29kAcS1ksGx8WE8A = __8jHhFIzUAr5Qh3zT3ac5EgAx + __r39Ruom_227x8SB38Paql0YJ.position.x if __r39Ruom_227x8SB38Paql0YJ.pressed else NAN
			MOUSE_BUTTON_LEFT:
				var id: int = __2eaXVHyk6dOhJDgiYOaTJSj9(__r39Ruom_227x8SB38Paql0YJ.position)
				if __r39Ruom_227x8SB38Paql0YJ.pressed:
					__Iwu8Hj5PTGtwa2aIq_AdkCa7 = __8jHhFIzUAr5Qh3zT3ac5EgAx + __r39Ruom_227x8SB38Paql0YJ.position.x
					__bqK_idCcXGYTI0P2vgfE8IQ0 = __r39Ruom_227x8SB38Paql0YJ.position.x
				if __r39Ruom_227x8SB38Paql0YJ.double_click and id >= 0 and id == __3G2EleNncFbT73ABKxzc2Abl:
					__mbOiCnB2RrUGG8KxpVIpv81O()
				elif __r39Ruom_227x8SB38Paql0YJ.pressed:
					_pressed = id
				else:
					if is_nan(__D9brDwaa29kAcS1ksGx8WE8A) and id >= 0 and id == _pressed:
						__ib1LeDAVfmqeWT3J6wPc4WEm(id)
					_pressed = -1
					__Iwu8Hj5PTGtwa2aIq_AdkCa7 = NAN
					__D9brDwaa29kAcS1ksGx8WE8A = NAN
					__0K3boQo4jAjlTlUv_yvA7nWV(__2eaXVHyk6dOhJDgiYOaTJSj9(__r39Ruom_227x8SB38Paql0YJ.position))
				__CgtEZnFtJYvrLjlSjFnhNN9n.queue_redraw()
func __oT6dYNbiolyPa0Da4Lqb2xbg(id: int) -> String:
	var __VvOcfHMKF5Ik_rFrAZ_8U9fU: int = __rFOA9iuI1K5SHwXmfDjEJczZ(id)
	if __VvOcfHMKF5Ik_rFrAZ_8U9fU < 0:
		return "—"
	var name: String = App.__YWyGam_15HuUyuIa4REmc8J4(__VvOcfHMKF5Ik_rFrAZ_8U9fU)
	return name if name != "" else App.__AqRLmDaYMC2aA5Jk6DLdJAGf(str(App.__PtNURh2PaYHMgsPlkLtni90Y().__ofKSCLcCg7jWtqacDa153ehk(__VvOcfHMKF5Ik_rFrAZ_8U9fU)["label"]))
func __ib1LeDAVfmqeWT3J6wPc4WEm(id: int) -> void :
	if __V0pOn5Sa7N2eQmRM4kwRkT34 != null and not __XnKRKIBD2_wT4flMtUKPYgTB().has(id):
		__9FBW8FJ6Zu6TagX2GoAtj_GJ.text = __ZOmjUz5oVls_0xzdcfM71poi(__M0ImV248NGNrBFXy9NCs5jwX.__IlwOWmYpiy_XUpD8gVj6YoPh(__V0pOn5Sa7N2eQmRM4kwRkT34, id), id)
		__9FBW8FJ6Zu6TagX2GoAtj_GJ.add_theme_color_override("font_color", __eBt5HIxcCIYFCRhcyd21idU2.__PDJ2eYH1RM56AXV47Yaop2B3)
		return
	__3G2EleNncFbT73ABKxzc2Abl = id
	__Rp0BlCS6jBaRK7BPcqggc2zT()
var __tA3YJLknlQFRzbdlkSywAVMu: __1OkQgYNA0NkvkBligBeQgZWC
func __uYGIcMTFEyeAwDQb5Sc2Eqcf(x: float) -> void :
	__8jHhFIzUAr5Qh3zT3ac5EgAx = clampf(roundf(x), 0.0, __YGNUnSdEvBsIrEnjUiDfJt1N())
	__CgtEZnFtJYvrLjlSjFnhNN9n.queue_redraw()
	__wdwmWtKigWF9FpVnmu4AABfx.queue_redraw()
const __zAonDaqWAlH50azKWdFPcpra: = 4.0
var __oB2yEFEuGibCQxo2ytnKyADt: Label
func __mUlPYHTsShQc4ES_nFChbIiS() -> int:
	if __iDNkCPxPojBek41rxB5M2Fvi >= 0:
		return __iDNkCPxPojBek41rxB5M2Fvi
	if __3G2EleNncFbT73ABKxzc2Abl >= 0:
		return __3G2EleNncFbT73ABKxzc2Abl
	return __V0pOn5Sa7N2eQmRM4kwRkT34.__hJTRC1qsUs9T0VQkseYzTT2f if __V0pOn5Sa7N2eQmRM4kwRkT34 != null else -1
var __5yBGFNKsDRQDr1cjLAgOjNbs: Array[Vector2i] = []
func __PKRImGY1KxWU8ghmieSZj6XL() -> int:
	return int(__M0ImV248NGNrBFXy9NCs5jwX.__LVCMU4xMBMMHO5bxpAYeHYWt(__V0pOn5Sa7N2eQmRM4kwRkT34).get("nation", 0)) if __V0pOn5Sa7N2eQmRM4kwRkT34 != null else 0
var __s_dp1PV1ZQeq_9bUR65dXRdy: Label
const __2OOf0uypilGWVcnMsh8itBxn: = 1.0 - 100.0 / 256.0

func meti_nation_dialog() -> void :
	var captain: bool = meti_is_captain_panel()
	if __V0pOn5Sa7N2eQmRM4kwRkT34 == null:
		return
	if __V0pOn5Sa7N2eQmRM4kwRkT34.__JMsr0yCjBlwnkO_7FV9gE93o():
		UI.__FZyGB2TVbKGb1g8kgT4bm_x4("請先將水兵從船上卸下。")
		return
	var buttons: PackedStringArray = []
	for nation: int in range(1, 8):
		buttons.append(tr(__o4BlGoLwjfAD3TYKD8Kt7FzU.__yDkbANaLPj6K2iCfn8NT3Pwn[nation]))
	buttons.append(tr("UI_CANCEL"))
	var title: String = "船長重置／轉籍" if captain else "水兵轉籍／重修"
	var description: String = "選擇重置後的國家。每次 %d 海點。\n保留等級、經驗、目前能力與新兵／熟練兵／技術兵。\n%s" % [__M0ImV248NGNrBFXy9NCs5jwX.meti_nation_fee(), "保留船長兵種，清除船艦路線，從起點重新選擇。" if captain else "退回所選國家的一般水兵；保留招募加點，未來依新職業成長。"]
	var choice: int = await UI.__Dzq5SbxUBHUUe7FLUyy2rI_S(title, description, buttons, 7, true)
	if choice < 0 or choice >= 7 or not is_instance_valid(self):
		return
	var nation: int = choice + 1
	var error: String = __M0ImV248NGNrBFXy9NCs5jwX.meti_nation_error(__V0pOn5Sa7N2eQmRM4kwRkT34, nation, captain)
	if error != "":
		UI.__FZyGB2TVbKGb1g8kgT4bm_x4(error)
		return
	var confirmed: int = await UI.__Dzq5SbxUBHUUe7FLUyy2rI_S(title, "%s → %s\n費用 %d 海點。%s\n確定執行？" % [__V0pOn5Sa7N2eQmRM4kwRkT34.name, buttons[choice], __M0ImV248NGNrBFXy9NCs5jwX.meti_nation_fee(), "船艦路線將清除。" if captain else "職業將退回一般水兵；已獲得能力保留，重修不補算舊等級能力。"], [tr("UI_OK"), tr("UI_CANCEL")])
	if confirmed != 0 or not is_instance_valid(self):
		return
	error = __M0ImV248NGNrBFXy9NCs5jwX.meti_change_nation(__V0pOn5Sa7N2eQmRM4kwRkT34, nation, captain)
	if error != "":
		UI.__FZyGB2TVbKGb1g8kgT4bm_x4(error)
		return
	__wr6C8oBxKi3NsqbLhFXJNUAz()
	meti_refresh_nation(nation)
	UI.__Qyp4Js7J9ejl5FSF4pVpfEi5("轉籍／重修完成；等級、經驗與兵員已保留。")

func meti_is_captain_panel() -> bool:
	return true

func meti_refresh_nation(nation: int) -> void :
	__3G2EleNncFbT73ABKxzc2Abl = -1
	__QLqCezf568KTQKD49yiUs15p.text = "%s　Lv%d　%s" % [__V0pOn5Sa7N2eQmRM4kwRkT34.name, __V0pOn5Sa7N2eQmRM4kwRkT34.__zMZVCIoyJu5zkEI6YyKqPDoG, tr(__o4BlGoLwjfAD3TYKD8Kt7FzU.__yDkbANaLPj6K2iCfn8NT3Pwn[nation])]
	__7iPv3fagAvvFQM0udNBU4yIt(nation)
