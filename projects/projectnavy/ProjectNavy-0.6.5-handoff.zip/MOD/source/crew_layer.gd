class_name __feayI5y05J3ON9FtctrJOCuc
extends Control
func hover(__el6w4aFUYecI_sjJcYm5So4T: __CgOl36_UCxYZW5PzufCcS4dS, __lJhIWPXhg9NTQ6nMKhnjsb0a: bool) -> void :
	# Harbor hover cards obscure the replenish button; details remain in the crew list.
	if is_instance_valid(__8g95kgpxCpdLzBoCp8oJxvuo):
		__8g95kgpxCpdLzBoCp8oJxvuo.hide()

var __RBxgrwTYrjwWPO6TKeTDJ4L7: __CgOl36_UCxYZW5PzufCcS4dS
func __Qa9GbnhM8GDjcw4fKszR0Ftz() -> void :
	var __o6kwdA343JQLKP2Y8Vxj_pOF: __2eoTFZc6WxKKaBxTkxeRtmOZ = __M0ImV248NGNrBFXy9NCs5jwX.__ofKSCLcCg7jWtqacDa153ehk()
	for v: __lECVwIWsQGlXOXoSmBcDqHgZ in __im6F1LNv3SFnj65QawSewbhT.values():
		v.queue_free()
	__im6F1LNv3SFnj65QawSewbhT.clear()
	if __o6kwdA343JQLKP2Y8Vxj_pOF != null:
		for s: int in __o6kwdA343JQLKP2Y8Vxj_pOF.__zIF9v7_0wMMhvSzdUeP1IIN3():
			var v: = __lECVwIWsQGlXOXoSmBcDqHgZ.new()
			v.layer = self
			v.__q26f3dCYzrR9TyO_pwwz7lre = s
			v.position = (__o6kwdA343JQLKP2Y8Vxj_pOF.__cyedBHfqnY_omyOCjvFNnYe3[s] as Vector2) + __FCwkrbua0xeoSZDWbuuHlUku
			add_child(v)
			move_child(v, 0)
			__im6F1LNv3SFnj65QawSewbhT[s] = v
			v.bind(__M0ImV248NGNrBFXy9NCs5jwX.__ifUAqOmtFvNZXIqHYuzi470Y(s))
	__08lUaVXHUgHst0KmvRmsCf5_()
	changed.emit()
func __0XyVOCWtoL1Gf1pZelpNAy2K(__PyiJQ5LGuyvpTcnL60HR9DRJ: __CgOl36_UCxYZW5PzufCcS4dS, __BoR19BbqSPs9wZWwquStgOuf: Vector2) -> void :
	__RBxgrwTYrjwWPO6TKeTDJ4L7 = __PyiJQ5LGuyvpTcnL60HR9DRJ
	__D9brDwaa29kAcS1ksGx8WE8A = __BoR19BbqSPs9wZWwquStgOuf
	__Q0cIwMzltuxHZsWA0LuA02S1 = false
func _init() -> void :
	size = Vector2(1024, 768)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
signal __iB2UqUil5MwE5LrbAKsm0pxr(id: String, __U0NDmZ4mvxXJgU35yN51r1cj: __CgOl36_UCxYZW5PzufCcS4dS)
func __zvmw7V61TCQpYD7yYazIl9zu() -> void :
	var __vz16R_MifAMJjBl5NI3n9JFo: int = await UI.__Dzq5SbxUBHUUe7FLUyy2rI_S(tr("UI_CREW_UNLOAD"), tr("UI_CREW_UNLOAD_ASK"), [tr("UI_OK"), tr("UI_CANCEL")])
	if __vz16R_MifAMJjBl5NI3n9JFo == 0:
		__M0ImV248NGNrBFXy9NCs5jwX.__Dg5_6UDaoA9lq2iM2xl0VAM5()
		__Qa9GbnhM8GDjcw4fKszR0Ftz()
var __im6F1LNv3SFnj65QawSewbhT: Dictionary = {}
var __uVHnM5LYJpwosw8V6yXdiPaJ: Control
const __8eE2BJzDXgBAO3W41ZPWgQat: = 2.0
class __lECVwIWsQGlXOXoSmBcDqHgZ extends Control:
	var layer: __feayI5y05J3ON9FtctrJOCuc
	var __q26f3dCYzrR9TyO_pwwz7lre: int = 0
	var __V0pOn5Sa7N2eQmRM4kwRkT34: __CgOl36_UCxYZW5PzufCcS4dS
	var __dAGqnexg_IDbNw344d0sOBgZ: = __3CVc7kD6yGCHSiBfO0OphMVd.new()
	var __UjNNdwvKF0WnFNKhWc_5NU4S: = __3CVc7kD6yGCHSiBfO0OphMVd.new()
	var __xJVaHFeSo_b2KzgsOivgr9K7: __Er3qHKxcEkfUWPtjkXRE6sZ3
	var __UBhhhF6iRr94DKLQvVjANsh4: Label
	var __25piJQxHn4e8rYkbSKRQ8SPR: Button
	var __xIwzjaRnzjLSFbAf5CGpmaXo: Button
	var __h3ii5RH8ZWV2JT_zl4hvKufB: bool = false
	var __1oElkVOacHIBcLWKCKhilZGK: float = 0.0
	var __zjL6MOH4ahCRS8nD6UtPvtC5: int = 0
	var __iDNkCPxPojBek41rxB5M2Fvi: bool = false
	var __sFk8wA8QhN909E6WZxd99O46: int = 0
	func _init() -> void :
		size = Vector2(64, 72)
		mouse_filter = Control.MOUSE_FILTER_STOP
		__dAGqnexg_IDbNw344d0sOBgZ.blend = "screen"
		__UjNNdwvKF0WnFNKhWc_5NU4S.blend = "mul"
		__UjNNdwvKF0WnFNKhWc_5NU4S.__5SRgdq4kqUc88lslGOc_6RxY = Assets.frame("ITPNFS", 188)
		__UjNNdwvKF0WnFNKhWc_5NU4S.position = Vector2(0, 8)
		__dAGqnexg_IDbNw344d0sOBgZ.position = Vector2(0, 8)
		add_child(__UjNNdwvKF0WnFNKhWc_5NU4S)
		add_child(__dAGqnexg_IDbNw344d0sOBgZ)
		mouse_entered.connect( func() -> void : __0K3boQo4jAjlTlUv_yvA7nWV(true))
		mouse_exited.connect( func() -> void : __wBjZpiG1iixMTglh5jxITR3r.call_deferred())
	func bind(__hZ3wY11rr8GDand_zj_rmQRT: __CgOl36_UCxYZW5PzufCcS4dS) -> void :
		__V0pOn5Sa7N2eQmRM4kwRkT34 = __hZ3wY11rr8GDand_zj_rmQRT
		__dAGqnexg_IDbNw344d0sOBgZ.visible = __hZ3wY11rr8GDand_zj_rmQRT == null
		__UjNNdwvKF0WnFNKhWc_5NU4S.visible = __hZ3wY11rr8GDand_zj_rmQRT == null
		if __hZ3wY11rr8GDand_zj_rmQRT != null:
			var __4EihzvsfkzxZ71cH1aG0axL4: Dictionary = layer.__M0ImV248NGNrBFXy9NCs5jwX.__LVCMU4xMBMMHO5bxpAYeHYWt(__hZ3wY11rr8GDand_zj_rmQRT)
			__xJVaHFeSo_b2KzgsOivgr9K7 = __Er3qHKxcEkfUWPtjkXRE6sZ3.new()
			__xJVaHFeSo_b2KzgsOivgr9K7.position = Vector2(2, 0)
			add_child(__xJVaHFeSo_b2KzgsOivgr9K7)
			__xJVaHFeSo_b2KzgsOivgr9K7.__H8edGzuZdf8pc4sUjNkAWiOb(__4EihzvsfkzxZ71cH1aG0axL4)
			__XiZeg0Kx4bgRwLIRXsYMZBfD(int(__4EihzvsfkzxZ71cH1aG0axL4.get("nation", 0)))
			__lfKBp8D47UJPWmvjmlwt28C5(str(__4EihzvsfkzxZ71cH1aG0axL4.get("name", "")))
			__ZuEl56XypGfVHZDoWwJO_v5s(__hZ3wY11rr8GDand_zj_rmQRT)
			__UBhhhF6iRr94DKLQvVjANsh4 = __QLqCezf568KTQKD49yiUs15p("Lv%d" % __hZ3wY11rr8GDand_zj_rmQRT.__zMZVCIoyJu5zkEI6YyKqPDoG, Rect2(0, -11, 64, 13), Color8(255, 230, 140))
			__h3ii5RH8ZWV2JT_zl4hvKufB = true
			queue_redraw()
		__sVG8ZzqFjX4yuWwyiFTcqQk2()
	func __XiZeg0Kx4bgRwLIRXsYMZBfD(__esU3CYQ12BWswN1N27evFzQQ: int) -> void :
		const __oXccOYfptyitBYkS1HbDEsXp: Array[int] = [-1, 49, 48, 50, 51, 83, 84, 85, 88]
		if __esU3CYQ12BWswN1N27evFzQQ <= 0 or __esU3CYQ12BWswN1N27evFzQQ >= __oXccOYfptyitBYkS1HbDEsXp.size():
			return
		var __6rBaPAjpfVPDbvTYQTWCcwT1: = __3CVc7kD6yGCHSiBfO0OphMVd.new()
		__6rBaPAjpfVPDbvTYQTWCcwT1.__5SRgdq4kqUc88lslGOc_6RxY = Assets.frame("ITPNFS", __oXccOYfptyitBYkS1HbDEsXp[__esU3CYQ12BWswN1N27evFzQQ])
		__6rBaPAjpfVPDbvTYQTWCcwT1.position = Vector2(-7, -8)
		__6rBaPAjpfVPDbvTYQTWCcwT1.mouse_filter = Control.MOUSE_FILTER_IGNORE
		add_child(__6rBaPAjpfVPDbvTYQTWCcwT1)
	func __lfKBp8D47UJPWmvjmlwt28C5(__r6ympXA1irsGGpc7HY4PG5r_: String) -> void :
		__QLqCezf568KTQKD49yiUs15p(__r6ympXA1irsGGpc7HY4PG5r_, Rect2(-16, 40, 96, 12), Color8(235, 240, 248))
	func __GgqGxO9lpt5n93MHkFpoF4df() -> Rect2:
		var transform: Transform2D = get_global_transform_with_canvas()
		var start: Vector2 = (transform * Vector2(9, 55)).round()
		var right: float = (transform * Vector2(54, 55)).round().x
		return Rect2(start, Vector2(maxf(5.0, right - start.x), 6))
	func __ZuEl56XypGfVHZDoWwJO_v5s(__j8c1fxIyKadl4AniUl7t8Nmq: __CgOl36_UCxYZW5PzufCcS4dS) -> void :
		var __xhMlZUdVZqh55H8OmGhDN8ZU: bool = __o4BlGoLwjfAD3TYKD8Kt7FzU.__jImD0sut02cad96nddoNN3be(layer.__M0ImV248NGNrBFXy9NCs5jwX.__LVCMU4xMBMMHO5bxpAYeHYWt(__j8c1fxIyKadl4AniUl7t8Nmq))
		__xIwzjaRnzjLSFbAf5CGpmaXo = __6y18KuMQKxg_LCgeB5GFsSXR(tr("UI_CREW_BTN_ROUTE") if __xhMlZUdVZqh55H8OmGhDN8ZU else tr("UI_CREW_BTN_CLASS"), tr("UI_TREE_TITLE") if __xhMlZUdVZqh55H8OmGhDN8ZU else tr("UI_CREW_CLASS"), "crew_class", __j8c1fxIyKadl4AniUl7t8Nmq)
		__25piJQxHn4e8rYkbSKRQ8SPR = __6y18KuMQKxg_LCgeB5GFsSXR(tr("UI_CREW_BTN_RCT"), tr("UI_CREW_RCT"), "crew_rct", __j8c1fxIyKadl4AniUl7t8Nmq)
	func __6y18KuMQKxg_LCgeB5GFsSXR(text: String, __VG0BX04CohGt4oE7id9aKkPp: String, __cJBqJDRxkyNAsGXSo6IOoXzo: String, __zcKyu8LLMJAoojARnQLtPC0H: __CgOl36_UCxYZW5PzufCcS4dS) -> Button:
		var b: = Button.new()
		b.text = text
		b.tooltip_text = __VG0BX04CohGt4oE7id9aKkPp
		b.theme = __Wl_Qw9KUEfRrP_gP8ETPRbl4.get_theme()
		b.theme_type_variation = &"SmallButton"
		b.focus_mode = Control.FOCUS_NONE
		b.add_theme_font_size_override("font_size", 12)
		b.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
		b.visible = false
		b.pressed.connect( func() -> void : layer.__iB2UqUil5MwE5LrbAKsm0pxr.emit(__cJBqJDRxkyNAsGXSo6IOoXzo, __zcKyu8LLMJAoojARnQLtPC0H))
		b.mouse_entered.connect( func() -> void : __0K3boQo4jAjlTlUv_yvA7nWV(true))
		b.mouse_exited.connect( func() -> void : __wBjZpiG1iixMTglh5jxITR3r.call_deferred())
		add_child(b)
		return b
	func __AglTbvWONhgjLkcHL2EQMxGR() -> void :
		if __25piJQxHn4e8rYkbSKRQ8SPR == null:
			return
		var __ac9aKPlzsKYtHQZTV9m7dLVC: Vector2 = get_global_transform_with_canvas().get_scale().abs()
		for b: Button in [__xIwzjaRnzjLSFbAf5CGpmaXo, __25piJQxHn4e8rYkbSKRQ8SPR]:
			b.add_theme_font_size_override("font_size", 12)
			b.size = b.get_combined_minimum_size()
			b.scale = Vector2.ONE / __ac9aKPlzsKYtHQZTV9m7dLVC.max(Vector2(0.001, 0.001))
		var __o1YAlSTkUNpKW5moKLR5JZPR: Rect2 = __GgqGxO9lpt5n93MHkFpoF4df()
		var __gv7IJjjjSY1VfPno4z9VHrOr: float = __xIwzjaRnzjLSFbAf5CGpmaXo.size.x + 3.0 + __25piJQxHn4e8rYkbSKRQ8SPR.size.x
		var __EdsnpvFaWHN7PLcx5H0PHJi1: float = __xJVaHFeSo_b2KzgsOivgr9K7.get_global_rect().get_center().x
		var __cmvVV5wFhppBqTal66PchX20: = Vector2(__EdsnpvFaWHN7PLcx5H0PHJi1 - __gv7IJjjjSY1VfPno4z9VHrOr / 2.0, __o1YAlSTkUNpKW5moKLR5JZPR.end.y + 2).round()
		var inverse: Transform2D = get_global_transform_with_canvas().affine_inverse()
		__xIwzjaRnzjLSFbAf5CGpmaXo.position = inverse * __cmvVV5wFhppBqTal66PchX20
		__25piJQxHn4e8rYkbSKRQ8SPR.position = inverse * (__cmvVV5wFhppBqTal66PchX20 + Vector2(__xIwzjaRnzjLSFbAf5CGpmaXo.size.x + 3.0, 0.0))
		queue_redraw()
	func __0K3boQo4jAjlTlUv_yvA7nWV(__0yejG8F8LdzuC8kKSPneteY8: bool) -> void :
		__0yejG8F8LdzuC8kKSPneteY8 = __0yejG8F8LdzuC8kKSPneteY8 and not layer.__Q0cIwMzltuxHZsWA0LuA02S1
		if __iDNkCPxPojBek41rxB5M2Fvi == __0yejG8F8LdzuC8kKSPneteY8:
			return
		if __0yejG8F8LdzuC8kKSPneteY8:
			for __tMUI3UDHBPssM8HJoBvbod_G: Node in get_parent().get_children():
				if __tMUI3UDHBPssM8HJoBvbod_G is __lECVwIWsQGlXOXoSmBcDqHgZ and __tMUI3UDHBPssM8HJoBvbod_G != self and (__tMUI3UDHBPssM8HJoBvbod_G as __lECVwIWsQGlXOXoSmBcDqHgZ).__iDNkCPxPojBek41rxB5M2Fvi:
					(__tMUI3UDHBPssM8HJoBvbod_G as __lECVwIWsQGlXOXoSmBcDqHgZ).__0K3boQo4jAjlTlUv_yvA7nWV(false)
			__sFk8wA8QhN909E6WZxd99O46 = get_index()
			get_parent().move_child(self, get_parent().get_child_count() - 1)
		else:
			get_parent().move_child(self, __sFk8wA8QhN909E6WZxd99O46)
		__iDNkCPxPojBek41rxB5M2Fvi = __0yejG8F8LdzuC8kKSPneteY8
		if __V0pOn5Sa7N2eQmRM4kwRkT34 != null:
			__25piJQxHn4e8rYkbSKRQ8SPR.visible = __0yejG8F8LdzuC8kKSPneteY8
			__xIwzjaRnzjLSFbAf5CGpmaXo.visible = __0yejG8F8LdzuC8kKSPneteY8
			if __0yejG8F8LdzuC8kKSPneteY8:
				__xJVaHFeSo_b2KzgsOivgr9K7.play(__Er3qHKxcEkfUWPtjkXRE6sZ3.Mode.__gM571fk5Ew8uyKGEoThVng08)
		layer.hover(__V0pOn5Sa7N2eQmRM4kwRkT34, __0yejG8F8LdzuC8kKSPneteY8)
	func __wBjZpiG1iixMTglh5jxITR3r() -> void :
		var __rrwnQjbn443MuQixtYPosxkb: Rect2 = get_global_rect()
		if __25piJQxHn4e8rYkbSKRQ8SPR != null and __25piJQxHn4e8rYkbSKRQ8SPR.visible:
			__rrwnQjbn443MuQixtYPosxkb = __rrwnQjbn443MuQixtYPosxkb.merge(__25piJQxHn4e8rYkbSKRQ8SPR.get_global_rect()).merge(__xIwzjaRnzjLSFbAf5CGpmaXo.get_global_rect())
		__0K3boQo4jAjlTlUv_yvA7nWV(__rrwnQjbn443MuQixtYPosxkb.has_point(get_global_mouse_position()))
	func _draw() -> void :
		if __h3ii5RH8ZWV2JT_zl4hvKufB:
			draw_set_transform_matrix(get_global_transform_with_canvas().affine_inverse())
			var __a84sIHaEnFsaq_6QoyPKXsGh: Rect2 = __GgqGxO9lpt5n93MHkFpoF4df()
			draw_rect(__a84sIHaEnFsaq_6QoyPKXsGh, Color(0.93, 0.96, 1.0, 1.0))
			draw_rect(__a84sIHaEnFsaq_6QoyPKXsGh.grow(-1), Color(0.02, 0.04, 0.06))
			var __f1K5cOHhPcWRNwA5Og0aEZeT: Rect2 = __a84sIHaEnFsaq_6QoyPKXsGh.grow(-2)
			var __f0fre0n_dPZnhurXg2bHutd9: PackedInt32Array = __V0pOn5Sa7N2eQmRM4kwRkT34.__pY661vwzoRY0D6Y5ORWYVaB_
			var __qHcOK24CszxzDP4R_rN3aSWh: int = maxi(1, __V0pOn5Sa7N2eQmRM4kwRkT34.__O5HLNA7SlbaePlRbjeQY8Yaz())
			var count: int = 0
			var left: float = __f1K5cOHhPcWRNwA5Og0aEZeT.position.x
			for __EQrlzLNiiWfjWTQt5eWuUkOB: int in 3:
				count += __f0fre0n_dPZnhurXg2bHutd9[__EQrlzLNiiWfjWTQt5eWuUkOB]
				var right: float = __f1K5cOHhPcWRNwA5Og0aEZeT.position.x + roundf(__f1K5cOHhPcWRNwA5Og0aEZeT.size.x * float(count) / float(__qHcOK24CszxzDP4R_rN3aSWh))
				var __XYxcUWOYrn9pVN5w9iPA0f2h: __cBjn_l7I8v2A2mo4oxWc1Hx5 = Assets.frame("ITPNFS", [908, 909, 907][__EQrlzLNiiWfjWTQt5eWuUkOB])
				if right > left and __XYxcUWOYrn9pVN5w9iPA0f2h.__9GUNq0RC3I2wtF6RyGyGCuST != null:
					draw_texture_rect(__XYxcUWOYrn9pVN5w9iPA0f2h.__9GUNq0RC3I2wtF6RyGyGCuST, Rect2(left, __f1K5cOHhPcWRNwA5Og0aEZeT.position.y, right - left, __f1K5cOHhPcWRNwA5Og0aEZeT.size.y), false)
				left = right
			draw_set_transform_matrix(Transform2D.IDENTITY)
	func __QLqCezf568KTQKD49yiUs15p(text: String, r: Rect2, color: Color) -> Label:
		var __VNeFBmV3Mwp8V50EXNrnTIUP: = Label.new()
		__VNeFBmV3Mwp8V50EXNrnTIUP.text = text
		__VNeFBmV3Mwp8V50EXNrnTIUP.position = r.position
		__VNeFBmV3Mwp8V50EXNrnTIUP.size = r.size
		__VNeFBmV3Mwp8V50EXNrnTIUP.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		__VNeFBmV3Mwp8V50EXNrnTIUP.add_theme_font_size_override("font_size", 10)
		__VNeFBmV3Mwp8V50EXNrnTIUP.add_theme_color_override("font_color", color)
		__VNeFBmV3Mwp8V50EXNrnTIUP.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.9))
		__VNeFBmV3Mwp8V50EXNrnTIUP.mouse_filter = Control.MOUSE_FILTER_IGNORE
		add_child(__VNeFBmV3Mwp8V50EXNrnTIUP)
		return __VNeFBmV3Mwp8V50EXNrnTIUP
	func __sVG8ZzqFjX4yuWwyiFTcqQk2() -> void :
		if __V0pOn5Sa7N2eQmRM4kwRkT34 == null:
			__dAGqnexg_IDbNw344d0sOBgZ.__5SRgdq4kqUc88lslGOc_6RxY = Assets.__MUCguPydNQwl8ZRXUX2ciJ44("ITPNFS", 10 if __iDNkCPxPojBek41rxB5M2Fvi else 9).frame(__zjL6MOH4ahCRS8nD6UtPvtC5)
	func _process(delta: float) -> void :
		if __iDNkCPxPojBek41rxB5M2Fvi:
			__wBjZpiG1iixMTglh5jxITR3r()
		__1oElkVOacHIBcLWKCKhilZGK += delta
		if __1oElkVOacHIBcLWKCKhilZGK >= 0.2:
			__1oElkVOacHIBcLWKCKhilZGK = 0.0
			__zjL6MOH4ahCRS8nD6UtPvtC5 += 1
			__sVG8ZzqFjX4yuWwyiFTcqQk2()
	func _gui_input(__Xv9ns9iC5KCetqIZa1LJUXkT: InputEvent) -> void :
		if __V0pOn5Sa7N2eQmRM4kwRkT34 == null:
			return
		if __Xv9ns9iC5KCetqIZa1LJUXkT is InputEventMouseButton and (__Xv9ns9iC5KCetqIZa1LJUXkT as InputEventMouseButton).button_index == MOUSE_BUTTON_LEFT:
			var __nW9zY7fW9k6AxO6ZrAezIkNL: InputEventMouseButton = __Xv9ns9iC5KCetqIZa1LJUXkT
			if __nW9zY7fW9k6AxO6ZrAezIkNL.double_click:
				layer.double_click(__V0pOn5Sa7N2eQmRM4kwRkT34)
			elif __nW9zY7fW9k6AxO6ZrAezIkNL.pressed:
				layer.__0XyVOCWtoL1Gf1pZelpNAy2K(__V0pOn5Sa7N2eQmRM4kwRkT34, get_global_mouse_position())
			else:
				layer.release()
			accept_event()
		elif __Xv9ns9iC5KCetqIZa1LJUXkT is InputEventMouseMotion:
			layer.motion(get_global_mouse_position())
const __FCwkrbua0xeoSZDWbuuHlUku: = Vector2(-32, -55)
var __BSdarC5TgXicvyW2vuz2uPRM: __Er3qHKxcEkfUWPtjkXRE6sZ3
func setup(__qyubZY5gh0dWD_ojzSlryEyW: __MxRtF5kMQ2PhDOJRxJ1ej8ie) -> void :
	__M0ImV248NGNrBFXy9NCs5jwX = __qyubZY5gh0dWD_ojzSlryEyW
	__8g95kgpxCpdLzBoCp8oJxvuo = __l0ljxOzuGuAaMAg0E9tYqY8N.new()
	__8g95kgpxCpdLzBoCp8oJxvuo.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	__8g95kgpxCpdLzBoCp8oJxvuo.visible = false
	(__uVHnM5LYJpwosw8V6yXdiPaJ if __uVHnM5LYJpwosw8V6yXdiPaJ != null else self).add_child(__8g95kgpxCpdLzBoCp8oJxvuo)
	__BSdarC5TgXicvyW2vuz2uPRM = __Er3qHKxcEkfUWPtjkXRE6sZ3.new()
	__BSdarC5TgXicvyW2vuz2uPRM.visible = false
	__BSdarC5TgXicvyW2vuz2uPRM.z_index = 10
	add_child(__BSdarC5TgXicvyW2vuz2uPRM)
	__Qa9GbnhM8GDjcw4fKszR0Ftz()
var __Q0cIwMzltuxHZsWA0LuA02S1: bool = false
var __M0ImV248NGNrBFXy9NCs5jwX: __MxRtF5kMQ2PhDOJRxJ1ej8ie
func motion(__E30O96qqGwElVLj_lTtUC1Fw: Vector2) -> void :
	if __RBxgrwTYrjwWPO6TKeTDJ4L7 == null:
		return
	if not __Q0cIwMzltuxHZsWA0LuA02S1 and __E30O96qqGwElVLj_lTtUC1Fw.distance_to(__D9brDwaa29kAcS1ksGx8WE8A) >= __5JNBb7OpRwsJ9kjvTFXb4KnU:
		__Q0cIwMzltuxHZsWA0LuA02S1 = true
		__8g95kgpxCpdLzBoCp8oJxvuo.visible = false
		__BSdarC5TgXicvyW2vuz2uPRM.__H8edGzuZdf8pc4sUjNkAWiOb(__M0ImV248NGNrBFXy9NCs5jwX.__LVCMU4xMBMMHO5bxpAYeHYWt(__RBxgrwTYrjwWPO6TKeTDJ4L7))
		__BSdarC5TgXicvyW2vuz2uPRM.play(__Er3qHKxcEkfUWPtjkXRE6sZ3.Mode.__SMdm1kmFeIusPcjutW4mbpxv)
		__BSdarC5TgXicvyW2vuz2uPRM.visible = true
	if __Q0cIwMzltuxHZsWA0LuA02S1:
		__BSdarC5TgXicvyW2vuz2uPRM.position = get_local_mouse_position() - __Er3qHKxcEkfUWPtjkXRE6sZ3.__kD5MpGbGI03ItQXuZAiXJBoV / 2
const __5JNBb7OpRwsJ9kjvTFXb4KnU: = 5.0
func __VyuMm05ujw3If0sNljXaXkvs() -> void :
	var host: Control = __8g95kgpxCpdLzBoCp8oJxvuo.get_parent_control()
	var __vU6vjTOHamZSH5aa7MkkeOSs: float = host.get_global_transform_with_canvas().get_scale().x if host != null else 1.0
	var __DQT_RYpXq63onOr9foPyo8Kn: float = (get_viewport_rect().size.y - 16.0) / __l0ljxOzuGuAaMAg0E9tYqY8N.__leD6A5XRn3zKfwhALPi2EQS0
	var z: float = minf(__8eE2BJzDXgBAO3W41ZPWgQat, __DQT_RYpXq63onOr9foPyo8Kn)
	var __B0RxXIV9rq3t_mdotN7HvP1X: float = z / maxf(__vU6vjTOHamZSH5aa7MkkeOSs, 0.001)
	__8g95kgpxCpdLzBoCp8oJxvuo.scale = Vector2(__B0RxXIV9rq3t_mdotN7HvP1X, __B0RxXIV9rq3t_mdotN7HvP1X)
	var __3xITkgZEUamm5FDe0isfMoBW: = Vector2(__l0ljxOzuGuAaMAg0E9tYqY8N.__qkI9rzzPHG3olOfJc5DxIE0c, __l0ljxOzuGuAaMAg0E9tYqY8N.__leD6A5XRn3zKfwhALPi2EQS0) * z
	__8g95kgpxCpdLzBoCp8oJxvuo.position = (__h921njZsIgv8S2inn4WHx0zV.call(__3xITkgZEUamm5FDe0isfMoBW) as Vector2) / __vU6vjTOHamZSH5aa7MkkeOSs if __h921njZsIgv8S2inn4WHx0zV.is_valid() else Vector2(8, 8)
	__eBt5HIxcCIYFCRhcyd21idU2.__08lUaVXHUgHst0KmvRmsCf5_(__8g95kgpxCpdLzBoCp8oJxvuo)
var __3a62lUzWk9xg4aXnjvJtoUT5: Callable
func double_click(__D2DanvJK16T6DgdTzXh7hUCb: __CgOl36_UCxYZW5PzufCcS4dS) -> void :
	__RBxgrwTYrjwWPO6TKeTDJ4L7 = null
	__Q0cIwMzltuxHZsWA0LuA02S1 = false
	var __DG1wZnhbGURqo1IN9BNFgj4U: String = __M0ImV248NGNrBFXy9NCs5jwX.__sdlPqoZlTuS5DkBvS_mnTzdQ(__D2DanvJK16T6DgdTzXh7hUCb)
	if __DG1wZnhbGURqo1IN9BNFgj4U != "":
		UI.__FZyGB2TVbKGb1g8kgT4bm_x4(tr(__DG1wZnhbGURqo1IN9BNFgj4U))
	__Qa9GbnhM8GDjcw4fKszR0Ftz()
var __8g95kgpxCpdLzBoCp8oJxvuo: __l0ljxOzuGuAaMAg0E9tYqY8N
var __h921njZsIgv8S2inn4WHx0zV: Callable
const __SNEborWuLnyocR3Te0l4BPJC: = Vector2(-32, -47)
var __m2droanQa_cnhkVUiY4O4rtJ: Control
var __D9brDwaa29kAcS1ksGx8WE8A: Vector2
signal changed
func __UtIa9_8uhk7_1ITiksMpL89m(__abAiDUMjYizYdSYWEhEVD9SN: __CgOl36_UCxYZW5PzufCcS4dS) -> void :
	var __esSw6ckyM_sWsP1N4meMdOHg: int = await UI.__Dzq5SbxUBHUUe7FLUyy2rI_S(tr("UI_CREW_DISMISS"), tr("UI_CREW_DISMISS_ASK") % __abAiDUMjYizYdSYWEhEVD9SN.name, [tr("UI_OK"), tr("UI_CANCEL")])
	if __esSw6ckyM_sWsP1N4meMdOHg == 0:
		var __nq47VxWB62dsoVu5_ls6UG0K: String = __M0ImV248NGNrBFXy9NCs5jwX.__UtIa9_8uhk7_1ITiksMpL89m(__abAiDUMjYizYdSYWEhEVD9SN)
		if __nq47VxWB62dsoVu5_ls6UG0K != "":
			UI.__FZyGB2TVbKGb1g8kgT4bm_x4(tr(__nq47VxWB62dsoVu5_ls6UG0K))
		__Qa9GbnhM8GDjcw4fKszR0Ftz()
func __08lUaVXHUgHst0KmvRmsCf5_(__uIIr2CVo09GSWzUTSHLJk0Ef: Node = self) -> void :
	__eBt5HIxcCIYFCRhcyd21idU2.__08lUaVXHUgHst0KmvRmsCf5_(__uIIr2CVo09GSWzUTSHLJk0Ef)
	for __ijPn7Sr2qU6NusjVZEpUO4Ui: __lECVwIWsQGlXOXoSmBcDqHgZ in __im6F1LNv3SFnj65QawSewbhT.values():
		__ijPn7Sr2qU6NusjVZEpUO4Ui.__AglTbvWONhgjLkcHL2EQMxGR()
func release() -> void :
	var __ty1xtWSPWEZVYJpZVL3Tgww5: __CgOl36_UCxYZW5PzufCcS4dS = __RBxgrwTYrjwWPO6TKeTDJ4L7
	__RBxgrwTYrjwWPO6TKeTDJ4L7 = null
	if not __Q0cIwMzltuxHZsWA0LuA02S1 or __ty1xtWSPWEZVYJpZVL3Tgww5 == null:
		return
	__Q0cIwMzltuxHZsWA0LuA02S1 = false
	__BSdarC5TgXicvyW2vuz2uPRM.visible = false
	if __m2droanQa_cnhkVUiY4O4rtJ != null and __m2droanQa_cnhkVUiY4O4rtJ.is_visible_in_tree() and __m2droanQa_cnhkVUiY4O4rtJ.get_global_rect().has_point(get_global_mouse_position()):
		var __BxuHUmPBRf4mFBE03jQXot9w: __CgOl36_UCxYZW5PzufCcS4dS = __3a62lUzWk9xg4aXnjvJtoUT5.call(get_global_mouse_position()) if __3a62lUzWk9xg4aXnjvJtoUT5.is_valid() else null
		if __ty1xtWSPWEZVYJpZVL3Tgww5.__JMsr0yCjBlwnkO_7FV9gE93o():
			__M0ImV248NGNrBFXy9NCs5jwX.__a49zmSJznHy0atFlCkwUPi4M(__ty1xtWSPWEZVYJpZVL3Tgww5, __BxuHUmPBRf4mFBE03jQXot9w)
		else:
			__M0ImV248NGNrBFXy9NCs5jwX.__7uYhXLkOUAfh6nv5PwanpntJ(__ty1xtWSPWEZVYJpZVL3Tgww5, __BxuHUmPBRf4mFBE03jQXot9w)
		__Qa9GbnhM8GDjcw4fKszR0Ftz()
		return
	var __qSs5F9RBTrC5TyiZlzZA_st3: Vector2 = get_local_mouse_position()
	for s: int in __im6F1LNv3SFnj65QawSewbhT:
		var v: __lECVwIWsQGlXOXoSmBcDqHgZ = __im6F1LNv3SFnj65QawSewbhT[s]
		if Rect2(v.position, v.size).has_point(__qSs5F9RBTrC5TyiZlzZA_st3):
			if __M0ImV248NGNrBFXy9NCs5jwX.__ifUAqOmtFvNZXIqHYuzi470Y(s) != null:
				if __M0ImV248NGNrBFXy9NCs5jwX.__ifUAqOmtFvNZXIqHYuzi470Y(s) != __ty1xtWSPWEZVYJpZVL3Tgww5:
					UI.__FZyGB2TVbKGb1g8kgT4bm_x4(tr("UI_CREW_ERR_OCCUPIED"))
				__Qa9GbnhM8GDjcw4fKszR0Ftz()
				return
			var __sC8e6ymsukS6sRc3MgkTUmxU: String = __M0ImV248NGNrBFXy9NCs5jwX.__EnIkrxRIuwB5ebUIEdBi2u89(__ty1xtWSPWEZVYJpZVL3Tgww5, s)
			if __sC8e6ymsukS6sRc3MgkTUmxU != "":
				UI.__FZyGB2TVbKGb1g8kgT4bm_x4(tr(__sC8e6ymsukS6sRc3MgkTUmxU) % __M0ImV248NGNrBFXy9NCs5jwX.__ofKSCLcCg7jWtqacDa153ehk().__zMZVCIoyJu5zkEI6YyKqPDoG if __sC8e6ymsukS6sRc3MgkTUmxU == "UI_CREW_ERR_CAPTAIN_LEVEL" else tr(__sC8e6ymsukS6sRc3MgkTUmxU))
			__Qa9GbnhM8GDjcw4fKszR0Ftz()
			return
	__Qa9GbnhM8GDjcw4fKszR0Ftz()
