class_name __2ZIL9u7_cM4KOmaAUAdneX5d
static func __EDY8L7ZwwyvqzS_1DgBi_MLl(__5zLAETzUZNWbUedz7dTrtmFJ: Variant, __8KOFBbRzBzpwe9B4dSRqDCWZ: int) -> Array[Dictionary]:
	var __QQKb08tUfqGc4mNGEkoSVZou: Array[Dictionary] = []
	if not (__5zLAETzUZNWbUedz7dTrtmFJ is Array) or (__5zLAETzUZNWbUedz7dTrtmFJ as Array).is_empty():
		var g: = __M4obS3bcfGYlfUJ_q98Y0AVX(__K1WTUdWXYcFgCkfsU0TGtS2L, __VSHoeG1OxPFOfSTVHjKqYI3S, __8KOFBbRzBzpwe9B4dSRqDCWZ, __zBSFZKwiDF2IecYyTzIvzp_x)
		__QQKb08tUfqGc4mNGEkoSVZou.append({"level": g["level"], "precision": 0, "reload": 0, "torpedo": 0})
		for __AE_8d0xUYwVKeB3oERchGopk: int in 4:
			__QQKb08tUfqGc4mNGEkoSVZou.append({"level": g["level"], "precision": g["precision"], "reload": g["reload"], "torpedo": 0})
		return __QQKb08tUfqGc4mNGEkoSVZou
	var __Bz3A9sFizmA7lfsPScqgjtTR: Array = __5zLAETzUZNWbUedz7dTrtmFJ
	for __JciO6nCFcMQrbDUpDV1D05g_: int in __wmijxqzbsM1G49CRlqqlAaBD:
		var b: Array = [0, 0, 0, 0]
		if __JciO6nCFcMQrbDUpDV1D05g_ < __Bz3A9sFizmA7lfsPScqgjtTR.size():
			var __gmNkFM7BnT9Sx3YyP77SxFM0: Array = Array(__Bz3A9sFizmA7lfsPScqgjtTR[__JciO6nCFcMQrbDUpDV1D05g_])
			for __jU_Oi6zmljeexCi60fwrznYb: int in mini(4, __gmNkFM7BnT9Sx3YyP77SxFM0.size()):
				b[__jU_Oi6zmljeexCi60fwrznYb] = int(__gmNkFM7BnT9Sx3YyP77SxFM0[__jU_Oi6zmljeexCi60fwrznYb])
		__QQKb08tUfqGc4mNGEkoSVZou.append({"level": clampi(b[0], 0, 120), "precision": mini(b[1], 65530), 
			"reload": mini(b[2], 65530), "torpedo": mini(b[3], 65530)})
	return __QQKb08tUfqGc4mNGEkoSVZou
const __aEicWSrGUe4LZ1bC04ld1rbC: = 0
const __SFLl9HogUNQdYVBWBiSxKskA: = 120
const __zBSFZKwiDF2IecYyTzIvzp_x: = 0
const __VSHoeG1OxPFOfSTVHjKqYI3S: = 5
static func __0aqgElJwReIe221GMKFmJFb2(__PHlGgR58VFNyzpdcacFO7JEn: __bzxMmNAcE_RKMny5gklgDglw, __2gYo7VFCMQP6dhkLDsF03Yho: Dictionary) -> int:
	var __Wl0fgzQKdtlsaRLSCAb95Er5: int = __PHlGgR58VFNyzpdcacFO7JEn.__Jy2hcMM9emCF3iBBkLMyeUr7("Frame", int(__2gYo7VFCMQP6dhkLDsF03Yho["frame_row"]), 128)
	var __yA4ULZuiZRvb_s7ZjMgq4hjy: PackedInt32Array = __Se4EsxPBCHX48h1ZS5MexaMl.__z60ooVwI9Q0G4gXJuZ_QzkIy(__2gYo7VFCMQP6dhkLDsF03Yho.get("armor", []))
	if __yA4ULZuiZRvb_s7ZjMgq4hjy[4] >= 0:
		__Wl0fgzQKdtlsaRLSCAb95Er5 += __PHlGgR58VFNyzpdcacFO7JEn.__vlQDTtuyQZ3KmvKohFfizJCm("Armor", __yA4ULZuiZRvb_s7ZjMgq4hjy[4], 154) * __yA4ULZuiZRvb_s7ZjMgq4hjy[5] / 10
	for r: Variant in __2gYo7VFCMQP6dhkLDsF03Yho["gun_rows"]:
		if int(r) >= 0:
			__Wl0fgzQKdtlsaRLSCAb95Er5 += __PHlGgR58VFNyzpdcacFO7JEn.__Jy2hcMM9emCF3iBBkLMyeUr7("Gunset", int(r), 28)
	for __lptFqD4h0LhGYPdFgUFpn2aY: Array in __2gYo7VFCMQP6dhkLDsF03Yho.get("side_guns", []):
		__Wl0fgzQKdtlsaRLSCAb95Er5 += __PHlGgR58VFNyzpdcacFO7JEn.__Jy2hcMM9emCF3iBBkLMyeUr7("Gunset", int(__lptFqD4h0LhGYPdFgUFpn2aY[1]), 28)
	for __Uimush0DQPWvjIiTu2KhJMcc: Array in __2gYo7VFCMQP6dhkLDsF03Yho.get("torps", []):
		__Wl0fgzQKdtlsaRLSCAb95Er5 += __PHlGgR58VFNyzpdcacFO7JEn.__Jy2hcMM9emCF3iBBkLMyeUr7("TpLauncher", int(__Uimush0DQPWvjIiTu2KhJMcc[1]), 28)
	var __lhtKniXIO6789lFly9JOxAak: int = int(__2gYo7VFCMQP6dhkLDsF03Yho.get("fcs", __aEicWSrGUe4LZ1bC04ld1rbC))
	if __lhtKniXIO6789lFly9JOxAak >= 0:
		__Wl0fgzQKdtlsaRLSCAb95Er5 += __PHlGgR58VFNyzpdcacFO7JEn.__Jy2hcMM9emCF3iBBkLMyeUr7("FCS", __lhtKniXIO6789lFly9JOxAak, 28)
	var __wnPSx2nTPyax5FC1DuifrGx6: int = int(__2gYo7VFCMQP6dhkLDsF03Yho["engine"])
	__Wl0fgzQKdtlsaRLSCAb95Er5 += __PHlGgR58VFNyzpdcacFO7JEn.__Jy2hcMM9emCF3iBBkLMyeUr7("Engine", __wnPSx2nTPyax5FC1DuifrGx6, 28)
	var a: int = __PHlGgR58VFNyzpdcacFO7JEn.__Jy2hcMM9emCF3iBBkLMyeUr7("Engine", __wnPSx2nTPyax5FC1DuifrGx6, 10)
	return 100 - mini(100, a + (100 - a) * __Wl0fgzQKdtlsaRLSCAb95Er5 / 1000)
const __K1WTUdWXYcFgCkfsU0TGtS2L: = 16
const __7LAX6iA_3EiLvNuT8tdV7o0O: = 28
static func __5EQmY2fm4FiwfMqfXxKteO7r(__MUwjO8nth8Ura2H37HobFxNp: __bzxMmNAcE_RKMny5gklgDglw, __j3Cr7EaFQCKUZpy5SNd5QHtJ: int) -> int:
	if __cKbKejhUu3ilZo2EnyTNYzVI.has(__j3Cr7EaFQCKUZpy5SNd5QHtJ):
		return __cKbKejhUu3ilZo2EnyTNYzVI[__j3Cr7EaFQCKUZpy5SNd5QHtJ]
	var __CEXoarNbggKeKcx6lo_A6OCB: int = -1
	var __JAiiiyMnottFQoTVJeQbpn0j: int = 0
	for r: int in __MUwjO8nth8Ura2H37HobFxNp.__IO68NHb5_E2BotbL8ReE7rAA("Projectile"):
		if (__MUwjO8nth8Ura2H37HobFxNp.__vlQDTtuyQZ3KmvKohFfizJCm("Projectile", r, 155) & 15) != 0:
			continue
		var __AOEBfH_Rwu4IQq4lLfoVsSke: int = __MUwjO8nth8Ura2H37HobFxNp.__Jy2hcMM9emCF3iBBkLMyeUr7("Projectile", r, 160)
		if __AOEBfH_Rwu4IQq4lLfoVsSke == 0:
			__AOEBfH_Rwu4IQq4lLfoVsSke = 100
		var d: int = absi(__AOEBfH_Rwu4IQq4lLfoVsSke - __j3Cr7EaFQCKUZpy5SNd5QHtJ)
		if __CEXoarNbggKeKcx6lo_A6OCB < 0 or d < __JAiiiyMnottFQoTVJeQbpn0j:
			__CEXoarNbggKeKcx6lo_A6OCB = r
			__JAiiiyMnottFQoTVJeQbpn0j = d
	__cKbKejhUu3ilZo2EnyTNYzVI[__j3Cr7EaFQCKUZpy5SNd5QHtJ] = __CEXoarNbggKeKcx6lo_A6OCB
	return __CEXoarNbggKeKcx6lo_A6OCB
static var __GPgVPS4_iJ5rzwVymvzuyq36: Dictionary = {}
static func __u1i5I6Wvo8jltCL4v11k1RDq(__zRSD6FduC_VlGFc8PZbmMVaH: __bzxMmNAcE_RKMny5gklgDglw, __Q2iKusKX_JaQk6VY5j7vy6bm: int, __M7u831wJ1XEVp7zmQonK2itr: Dictionary) -> int:
	var __Eo4isKrsalNa0ZmVUmZAXnc9: int = __zRSD6FduC_VlGFc8PZbmMVaH.__Jy2hcMM9emCF3iBBkLMyeUr7("Gunset", __Q2iKusKX_JaQk6VY5j7vy6bm, 158)
	var a: int = __M7u831wJ1XEVp7zmQonK2itr["reload"]
	var v: int = 10000 / (100 + a) * __Eo4isKrsalNa0ZmVUmZAXnc9 / 100 + 1
	v = v * 13 / 10
	return maxi(v, __Eo4isKrsalNa0ZmVUmZAXnc9 / 2)
static func __6JV8CAX2HqhD7_dopT9dfg_8(__2R1kUBiyE9g0XRxBZT_6tn6I: __bzxMmNAcE_RKMny5gklgDglw, __l7DMcBFdSZxN0oHhsax4sJVq: int, __Kp3YoF5dgwYhfRWWsTrcN_tr: int, __OCOr0d_AY9s7yDldw2w4vpWc: int, 
		__VxWHIlLhdDbzo2jnxmopZvk2: int, __RoCYwBDLzQh2x2rChMnavzzq: PackedInt32Array = PackedInt32Array()) -> int:
	var __VxeiSF60hRX0q4NwHVP1V6mh: int = mini(__qSOTPCP5LQpqi7iJU0fh7v5v, __2R1kUBiyE9g0XRxBZT_6tn6I.__Jy2hcMM9emCF3iBBkLMyeUr7("Frame", __l7DMcBFdSZxN0oHhsax4sJVq, 124) * __2R1kUBiyE9g0XRxBZT_6tn6I.__Jy2hcMM9emCF3iBBkLMyeUr7("Engine", __Kp3YoF5dgwYhfRWWsTrcN_tr, 164) / 100 + __Q5qhEQeDga9zPIoLe7Y77Mfo(__RoCYwBDLzQh2x2rChMnavzzq))
	return __Ie6YkLIg3gRBfAMx7kQOJJbN(__VxWHIlLhdDbzo2jnxmopZvk2, __OCOr0d_AY9s7yDldw2w4vpWc, __VxeiSF60hRX0q4NwHVP1V6mh)
const __bNPpeuRkyJLCHe1DdXcSlDqu: = {1: 30, 2: 35, 3: 33, 4: 32, 5: 24, 6: 30, 7: 27, 8: 30, 9: 18}
static func __P7mKJOdBkGLoHIrg0rZud0qO(__T675ZeRzZmjcNVS7pP2OmyNU: __bzxMmNAcE_RKMny5gklgDglw, __dbljqPi_g5ccDwVXLQYIhN6e: int) -> Dictionary:
	if __GPgVPS4_iJ5rzwVymvzuyq36.has(__dbljqPi_g5ccDwVXLQYIhN6e):
		return __GPgVPS4_iJ5rzwVymvzuyq36[__dbljqPi_g5ccDwVXLQYIhN6e]
	var __yq3tXXI2n5apbQUC0YZ7r43w: int = __T675ZeRzZmjcNVS7pP2OmyNU.__Jy2hcMM9emCF3iBBkLMyeUr7("Projectile", __dbljqPi_g5ccDwVXLQYIhN6e, 160)
	if __yq3tXXI2n5apbQUC0YZ7r43w == 0:
		__yq3tXXI2n5apbQUC0YZ7r43w = 100
	var __csFQzcti_8dAGxtDkGBR1L7c: = {
		"proj_row": __dbljqPi_g5ccDwVXLQYIhN6e, 
		"t0": __a3Qlrip4DI7L5IkLGkgxE5xK.__JI2WieShJuy_m4l0qRsK5CZT(__T675ZeRzZmjcNVS7pP2OmyNU, __dbljqPi_g5ccDwVXLQYIhN6e), 
		"Ca": __yq3tXXI2n5apbQUC0YZ7r43w, 
		"Ms": __T675ZeRzZmjcNVS7pP2OmyNU.__Jy2hcMM9emCF3iBBkLMyeUr7("Projectile", __dbljqPi_g5ccDwVXLQYIhN6e, 158), 
		"kind": __T675ZeRzZmjcNVS7pP2OmyNU.__vlQDTtuyQZ3KmvKohFfizJCm("Projectile", __dbljqPi_g5ccDwVXLQYIhN6e, 155) & 15, 
		"HE_base": __T675ZeRzZmjcNVS7pP2OmyNU.__Jy2hcMM9emCF3iBBkLMyeUr7("Projectile", __dbljqPi_g5ccDwVXLQYIhN6e, 156), 
		"grade": __tpg8hBNbPo8dBkRcwPauZr7X(__yq3tXXI2n5apbQUC0YZ7r43w), 
		"c1cc": __T675ZeRzZmjcNVS7pP2OmyNU.__W6CI0qz_EcizmoUzla_lpyar("Projectile", __dbljqPi_g5ccDwVXLQYIhN6e, 154) * 10 + 100, 
	}
	__GPgVPS4_iJ5rzwVymvzuyq36[__dbljqPi_g5ccDwVXLQYIhN6e] = __csFQzcti_8dAGxtDkGBR1L7c
	return __csFQzcti_8dAGxtDkGBR1L7c
static func __UVs0YVUyclqKV5cslFLEeelz(__FqYuaQQAaUxrcO4W6NAo7VTA: __bzxMmNAcE_RKMny5gklgDglw, __DEqnmowuTHR7xVvZVf2_8J1_: int, __bkDNgEIePY5IRc6PboLWGiMz: int, __5iYVyihK6mQKEJfKPLNgIzLY: Dictionary) -> int:
	var b: int = __FqYuaQQAaUxrcO4W6NAo7VTA.__Jy2hcMM9emCF3iBBkLMyeUr7("Gunset", __DEqnmowuTHR7xVvZVf2_8J1_, 172) + __FqYuaQQAaUxrcO4W6NAo7VTA.__Jy2hcMM9emCF3iBBkLMyeUr7("FCS", __bkDNgEIePY5IRc6PboLWGiMz, 152)
	var __6itMZ4uJ6WwmpLma5qLZZEx5: int = 300 * b + (12 * int(__5iYVyihK6mQKEJfKPLNgIzLY["level"]) / 10) * 100 * b / 85
	return (mini(int(__5iYVyihK6mQKEJfKPLNgIzLY["precision"]) * b, __6itMZ4uJ6WwmpLma5qLZZEx5) + 100 * b) / 100
static func __Gsc4TBpL9dL13Qyj6ciojiAi(__umG8pGRVY8XA9r5mw2mr3x9B: __bzxMmNAcE_RKMny5gklgDglw, __UBuSccETstLaD3AIWWeRCMM5: int) -> Dictionary:
	var __gSb97NFWSUGlCfWH0WZ3PI7K: int = __umG8pGRVY8XA9r5mw2mr3x9B.__Jy2hcMM9emCF3iBBkLMyeUr7("Gunset", __UBuSccETstLaD3AIWWeRCMM5, 2)
	if __CVESE_dpIkk8IUty16dF6Y76.has(__gSb97NFWSUGlCfWH0WZ3PI7K):
		return __CVESE_dpIkk8IUty16dF6Y76[__gSb97NFWSUGlCfWH0WZ3PI7K]
	var __1aW3P4XrEuQN6fc1vrlGm2tu: Dictionary = __P7mKJOdBkGLoHIrg0rZud0qO(__umG8pGRVY8XA9r5mw2mr3x9B, __5EQmY2fm4FiwfMqfXxKteO7r(__umG8pGRVY8XA9r5mw2mr3x9B, __umG8pGRVY8XA9r5mw2mr3x9B.__Jy2hcMM9emCF3iBBkLMyeUr7("Gunset", __UBuSccETstLaD3AIWWeRCMM5, 160)))
	__CVESE_dpIkk8IUty16dF6Y76[__gSb97NFWSUGlCfWH0WZ3PI7K] = __1aW3P4XrEuQN6fc1vrlGm2tu
	return __1aW3P4XrEuQN6fc1vrlGm2tu
static func __YbiyT1SbBDOEjLBq1Jl4w6By(__rorTOpQv1_6ec2md4lOLZa1P: Array[Dictionary], __J_MvD_QLQ9SjamVU9TVwQOVK: int) -> Array[Dictionary]:
	if __rorTOpQv1_6ec2md4lOLZa1P.is_empty():
		return []
	var __FQTLiWLMPj8XFn9TWzBXJVy1: Array[Dictionary] = []
	for __z2X5knsdXAuML9O8osaLd6YR: Dictionary in __rorTOpQv1_6ec2md4lOLZa1P:
		if __z2X5knsdXAuML9O8osaLd6YR["kind"]:
			__FQTLiWLMPj8XFn9TWzBXJVy1.append(__z2X5knsdXAuML9O8osaLd6YR)
	if __FQTLiWLMPj8XFn9TWzBXJVy1.is_empty():
		__FQTLiWLMPj8XFn9TWzBXJVy1 = __rorTOpQv1_6ec2md4lOLZa1P.duplicate()
	__FQTLiWLMPj8XFn9TWzBXJVy1 = __kIh5iP0Ay2Ogv_WsRuIw1fDD(__FQTLiWLMPj8XFn9TWzBXJVy1, func(__km_3f954iX5vXeF7xJ3ImvjC: Dictionary) -> int: return - absi(int(__km_3f954iX5vXeF7xJ3ImvjC["b"])))
	__FQTLiWLMPj8XFn9TWzBXJVy1 = __FQTLiWLMPj8XFn9TWzBXJVy1.slice(0, __J_MvD_QLQ9SjamVU9TVwQOVK)
	return __kIh5iP0Ay2Ogv_WsRuIw1fDD(__FQTLiWLMPj8XFn9TWzBXJVy1, func(__dqCM5LazfqY_RRyumOLC2NYz: Dictionary) -> int: return - int(__dqCM5LazfqY_RRyumOLC2NYz["b"]))
static func __ZSdRTjOk2A4sMv3Uo24ybZTk(__b7DBmKOkfKrF0ap2Tqczts3M: __bzxMmNAcE_RKMny5gklgDglw, __8cWxBeZduM7Y5HPaNx9YL0C7: Array) -> int:
	var __SpuP2y7PyJMiXXD0XVZ8pQxK: int = 0
	for __AZBzorQsUsG47CAofyMFKIeS: int in __8cWxBeZduM7Y5HPaNx9YL0C7.size() / 2:
		var __FM6wY3nEPOMcxSk5HpovAFYT: int = int(__8cWxBeZduM7Y5HPaNx9YL0C7[2 * __AZBzorQsUsG47CAofyMFKIeS])
		var __KSp41ggcIKFkr_iLcv4NkaiD: int = int(__8cWxBeZduM7Y5HPaNx9YL0C7[2 * __AZBzorQsUsG47CAofyMFKIeS + 1])
		if __FM6wY3nEPOMcxSk5HpovAFYT >= 0 and __KSp41ggcIKFkr_iLcv4NkaiD > 0:
			var __3hcwx1m9Kcv9K44kgIv8Hbii: int = maxi(1, __b7DBmKOkfKrF0ap2Tqczts3M.__Jy2hcMM9emCF3iBBkLMyeUr7("Projectile", __FM6wY3nEPOMcxSk5HpovAFYT, 152) & 255)
			__SpuP2y7PyJMiXXD0XVZ8pQxK += (__KSp41ggcIKFkr_iLcv4NkaiD + __3hcwx1m9Kcv9K44kgIv8Hbii - 1) / __3hcwx1m9Kcv9K44kgIv8Hbii * __b7DBmKOkfKrF0ap2Tqczts3M.__pGLr1ud1V6XsMMJoSyeTRFjY("Projectile", __FM6wY3nEPOMcxSk5HpovAFYT, 36)
	return __SpuP2y7PyJMiXXD0XVZ8pQxK
static func __1gDVimh_0u4wycINI_M4_2Z1(__eEZhJEPE4n6d2tJLlsyTBAu2: int, __cI6EeC2PQn9KAFm_JtOXZ59y: Array[Dictionary]) -> Array[int]:
	var g: Array[int] = []
	for __rRAi6ni2KY5afGCK2hRe8FFB: int in __eEZhJEPE4n6d2tJLlsyTBAu2:
		g.append(int(__cI6EeC2PQn9KAFm_JtOXZ59y[__rRAi6ni2KY5afGCK2hRe8FFB % __cI6EeC2PQn9KAFm_JtOXZ59y.size()].get("aft", 0)) if not __cI6EeC2PQn9KAFm_JtOXZ59y.is_empty() else 0)
	return g
static func __ECbQieV6yznwf8qWLDs5Jukv(__2MYrIiTcqWh9HNHGdqp0U8Ks: __bzxMmNAcE_RKMny5gklgDglw, __svpUvxebbCjVZYFdoz3Q2zPz: Array[int]) -> int:
	if __svpUvxebbCjVZYFdoz3Q2zPz.is_empty():
		return 0
	var __sEEg0zU9gD_OFRMCJMfSZPVt: int = 2147483647
	for r: int in __svpUvxebbCjVZYFdoz3Q2zPz:
		__sEEg0zU9gD_OFRMCJMfSZPVt = mini(__sEEg0zU9gD_OFRMCJMfSZPVt, (__2MYrIiTcqWh9HNHGdqp0U8Ks.__Jy2hcMM9emCF3iBBkLMyeUr7("Gunset", r, 154) >> 4) & 127)
	return mini(__sEEg0zU9gD_OFRMCJMfSZPVt, 100)
static func __75_LI690Lf5dh2wEl8tGcbZp(__t8tU11kj6F1vXm8ygm1Bq2Pj: __bzxMmNAcE_RKMny5gklgDglw, __uLSbyr45F50Jkc2vkg1GHQ6A: PackedInt32Array, __KUcXoxkUG4Trp2LTCt51PQ94: int, __7rxXCVYZ8oT_9oIA2xLm1eRb: int) -> int:
	var r: int = __uLSbyr45F50Jkc2vkg1GHQ6A[2 * __KUcXoxkUG4Trp2LTCt51PQ94]
	return __t8tU11kj6F1vXm8ygm1Bq2Pj.__vlQDTtuyQZ3KmvKohFfizJCm("Armor", r, __7rxXCVYZ8oT_9oIA2xLm1eRb) * __uLSbyr45F50Jkc2vkg1GHQ6A[2 * __KUcXoxkUG4Trp2LTCt51PQ94 + 1] if r >= 0 else 0
static func __kIh5iP0Ay2Ogv_WsRuIw1fDD(__u0uYBywZCLkRhOkWQBAr4HhP: Array[Dictionary], __oUDT56uOKk3KN5IBuswgQiwj: Callable) -> Array[Dictionary]:
	var __0kTWcKhInI9zNtdKc6eGiPBp: Array[int] = []
	var keys: Array[int] = []
	for __HTCciu62f9OVkKRuzBXBQV3V: int in __u0uYBywZCLkRhOkWQBAr4HhP.size():
		__0kTWcKhInI9zNtdKc6eGiPBp.append(__HTCciu62f9OVkKRuzBXBQV3V)
		keys.append(__oUDT56uOKk3KN5IBuswgQiwj.call(__u0uYBywZCLkRhOkWQBAr4HhP[__HTCciu62f9OVkKRuzBXBQV3V]))
	__0kTWcKhInI9zNtdKc6eGiPBp.sort_custom( func(x: int, y: int) -> bool:
		return keys[x] < keys[y] or (keys[x] == keys[y] and x < y))
	var __4VgwDLPgMadcYVeJVI40_6qB: Array[Dictionary] = []
	for __wGNno0f_2JbtEpbxzFCpd4C5: int in __0kTWcKhInI9zNtdKc6eGiPBp:
		__4VgwDLPgMadcYVeJVI40_6qB.append(__u0uYBywZCLkRhOkWQBAr4HhP[__wGNno0f_2JbtEpbxzFCpd4C5])
	return __4VgwDLPgMadcYVeJVI40_6qB
const __wmijxqzbsM1G49CRlqqlAaBD: = 5
static func __tpg8hBNbPo8dBkRcwPauZr7X(__mHOJ7MYhTSgRDl74iaycGnnz: int) -> int:
	if __mHOJ7MYhTSgRDl74iaycGnnz > 1500:
		return 3
	if __mHOJ7MYhTSgRDl74iaycGnnz >= 1000:
		return 2
	if __mHOJ7MYhTSgRDl74iaycGnnz > 500:
		return 1
	return 0
const __nvg1NFIt_bqB4tGqN3IgI5Fl: Array[int] = [288, 286, 290, 292]
const __hGmKpIaoEtcWvIrLMRyiwBpe: = [1000, 707, 577, 500, 447, 408, 377, 354, 333, 316, 300]
static func __lD9jdayjUI4kyjb3FfGbuNHq(__RD0K1o8TYenv9QrByLtd77tW: __bzxMmNAcE_RKMny5gklgDglw, __FuSnmGaj3NlN3Z9LcMTU3PT8: int, __2kCThbcex_RGRV0dDAMa2pbb: Variant) -> __nZxK7u5JB3kHTF7XC5Hr9MHe.__C9ZAnKztslaadyzGQaCAJD4g:
	var __2oA7qtdOqmchtCzy8o5DsMsx: PackedInt32Array = __Se4EsxPBCHX48h1ZS5MexaMl.__z60ooVwI9Q0G4gXJuZ_QzkIy(__2kCThbcex_RGRV0dDAMa2pbb)
	var __AJ9k5aT_4xtsppKyHMUpoNJp: = __nZxK7u5JB3kHTF7XC5Hr9MHe.__C9ZAnKztslaadyzGQaCAJD4g.new()
	__AJ9k5aT_4xtsppKyHMUpoNJp.ap_deck = __75_LI690Lf5dh2wEl8tGcbZp(__RD0K1o8TYenv9QrByLtd77tW, __2oA7qtdOqmchtCzy8o5DsMsx, 0, 152) / 100
	__AJ9k5aT_4xtsppKyHMUpoNJp.he_deck = __75_LI690Lf5dh2wEl8tGcbZp(__RD0K1o8TYenv9QrByLtd77tW, __2oA7qtdOqmchtCzy8o5DsMsx, 0, 153) / 100
	__AJ9k5aT_4xtsppKyHMUpoNJp.ap_side = __75_LI690Lf5dh2wEl8tGcbZp(__RD0K1o8TYenv9QrByLtd77tW, __2oA7qtdOqmchtCzy8o5DsMsx, 1, 152) / 100
	__AJ9k5aT_4xtsppKyHMUpoNJp.he_side = __75_LI690Lf5dh2wEl8tGcbZp(__RD0K1o8TYenv9QrByLtd77tW, __2oA7qtdOqmchtCzy8o5DsMsx, 1, 153) / 100
	__AJ9k5aT_4xtsppKyHMUpoNJp.sub = __RD0K1o8TYenv9QrByLtd77tW.__Jy2hcMM9emCF3iBBkLMyeUr7("Frame", __FuSnmGaj3NlN3Z9LcMTU3PT8, 128) + __75_LI690Lf5dh2wEl8tGcbZp(__RD0K1o8TYenv9QrByLtd77tW, __2oA7qtdOqmchtCzy8o5DsMsx, 2, 154) / 10
	__AJ9k5aT_4xtsppKyHMUpoNJp.__tU3LKkiKFkCz9gqPVWopN1ej = __RD0K1o8TYenv9QrByLtd77tW.__Jy2hcMM9emCF3iBBkLMyeUr7("Frame", __FuSnmGaj3NlN3Z9LcMTU3PT8, 292) * __2oA7qtdOqmchtCzy8o5DsMsx[7]
	__AJ9k5aT_4xtsppKyHMUpoNJp.__Ub5aVTwuCgOWLFhYmM4vLKch = __75_LI690Lf5dh2wEl8tGcbZp(__RD0K1o8TYenv9QrByLtd77tW, __2oA7qtdOqmchtCzy8o5DsMsx, 3, 155)
	__AJ9k5aT_4xtsppKyHMUpoNJp.__ZPD08eddwIhTA6Wx8PIYv3_F = __RD0K1o8TYenv9QrByLtd77tW.__pGLr1ud1V6XsMMJoSyeTRFjY("Frame", __FuSnmGaj3NlN3Z9LcMTU3PT8, 120)
	return __AJ9k5aT_4xtsppKyHMUpoNJp
static func __y0S06mrMPVxMf_Zlje07ITBq(__MkQgU99jH0d4R2XLaKPKcsMf: __bzxMmNAcE_RKMny5gklgDglw, __kFPoDcfJ7XyBP52U7_9gsIZI: Dictionary) -> int:
	var __qiawXMLR9dKaPewDKqNY5U6y: int = int(__kFPoDcfJ7XyBP52U7_9gsIZI["frame_row"])
	var __MWCRZadYiyMCqZAmJex6CiAc: int = __MkQgU99jH0d4R2XLaKPKcsMf.__pGLr1ud1V6XsMMJoSyeTRFjY("Frame", __qiawXMLR9dKaPewDKqNY5U6y, 112) * 1000 + maxi(0, int(__kFPoDcfJ7XyBP52U7_9gsIZI.get("crew_weight", 0)))
	var __cKFlO2LAEWAHH44IugtP4K_i: int = int(__kFPoDcfJ7XyBP52U7_9gsIZI.get("engine", -1))
	if __cKFlO2LAEWAHH44IugtP4K_i >= 0:
		__MWCRZadYiyMCqZAmJex6CiAc += __MkQgU99jH0d4R2XLaKPKcsMf.__pGLr1ud1V6XsMMJoSyeTRFjY("Engine", __cKFlO2LAEWAHH44IugtP4K_i, 36)
	var __kQQb38qb4QEgwaQfYpoLNbR1: int = int(__kFPoDcfJ7XyBP52U7_9gsIZI.get("fcs", __aEicWSrGUe4LZ1bC04ld1rbC))
	if __kQQb38qb4QEgwaQfYpoLNbR1 >= 0:
		__MWCRZadYiyMCqZAmJex6CiAc += __MkQgU99jH0d4R2XLaKPKcsMf.__pGLr1ud1V6XsMMJoSyeTRFjY("FCS", __kQQb38qb4QEgwaQfYpoLNbR1, 36)
	var __BezE2I5AXVCjW0maTNX6tPy_: PackedInt32Array = __Se4EsxPBCHX48h1ZS5MexaMl.__z60ooVwI9Q0G4gXJuZ_QzkIy(__kFPoDcfJ7XyBP52U7_9gsIZI.get("armor", []))
	for __EfoQpgXM2mPqLlQxip28fwEc: int in 4:
		if __BezE2I5AXVCjW0maTNX6tPy_[2 * __EfoQpgXM2mPqLlQxip28fwEc] >= 0:
			__MWCRZadYiyMCqZAmJex6CiAc += __MkQgU99jH0d4R2XLaKPKcsMf.__Jy2hcMM9emCF3iBBkLMyeUr7("Frame", __qiawXMLR9dKaPewDKqNY5U6y, __nvg1NFIt_bqB4tGqN3IgI5Fl[__EfoQpgXM2mPqLlQxip28fwEc]) * __MkQgU99jH0d4R2XLaKPKcsMf.__pGLr1ud1V6XsMMJoSyeTRFjY("Armor", __BezE2I5AXVCjW0maTNX6tPy_[2 * __EfoQpgXM2mPqLlQxip28fwEc], 36) * __BezE2I5AXVCjW0maTNX6tPy_[2 * __EfoQpgXM2mPqLlQxip28fwEc + 1]
	var __PcOWzGjRMNQzJvdsREt83bHE: Array = __kFPoDcfJ7XyBP52U7_9gsIZI.get("gun_ammo", [])
	var __nGFqkBNXpU6BmO8vU_fP0HoU: Array = Array(__kFPoDcfJ7XyBP52U7_9gsIZI["gun_rows"])
	for __d901si3j3yrOicheKn7FUTuv: int in __nGFqkBNXpU6BmO8vU_fP0HoU.size():
		if int(__nGFqkBNXpU6BmO8vU_fP0HoU[__d901si3j3yrOicheKn7FUTuv]) >= 0:
			__MWCRZadYiyMCqZAmJex6CiAc += __MkQgU99jH0d4R2XLaKPKcsMf.__pGLr1ud1V6XsMMJoSyeTRFjY("Gunset", int(__nGFqkBNXpU6BmO8vU_fP0HoU[__d901si3j3yrOicheKn7FUTuv]), 36)
			if __d901si3j3yrOicheKn7FUTuv < __PcOWzGjRMNQzJvdsREt83bHE.size():
				__MWCRZadYiyMCqZAmJex6CiAc += __ZSdRTjOk2A4sMv3Uo24ybZTk(__MkQgU99jH0d4R2XLaKPKcsMf, __PcOWzGjRMNQzJvdsREt83bHE[__d901si3j3yrOicheKn7FUTuv])
			else:
				var __QM13f8jdUVGxF_66lVaVbAtx: int = __5EQmY2fm4FiwfMqfXxKteO7r(__MkQgU99jH0d4R2XLaKPKcsMf, __MkQgU99jH0d4R2XLaKPKcsMf.__Jy2hcMM9emCF3iBBkLMyeUr7("Gunset", int(__nGFqkBNXpU6BmO8vU_fP0HoU[__d901si3j3yrOicheKn7FUTuv]), 160))
				__MWCRZadYiyMCqZAmJex6CiAc += __ZSdRTjOk2A4sMv3Uo24ybZTk(__MkQgU99jH0d4R2XLaKPKcsMf, [__QM13f8jdUVGxF_66lVaVbAtx, __SFLl9HogUNQdYVBWBiSxKskA, __QM13f8jdUVGxF_66lVaVbAtx, __SFLl9HogUNQdYVBWBiSxKskA])
	for __Xo8r3LfTvD2dyvne2rKdD0bg: Array in __kFPoDcfJ7XyBP52U7_9gsIZI.get("side_guns", []):
		__MWCRZadYiyMCqZAmJex6CiAc += __MkQgU99jH0d4R2XLaKPKcsMf.__pGLr1ud1V6XsMMJoSyeTRFjY("Gunset", int(__Xo8r3LfTvD2dyvne2rKdD0bg[1]), 36) + __ZSdRTjOk2A4sMv3Uo24ybZTk(__MkQgU99jH0d4R2XLaKPKcsMf, __Xo8r3LfTvD2dyvne2rKdD0bg.slice(2, 6))
	for __HkUpvr5reJw4Rd0Ex3LJ_jqN: Array in __kFPoDcfJ7XyBP52U7_9gsIZI.get("torps", []):
		__MWCRZadYiyMCqZAmJex6CiAc += __MkQgU99jH0d4R2XLaKPKcsMf.__pGLr1ud1V6XsMMJoSyeTRFjY("TpLauncher", int(__HkUpvr5reJw4Rd0Ex3LJ_jqN[1]), 36)
		var tr: int = int(__HkUpvr5reJw4Rd0Ex3LJ_jqN[2]) if __HkUpvr5reJw4Rd0Ex3LJ_jqN.size() >= 4 else __0QiGqbYBLZEUENpkfN6eZqIr.__wVuHzY9YCCaYKv6084XTWI4U(__MkQgU99jH0d4R2XLaKPKcsMf, int(__HkUpvr5reJw4Rd0Ex3LJ_jqN[1]))
		var count: int = int(__HkUpvr5reJw4Rd0Ex3LJ_jqN[3]) if __HkUpvr5reJw4Rd0Ex3LJ_jqN.size() >= 4 else (__MkQgU99jH0d4R2XLaKPKcsMf.__Jy2hcMM9emCF3iBBkLMyeUr7("TpLauncher", int(__HkUpvr5reJw4Rd0Ex3LJ_jqN[1]), 152) & 15) * __0QiGqbYBLZEUENpkfN6eZqIr.__9HOKEyafSg6VJNKCzs1I7itD
		if tr >= 0:
			__MWCRZadYiyMCqZAmJex6CiAc += __MkQgU99jH0d4R2XLaKPKcsMf.__pGLr1ud1V6XsMMJoSyeTRFjY("Torpedo", tr, 36) * maxi(0, count)
	for __qMkmjyjoB8QQzLZJsVs4q2wu: Array in __kFPoDcfJ7XyBP52U7_9gsIZI.get("air", []):
		if int(__qMkmjyjoB8QQzLZJsVs4q2wu[1]) >= 0:
			__MWCRZadYiyMCqZAmJex6CiAc += __MkQgU99jH0d4R2XLaKPKcsMf.__pGLr1ud1V6XsMMJoSyeTRFjY("Aircraft", int(__qMkmjyjoB8QQzLZJsVs4q2wu[1]), 36) * int(__qMkmjyjoB8QQzLZJsVs4q2wu[2])
		if int(__qMkmjyjoB8QQzLZJsVs4q2wu[1]) >= 0 and int(__qMkmjyjoB8QQzLZJsVs4q2wu[3]) >= 0:
			__MWCRZadYiyMCqZAmJex6CiAc += __MkQgU99jH0d4R2XLaKPKcsMf.__pGLr1ud1V6XsMMJoSyeTRFjY("Torpedo" if int(__qMkmjyjoB8QQzLZJsVs4q2wu[0]) == 30 else "Projectile", int(__qMkmjyjoB8QQzLZJsVs4q2wu[3]), 36) * int(__qMkmjyjoB8QQzLZJsVs4q2wu[4])
	return __MWCRZadYiyMCqZAmJex6CiAc
static func __Q5qhEQeDga9zPIoLe7Y77Mfo(__gVptyNm9dFzuWVUeGmWrAOYr: PackedInt32Array) -> int:
	if __gVptyNm9dFzuWVUeGmWrAOYr.size() != 3 or __gVptyNm9dFzuWVUeGmWrAOYr[0] <= 0:
		return 0
	var __VQlke5Ampc5r_4DDcgkWrICe: int = __hGmKpIaoEtcWvIrLMRyiwBpe[mini(__gVptyNm9dFzuWVUeGmWrAOYr[0], 11) - 1]
	return maxi(__gVptyNm9dFzuWVUeGmWrAOYr[1], 0) * __VQlke5Ampc5r_4DDcgkWrICe / 1000 / 20
static func __KELTLmGSrnNU7KQ0gs5NQE7T(__JrHhRyyECWkJJxzrl03MhYHg: __bzxMmNAcE_RKMny5gklgDglw, __btTsarkBG0snKfdIQnlxbMGt: int) -> Array[Dictionary]:
	var __2htVILTA7L08sxFQNnaknQiB: int = (__JrHhRyyECWkJJxzrl03MhYHg.__Jy2hcMM9emCF3iBBkLMyeUr7("Frame", __btTsarkBG0snKfdIQnlxbMGt, 12) >> 10) & 31
	var __T7XQ9DhtYXFFzLbQ7wnIlnS6: int = (__JrHhRyyECWkJJxzrl03MhYHg.__Jy2hcMM9emCF3iBBkLMyeUr7("Frame", __btTsarkBG0snKfdIQnlxbMGt, 6) >> 1) & 255
	var __F38ISVfDJZyuoHnia_Sfr_rw: Array[Dictionary] = []
	for __DBu2b3MoajTDZaamP3uSlrSY: int in __2htVILTA7L08sxFQNnaknQiB:
		var ___uQ4xmp9yBBrzWNmpTfU81e4: int = __JrHhRyyECWkJJxzrl03MhYHg.__pGLr1ud1V6XsMMJoSyeTRFjY("Frame", __btTsarkBG0snKfdIQnlxbMGt, 668 + 4 * (__DBu2b3MoajTDZaamP3uSlrSY >> 3))
		var __E0PZvJhYX3p_j1lwqXZ2_eRN: int = (___uQ4xmp9yBBrzWNmpTfU81e4 >> (4 * (7 - (__DBu2b3MoajTDZaamP3uSlrSY & 7)))) & 15
		var a: int = __JrHhRyyECWkJJxzrl03MhYHg.__HjH6rEN8pyt_TMZ3GUM09N6A("Frame", __btTsarkBG0snKfdIQnlxbMGt, 700 + 2 * __DBu2b3MoajTDZaamP3uSlrSY)
		var __kSwzHOdm_CXt4VxjRFhy4D_f: int = __JrHhRyyECWkJJxzrl03MhYHg.__HjH6rEN8pyt_TMZ3GUM09N6A("Frame", __btTsarkBG0snKfdIQnlxbMGt, 360 + 4 * __DBu2b3MoajTDZaamP3uSlrSY)
		var __QDxANn4jmAnq1OgOrpu9kt7P: int = __JrHhRyyECWkJJxzrl03MhYHg.__HjH6rEN8pyt_TMZ3GUM09N6A("Frame", __btTsarkBG0snKfdIQnlxbMGt, 362 + 4 * __DBu2b3MoajTDZaamP3uSlrSY)
		__F38ISVfDJZyuoHnia_Sfr_rw.append({
			"i": __DBu2b3MoajTDZaamP3uSlrSY, 
			"aft": (__JrHhRyyECWkJJxzrl03MhYHg.__pGLr1ud1V6XsMMJoSyeTRFjY("Frame", __btTsarkBG0snKfdIQnlxbMGt, 620) >> (31 - __DBu2b3MoajTDZaamP3uSlrSY)) & 1, 
			"grp": (__JrHhRyyECWkJJxzrl03MhYHg.__pGLr1ud1V6XsMMJoSyeTRFjY("Frame", __btTsarkBG0snKfdIQnlxbMGt, 616) >> (31 - __DBu2b3MoajTDZaamP3uSlrSY)) & 1, 
			"a": a, 
			"b": __T7XQ9DhtYXFFzLbQ7wnIlnS6 - __JrHhRyyECWkJJxzrl03MhYHg.__HjH6rEN8pyt_TMZ3GUM09N6A("Frame", __btTsarkBG0snKfdIQnlxbMGt, 764 + 2 * __DBu2b3MoajTDZaamP3uSlrSY), 
			"lvl": __E0PZvJhYX3p_j1lwqXZ2_eRN, 
			"h": __JrHhRyyECWkJJxzrl03MhYHg.__vlQDTtuyQZ3KmvKohFfizJCm("Frame", __btTsarkBG0snKfdIQnlxbMGt, 636 + __E0PZvJhYX3p_j1lwqXZ2_eRN) * 86 / 100, 
			"base": __JrHhRyyECWkJJxzrl03MhYHg.__HjH6rEN8pyt_TMZ3GUM09N6A("Frame", __btTsarkBG0snKfdIQnlxbMGt, 296 + 2 * __DBu2b3MoajTDZaamP3uSlrSY) * 10, 
			"kind": a == 0 and __kSwzHOdm_CXt4VxjRFhy4D_f + __QDxANn4jmAnq1OgOrpu9kt7P == 360, 
		})
	return __F38ISVfDJZyuoHnia_Sfr_rw
static func __Ie6YkLIg3gRBfAMx7kQOJJbN(__OhJMzxEZ1jWUE1od3YYP4e3q: int, __hctSlqSR9knDWkvlkb0U9K5Z: int, __E53CFbEi3ljqchPMTKS11dRS: int) -> int:
	var __n57TOxQfKbi1fW6jk_EdVQOl: int = __NYbIaW78BNqdaS0BgoYwqAci.__oUg0mj2UMlXk3x_qZQqC_Bys.get(__hctSlqSR9knDWkvlkb0U9K5Z, 0)
	if __n57TOxQfKbi1fW6jk_EdVQOl == 0 or __OhJMzxEZ1jWUE1od3YYP4e3q * (100 + __E53CFbEi3ljqchPMTKS11dRS) / 100 <= __n57TOxQfKbi1fW6jk_EdVQOl:
		return __E53CFbEi3ljqchPMTKS11dRS
	var __FrStL1GSkyBj81A5XrWRCPPl: int = __n57TOxQfKbi1fW6jk_EdVQOl * 100 / maxi(__OhJMzxEZ1jWUE1od3YYP4e3q, 1) - 100
	var __7wE8sBJAx_Xv4hRq_UR8zOdu: int = __OhJMzxEZ1jWUE1od3YYP4e3q * (100 + __FrStL1GSkyBj81A5XrWRCPPl) / 100
	if __7wE8sBJAx_Xv4hRq_UR8zOdu < __n57TOxQfKbi1fW6jk_EdVQOl:
		__FrStL1GSkyBj81A5XrWRCPPl += 1
	elif __7wE8sBJAx_Xv4hRq_UR8zOdu > __n57TOxQfKbi1fW6jk_EdVQOl:
		__FrStL1GSkyBj81A5XrWRCPPl -= 1
	return maxi(__FrStL1GSkyBj81A5XrWRCPPl, 0)
static func __rE0McfzbdQFKc4LopFW9XMAd(__Pr0fVS_aRhD7DSAoZ3CwGzJf: __bzxMmNAcE_RKMny5gklgDglw, __9jUsyzdQP0yqJUc2uYTEabcw: int, __DfyV4TvNlk_IBb9Ubf9nC7gE: int, __ag55K0f3jurtq0MPzgxdJ0wx: int) -> int:
	var reference: int = __Pr0fVS_aRhD7DSAoZ3CwGzJf.__pGLr1ud1V6XsMMJoSyeTRFjY("Frame", __9jUsyzdQP0yqJUc2uYTEabcw, 116)
	if reference <= 0:
		return 0
	var sub: bool = (__Pr0fVS_aRhD7DSAoZ3CwGzJf.__Jy2hcMM9emCF3iBBkLMyeUr7("Frame", __9jUsyzdQP0yqJUc2uYTEabcw, 4) & 31) == __Se4EsxPBCHX48h1ZS5MexaMl.__4cYyo29DcWFPcLdEsHACapS4
	var __q5XxF4NH_BEYnouW_h2InJnm: int = maxi(__ag55K0f3jurtq0MPzgxdJ0wx, 0) * (100 if sub else 1) / 1000
	var __4skDAT7B3N1TCBzLKqEeFFHB: int = maxi(1, __Pr0fVS_aRhD7DSAoZ3CwGzJf.__Jy2hcMM9emCF3iBBkLMyeUr7("Frame", __9jUsyzdQP0yqJUc2uYTEabcw, 126) * __q5XxF4NH_BEYnouW_h2InJnm / reference / 100)
	var __udg_Y7b72Dwnh5meYksvvCrb: int = __Pr0fVS_aRhD7DSAoZ3CwGzJf.__pGLr1ud1V6XsMMJoSyeTRFjY("Engine", __DfyV4TvNlk_IBb9Ubf9nC7gE, 152) * (90 if sub else 1)
	return __Irz9hiGcyslSDsJT8BenfEt2.__f8g2PjfN7nwJbTHn9ePhmeZH(__udg_Y7b72Dwnh5meYksvvCrb / __4skDAT7B3N1TCBzLKqEeFFHB)
static func __LcbL96hhs0uDGpxL5IdC8qIS(__LVq9INEtGKrQ_Xgnp6qfLUkg: __bzxMmNAcE_RKMny5gklgDglw, ___VN0fJpd4TczHkdb_PEnDttM: int, __3HJVuw4nm5nh7WqFrFv7rfi5: Dictionary, __cuFhpp49_ceIvv3LZmG16sci: int, __qNYkoR_pkWVpCjGn0QibvDDp: int, __gQIOYasTkpKXYbMvZTdYacq0: int, __CH9xaESdT0bTikGqIgfYeJKG: Array, 
		__HMSUPkxPMuPU0xuUhYoYHhRZ: Array[Dictionary], __17mGsxyuAHP27xWDR4qJdF3C: int, __L2VtXb_09K9fUrJ45wNzlRs1: int = __aEicWSrGUe4LZ1bC04ld1rbC) -> Dictionary:
	var __sGpXm28qRV2cLi3jWvptG_bt: int = __u22yUI0h9LYZYTkYTw5lVM1y(__3HJVuw4nm5nh7WqFrFv7rfi5)
	var __TIj3DOm4Y6oyEaYrb8cYbq9y: Dictionary = __HMSUPkxPMuPU0xuUhYoYHhRZ[1 + __sGpXm28qRV2cLi3jWvptG_bt]
	var g: Dictionary = __a3Qlrip4DI7L5IkLGkgxE5xK.__eY2uIcoZhiz2WRqGDlLe85tO(__LVq9INEtGKrQ_Xgnp6qfLUkg, ___VN0fJpd4TczHkdb_PEnDttM, __UVs0YVUyclqKV5cslFLEeelz(__LVq9INEtGKrQ_Xgnp6qfLUkg, ___VN0fJpd4TczHkdb_PEnDttM, __L2VtXb_09K9fUrJ45wNzlRs1, __TIj3DOm4Y6oyEaYrb8cYbq9y), __cuFhpp49_ceIvv3LZmG16sci, __3HJVuw4nm5nh7WqFrFv7rfi5["base"])
	var __wQIaMOc7wdTNyWtZ09VUPK6h: int = __u1i5I6Wvo8jltCL4v11k1RDq(__LVq9INEtGKrQ_Xgnp6qfLUkg, ___VN0fJpd4TczHkdb_PEnDttM, __TIj3DOm4Y6oyEaYrb8cYbq9y)
	var __qE3FJBNt7oGZmIjBEWj2mMRc: Dictionary = __Gsc4TBpL9dL13Qyj6ciojiAi(__LVq9INEtGKrQ_Xgnp6qfLUkg, ___VN0fJpd4TczHkdb_PEnDttM)
	var __eCk_ZYLJFD88Y8c03SVeOeef: Dictionary = __qE3FJBNt7oGZmIjBEWj2mMRc
	var __EAviDV0uWTpZxJ_HTpE25i4r: int = __SFLl9HogUNQdYVBWBiSxKskA
	var __71PXAz0tY9phNPyxzHAAmrOe: int = __SFLl9HogUNQdYVBWBiSxKskA
	if __CH9xaESdT0bTikGqIgfYeJKG.size() >= 4:
		__qE3FJBNt7oGZmIjBEWj2mMRc = __P7mKJOdBkGLoHIrg0rZud0qO(__LVq9INEtGKrQ_Xgnp6qfLUkg, int(__CH9xaESdT0bTikGqIgfYeJKG[0])) if int(__CH9xaESdT0bTikGqIgfYeJKG[0]) >= 0 else __qE3FJBNt7oGZmIjBEWj2mMRc
		__eCk_ZYLJFD88Y8c03SVeOeef = __P7mKJOdBkGLoHIrg0rZud0qO(__LVq9INEtGKrQ_Xgnp6qfLUkg, int(__CH9xaESdT0bTikGqIgfYeJKG[2])) if int(__CH9xaESdT0bTikGqIgfYeJKG[2]) >= 0 else __qE3FJBNt7oGZmIjBEWj2mMRc
		__EAviDV0uWTpZxJ_HTpE25i4r = int(__CH9xaESdT0bTikGqIgfYeJKG[1]) if int(__CH9xaESdT0bTikGqIgfYeJKG[0]) >= 0 else 0
		__71PXAz0tY9phNPyxzHAAmrOe = int(__CH9xaESdT0bTikGqIgfYeJKG[3]) if int(__CH9xaESdT0bTikGqIgfYeJKG[2]) >= 0 else 0
	g.merge({
		"gunset_row": ___VN0fJpd4TczHkdb_PEnDttM, 
		"shell": __qE3FJBNt7oGZmIjBEWj2mMRc, 
		"shell_b": __eCk_ZYLJFD88Y8c03SVeOeef, 
		"group": __qNYkoR_pkWVpCjGn0QibvDDp, 
		"seat": __gQIOYasTkpKXYbMvZTdYacq0, 
		"angle": 0, "elev": 0, 
		"step_base": __17mGsxyuAHP27xWDR4qJdF3C, 
		"rot_dir": 0, "elev_dir": 0, 
		"rotating": false, "elevating": false, 
		"ready": true, "in_arc": true, 
		"slot": __3HJVuw4nm5nh7WqFrFv7rfi5["i"], "mount_a": __3HJVuw4nm5nh7WqFrFv7rfi5["a"], "mount_b": __3HJVuw4nm5nh7WqFrFv7rfi5["b"], "mount_h": __3HJVuw4nm5nh7WqFrFv7rfi5["h"], 
		"ammo_a": __EAviDV0uWTpZxJ_HTpE25i4r, "ammo_b": __71PXAz0tY9phNPyxzHAAmrOe, "cargo": 0, 
		"reload_total": __wQIaMOc7wdTNyWtZ09VUPK6h, "reload_cnt": __wQIaMOc7wdTNyWtZ09VUPK6h, 
		"crew_group": __sGpXm28qRV2cLi3jWvptG_bt, 
		"aa": 1 if (__LVq9INEtGKrQ_Xgnp6qfLUkg.__vlQDTtuyQZ3KmvKohFfizJCm("Gunset", ___VN0fJpd4TczHkdb_PEnDttM, 0) == 5 and __LVq9INEtGKrQ_Xgnp6qfLUkg.__vlQDTtuyQZ3KmvKohFfizJCm("Gunset", ___VN0fJpd4TczHkdb_PEnDttM, 1) == 0
			and __LVq9INEtGKrQ_Xgnp6qfLUkg.__Jy2hcMM9emCF3iBBkLMyeUr7("Gunset", ___VN0fJpd4TczHkdb_PEnDttM, 2) in [433, 583, 584]) else 0, 
	}, true)
	return g
static var __CVESE_dpIkk8IUty16dF6Y76: Dictionary = {}
static func __u22yUI0h9LYZYTkYTw5lVM1y(__akyaNw9FjM_4Bxhj3fW7u6JI: Dictionary) -> int:
	return int(__akyaNw9FjM_4Bxhj3fW7u6JI.get("aft", 0)) + 2 * int(__akyaNw9FjM_4Bxhj3fW7u6JI.get("grp", 0))
static func __M4obS3bcfGYlfUJ_q98Y0AVX(precision: int, __EMXN0dNvWtEK9nPz8RTcIMkh: int, __lByILi6CfCX2TW_wSFXzh8tH: int, __Hdgxi1rqpEFn1iiEHShbEt3S: int) -> Dictionary:
	var ___uVMtK0DW4BFu8bLsaWD6PQf: Array[int] = [100, 106, 110, 113, 113]
	return {
		"precision": mini(precision, 65530), 
		"reload": mini(__EMXN0dNvWtEK9nPz8RTcIMkh, 65530), 
		"level": __lByILi6CfCX2TW_wSFXzh8tH, 
		"nation_pct": ___uVMtK0DW4BFu8bLsaWD6PQf[__Hdgxi1rqpEFn1iiEHShbEt3S] if __Hdgxi1rqpEFn1iiEHShbEt3S < 5 else 100, 
	}
static var __cKbKejhUu3ilZo2EnyTNYzVI: Dictionary = {}
static func __OkVfGWi6A7iSRtV1KMbEPTze(__W7h0mVCIdSyQlXJhfypWqySy: __bzxMmNAcE_RKMny5gklgDglw, __sQbzhjlynzGfwgx2lrXjQqsc: int, __OdoD24jY5nGghzJ1uFNx44cT: PackedInt32Array = PackedInt32Array()) -> int:
	return __W7h0mVCIdSyQlXJhfypWqySy.__Jy2hcMM9emCF3iBBkLMyeUr7("Engine", __sQbzhjlynzGfwgx2lrXjQqsc, 156) * 50 + (maxi(__OdoD24jY5nGghzJ1uFNx44cT[2], 0) if __OdoD24jY5nGghzJ1uFNx44cT.size() == 3 else 0)
const __qSOTPCP5LQpqi7iJU0fh7v5v: = 70
static func __CqzDpplM5ETWU2SW2VGKogkg(__36Zpa33fE9uR65rtm7gqhqxP: __bzxMmNAcE_RKMny5gklgDglw, __Bao7vWrytRTJMy5VZ4WMTLw4: Dictionary, terrain: __NYbIaW78BNqdaS0BgoYwqAci.__O1Urlr6IdUTnFWvioe6wcQrt, index: int) -> __YdhZSn3k6BLtSITi5naOCb7n:
	var __zSSlTPHoSmmFH5vX2_4j8d69: int = __Bao7vWrytRTJMy5VZ4WMTLw4["frame_row"]
	var __Atp8MoxKoQM9tdMR6w80VJG2: int = __36Zpa33fE9uR65rtm7gqhqxP.__Jy2hcMM9emCF3iBBkLMyeUr7("Frame", __zSSlTPHoSmmFH5vX2_4j8d69, 6)
	var __S0wcWvy_PnvT0hxvr5dq1Say: int = __36Zpa33fE9uR65rtm7gqhqxP.__Jy2hcMM9emCF3iBBkLMyeUr7("Frame", __zSSlTPHoSmmFH5vX2_4j8d69, 4) & 31
	var __8q63qnYFu8xFOf1basWG4sBs: int = maxi(1, __36Zpa33fE9uR65rtm7gqhqxP.__Jy2hcMM9emCF3iBBkLMyeUr7("Frame", __zSSlTPHoSmmFH5vX2_4j8d69, 14) >> 4)
	var s: = __YdhZSn3k6BLtSITi5naOCb7n.new()
	s.__JCVAOijT_RUiAesgY0ay5TGW = __Bao7vWrytRTJMy5VZ4WMTLw4["key"]
	s.__7OKcEzdMfOdabzyMipWdSzWD = __Bao7vWrytRTJMy5VZ4WMTLw4["side"]
	s.__ZMgQrrB9zxLXJ4nY9DOrkD1m = bool(__Bao7vWrytRTJMy5VZ4WMTLw4.get("player", false))
	s.__KLxhKPISj_AUmBVDjcFeRqL7 = str(__Bao7vWrytRTJMy5VZ4WMTLw4["ai"]) if __Bao7vWrytRTJMy5VZ4WMTLw4.get("ai") != null else ""
	s.terrain = terrain
	s.__WeB9Hi0OxaFBUuwm2WU2qKEH = __zSSlTPHoSmmFH5vX2_4j8d69
	s.__RZSGss6vMJxzvS6fmWkQMma8 = __S0wcWvy_PnvT0hxvr5dq1Say
	s.__zMZVCIoyJu5zkEI6YyKqPDoG = __8q63qnYFu8xFOf1basWG4sBs
	s.__11jta_pen9MsoYrWopEHFcWy = (__Atp8MoxKoQM9tdMR6w80VJG2 >> 1) & 255
	s.__TMaqDrkAeK6UVY6d4JshSgUc = (__Atp8MoxKoQM9tdMR6w80VJG2 >> 10) & 31
	var __CNY56ZmxlLQtcwZrg38hFleU: int = (__36Zpa33fE9uR65rtm7gqhqxP.__Jy2hcMM9emCF3iBBkLMyeUr7("Frame", __zSSlTPHoSmmFH5vX2_4j8d69, 8) >> 6) & 255
	var __Wzynz0dOe0SvUrgMuYPh0Ewu: Array[Dictionary] = __EDY8L7ZwwyvqzS_1DgBi_MLl(__Bao7vWrytRTJMy5VZ4WMTLw4.get("crew", []), __8q63qnYFu8xFOf1basWG4sBs)
	var __DGQ0uhEX1fdGQpMxBY3jG78h: int = int(__Bao7vWrytRTJMy5VZ4WMTLw4.get("fcs", __aEicWSrGUe4LZ1bC04ld1rbC))
	if __DGQ0uhEX1fdGQpMxBY3jG78h < 0:
		__DGQ0uhEX1fdGQpMxBY3jG78h = __aEicWSrGUe4LZ1bC04ld1rbC
	var __VeRYouLxb3ex3KrGJu0uTdRZ: Array[int] = []
	for r: Variant in __Bao7vWrytRTJMy5VZ4WMTLw4["gun_rows"]:
		__VeRYouLxb3ex3KrGJu0uTdRZ.append(int(r))
	var __Zz7mRt8AoFlmZm5xHVs9AKHz: int = __VeRYouLxb3ex3KrGJu0uTdRZ.size()
	var __PnIX59nioJJ_UoPYjn7ahl9v: Array[int] = []
	for r: int in __VeRYouLxb3ex3KrGJu0uTdRZ:
		if r >= 0:
			__PnIX59nioJJ_UoPYjn7ahl9v.append(r)
	for __KEKu7g0PtHKxZaTIzjTJEkbG: Variant in __Bao7vWrytRTJMy5VZ4WMTLw4.get("side_guns", []):
		__PnIX59nioJJ_UoPYjn7ahl9v.append(int((__KEKu7g0PtHKxZaTIzjTJEkbG as Array)[1]))
	var __jTR2bN7LV04KQhea9uxogIrN: int = __ECbQieV6yznwf8qWLDs5Jukv(__36Zpa33fE9uR65rtm7gqhqxP, __PnIX59nioJJ_UoPYjn7ahl9v)
	var __CFOyCcaij71U5m95ltbECkdh: Array[Dictionary] = __YbiyT1SbBDOEjLBq1Jl4w6By(__KELTLmGSrnNU7KQ0gs5NQE7T(__36Zpa33fE9uR65rtm7gqhqxP, __zSSlTPHoSmmFH5vX2_4j8d69), __Zz7mRt8AoFlmZm5xHVs9AKHz)
	if __CFOyCcaij71U5m95ltbECkdh.is_empty():
		for __yEqj8OMHET0wPmj1axHgT0nU: int in __Zz7mRt8AoFlmZm5xHVs9AKHz:
			__CFOyCcaij71U5m95ltbECkdh.append({"i": 0, "a": 0, "b": 0, "lvl": 0, "h": 0, "base": 0})
	var __jLuhnDHzqaLbVtu_Dnzb35JE: Array[int] = __1gDVimh_0u4wycINI_M4_2Z1(__Zz7mRt8AoFlmZm5xHVs9AKHz, __CFOyCcaij71U5m95ltbECkdh)
	for __YMdBF5zlEm2e6BusodV9JLxt: int in __Zz7mRt8AoFlmZm5xHVs9AKHz:
		if __VeRYouLxb3ex3KrGJu0uTdRZ[__YMdBF5zlEm2e6BusodV9JLxt] < 0:
			continue
		var __jzW6mcgroqesIsdSxJIlM1mH: Array = (__Bao7vWrytRTJMy5VZ4WMTLw4["gun_ammo"] as Array)[__YMdBF5zlEm2e6BusodV9JLxt] if __Bao7vWrytRTJMy5VZ4WMTLw4.has("gun_ammo") and __YMdBF5zlEm2e6BusodV9JLxt < (__Bao7vWrytRTJMy5VZ4WMTLw4["gun_ammo"] as Array).size() else []
		var meti_mount: Dictionary = __CFOyCcaij71U5m95ltbECkdh[__YMdBF5zlEm2e6BusodV9JLxt % __CFOyCcaij71U5m95ltbECkdh.size()]
		var meti_secondary = s.__ZMgQrrB9zxLXJ4nY9DOrkD1m and int(meti_mount.get("grp", 0)) == 1
		s.__BJReFJ4ugditvprP9JFCx5S2.append(__LcbL96hhs0uDGpxL5IdC8qIS(__36Zpa33fE9uR65rtm7gqhqxP, __VeRYouLxb3ex3KrGJu0uTdRZ[__YMdBF5zlEm2e6BusodV9JLxt], __CFOyCcaij71U5m95ltbECkdh[__YMdBF5zlEm2e6BusodV9JLxt % __CFOyCcaij71U5m95ltbECkdh.size()], s.__BJReFJ4ugditvprP9JFCx5S2.size(), int(meti_mount.get("aft", 0)) if meti_secondary else __jLuhnDHzqaLbVtu_Dnzb35JE[__YMdBF5zlEm2e6BusodV9JLxt], 1 if meti_secondary else 0, __jzW6mcgroqesIsdSxJIlM1mH, __Wzynz0dOe0SvUrgMuYPh0Ewu, __jTR2bN7LV04KQhea9uxogIrN, __DGQ0uhEX1fdGQpMxBY3jG78h))
	var __g36Eynb7z6aa8d9MCNG0rYm8: Array[Dictionary] = __KELTLmGSrnNU7KQ0gs5NQE7T(__36Zpa33fE9uR65rtm7gqhqxP, __zSSlTPHoSmmFH5vX2_4j8d69)
	for __ssnc6iiSeSPaVCFIydzSyV3p: Variant in __Bao7vWrytRTJMy5VZ4WMTLw4.get("side_guns", []):
		var __I8t2kPnhbWJmdiDVybFsIaPV: Array = __ssnc6iiSeSPaVCFIydzSyV3p
		var __GRH9byGvJarluY696tOd5rSf: int = int(__I8t2kPnhbWJmdiDVybFsIaPV[0])
		if __GRH9byGvJarluY696tOd5rSf < 0 or __GRH9byGvJarluY696tOd5rSf >= __g36Eynb7z6aa8d9MCNG0rYm8.size():
			continue
		var __LJ2Y3IoNhffkvekIy0reFL33: Dictionary = __g36Eynb7z6aa8d9MCNG0rYm8[__GRH9byGvJarluY696tOd5rSf]
		var __IKxAM9m2VzSH9uAwjl1WsBMS: int = (__36Zpa33fE9uR65rtm7gqhqxP.__pGLr1ud1V6XsMMJoSyeTRFjY("Frame", __zSSlTPHoSmmFH5vX2_4j8d69, 616) >> (31 - __GRH9byGvJarluY696tOd5rSf)) & 1
		var __U1iLvYYREZ6ywUAoq0y2KnFu: int = int(__LJ2Y3IoNhffkvekIy0reFL33.get("aft", 0))
		var __yR_iLmKU32nh5oo7Lf6zHnpg: Dictionary = __LcbL96hhs0uDGpxL5IdC8qIS(__36Zpa33fE9uR65rtm7gqhqxP, int(__I8t2kPnhbWJmdiDVybFsIaPV[1]), __LJ2Y3IoNhffkvekIy0reFL33, s.__BJReFJ4ugditvprP9JFCx5S2.size(), __U1iLvYYREZ6ywUAoq0y2KnFu, __IKxAM9m2VzSH9uAwjl1WsBMS, __I8t2kPnhbWJmdiDVybFsIaPV.slice(2, 6), __Wzynz0dOe0SvUrgMuYPh0Ewu, __jTR2bN7LV04KQhea9uxogIrN, __DGQ0uhEX1fdGQpMxBY3jG78h)
		__yR_iLmKU32nh5oo7Lf6zHnpg["arc"] = __qMgx2xniWV3CrHxkVBORnmfJ.__gZ1cKgcxU_2wQ9Sjq5C5NuMQ(__36Zpa33fE9uR65rtm7gqhqxP, __zSSlTPHoSmmFH5vX2_4j8d69, __GRH9byGvJarluY696tOd5rSf)
		__qMgx2xniWV3CrHxkVBORnmfJ.update(__yR_iLmKU32nh5oo7Lf6zHnpg)
		s.__BJReFJ4ugditvprP9JFCx5S2.append(__yR_iLmKU32nh5oo7Lf6zHnpg)
	s.__Z1n6LQ0e8g_Sv5O7it1HPeiw = s.__BJReFJ4ugditvprP9JFCx5S2[0]["shell"] if not s.__BJReFJ4ugditvprP9JFCx5S2.is_empty() else {}
	var __vQlLyeBl_y0NswhFhMOWKLD8: Array[Dictionary] = __KELTLmGSrnNU7KQ0gs5NQE7T(__36Zpa33fE9uR65rtm7gqhqxP, __zSSlTPHoSmmFH5vX2_4j8d69)
	for __VdsmgS5nQtGPnwOidXYKqJBd: Variant in __Bao7vWrytRTJMy5VZ4WMTLw4.get("torps", []):
		var __LKQSE94IqAN_6EY0WffMpRKM: Array = __VdsmgS5nQtGPnwOidXYKqJBd
		var __sbdXJfzJPV83KKb1nqJB2tAn: int = int(__LKQSE94IqAN_6EY0WffMpRKM[0])
		var __grm8GJkoC8Vp_ZYFZCaHWOYj: int = int(__LKQSE94IqAN_6EY0WffMpRKM[1])
		if __grm8GJkoC8Vp_ZYFZCaHWOYj < 0 or __sbdXJfzJPV83KKb1nqJB2tAn < 0 or __sbdXJfzJPV83KKb1nqJB2tAn >= __vQlLyeBl_y0NswhFhMOWKLD8.size():
			continue
		var __sx0Yr6JJImUzb2TdNK_wtLsZ: Dictionary = __0QiGqbYBLZEUENpkfN6eZqIr.__HZi2risTlbqOUjRCjHNjLHFR(__36Zpa33fE9uR65rtm7gqhqxP, __grm8GJkoC8Vp_ZYFZCaHWOYj, __vQlLyeBl_y0NswhFhMOWKLD8[__sbdXJfzJPV83KKb1nqJB2tAn], 
			int(__LKQSE94IqAN_6EY0WffMpRKM[2]) if __LKQSE94IqAN_6EY0WffMpRKM.size() >= 4 else -2, int(__LKQSE94IqAN_6EY0WffMpRKM[3]) if __LKQSE94IqAN_6EY0WffMpRKM.size() >= 4 else -1)
		__sx0Yr6JJImUzb2TdNK_wtLsZ["step_base"] = __jTR2bN7LV04KQhea9uxogIrN
		__sx0Yr6JJImUzb2TdNK_wtLsZ["arc"] = __qMgx2xniWV3CrHxkVBORnmfJ.__gZ1cKgcxU_2wQ9Sjq5C5NuMQ(__36Zpa33fE9uR65rtm7gqhqxP, __zSSlTPHoSmmFH5vX2_4j8d69, __sbdXJfzJPV83KKb1nqJB2tAn)
		__qMgx2xniWV3CrHxkVBORnmfJ.update(__sx0Yr6JJImUzb2TdNK_wtLsZ)
		s.__bFJ1csmbpVraScDCZhw1ETZ5.append(__sx0Yr6JJImUzb2TdNK_wtLsZ)
	s.__dKFYKO52kDsiWE3ajFZXSNS8 = __36Zpa33fE9uR65rtm7gqhqxP.__Jy2hcMM9emCF3iBBkLMyeUr7("FCS", __DGQ0uhEX1fdGQpMxBY3jG78h, 156) + int(__Wzynz0dOe0SvUrgMuYPh0Ewu[0]["reload"]) * 2
	s.__sfrhGgpP8JHW6nvd0GQRC91I = __36Zpa33fE9uR65rtm7gqhqxP.__pGLr1ud1V6XsMMJoSyeTRFjY("FCS", __DGQ0uhEX1fdGQpMxBY3jG78h, 40) == 1
	s.__P6eCDN63DJlbyMrNKQSMz7jJ = __36Zpa33fE9uR65rtm7gqhqxP.__Jy2hcMM9emCF3iBBkLMyeUr7("FCS", __DGQ0uhEX1fdGQpMxBY3jG78h, 32) == 2 and __36Zpa33fE9uR65rtm7gqhqxP.__Jy2hcMM9emCF3iBBkLMyeUr7("FCS", __DGQ0uhEX1fdGQpMxBY3jG78h, 34) == 13
	s.__EDY8L7ZwwyvqzS_1DgBi_MLl = __Wzynz0dOe0SvUrgMuYPh0Ewu
	for v: Variant in __Bao7vWrytRTJMy5VZ4WMTLw4.get("crew_men", []):
		s.___eFzo1uyZh_e9NPYOmnK6zN7.append(clampi(int(v), 0, 255))
	s.__c15rG2tC96oGc8kXqdQ_1wyL.resize(s.___eFzo1uyZh_e9NPYOmnK6zN7.size())
	var __8IBnJvqhKiR0IbfW4izp8j1E: Array = __Bao7vWrytRTJMy5VZ4WMTLw4.get("sub_crew", [])
	s.__ZhyiLCIyqHoRZeY0UaFeTs3e = __qUuRE3qEzIGmcU0ysMMtWssY.__CFp_Gkyg7KU_KTsHY4j4RY2O(__36Zpa33fE9uR65rtm7gqhqxP, __zSSlTPHoSmmFH5vX2_4j8d69, __S0wcWvy_PnvT0hxvr5dq1Say, __8IBnJvqhKiR0IbfW4izp8j1E)
	s.__lp5nMIOUyaTDuOPtUm4IpHRu = __36Zpa33fE9uR65rtm7gqhqxP.__Jy2hcMM9emCF3iBBkLMyeUr7("Frame", __zSSlTPHoSmmFH5vX2_4j8d69, 896) * __osOG1KsSfr5d06WoVaC5BGTs.__PZuvU2poi87JVOji8imEUsic / 100
	s.__z0cWmVEHlOSDFrPoyOKsE_Uz = (__36Zpa33fE9uR65rtm7gqhqxP.__Jy2hcMM9emCF3iBBkLMyeUr7("FCS", __DGQ0uhEX1fdGQpMxBY3jG78h, 154) + int(__Wzynz0dOe0SvUrgMuYPh0Ewu[0]["reload"])) * 65 / 100
	if __S0wcWvy_PnvT0hxvr5dq1Say == __Se4EsxPBCHX48h1ZS5MexaMl.__4cYyo29DcWFPcLdEsHACapS4:
		s.__AReCBHrBYt7dD7H_WiK9Tklz = __qUuRE3qEzIGmcU0ysMMtWssY.__QzaulhB5qi1lk5lL1_bQpc1D(__36Zpa33fE9uR65rtm7gqhqxP, __zSSlTPHoSmmFH5vX2_4j8d69, __8IBnJvqhKiR0IbfW4izp8j1E)
	var __WGpZLuvAxw4bS1jgEY3qVF6w: int = __36Zpa33fE9uR65rtm7gqhqxP.__pGLr1ud1V6XsMMJoSyeTRFjY("Frame", __zSSlTPHoSmmFH5vX2_4j8d69, 104)
	s.target = __lD9jdayjUI4kyjb3FfGbuNHq(__36Zpa33fE9uR65rtm7gqhqxP, __zSSlTPHoSmmFH5vX2_4j8d69, __Bao7vWrytRTJMy5VZ4WMTLw4.get("armor", []))
	s.__F41ZT8z_0zKKqYDFwqS1WGTs = __WGpZLuvAxw4bS1jgEY3qVF6w
	s.__EnRnlPve0Y145ZsCmTA3iWUI = __WGpZLuvAxw4bS1jgEY3qVF6w
	s.__pzCTF_BkwoDdXpHKn6Fvy06v = mini(__WGpZLuvAxw4bS1jgEY3qVF6w, s.__EnRnlPve0Y145ZsCmTA3iWUI)
	s.__1_VYwkJQtQVG29nVEi0IzFyr = s.__pzCTF_BkwoDdXpHKn6Fvy06v
	s.__aD1qlnd4hnNTYgeXVdepDA_r = __WGpZLuvAxw4bS1jgEY3qVF6w * 100
	var __U9pC1D_wiqrl7k_yY9Vi9k0u: int = clampi(int(__Bao7vWrytRTJMy5VZ4WMTLw4.get("crew_repair", 0)), 0, 2047)
	s.__VbylkHuK2INqbIKAJCnc5bAl = maxi(1, 1000 / (__U9pC1D_wiqrl7k_yY9Vi9k0u + 100))
	s.__taA4rALZcNBmsecQJlevt9Lp = __U9pC1D_wiqrl7k_yY9Vi9k0u / 2 + 100
	s.target.__z1h5crv4MA_meJnC8VvHilW3 = mini(900, 2 * clampi(int(__Bao7vWrytRTJMy5VZ4WMTLw4.get("crew_restore", 0)), 0, 65535))
	s.__Ve8GcAIF_A5LCRbDWrCm4UTG = __NYbIaW78BNqdaS0BgoYwqAci.__2sWFTMVqasaRcdvV0b4W5_lZ(s.__TMaqDrkAeK6UVY6d4JshSgUc, s.__11jta_pen9MsoYrWopEHFcWy)
	s.__qRd4QjUucufMZ5_bNJXHQAA8 = __NYbIaW78BNqdaS0BgoYwqAci.__xFhBsH_CiM4qJWi1cUo2fHki(s.__TMaqDrkAeK6UVY6d4JshSgUc, s.__11jta_pen9MsoYrWopEHFcWy)
	s.__xp5_QDRUZ8Q1w94JJafc_35N = __a3Qlrip4DI7L5IkLGkgxE5xK.__DsPMDiFMjhFuKK6KYj6QVgYN(__Atp8MoxKoQM9tdMR6w80VJG2)
	s.__NELIelBEafKRGQultNqYAbM7 = __NYbIaW78BNqdaS0BgoYwqAci.___bw4ml0gwbxgfsM9S7qgu8mj(__bNPpeuRkyJLCHe1DdXcSlDqu.get(__S0wcWvy_PnvT0hxvr5dq1Say, __7LAX6iA_3EiLvNuT8tdV7o0O))
	if __Bao7vWrytRTJMy5VZ4WMTLw4.has("engine") and int(__Bao7vWrytRTJMy5VZ4WMTLw4["engine"]) >= 0:
		var __CL6xIEDMatDdRTi1hCUifEH3: int = int(__Bao7vWrytRTJMy5VZ4WMTLw4["engine"])
		var __uW2DAugQh1YUGv7JQF_YIBPr: int = __rE0McfzbdQFKc4LopFW9XMAd(__36Zpa33fE9uR65rtm7gqhqxP, __zSSlTPHoSmmFH5vX2_4j8d69, __CL6xIEDMatDdRTi1hCUifEH3, __y0S06mrMPVxMf_Zlje07ITBq(__36Zpa33fE9uR65rtm7gqhqxP, __Bao7vWrytRTJMy5VZ4WMTLw4))
		s.__NELIelBEafKRGQultNqYAbM7 = __NYbIaW78BNqdaS0BgoYwqAci.___bw4ml0gwbxgfsM9S7qgu8mj(__uW2DAugQh1YUGv7JQF_YIBPr)
		var __sNRIPakS9BHZsGiEHhjZaM9z: = PackedInt32Array(__Bao7vWrytRTJMy5VZ4WMTLw4.get("crew_engine", [0, 0, 0]))
		var __NYxnMtrNs3MA6s3gVbvc1BlS: int = __6JV8CAX2HqhD7_dopT9dfg_8(__36Zpa33fE9uR65rtm7gqhqxP, __zSSlTPHoSmmFH5vX2_4j8d69, __CL6xIEDMatDdRTi1hCUifEH3, __S0wcWvy_PnvT0hxvr5dq1Say, __uW2DAugQh1YUGv7JQF_YIBPr, __sNRIPakS9BHZsGiEHhjZaM9z)
		__NYbIaW78BNqdaS0BgoYwqAci.__vUuy3zr2zlR1gaJCTRVk5Agz(s.__NELIelBEafKRGQultNqYAbM7, __NYxnMtrNs3MA6s3gVbvc1BlS, __OkVfGWi6A7iSRtV1KMbEPTze(__36Zpa33fE9uR65rtm7gqhqxP, __CL6xIEDMatDdRTi1hCUifEH3, __sNRIPakS9BHZsGiEHhjZaM9z), __36Zpa33fE9uR65rtm7gqhqxP.__Jy2hcMM9emCF3iBBkLMyeUr7("Engine", __CL6xIEDMatDdRTi1hCUifEH3, 10), __0aqgElJwReIe221GMKFmJFb2(__36Zpa33fE9uR65rtm7gqhqxP, __Bao7vWrytRTJMy5VZ4WMTLw4))
		s.__8NOgOL41CVxb75P_V2_ouKa9()
	var __Fd2RoyE1i2Uf1Rhu5sWawTa8: Vector2i = __Bao7vWrytRTJMy5VZ4WMTLw4["pos"]
	s.__gz4iZzIm1ic26sbX2dyDa0Lg = __NYbIaW78BNqdaS0BgoYwqAci.__kqOm_ZCSIe1QlLbPW1PAJ2Ds(__Fd2RoyE1i2Uf1Rhu5sWawTa8.x, __Fd2RoyE1i2Uf1Rhu5sWawTa8.y, __Bao7vWrytRTJMy5VZ4WMTLw4["heading"], s.__NELIelBEafKRGQultNqYAbM7["max_speed"], __CNY56ZmxlLQtcwZrg38hFleU)
	s.__g7JC3EJmfsOWnIyqLGGB93eB = __1q0DwOCFFBOQDiHI3310K_lq.__YNjSGlrkuU4xu5LIhzsrDpM7(__36Zpa33fE9uR65rtm7gqhqxP, __zSSlTPHoSmmFH5vX2_4j8d69, __Bao7vWrytRTJMy5VZ4WMTLw4.get("air", []), __Bao7vWrytRTJMy5VZ4WMTLw4.get("pilots", []))

	s.set_meta("meti_reward_base_hp", maxi(0, s.__EnRnlPve0Y145ZsCmTA3iWUI))
	if s.__ZMgQrrB9zxLXJ4nY9DOrkD1m:
		meti_apply_player_boost(s)
	s.__EmMf0cxHRAVgj110OQS4mPPJ(index)
	return s

static func meti_gain(n: int) -> int:
	return maxi(n, 0) * 3 / 2
static func meti_is_boosted(s: __YdhZSn3k6BLtSITi5naOCb7n) -> bool:
	return s != null and s.has_meta("meti_fleet_boost")
static func meti_apply_player_boost(s: __YdhZSn3k6BLtSITi5naOCb7n) -> void :
	if not s.__ZMgQrrB9zxLXJ4nY9DOrkD1m or meti_is_boosted(s):
		return
	s.set_meta("meti_fleet_boost", 150)

	for g: Dictionary in s.__BJReFJ4ugditvprP9JFCx5S2:
		g["acc70"] = meti_gain(meti_gain(int(g["acc70"])))
		g["reload_total"] = maxi(1, int(g["reload_total"]) / 2)
		g["reload_cnt"] = int(g["reload_total"])
		g["meti_range_pct"] = 150
		g["meti_spread_floor"] = 4
	for g: Dictionary in s.__bFJ1csmbpVraScDCZhw1ETZ5:
		g["reload_total"] = maxi(1, int(g["reload_total"]) / 2)
		g["reload_cnt"] = int(g["reload_total"])
		for key: String in ["spd_slow", "spd_fast", "r_slow", "r_fast"]:
			g[key] = meti_gain(int(g[key]))
	for key: String in ["__F41ZT8z_0zKKqYDFwqS1WGTs", "__EnRnlPve0Y145ZsCmTA3iWUI", "__pzCTF_BkwoDdXpHKn6Fvy06v", "__1_VYwkJQtQVG29nVEi0IzFyr", "__aD1qlnd4hnNTYgeXVdepDA_r", "__taA4rALZcNBmsecQJlevt9Lp", "__lp5nMIOUyaTDuOPtUm4IpHRu", "__ZhyiLCIyqHoRZeY0UaFeTs3e", "__dKFYKO52kDsiWE3ajFZXSNS8", "__z0cWmVEHlOSDFrPoyOKsE_Uz"]:
		s.set(key, meti_gain(int(s.get(key))))
	for key: String in ["ap_deck", "he_deck", "ap_side", "he_side", "__tU3LKkiKFkCz9gqPVWopN1ej", "__Ub5aVTwuCgOWLFhYmM4vLKch"]:
		s.target.set(key, meti_gain(int(s.target.get(key))))
	s.target.sub = mini(10000, meti_gain(s.target.sub))

	s.target.__z1h5crv4MA_meJnC8VvHilW3 = mini(950, meti_gain(s.target.__z1h5crv4MA_meJnC8VvHilW3))
	s.__NELIelBEafKRGQultNqYAbM7["max_speed"] = meti_gain(int(s.__NELIelBEafKRGQultNqYAbM7["max_speed"]))
	s.__NELIelBEafKRGQultNqYAbM7["heat_max"] = meti_gain(int(s.__NELIelBEafKRGQultNqYAbM7.get("heat_max", 0)))
	s.__NELIelBEafKRGQultNqYAbM7["meti_fleet_boost"] = true
	s.__gz4iZzIm1ic26sbX2dyDa0Lg["max_speed"] = int(s.__NELIelBEafKRGQultNqYAbM7["max_speed"])
	s.__gz4iZzIm1ic26sbX2dyDa0Lg["rudder"] = meti_gain(int(s.__gz4iZzIm1ic26sbX2dyDa0Lg["rudder"]))
	if not s.__AReCBHrBYt7dD7H_WiK9Tklz.is_empty():
		for key: String in ["o2", "o2_max", "o2_regen", "o2_alarm"]:
			s.__AReCBHrBYt7dD7H_WiK9Tklz[key] = meti_gain(int(s.__AReCBHrBYt7dD7H_WiK9Tklz[key]))
static func meti_apply_aircraft_boost(owner: __YdhZSn3k6BLtSITi5naOCb7n, a: __YCYnibBjVPRhMDf3YPwizbkN) -> void :
	if not meti_is_boosted(owner) or a.has_meta("meti_fleet_boost"):
		return
	a.set_meta("meti_fleet_boost", 150)
	for key: String in ["__405kukUhPFu5e4xu_Qs1ihtC", "__MVPWKWAdbVfRM4oRuvTXhfBA", "__HqMti1TAnrtmLUJSJQBYdY_P", "__F41ZT8z_0zKKqYDFwqS1WGTs", "__iWPWvu2E2PGZ_Ugxj5W2EIIM", "__lp5nMIOUyaTDuOPtUm4IpHRu", "__FiUAjtJlUwX6oDIWxrerhOV4", "__EHjU5UjAgmmddD5nyx49ar6j", "__wK6c6xRBxB0Lka8tqK6RrNfH", "__w87XrXWtBktdMVowYWiePwsm"]:
		a.set(key, meti_gain(int(a.get(key))))

static func meti_reward_hp(s: __YdhZSn3k6BLtSITi5naOCb7n) -> int:
	return maxi(0, int(s.get_meta("meti_reward_base_hp", s.__EnRnlPve0Y145ZsCmTA3iWUI)))


static func meti_catalog_main_seat(catalog: Variant, frame: int, index: int) -> int:
	var mounts: PackedInt32Array = catalog.__1y_c36LINhCmyTQh_Ii1WqjM(frame)
	if index < 0 or index >= mounts.size(): return 0
	var details: Dictionary = catalog.__ofKSCLcCg7jWtqacDa153ehk(frame)
	return 1 if (details.get("t_slots", PackedInt32Array()) as PackedInt32Array).has(mounts[index]) else 0
