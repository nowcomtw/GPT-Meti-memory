class_name __YdhZSn3k6BLtSITi5naOCb7n
extends RefCounted
var meti_convergence_solver: Variant
var meti_convergence_tick: int = 0
var __taA4rALZcNBmsecQJlevt9Lp: int = 100
var __aCAPgZOjbD1shm6WhpFLgjLA: int = 0
var __l9VibzAjJA8MnBH74WNhUJZL: int = 0
var __pzCTF_BkwoDdXpHKn6Fvy06v: int = 0
var __CQmrJDrlrxQho2i8OkSrVQ1N: int = 0
var __VbylkHuK2INqbIKAJCnc5bAl: int = 10
var __7OKcEzdMfOdabzyMipWdSzWD: int = 0
var __gz4iZzIm1ic26sbX2dyDa0Lg: Dictionary
var __hPAwypoCaWQ892foj1dQ9sNQ: bool = false
var target: __nZxK7u5JB3kHTF7XC5Hr9MHe.__C9ZAnKztslaadyzGQaCAJD4g
func __Ca1QMASFb6V5xXOp2z7G46y2(__HIQKIPLb8masbBKrWxn1SFM5: __aDswGCE4WWdmypkp3eC7rExn, __CpttG9wdxgeqfOTkKrZi0qCL: int) -> bool:
	if __5M2Kw9tr4U856gth8pKR0sL6() != 0:
		__HIQKIPLb8masbBKrWxn1SFM5.__VkzoyB_koPjfXQZjEINKML3x(self, 0)
		return false
	var g: Dictionary = __BJReFJ4ugditvprP9JFCx5S2[__CpttG9wdxgeqfOTkKrZi0qCL]
	var __d2bc0NYx50jrEowIGZP3wcom: String = "ammo_a" if int(g["cargo"]) == 0 else "ammo_b"
	var __4KgeLYSBHTCVzEvm4t2YLWlw: Vector2i = __yRuUzjxz_RR_5vyQfUbTx_ec(__CpttG9wdxgeqfOTkKrZi0qCL)
	var __SksdldC3RmAB50TlM8qjLTaW: int = (__Rzlu0K6FmW_AJtyGtfyruX3f(g) + 900) % 3600
	var __7QzGUm68_J5mE6QcD29GcSA7: Array[Dictionary] = __a3Qlrip4DI7L5IkLGkgxE5xK.__Uinp0qKlBAx07Wxg3OpdJrIb(g, __SksdldC3RmAB50TlM8qjLTaW, g["elev"], __HIQKIPLb8masbBKrWxn1SFM5.__EaiCL_s7Is8n8XhLMgCmd8bh, __HIQKIPLb8masbBKrWxn1SFM5.__t2UdGLb5AjoD9DJacXSIpDUA, __HIQKIPLb8masbBKrWxn1SFM5.__T3MhJL9nMTQaWMJrYSTIXXqi, __4KgeLYSBHTCVzEvm4t2YLWlw.x, __4KgeLYSBHTCVzEvm4t2YLWlw.y, not meti_convergence_active(g), __CQmrJDrlrxQho2i8OkSrVQ1N)
	if meti_convergence_active(g) and bool((g["meti_convergence"] as Dictionary).get("in_range", false)):
		var meti_shell: Dictionary = g["shell"] if int(g["cargo"]) == 0 else g["shell_b"]
		__7QzGUm68_J5mE6QcD29GcSA7 = meti_convergence_solver.align_shots(__7QzGUm68_J5mE6QcD29GcSA7, meti_shell, Vector2i(__k2tNHcrJ7Ubu73oDndNmYPUU, __PnHs8Uffgi24ue5O7EVvelTY))
	var __Eyz5KRlOj5KbkAlh0UwyGoL8: int = posmod(__SksdldC3RmAB50TlM8qjLTaW - 900 + 50, 3600) / 100
	var __HcinxX4LXZaKbECy4Od_evU4: int = int(g["max_el"]) / 8
	var __eZ508JALvk9RZEFgJqPljsO1: int = mini((int(g["elev"]) + __HcinxX4LXZaKbECy4Od_evU4 / 2) / __HcinxX4LXZaKbECy4Od_evU4, 7) if __HcinxX4LXZaKbECy4Od_evU4 != 0 else 0
	for b: int in __7QzGUm68_J5mE6QcD29GcSA7.size():
		__HIQKIPLb8masbBKrWxn1SFM5.__SDO_gx_r7X0a5aDqKCZQvEOl(self, __7QzGUm68_J5mE6QcD29GcSA7[b], __CpttG9wdxgeqfOTkKrZi0qCL, b, __4KgeLYSBHTCVzEvm4t2YLWlw, __Eyz5KRlOj5KbkAlh0UwyGoL8, __eZ508JALvk9RZEFgJqPljsO1)
	g["ready"] = false
	g["reload_cnt"] = 0
	g[__d2bc0NYx50jrEowIGZP3wcom] = maxi(0, int(g[__d2bc0NYx50jrEowIGZP3wcom]) - int(g["barrels"]))
	return true
var __tUvbj0r8Sx1dDiR_V1FeCNWc: bool = false
var __NqcLKvQgaJD_pE3JD6vSe71E: Dictionary
var __dKFYKO52kDsiWE3ajFZXSNS8: int = 0
var __zMZVCIoyJu5zkEI6YyKqPDoG: int = 1
const __C7xcmZA2pKrTCZKgj1qKKrFu: = 18
func __ZV7plMkusH5L3GTvXeqo9_1l(__ZEVOIgDsUpQcNTTC2h7u9ZMe: Dictionary) -> bool:
	return bool(__ODOtqe2fVanVALAUFKm2DrFT(__ZEVOIgDsUpQcNTTC2h7u9ZMe)["in_arc"])
var __WeB9Hi0OxaFBUuwm2WU2qKEH: int = 0
func __7pjg1aLmopfQC2fotNH01Sr1() -> int:
	var __OBZRi3ghbEe9IBEEoMqZcdRk: int = 0
	for __JWkN0CmVdSijd3m9tr0qDPL3: Dictionary in __bFJ1csmbpVraScDCZhw1ETZ5:
		__OBZRi3ghbEe9IBEEoMqZcdRk |= 1 << clampi(int(__JWkN0CmVdSijd3m9tr0qDPL3["group"]), 0, 1)
	return __OBZRi3ghbEe9IBEEoMqZcdRk
func __vqYa6WuT8lqRfpObeEEtFMHG() -> int:
	return __NYbIaW78BNqdaS0BgoYwqAci.__RWH6xbYnbHrh4GpYPcCA_viz(__gz4iZzIm1ic26sbX2dyDa0Lg)
var __JCVAOijT_RUiAesgY0ay5TGW: String = ""
func __dikdT8ep_BEw8dJq04CW6Hqc() -> Array[Dictionary]:
	var __rq11wu4HZoB9W0RFsM7nUzse: Array[Dictionary] = []
	for g: Dictionary in __BJReFJ4ugditvprP9JFCx5S2:
		if int(g.get("seat", 0)) == __1Z7OFhxB6TttwviVl7guTYN5:
			__rq11wu4HZoB9W0RFsM7nUzse.append(g)
	for __t12Y8hFMhgqlybNwdc4AotL4: Dictionary in __bFJ1csmbpVraScDCZhw1ETZ5:
		if int(__t12Y8hFMhgqlybNwdc4AotL4["seat"]) == __1Z7OFhxB6TttwviVl7guTYN5:
			__rq11wu4HZoB9W0RFsM7nUzse.append(__t12Y8hFMhgqlybNwdc4AotL4)
	return __rq11wu4HZoB9W0RFsM7nUzse
var __TUveEYNBcdzuJiqL7lNZR8jT: int = __PqwHiMCiEKMg9bL_3LrzgjVT.__Df7mxkznfLfIj2iCD1v2Tzl8
var __Ve8GcAIF_A5LCRbDWrCm4UTG: PackedInt32Array
func __Bpoqe1W5ylsDxCjA0DYpM1c4(__T7UBJvSiU_27z7K74ImVV5M1: __aDswGCE4WWdmypkp3eC7rExn, __aGpcDZORrOlxVF3k7V_S2eEn: Dictionary) -> bool:
	if __aGpcDZORrOlxVF3k7V_S2eEn["launcher"]:
		return __Q_9fkG2hGD6ORvZ7SlpxS5kE(__T7UBJvSiU_27z7K74ImVV5M1, int(__aGpcDZORrOlxVF3k7V_S2eEn["index"]))
	return __Ca1QMASFb6V5xXOp2z7G46y2(__T7UBJvSiU_27z7K74ImVV5M1, int(__aGpcDZORrOlxVF3k7V_S2eEn["index"]))
func __solO5HvH5_phFEVtjG1aHjOu(g: Dictionary) -> int:
	var __qGshlow9H1unkqYITCEmxjL_: Vector2i = __oc4DIMhqXqRDsyYDHkfod1e6(g)
	return posmod(__NYbIaW78BNqdaS0BgoYwqAci.__KojNCs5E3fJteg0BP_ow8L2D(__k2tNHcrJ7Ubu73oDndNmYPUU - __qGshlow9H1unkqYITCEmxjL_.x, (__PnHs8Uffgi24ue5O7EVvelTY - __qGshlow9H1unkqYITCEmxjL_.y) * 117 / 100) - 900, 3600)
var __RZSGss6vMJxzvS6fmWkQMma8: int = 0
var __JyKN1BCLnMyYGyw5SpRUKPUu: int = -1
var __kWx_ghjWrsvKfbTBZsiahQQd: = PackedInt32Array()
func __SPR76xfpBxHAoiwc3f8pLgC0(__SKkJxPHDxkNWq_NuhOa2MLlk: Dictionary) -> bool:
	return __ZV7plMkusH5L3GTvXeqo9_1l(__SKkJxPHDxkNWq_NuhOa2MLlk) and __76Z0rglxZP6S_ZI_ZfUWN4YZ(__SKkJxPHDxkNWq_NuhOa2MLlk)
func __Rzlu0K6FmW_AJtyGtfyruX3f(g: Dictionary) -> int:
	return posmod(__vqYa6WuT8lqRfpObeEEtFMHG() + int(g["base"]) + int(g["angle"]), 3600)
var __sfrhGgpP8JHW6nvd0GQRC91I: bool = false
func __Q_9fkG2hGD6ORvZ7SlpxS5kE(__HWi6Fmah1krIRJgrfUdd59U2: __aDswGCE4WWdmypkp3eC7rExn, __lDxcznMOrJlP5exdU1SDDP0Z: int) -> bool:
	if __5M2Kw9tr4U856gth8pKR0sL6() > __qUuRE3qEzIGmcU0ysMMtWssY.__hyGIR4DJfnQtW3RWkaPipovP:
		__HWi6Fmah1krIRJgrfUdd59U2.__VkzoyB_koPjfXQZjEINKML3x(self, 1)
		return false
	var __NmJvb5krhtgwtBhlmDdR7zqO: Dictionary = __bFJ1csmbpVraScDCZhw1ETZ5[__lDxcznMOrJlP5exdU1SDDP0Z]
	if int(__NmJvb5krhtgwtBhlmDdR7zqO.get("type", 0)) == __Se4EsxPBCHX48h1ZS5MexaMl.__0U0KBY397RbdFoLdZ_I870eo:
		__HWi6Fmah1krIRJgrfUdd59U2.__C7KC9_8obIScUs3UrOqPmWr1(self, __lDxcznMOrJlP5exdU1SDDP0Z)
	else:
		__HWi6Fmah1krIRJgrfUdd59U2.__00bBZDN3MIh6G8fMyPRVYOsa(self, __lDxcznMOrJlP5exdU1SDDP0Z)
	__NmJvb5krhtgwtBhlmDdR7zqO["ready"] = false
	__NmJvb5krhtgwtBhlmDdR7zqO["reload_cnt"] = 0
	__NmJvb5krhtgwtBhlmDdR7zqO["ammo"] = maxi(0, int(__NmJvb5krhtgwtBhlmDdR7zqO["ammo"]) - mini(int(__NmJvb5krhtgwtBhlmDdR7zqO["ammo"]), int(__NmJvb5krhtgwtBhlmDdR7zqO["tubes"])))
	return true
const __gJlQ_MAOI1fUZ0lp200xQHBV: = 2
var __P6eCDN63DJlbyMrNKQSMz7jJ: bool = false
var state: int = __lAo0PsogaUvqHw4muTzPsHiR.__pRO7nOY10o2GAU3KzWQvIvwY
var __g7JC3EJmfsOWnIyqLGGB93eB: __1q0DwOCFFBOQDiHI3310K_lq
var __1Z7OFhxB6TttwviVl7guTYN5: int = 0
var terrain: __NYbIaW78BNqdaS0BgoYwqAci.__O1Urlr6IdUTnFWvioe6wcQrt
enum __PqwHiMCiEKMg9bL_3LrzgjVT{__Df7mxkznfLfIj2iCD1v2Tzl8, __PLG2h02Fza5h2Njac1k_BipJ, __EoLOtxbBEbp6g1WLVe7W5fow}
func __eApL0Mnhi3qPFjXtuxe0KTtH(__t9wERMkFQ8M4lAuUfpO_ALof: Vector2i) -> int:
	var __XRdtzbi3s5TGMpsAWWyvMqZK: int = 0
	for g: Dictionary in __BJReFJ4ugditvprP9JFCx5S2:
		if not g.get("broken", false) and __oc4DIMhqXqRDsyYDHkfod1e6(g) == __t9wERMkFQ8M4lAuUfpO_ALof:
			__egEhGs_JGZBzwbo5g8bIAmPr(g)
			__XRdtzbi3s5TGMpsAWWyvMqZK += 1
	for __Oy6BeM0CNSPjHQKd5UZcKn60: Dictionary in __bFJ1csmbpVraScDCZhw1ETZ5:
		if not __Oy6BeM0CNSPjHQKd5UZcKn60.get("broken", false) and __oc4DIMhqXqRDsyYDHkfod1e6(__Oy6BeM0CNSPjHQKd5UZcKn60) == __t9wERMkFQ8M4lAuUfpO_ALof:
			__egEhGs_JGZBzwbo5g8bIAmPr(__Oy6BeM0CNSPjHQKd5UZcKn60)
			__XRdtzbi3s5TGMpsAWWyvMqZK += 1
	return __XRdtzbi3s5TGMpsAWWyvMqZK
var ___eFzo1uyZh_e9NPYOmnK6zN7: PackedInt32Array = PackedInt32Array()
func __kC6zD903kIOB35eRqjx8Rhn6(__9f8ADE18XZq1vofpX87KdLCD: __aDswGCE4WWdmypkp3eC7rExn) -> void :
	if state != __lAo0PsogaUvqHw4muTzPsHiR.__pRO7nOY10o2GAU3KzWQvIvwY:
		return
	if not __AReCBHrBYt7dD7H_WiK9Tklz.is_empty():
		__qUuRE3qEzIGmcU0ysMMtWssY.__kC6zD903kIOB35eRqjx8Rhn6(__9f8ADE18XZq1vofpX87KdLCD, self)
	__gz4iZzIm1ic26sbX2dyDa0Lg["speed"] = __NYbIaW78BNqdaS0BgoYwqAci.__KrsSmgV_rDiZ33uCFtPv6OiV(__NELIelBEafKRGQultNqYAbM7)
	if int(__NELIelBEafKRGQultNqYAbM7.get("evt", -1)) >= 0:
		__9f8ADE18XZq1vofpX87KdLCD.__p4BfRGGYcGsflWTqyV1NyITt(self, int(__NELIelBEafKRGQultNqYAbM7["evt"]))
		__NELIelBEafKRGQultNqYAbM7["evt"] = __NYbIaW78BNqdaS0BgoYwqAci.__oj0fZgh_8Nb6kwHfmU6ttWyD.NONE
	if __z3E6yteFGGFPHRPT5j4Cy1cu < 0:
		__z3E6yteFGGFPHRPT5j4Cy1cu = __vqYa6WuT8lqRfpObeEEtFMHG()
	__tUvbj0r8Sx1dDiR_V1FeCNWc = __NYbIaW78BNqdaS0BgoYwqAci.__7cUj3z5t30yxrHXrICbEqcGv(__gz4iZzIm1ic26sbX2dyDa0Lg, __Ve8GcAIF_A5LCRbDWrCm4UTG, terrain) == __NYbIaW78BNqdaS0BgoYwqAci.__f175MfZwVQGiKWRyJg8wlbn1.__aLRYuOKQE6yNrtNFEfx5hbQ5
	__f7LrUFIKIheZs6lRNgJZU6u7()
	__gz4iZzIm1ic26sbX2dyDa0Lg["forced_back"] = 0 if __NYbIaW78BNqdaS0BgoYwqAci.__iGECzm9BEXFrHekNgHDCTkaQ(terrain, x(), y()) else 1
	if __rWMF7C3LY0TC6hhI0FLU6j3w and (__RZSGss6vMJxzvS6fmWkQMma8 == __Se4EsxPBCHX48h1ZS5MexaMl.__G44Evdb0N6ASIG4CZetONXN3 or __RZSGss6vMJxzvS6fmWkQMma8 == __Se4EsxPBCHX48h1ZS5MexaMl.___e9YmZDsB38bzJrvwKRJL5VJ) and __F41ZT8z_0zKKqYDFwqS1WGTs * 100 < __EnRnlPve0Y145ZsCmTA3iWUI * __lAo0PsogaUvqHw4muTzPsHiR.__kJiZhKac7aZLQMeVJVWRIdct:
		__rWMF7C3LY0TC6hhI0FLU6j3w = false
		__9f8ADE18XZq1vofpX87KdLCD.__iaETM43CHl2xsxBnGjisMUgG(self)
	meti_convergence_tick += 1
	for g: Dictionary in __BJReFJ4ugditvprP9JFCx5S2:
		__C6pewoIsQqLWcmNf6AFJV9OO(g)
	for __Bhhyu3HlY46QHz8DRT9NUwfB: Dictionary in __bFJ1csmbpVraScDCZhw1ETZ5:
		__C6pewoIsQqLWcmNf6AFJV9OO(__Bhhyu3HlY46QHz8DRT9NUwfB)
	if __tUvbj0r8Sx1dDiR_V1FeCNWc:
		__zp3VN8122KJqD8VYx2at1x2y(1, 1, 1, 0, 4)
	if (__9f8ADE18XZq1vofpX87KdLCD.__EaiCL_s7Is8n8XhLMgCmd8bh + __9f8ADE18XZq1vofpX87KdLCD.__t2UdGLb5AjoD9DJacXSIpDUA) % __VbylkHuK2INqbIKAJCnc5bAl == 0:
		__tfU6sIqLdczoVvPcEGbX1DcY()
	if __ws2s4Lfa3YoMJ_OoXIToq1w_:
		__ws2s4Lfa3YoMJ_OoXIToq1w_ = false
		__Q1Ln01NXPgdvF6QhefXUrm89(__9f8ADE18XZq1vofpX87KdLCD)
func __QYxNDclhLiUG8cH9G_EpMh6K(code: int, __vXCSZrjdvPgjmpItbGaSWzdb: PackedByteArray) -> void :
	var __RD9VG5t4MkgTvTRkjF07JhGA: bool = code <= __lAo0PsogaUvqHw4muTzPsHiR.__gLoQenqQKJmSjbh_G751Ko5Z
	var __RVZQV1yhRsRKFt7k2BmGnK9Z: int = code
	if code > __lAo0PsogaUvqHw4muTzPsHiR.__gLoQenqQKJmSjbh_G751Ko5Z:
		__RD9VG5t4MkgTvTRkjF07JhGA = false
		__RVZQV1yhRsRKFt7k2BmGnK9Z = code - __lAo0PsogaUvqHw4muTzPsHiR.__gLoQenqQKJmSjbh_G751Ko5Z
	if not __AReCBHrBYt7dD7H_WiK9Tklz.is_empty() and __5M2Kw9tr4U856gth8pKR0sL6() > __qUuRE3qEzIGmcU0ysMMtWssY.__hyGIR4DJfnQtW3RWkaPipovP and (__RVZQV1yhRsRKFt7k2BmGnK9Z == __lAo0PsogaUvqHw4muTzPsHiR.__Dsb4LjdxP00zxF3IUtswUVjG or __RVZQV1yhRsRKFt7k2BmGnK9Z == __lAo0PsogaUvqHw4muTzPsHiR.__dMHONq9ik330c3bH2pw2zAAX or __RVZQV1yhRsRKFt7k2BmGnK9Z == __lAo0PsogaUvqHw4muTzPsHiR.___lp2hDbtgdIu1E4_S7ss1e93):
		return
	if __sfrhGgpP8JHW6nvd0GQRC91I and __RVZQV1yhRsRKFt7k2BmGnK9Z in __avkYETo5OTNKhnoKiwIqNdR1:
		return
	match __RVZQV1yhRsRKFt7k2BmGnK9Z:
		__lAo0PsogaUvqHw4muTzPsHiR.__QBgR4salFkVbsOQyeDL2U7FY:
			__rWMF7C3LY0TC6hhI0FLU6j3w = __RD9VG5t4MkgTvTRkjF07JhGA
		__lAo0PsogaUvqHw4muTzPsHiR.__cewsf_vW3eJj1apjb3LfTBVx:
			__EUkbEAh4d5DldiqwEPuX9leZ = __RD9VG5t4MkgTvTRkjF07JhGA
		__lAo0PsogaUvqHw4muTzPsHiR.__3d5z0svmANktmwFkrPC1mefB:
			__0j_qIrRynBs_5RNxom5Lo_bi = 16
		__lAo0PsogaUvqHw4muTzPsHiR.__BUjmR2W6genrB_HePsbdMlW0:
			__0j_qIrRynBs_5RNxom5Lo_bi = 32
		__lAo0PsogaUvqHw4muTzPsHiR.__zjrBy1cfGfTf3izcAfz7nsGX:
			__0j_qIrRynBs_5RNxom5Lo_bi = 48
		__lAo0PsogaUvqHw4muTzPsHiR.__2ogiMbKSY7aCBSaMOTp7JxES, __lAo0PsogaUvqHw4muTzPsHiR.__hJ906P5T7hYZzc1aHoPNprmB:
			if __RD9VG5t4MkgTvTRkjF07JhGA:
				var d: int = 1 if __RVZQV1yhRsRKFt7k2BmGnK9Z == __lAo0PsogaUvqHw4muTzPsHiR.__2ogiMbKSY7aCBSaMOTp7JxES else -1
				for g: Dictionary in __dikdT8ep_BEw8dJq04CW6Hqc():
					if __hQ0Qf6xcbMMYVte0AH7gKSm7(g):
						g["rot_dir"] = d
						g["rotating"] = true
			else:
				__KhmVtyYlmSSvNn5KsfgPDfgU()
		__lAo0PsogaUvqHw4muTzPsHiR.__lOHmdo7cEYWT7Dci6dgjLNSC, __lAo0PsogaUvqHw4muTzPsHiR.__iYjF7VTaRBU9Oa7XIqZI756V:
			if __RD9VG5t4MkgTvTRkjF07JhGA:
				var __BrNU5tNsfP0geATaJU4dJ4Wt: int = 1 if __RVZQV1yhRsRKFt7k2BmGnK9Z == __lAo0PsogaUvqHw4muTzPsHiR.__lOHmdo7cEYWT7Dci6dgjLNSC else -1
				__hPAwypoCaWQ892foj1dQ9sNQ = true
				for g: Dictionary in __dikdT8ep_BEw8dJq04CW6Hqc():
					g["rot_dir"] = __BrNU5tNsfP0geATaJU4dJ4Wt if int(g["group"]) == 0 else - __BrNU5tNsfP0geATaJU4dJ4Wt
					g["rotating"] = true
			else:
				__KhmVtyYlmSSvNn5KsfgPDfgU()
		__lAo0PsogaUvqHw4muTzPsHiR.__1xZojPAXYnqTbsgr_dPisBM0, __lAo0PsogaUvqHw4muTzPsHiR.__XjXeXgQAsqoe1wUcPGCGzSwD:
			var d: int = 1 if __RVZQV1yhRsRKFt7k2BmGnK9Z == __lAo0PsogaUvqHw4muTzPsHiR.__1xZojPAXYnqTbsgr_dPisBM0 else -1
			for g: Dictionary in __BJReFJ4ugditvprP9JFCx5S2:
				if __hQ0Qf6xcbMMYVte0AH7gKSm7(g) and int(g.get("seat", 0)) == __1Z7OFhxB6TttwviVl7guTYN5:
					__M5ZgulieFBERxDbGFPtfpqep(g, d, __RD9VG5t4MkgTvTRkjF07JhGA)
		__lAo0PsogaUvqHw4muTzPsHiR.__Dsb4LjdxP00zxF3IUtswUVjG:
			__NELIelBEafKRGQultNqYAbM7["order"] = 1 if __RD9VG5t4MkgTvTRkjF07JhGA else 4
		__lAo0PsogaUvqHw4muTzPsHiR.__dMHONq9ik330c3bH2pw2zAAX:
			__NELIelBEafKRGQultNqYAbM7["order"] = 2 if __RD9VG5t4MkgTvTRkjF07JhGA else 4
		__lAo0PsogaUvqHw4muTzPsHiR.___lp2hDbtgdIu1E4_S7ss1e93:
			if __RD9VG5t4MkgTvTRkjF07JhGA:
				__NELIelBEafKRGQultNqYAbM7["order"] = 4
				__NELIelBEafKRGQultNqYAbM7["notch"] = mini(100, int(__NELIelBEafKRGQultNqYAbM7["cap"]))
		__lAo0PsogaUvqHw4muTzPsHiR.__VQY0_u79FK4EiyI4L6TWIVjn:
			var h: int = __gz4iZzIm1ic26sbX2dyDa0Lg["heading"]
			__gz4iZzIm1ic26sbX2dyDa0Lg["dest_x"] = x() + __TXCdoY85HWzo9E7Qcf9l8raZ.__9nHAKAsjPH38LR2tAezCTqd_[h] * 4000 / 1000
			__gz4iZzIm1ic26sbX2dyDa0Lg["dest_y"] = y() - __TXCdoY85HWzo9E7Qcf9l8raZ.__7laIgLr3i8VN0D_tZnYT3p0D[h] * 4000 / 1000
			__gz4iZzIm1ic26sbX2dyDa0Lg["arrived"] = 0
		__lAo0PsogaUvqHw4muTzPsHiR.__rxKLn2zNn0YfPpRPd7y5XJ8R:
			__gz4iZzIm1ic26sbX2dyDa0Lg["dest_x"] = __vXCSZrjdvPgjmpItbGaSWzdb.decode_s16(0)
			__gz4iZzIm1ic26sbX2dyDa0Lg["dest_y"] = __vXCSZrjdvPgjmpItbGaSWzdb.decode_s16(2)
			__gz4iZzIm1ic26sbX2dyDa0Lg["arrived"] = 0
			__gz4iZzIm1ic26sbX2dyDa0Lg["follow"] = 0
		__lAo0PsogaUvqHw4muTzPsHiR.__K1NW_qnIvknoGGkxaf24lsNr:
			__ws2s4Lfa3YoMJ_OoXIToq1w_ = true
		__lAo0PsogaUvqHw4muTzPsHiR.__sKP2pX8KjRdyhsUnZlBoy8m7:
			if __RD9VG5t4MkgTvTRkjF07JhGA:
				__TUveEYNBcdzuJiqL7lNZR8jT = (__TUveEYNBcdzuJiqL7lNZR8jT + 1) % 3
		__lAo0PsogaUvqHw4muTzPsHiR.__zgCYYCU4ZzZcxsYWnnvBe9vp, __lAo0PsogaUvqHw4muTzPsHiR.__D4rOWsJ8XW1iJ9yMW1uULvCr:
			if __RD9VG5t4MkgTvTRkjF07JhGA:
				for g: Dictionary in __BJReFJ4ugditvprP9JFCx5S2:
					g["rotating"] = false
					g["elevating"] = false
					g["el_goal"] = -1
				for __25wfeykpiYkqJavXYgIWzftW: Dictionary in __bFJ1csmbpVraScDCZhw1ETZ5:
					__25wfeykpiYkqJavXYgIWzftW["rotating"] = false
				__hPAwypoCaWQ892foj1dQ9sNQ = false
				__1Z7OFhxB6TttwviVl7guTYN5 = 0 if __RVZQV1yhRsRKFt7k2BmGnK9Z == __lAo0PsogaUvqHw4muTzPsHiR.__zgCYYCU4ZzZcxsYWnnvBe9vp else 1
		__lAo0PsogaUvqHw4muTzPsHiR.__kfX66rmDmQ2K_XOIie1GiS2E:
			if __RD9VG5t4MkgTvTRkjF07JhGA:
				for g: Dictionary in __BJReFJ4ugditvprP9JFCx5S2:
					if __hQ0Qf6xcbMMYVte0AH7gKSm7(g) and int(g.get("seat", 0)) == __1Z7OFhxB6TttwviVl7guTYN5:
						g["cargo"] = 1 - int(g["cargo"])
		__lAo0PsogaUvqHw4muTzPsHiR.__S2o_fvLm7mGMyCVCuahRIVFl, __lAo0PsogaUvqHw4muTzPsHiR.__HRFjMaKLCxHsSVll2zvyduyC:
			if __RD9VG5t4MkgTvTRkjF07JhGA:
				var __ClSATRUp18tfQhNptXInGYK5: int = int(__vXCSZrjdvPgjmpItbGaSWzdb[0]) & 3 if __vXCSZrjdvPgjmpItbGaSWzdb.size() >= 1 else __0j_qIrRynBs_5RNxom5Lo_bi >> 4
				var __OqKEOPv7aWuGs27eUtqyAjb6: Array[bool] = __NNllNpdcFaCi_4XYufJlvaqy if __RVZQV1yhRsRKFt7k2BmGnK9Z == __lAo0PsogaUvqHw4muTzPsHiR.__S2o_fvLm7mGMyCVCuahRIVFl else __dFQZCtulu2HCzKfxAuhLiq1b
				for __TdUDJQ4mk8y5Ccw0kpOfGIhG: int in 2:
					if (__ClSATRUp18tfQhNptXInGYK5 & (1 << __TdUDJQ4mk8y5Ccw0kpOfGIhG)) != 0:
						__OqKEOPv7aWuGs27eUtqyAjb6[__TdUDJQ4mk8y5Ccw0kpOfGIhG] = not __OqKEOPv7aWuGs27eUtqyAjb6[__TdUDJQ4mk8y5Ccw0kpOfGIhG]
var __EDY8L7ZwwyvqzS_1DgBi_MLl: Array[Dictionary] = []
func __oc4DIMhqXqRDsyYDHkfod1e6(g: Dictionary) -> Vector2i:
	var d: int = (__Bbtqn2iLah0_TnXXrRodcN9S() * 100) % 3600
	var __sEvDC34r_Uk5YSZMpb5cgV9T: int = __TXCdoY85HWzo9E7Qcf9l8raZ.__9nHAKAsjPH38LR2tAezCTqd_[d]
	var s: int = __TXCdoY85HWzo9E7Qcf9l8raZ.__7laIgLr3i8VN0D_tZnYT3p0D[d]
	var a: int = g["mount_a"]
	var b: int = g["mount_b"]
	return Vector2i(x() + (a * __sEvDC34r_Uk5YSZMpb5cgV9T - b * s) / 1000, y() - int(g["mount_h"]) - (a * s + b * __sEvDC34r_Uk5YSZMpb5cgV9T) / 2000)
func y() -> int:
	return __gz4iZzIm1ic26sbX2dyDa0Lg["y"]
func __Bbtqn2iLah0_TnXXrRodcN9S() -> int:
	return ((__vqYa6WuT8lqRfpObeEEtFMHG() + 50) / 100) % 36
func __zp3VN8122KJqD8VYx2at1x2y(__toWCKOvONsF2rwvHEPv1ceTt: int, __ocLFJR8owJ_LWb8qaUogK4AH: int, __b5wXwhww3XiLImEItgYts8gg: int, __8azzu2ZVymSutI0LeCqnYQex: int, type: int) -> int:
	target.__tU3LKkiKFkCz9gqPVWopN1ej = maxi(0, target.__tU3LKkiKFkCz9gqPVWopN1ej - __8azzu2ZVymSutI0LeCqnYQex)
	var r: int = __pzCTF_BkwoDdXpHKn6Fvy06v - __ocLFJR8owJ_LWb8qaUogK4AH
	__pzCTF_BkwoDdXpHKn6Fvy06v = r
	__aD1qlnd4hnNTYgeXVdepDA_r = r * 100
	if type != 5 and r < 0:
		if __toWCKOvONsF2rwvHEPv1ceTt < - r:
			__toWCKOvONsF2rwvHEPv1ceTt = - r
		__pzCTF_BkwoDdXpHKn6Fvy06v = 0
	__1_VYwkJQtQVG29nVEi0IzFyr = maxi(0, __1_VYwkJQtQVG29nVEi0IzFyr - __b5wXwhww3XiLImEItgYts8gg)
	__F41ZT8z_0zKKqYDFwqS1WGTs = 0 if __F41ZT8z_0zKKqYDFwqS1WGTs < __toWCKOvONsF2rwvHEPv1ceTt else __F41ZT8z_0zKKqYDFwqS1WGTs - __toWCKOvONsF2rwvHEPv1ceTt
	__8NOgOL41CVxb75P_V2_ouKa9()
	return __ocLFJR8owJ_LWb8qaUogK4AH
var __KLxhKPISj_AUmBVDjcFeRqL7: String = ""
var __v8mocfZjhMZerysSVdVBa3gx: int = -1
func __KhmVtyYlmSSvNn5KsfgPDfgU() -> void :
	for g: Dictionary in __BJReFJ4ugditvprP9JFCx5S2:
		if __hPAwypoCaWQ892foj1dQ9sNQ or __hQ0Qf6xcbMMYVte0AH7gKSm7(g):
			g["rotating"] = false
	for __X7YkpdWZCnlncDDku58ECFOw: Dictionary in __bFJ1csmbpVraScDCZhw1ETZ5:
		if __hPAwypoCaWQ892foj1dQ9sNQ or __hQ0Qf6xcbMMYVte0AH7gKSm7(__X7YkpdWZCnlncDDku58ECFOw):
			__X7YkpdWZCnlncDDku58ECFOw["rotating"] = false
	__hPAwypoCaWQ892foj1dQ9sNQ = false
var __c15rG2tC96oGc8kXqdQ_1wyL: PackedInt32Array = PackedInt32Array()
func __M5ZgulieFBERxDbGFPtfpqep(g: Dictionary, d: int, __6IvcZE6Zyiyhh2jAVerz3o25: bool) -> void :
	if __6IvcZE6Zyiyhh2jAVerz3o25:
		var __oy7VRxmOe0pNc2kY61to7PuN: int = int(g.get("el_goal", -1))
		var from: int = __oy7VRxmOe0pNc2kY61to7PuN if __oy7VRxmOe0pNc2kY61to7PuN >= 0 else int(g["elev"])
		g["el_goal"] = -1 if __EUkbEAh4d5DldiqwEPuX9leZ else clampi((from / 10 + d) * 10, 0, int(g["max_el"]))
		g["elev_dir"] = d
		g["elevating"] = true
		g["el_hold"] = 0
		g["el_cont"] = false
		return
	g["el_hold"] = -1
	if g.get("el_cont", false) and int(g["elev"]) != int(g["max_el"]):
		g["elev"] = int(g["elev"]) / 10 * 10
	g["el_cont"] = false
	if int(g.get("el_goal", -1)) < 0:
		g["elevating"] = false
var __k2tNHcrJ7Ubu73oDndNmYPUU: int = -1
func __f7LrUFIKIheZs6lRNgJZU6u7() -> void :
	var h: int = __vqYa6WuT8lqRfpObeEEtFMHG()
	var __oqd2Gyew_hLhG4JY4iojQtrS: int = posmod(h - __z3E6yteFGGFPHRPT5j4Cy1cu + 1800, 3600) - 1800
	__z3E6yteFGGFPHRPT5j4Cy1cu = h
	if __oqd2Gyew_hLhG4JY4iojQtrS == 0:
		return
	for g: Dictionary in __BJReFJ4ugditvprP9JFCx5S2:
		g["angle"] = posmod(int(g["angle"]) - __oqd2Gyew_hLhG4JY4iojQtrS, 3600)
	for __x9eFADihmh45o3sTlyKKhffB: Dictionary in __bFJ1csmbpVraScDCZhw1ETZ5:
		__x9eFADihmh45o3sTlyKKhffB["angle"] = posmod(int(__x9eFADihmh45o3sTlyKKhffB["angle"]) - __oqd2Gyew_hLhG4JY4iojQtrS, 3600)
func __MpnqF3TEucSJpg5SlIfA6pFP() -> bool:
	var __grCmeaB7e0gDcrKMyrb3KCHR: Array[Dictionary] = __WHseGwgjEprddkpOGYqALvgd()
	if __TUveEYNBcdzuJiqL7lNZR8jT == __PqwHiMCiEKMg9bL_3LrzgjVT.__PLG2h02Fza5h2Njac1k_BipJ:
		var __TrC_Sf567DKY3ijizwPeSPyq: bool = false
		for __4pMZdr2vdtMBpmewiMr051UW: Dictionary in __grCmeaB7e0gDcrKMyrb3KCHR:
			if not __ZV7plMkusH5L3GTvXeqo9_1l(__4pMZdr2vdtMBpmewiMr051UW):
				continue
			__TrC_Sf567DKY3ijizwPeSPyq = true
			if not __76Z0rglxZP6S_ZI_ZfUWN4YZ(__4pMZdr2vdtMBpmewiMr051UW):
				return false
		return __TrC_Sf567DKY3ijizwPeSPyq
	for __5hmgKtzUGoKdEIeCiZVOyxTB: Dictionary in __grCmeaB7e0gDcrKMyrb3KCHR:
		if __SPR76xfpBxHAoiwc3f8pLgC0(__5hmgKtzUGoKdEIeCiZVOyxTB):
			return true
	return false
var __rWMF7C3LY0TC6hhI0FLU6j3w: bool = false
func __76Z0rglxZP6S_ZI_ZfUWN4YZ(__JKsiWcyVLOuGL7Lo1v2kA9kF: Dictionary) -> bool:
	var meti_weapon: Dictionary = __ODOtqe2fVanVALAUFKm2DrFT(__JKsiWcyVLOuGL7Lo1v2kA9kF)
	if not bool(meti_weapon["ready"]):
		return false
	if not bool(__JKsiWcyVLOuGL7Lo1v2kA9kF["launcher"]) and meti_convergence_active(meti_weapon):
		var meti_solution: Dictionary = meti_weapon["meti_convergence"]
		var meti_az_error: int = posmod(int(meti_solution["az"]) - 900 - __Rzlu0K6FmW_AJtyGtfyruX3f(meti_weapon) + 1800, 3600) - 1800
		return absi(meti_az_error) <= 1 and absi(int(meti_solution["elev"]) - int(meti_weapon["elev"])) <= 1
	return true
var __AReCBHrBYt7dD7H_WiK9Tklz: Dictionary = {}
var __dFQZCtulu2HCzKfxAuhLiq1b: Array[bool] = [false, false]
func __Q1Ln01NXPgdvF6QhefXUrm89(__qNxbzSRdY9ANboQwoi2Rx4DK: __aDswGCE4WWdmypkp3eC7rExn) -> void :
	var __mq6hG4Vvqi32QwNlKcPfbwu0: Array[Dictionary] = __WHseGwgjEprddkpOGYqALvgd()
	var __GAvuiZxR7u1N13hIDxMZw3bI: Array[Dictionary] = []
	match __TUveEYNBcdzuJiqL7lNZR8jT:
		__PqwHiMCiEKMg9bL_3LrzgjVT.__PLG2h02Fza5h2Njac1k_BipJ:
			for __mOdRs1MgK2edNLz7BqFPee65: Dictionary in __mq6hG4Vvqi32QwNlKcPfbwu0:
				if not __ZV7plMkusH5L3GTvXeqo9_1l(__mOdRs1MgK2edNLz7BqFPee65):
					continue
				if not __76Z0rglxZP6S_ZI_ZfUWN4YZ(__mOdRs1MgK2edNLz7BqFPee65):
					return
				__GAvuiZxR7u1N13hIDxMZw3bI.append(__mOdRs1MgK2edNLz7BqFPee65)
		__PqwHiMCiEKMg9bL_3LrzgjVT.__EoLOtxbBEbp6g1WLVe7W5fow:
			for step: int in __mq6hG4Vvqi32QwNlKcPfbwu0.size():
				var __18db06eTQi3AIbhC0dilsG27: Dictionary = __mq6hG4Vvqi32QwNlKcPfbwu0[(step + __scoalrEUDOUfB1BIgj9o35vI(__mq6hG4Vvqi32QwNlKcPfbwu0)) % __mq6hG4Vvqi32QwNlKcPfbwu0.size()]
				if __SPR76xfpBxHAoiwc3f8pLgC0(__18db06eTQi3AIbhC0dilsG27):
					__GAvuiZxR7u1N13hIDxMZw3bI.append(__18db06eTQi3AIbhC0dilsG27)
					break
		_:
			for __c_O3_7twyQRxuYdxZioIOmFi: Dictionary in __mq6hG4Vvqi32QwNlKcPfbwu0:
				if __SPR76xfpBxHAoiwc3f8pLgC0(__c_O3_7twyQRxuYdxZioIOmFi):
					__GAvuiZxR7u1N13hIDxMZw3bI.append(__c_O3_7twyQRxuYdxZioIOmFi)
	for __0_JoasJHNO7zLg7aJlttEMgw: Dictionary in __GAvuiZxR7u1N13hIDxMZw3bI:
		var __mNCXBaUcm2vD8kyxaXtk15go: bool = __Bpoqe1W5ylsDxCjA0DYpM1c4(__qNxbzSRdY9ANboQwoi2Rx4DK, __0_JoasJHNO7zLg7aJlttEMgw)
		if __mNCXBaUcm2vD8kyxaXtk15go and __TUveEYNBcdzuJiqL7lNZR8jT == __PqwHiMCiEKMg9bL_3LrzgjVT.__EoLOtxbBEbp6g1WLVe7W5fow:
			__v8mocfZjhMZerysSVdVBa3gx = int(__0_JoasJHNO7zLg7aJlttEMgw["slot"])
const __avkYETo5OTNKhnoKiwIqNdR1: = [__lAo0PsogaUvqHw4muTzPsHiR.__2ogiMbKSY7aCBSaMOTp7JxES, __lAo0PsogaUvqHw4muTzPsHiR.__hJ906P5T7hYZzc1aHoPNprmB, __lAo0PsogaUvqHw4muTzPsHiR.__lOHmdo7cEYWT7Dci6dgjLNSC, __lAo0PsogaUvqHw4muTzPsHiR.__iYjF7VTaRBU9Oa7XIqZI756V, __lAo0PsogaUvqHw4muTzPsHiR.__1xZojPAXYnqTbsgr_dPisBM0, __lAo0PsogaUvqHw4muTzPsHiR.__XjXeXgQAsqoe1wUcPGCGzSwD]
var __Z1n6LQ0e8g_Sv5O7it1HPeiw: Dictionary
var __QiHzrKvwrwbVmkkk810kJg1o: int = 0
var __NNllNpdcFaCi_4XYufJlvaqy: Array[bool] = [false, false]
func __hQ0Qf6xcbMMYVte0AH7gKSm7(g: Dictionary) -> bool:
	var __udK3nsuqLNU4JO6F26xoOyh2: int = 16 if int(g["group"]) == 0 else 32
	return (__0j_qIrRynBs_5RNxom5Lo_bi & __udK3nsuqLNU4JO6F26xoOyh2) != 0
func __ZyQ4vUu4MYH__GF0hCZPc6Um(g: Dictionary) -> void :
	if __k2tNHcrJ7Ubu73oDndNmYPUU < 0 or int(g.get("seat", 0)) != __1Z7OFhxB6TttwviVl7guTYN5 or not __hQ0Qf6xcbMMYVte0AH7gKSm7(g):
		if g.has("aim_rot_step"):
			g["rotating"] = false
			g.erase("aim_rot_step")
		if g.has("aim_elev_step"):
			g["elevating"] = false
			g.erase("aim_elev_step")
		return
	var __EQCrLhh9pXK6VzYE8riuFeyM: bool = g.has("tp_row")
	var meti_solution: Dictionary = meti_converge_solution(g) if not __EQCrLhh9pXK6VzYE8riuFeyM else {}
	var __K3bzGozcwIYitknHXJZFzGOX: int = int(g["aim_az"]) if (__P6eCDN63DJlbyMrNKQSMz7jJ and g.has("aim_az")) else __QiHzrKvwrwbVmkkk810kJg1o
	if not meti_solution.is_empty():
		__K3bzGozcwIYitknHXJZFzGOX = posmod(int(meti_solution["az"]) - 900, 3600)
	var d: int = posmod(__K3bzGozcwIYitknHXJZFzGOX - __Rzlu0K6FmW_AJtyGtfyruX3f(g) + 1800, 3600) - 1800
	if g.has("arc"):
		var __9EWaujHoGoQf6S4rG5P1wsAG: PackedInt32Array = g["arc"]
		d = __qMgx2xniWV3CrHxkVBORnmfJ.__HnkNEEzx9cicC0YZSbxS7l0S(__9EWaujHoGoQf6S4rG5P1wsAG, posmod(__9EWaujHoGoQf6S4rG5P1wsAG[__qMgx2xniWV3CrHxkVBORnmfJ.__68waEMvuU8SORbBP2i6X3UOD] + int(g["angle"]), 3600), posmod(__K3bzGozcwIYitknHXJZFzGOX - __vqYa6WuT8lqRfpObeEEtFMHG(), 3600))
	var __hcsiwLKVH5CWwqRRJbFcnqkb: int = (__C7xcmZA2pKrTCZKgj1qKKrFu if __rWMF7C3LY0TC6hhI0FLU6j3w else __nlthqFBoqlwZmvAHBTPDGIYz) if __EQCrLhh9pXK6VzYE8riuFeyM else __BgNu6qlKbMFxOIduOfRw1lpN
	if not meti_solution.is_empty():
		__hcsiwLKVH5CWwqRRJbFcnqkb = 0
		g["meti_rot_remaining"] = absi(d)
	if absi(d) <= __hcsiwLKVH5CWwqRRJbFcnqkb:
		g["rotating"] = false
		g.erase("aim_rot_step")
	else:
		g["rotating"] = true
		g["rot_dir"] = 1 if d > 0 else -1
		g["aim_rot_step"] = 2 if absi(d) <= int(g["step_base"]) + 2 else 5
		if __rWMF7C3LY0TC6hhI0FLU6j3w:
			g["aim_rot_step"] = mini(2 if __EUkbEAh4d5DldiqwEPuX9leZ else int(g["step_base"]) + 2, absi(d))
	if __EQCrLhh9pXK6VzYE8riuFeyM:
		return
	var __0dUy3nixZqFUs5DlTiYVzlOT: int = __zju8koRRwto7fzzxR5TTU1ZT[int(g.get("seat", 0))]
	var __O5eLbVJUAyosv80P4W4QwpbL: Dictionary = g["shell"] if int(g["cargo"]) == 0 else g["shell_b"]
	if int(__O5eLbVJUAyosv80P4W4QwpbL.get("kind", 0)) == 1:
		var __m4yqIUwI6hkgiQ6QCSDGYusm: Vector2i = __oc4DIMhqXqRDsyYDHkfod1e6(g)
		var __wdEhp7GECKaUk_k1OY7d2jUN: int = __Irz9hiGcyslSDsJT8BenfEt2.__f8g2PjfN7nwJbTHn9ePhmeZH((__k2tNHcrJ7Ubu73oDndNmYPUU - __m4yqIUwI6hkgiQ6QCSDGYusm.x) * (__k2tNHcrJ7Ubu73oDndNmYPUU - __m4yqIUwI6hkgiQ6QCSDGYusm.x) + (__PnHs8Uffgi24ue5O7EVvelTY - __m4yqIUwI6hkgiQ6QCSDGYusm.y) * (__PnHs8Uffgi24ue5O7EVvelTY - __m4yqIUwI6hkgiQ6QCSDGYusm.y))
		__0dUy3nixZqFUs5DlTiYVzlOT = mini(maxi(900 - __wdEhp7GECKaUk_k1OY7d2jUN * 10 / 6, 100), int(g["max_el"]))
	if not meti_solution.is_empty():
		__0dUy3nixZqFUs5DlTiYVzlOT = int(meti_solution["elev"])
	var __5qf09YdieB8GxLvBMQmk9NBp: int = __0dUy3nixZqFUs5DlTiYVzlOT - int(g["elev"])
	if not meti_solution.is_empty():
		g["meti_elev_remaining"] = absi(__5qf09YdieB8GxLvBMQmk9NBp)
	if absi(__5qf09YdieB8GxLvBMQmk9NBp) <= (0 if not meti_solution.is_empty() else __gJlQ_MAOI1fUZ0lp200xQHBV):
		g["elevating"] = false
		g.erase("aim_elev_step")
	else:
		g["elevating"] = true
		g["elev_dir"] = 1 if __5qf09YdieB8GxLvBMQmk9NBp > 0 else -1
		g["aim_elev_step"] = 1 if absi(__5qf09YdieB8GxLvBMQmk9NBp) < __UiwJBpIkgjBc2ujJdryKWVRJ else 3
		if __rWMF7C3LY0TC6hhI0FLU6j3w:
			g["aim_elev_step"] = mini(1 if __EUkbEAh4d5DldiqwEPuX9leZ else int(g["step_base"]) / 2 + 3, absi(__5qf09YdieB8GxLvBMQmk9NBp))
var index: int = 0
var __ZMgQrrB9zxLXJ4nY9DOrkD1m: bool = false
var __lp5nMIOUyaTDuOPtUm4IpHRu: int = 0
var __xp5_QDRUZ8Q1w94JJafc_35N: Dictionary
func __2mSX9u3Uv_8woBUECnpZM0xY() -> void :
	var __QNeSm42Ne3Xznyg_vgSUCkjT: int = __k2tNHcrJ7Ubu73oDndNmYPUU - x()
	var __Kt_5LF8HEdbY_ZjGiy415aeh: int = __PnHs8Uffgi24ue5O7EVvelTY - y()
	var b: int = __NYbIaW78BNqdaS0BgoYwqAci.__KojNCs5E3fJteg0BP_ow8L2D(__QNeSm42Ne3Xznyg_vgSUCkjT, __Kt_5LF8HEdbY_ZjGiy415aeh * 117 / 100)
	__QiHzrKvwrwbVmkkk810kJg1o = posmod(b - 900, 3600)
	var __kFL2y5nNrsRiLzyUaQqTSEIq: int = __Irz9hiGcyslSDsJT8BenfEt2.__f8g2PjfN7nwJbTHn9ePhmeZH(__QNeSm42Ne3Xznyg_vgSUCkjT * __QNeSm42Ne3Xznyg_vgSUCkjT + __Kt_5LF8HEdbY_ZjGiy415aeh * __Kt_5LF8HEdbY_ZjGiy415aeh)
	var __r_bzNGxGeevjHW1B1tOFUO_D: bool = (450 <= b and b <= 1350) or (2250 <= b and b <= 3150)
	for ___7OIvKbsUeNpXkrDIdIKk8YD: int in 2:
		var __icVwmsH66WDzK3tk1NodtEmH: int = __7aPSjzsiug8Scbil7Xy9VkQ1(___7OIvKbsUeNpXkrDIdIKk8YD)
		if __icVwmsH66WDzK3tk1NodtEmH < 0:
			continue
		var __zvpKNYU8qZN0oB9OJ9MqEceD: int = __FbfcZh7zipvK02thKpA13yoN.__kaiZ0kjaagXyKF3ZaVK_ICNW(self, __kFL2y5nNrsRiLzyUaQqTSEIq, __icVwmsH66WDzK3tk1NodtEmH).x
		if __r_bzNGxGeevjHW1B1tOFUO_D:
			__zvpKNYU8qZN0oB9OJ9MqEceD += __zvpKNYU8qZN0oB9OJ9MqEceD * 3 / 10
		__zju8koRRwto7fzzxR5TTU1ZT[___7OIvKbsUeNpXkrDIdIKk8YD] = mini(__zvpKNYU8qZN0oB9OJ9MqEceD, int(__BJReFJ4ugditvprP9JFCx5S2[__icVwmsH66WDzK3tk1NodtEmH]["max_el"]))
	if __P6eCDN63DJlbyMrNKQSMz7jJ:
		for g: Dictionary in __BJReFJ4ugditvprP9JFCx5S2:
			g["aim_az"] = __solO5HvH5_phFEVtjG1aHjOu(g)
		for __YSwAcMEIJIZKnW1KfsnoA2Rn: Dictionary in __bFJ1csmbpVraScDCZhw1ETZ5:
			__YSwAcMEIJIZKnW1KfsnoA2Rn["aim_az"] = __solO5HvH5_phFEVtjG1aHjOu(__YSwAcMEIJIZKnW1KfsnoA2Rn)
var __qRd4QjUucufMZ5_bNJXHQAA8: PackedInt32Array
var __F41ZT8z_0zKKqYDFwqS1WGTs: int = 0
var __bFJ1csmbpVraScDCZhw1ETZ5: Array[Dictionary] = []
const __UiwJBpIkgjBc2ujJdryKWVRJ: = 16
var __BJReFJ4ugditvprP9JFCx5S2: Array[Dictionary] = []
var __zju8koRRwto7fzzxR5TTU1ZT: PackedInt32Array = PackedInt32Array([0, 0])
const __fIyWKHXmqCz0bTU1oUwUrkni: = 10
func __scoalrEUDOUfB1BIgj9o35vI(__XFWwYkWwNLbrBGu0XTxkDcYb: Array[Dictionary]) -> int:
	for __coYuV_zrIIs4BkD7bbVH0SJX: int in __XFWwYkWwNLbrBGu0XTxkDcYb.size():
		if int(__XFWwYkWwNLbrBGu0XTxkDcYb[__coYuV_zrIIs4BkD7bbVH0SJX]["slot"]) > __v8mocfZjhMZerysSVdVBa3gx:
			return __coYuV_zrIIs4BkD7bbVH0SJX
	return 0
func __7aPSjzsiug8Scbil7Xy9VkQ1(__Hx7XM1ZIepalR5SEIPu9dl2r: int) -> int:
	for __xLDYwDtLMrzjfFEZcWPDDijO: int in __BJReFJ4ugditvprP9JFCx5S2.size():
		if int(__BJReFJ4ugditvprP9JFCx5S2[__xLDYwDtLMrzjfFEZcWPDDijO].get("seat", 0)) == __Hx7XM1ZIepalR5SEIPu9dl2r:
			return __xLDYwDtLMrzjfFEZcWPDDijO
	return -1
func __5M2Kw9tr4U856gth8pKR0sL6() -> int:
	return int(__AReCBHrBYt7dD7H_WiK9Tklz["state"]) if not __AReCBHrBYt7dD7H_WiK9Tklz.is_empty() else 0
var __z3E6yteFGGFPHRPT5j4Cy1cu: int = -1
var __0j_qIrRynBs_5RNxom5Lo_bi: int = 48
func __EmMf0cxHRAVgj110OQS4mPPJ(__Wu2ELlY2I7b8NYjSqJLjrnCP: int) -> void :
	index = __Wu2ELlY2I7b8NYjSqJLjrnCP
	__NqcLKvQgaJD_pE3JD6vSe71E = {"hull": __xp5_QDRUZ8Q1w94JJafc_35N, "x": 0, "y": 0, "dir": 0, "state": state, "depth": 0, "team": __7OKcEzdMfOdabzyMipWdSzWD, "ship": __Wu2ELlY2I7b8NYjSqJLjrnCP}
	__KMQO2Dqf4U7hxuzv7dYCmrfF()
func __KMQO2Dqf4U7hxuzv7dYCmrfF() -> void :
	__NqcLKvQgaJD_pE3JD6vSe71E["x"] = __gz4iZzIm1ic26sbX2dyDa0Lg["x"]
	__NqcLKvQgaJD_pE3JD6vSe71E["y"] = __gz4iZzIm1ic26sbX2dyDa0Lg["y"]
	__NqcLKvQgaJD_pE3JD6vSe71E["dir"] = __Bbtqn2iLah0_TnXXrRodcN9S()
	__NqcLKvQgaJD_pE3JD6vSe71E["state"] = state
	__NqcLKvQgaJD_pE3JD6vSe71E["depth"] = __5M2Kw9tr4U856gth8pKR0sL6()
func __ODOtqe2fVanVALAUFKm2DrFT(__0Tpfywzhlny40FUEt8CHZN8b: Dictionary) -> Dictionary:
	return __bFJ1csmbpVraScDCZhw1ETZ5[int(__0Tpfywzhlny40FUEt8CHZN8b["index"])] if __0Tpfywzhlny40FUEt8CHZN8b["launcher"] else __BJReFJ4ugditvprP9JFCx5S2[int(__0Tpfywzhlny40FUEt8CHZN8b["index"])]
func __C6pewoIsQqLWcmNf6AFJV9OO(g: Dictionary) -> void :
	if g.get("broken", false):
		return
	if __sfrhGgpP8JHW6nvd0GQRC91I:
		__ZyQ4vUu4MYH__GF0hCZPc6Um(g)
	if g["rotating"]:
		var __5B2g58fxaWxgGDctoUpqKL1h: int = int(g["aim_rot_step"]) if g.has("aim_rot_step") else (2 if __EUkbEAh4d5DldiqwEPuX9leZ else ((int(g["step_base"]) + 2) if __rWMF7C3LY0TC6hhI0FLU6j3w else 5))
		if has_meta("meti_fleet_boost"):
			__5B2g58fxaWxgGDctoUpqKL1h = maxi(1, __5B2g58fxaWxgGDctoUpqKL1h * 3 / 2)
		if meti_convergence_active(g):
			__5B2g58fxaWxgGDctoUpqKL1h = mini(__5B2g58fxaWxgGDctoUpqKL1h, int(g.get("meti_rot_remaining", __5B2g58fxaWxgGDctoUpqKL1h)))
		g["angle"] = posmod(int(g["angle"]) + int(g["rot_dir"]) * __5B2g58fxaWxgGDctoUpqKL1h, 3600)
	if g.has("arc"):
		__qMgx2xniWV3CrHxkVBORnmfJ.update(g)
	if g["elevating"]:
		var __jY3vFyaCmt6U0_0n10cGLCFA: int = int(g["aim_elev_step"]) if g.has("aim_elev_step") else (1 if __EUkbEAh4d5DldiqwEPuX9leZ else ((int(g["step_base"]) / 2 + 3) if __rWMF7C3LY0TC6hhI0FLU6j3w else 3))
		if has_meta("meti_fleet_boost"):
			__jY3vFyaCmt6U0_0n10cGLCFA = maxi(1, __jY3vFyaCmt6U0_0n10cGLCFA * 3 / 2)
		if meti_convergence_active(g):
			__jY3vFyaCmt6U0_0n10cGLCFA = mini(__jY3vFyaCmt6U0_0n10cGLCFA, int(g.get("meti_elev_remaining", __jY3vFyaCmt6U0_0n10cGLCFA)))
		var __ndsCdx2W_9IKM6wniG6HA5Pc: int = int(g.get("el_hold", -1))
		if __ndsCdx2W_9IKM6wniG6HA5Pc >= 0:
			__ndsCdx2W_9IKM6wniG6HA5Pc += 1
			g["el_hold"] = __ndsCdx2W_9IKM6wniG6HA5Pc
		var __0T0WmNaoyDFDSz2GjUjYJTLU: int = int(g.get("el_goal", -1))
		if __sfrhGgpP8JHW6nvd0GQRC91I or __EUkbEAh4d5DldiqwEPuX9leZ or __ndsCdx2W_9IKM6wniG6HA5Pc > __fIyWKHXmqCz0bTU1oUwUrkni:
			g["el_goal"] = -1
			g["el_cont"] = not __sfrhGgpP8JHW6nvd0GQRC91I and not __EUkbEAh4d5DldiqwEPuX9leZ
			var __cjuXJkDDMPUUo90vYFjHo03J: int = int(g["elev"]) + int(g["elev_dir"]) * __jY3vFyaCmt6U0_0n10cGLCFA
			if __cjuXJkDDMPUUo90vYFjHo03J > int(g["max_el"]):
				__cjuXJkDDMPUUo90vYFjHo03J = g["max_el"]
				g["elevating"] = false
			if __cjuXJkDDMPUUo90vYFjHo03J < 0:
				__cjuXJkDDMPUUo90vYFjHo03J = 0
				g["elevating"] = false
			g["elev"] = __cjuXJkDDMPUUo90vYFjHo03J
		elif __0T0WmNaoyDFDSz2GjUjYJTLU >= 0:
			var __ziGxraQZV0CAiv0pPtB50WpM: int = int(g["elev"])
			__ziGxraQZV0CAiv0pPtB50WpM = mini(__ziGxraQZV0CAiv0pPtB50WpM + __jY3vFyaCmt6U0_0n10cGLCFA, __0T0WmNaoyDFDSz2GjUjYJTLU) if __ziGxraQZV0CAiv0pPtB50WpM < __0T0WmNaoyDFDSz2GjUjYJTLU else maxi(__ziGxraQZV0CAiv0pPtB50WpM - __jY3vFyaCmt6U0_0n10cGLCFA, __0T0WmNaoyDFDSz2GjUjYJTLU)
			g["elev"] = __ziGxraQZV0CAiv0pPtB50WpM
			if __ziGxraQZV0CAiv0pPtB50WpM == __0T0WmNaoyDFDSz2GjUjYJTLU:
				g["el_goal"] = -1
				if __ndsCdx2W_9IKM6wniG6HA5Pc < 0:
					g["elevating"] = false
		elif __ndsCdx2W_9IKM6wniG6HA5Pc < 0:
			g["elevating"] = false
	if not g["ready"]:
		if int(g["reload_cnt"]) < int(g["reload_total"]):
			g["reload_cnt"] = int(g["reload_cnt"]) + 1
		else:
			g["ready"] = true
func __yRuUzjxz_RR_5vyQfUbTx_ec(__BkprrNMrIrD0vFh_rqS_u1JT: int) -> Vector2i:
	return __oc4DIMhqXqRDsyYDHkfod1e6(__BJReFJ4ugditvprP9JFCx5S2[__BkprrNMrIrD0vFh_rqS_u1JT])
func __tfU6sIqLdczoVvPcEGbX1DcY() -> void :
	var __b_mXTn2RAQd32mqZiezA1Y_m: int = __5M2Kw9tr4U856gth8pKR0sL6()
	if __pzCTF_BkwoDdXpHKn6Fvy06v < __1_VYwkJQtQVG29nVEi0IzFyr:
		if __b_mXTn2RAQd32mqZiezA1Y_m != __qUuRE3qEzIGmcU0ysMMtWssY.__F_jqEWMCiinD78WMy2CvF0Vb:
			__aD1qlnd4hnNTYgeXVdepDA_r += __taA4rALZcNBmsecQJlevt9Lp if __b_mXTn2RAQd32mqZiezA1Y_m == __qUuRE3qEzIGmcU0ysMMtWssY.__A0W5Vw78_6xZnWPW2C9pqYbi else __taA4rALZcNBmsecQJlevt9Lp * 3 / 10
		__pzCTF_BkwoDdXpHKn6Fvy06v = __aD1qlnd4hnNTYgeXVdepDA_r / 100
	else:
		__pzCTF_BkwoDdXpHKn6Fvy06v = __1_VYwkJQtQVG29nVEi0IzFyr
	if __pzCTF_BkwoDdXpHKn6Fvy06v < __F41ZT8z_0zKKqYDFwqS1WGTs:
		__F41ZT8z_0zKKqYDFwqS1WGTs -= 1
	elif __F41ZT8z_0zKKqYDFwqS1WGTs < __1_VYwkJQtQVG29nVEi0IzFyr:
		__F41ZT8z_0zKKqYDFwqS1WGTs = __pzCTF_BkwoDdXpHKn6Fvy06v
	if __1_VYwkJQtQVG29nVEi0IzFyr < __F41ZT8z_0zKKqYDFwqS1WGTs:
		__F41ZT8z_0zKKqYDFwqS1WGTs = __1_VYwkJQtQVG29nVEi0IzFyr
	__8NOgOL41CVxb75P_V2_ouKa9()
static func __9bvqKDMT2IFXttS2HGV76zeD(mode: int) -> String:
	match mode:
		__PqwHiMCiEKMg9bL_3LrzgjVT.__PLG2h02Fza5h2Njac1k_BipJ: return "UI_BT_FIRE_VOLLEY"
		__PqwHiMCiEKMg9bL_3LrzgjVT.__EoLOtxbBEbp6g1WLVe7W5fow: return "UI_BT_FIRE_SUCCESSIVE"
		_: return "UI_BT_FIRE_MAXIMUM"
var __EUkbEAh4d5DldiqwEPuX9leZ: bool = false
func __WHseGwgjEprddkpOGYqALvgd() -> Array[Dictionary]:
	var __sHaebV4Lufo1HlA4QLFQUq2l: Array[Dictionary] = []
	for __1lHbzkKAWyrYWBDbnuSfgdyL: int in __BJReFJ4ugditvprP9JFCx5S2.size():
		var g: Dictionary = __BJReFJ4ugditvprP9JFCx5S2[__1lHbzkKAWyrYWBDbnuSfgdyL]
		var __NMCC9rqRFyGaarVCQRJPSfI7: String = "ammo_a" if int(g["cargo"]) == 0 else "ammo_b"
		if __hQ0Qf6xcbMMYVte0AH7gKSm7(g) and int(g.get("seat", 0)) == __1Z7OFhxB6TttwviVl7guTYN5 and not g.get("broken", false) and int(g[__NMCC9rqRFyGaarVCQRJPSfI7]) > 0:
			__sHaebV4Lufo1HlA4QLFQUq2l.append({"launcher": false, "index": __1lHbzkKAWyrYWBDbnuSfgdyL, "slot": int(g["slot"])})
	for __qiQ5hQOtDlW295DcryqGE7f7: int in __bFJ1csmbpVraScDCZhw1ETZ5.size():
		var __gnXWyU8gC2mGk_kLeNNpZvkc: Dictionary = __bFJ1csmbpVraScDCZhw1ETZ5[__qiQ5hQOtDlW295DcryqGE7f7]
		if __hQ0Qf6xcbMMYVte0AH7gKSm7(__gnXWyU8gC2mGk_kLeNNpZvkc) and int(__gnXWyU8gC2mGk_kLeNNpZvkc["seat"]) == __1Z7OFhxB6TttwviVl7guTYN5 and not __gnXWyU8gC2mGk_kLeNNpZvkc.get("broken", false) and int(__gnXWyU8gC2mGk_kLeNNpZvkc["ammo"]) > 0:
			__sHaebV4Lufo1HlA4QLFQUq2l.append({"launcher": true, "index": __qiQ5hQOtDlW295DcryqGE7f7, "slot": int(__gnXWyU8gC2mGk_kLeNNpZvkc["slot"])})
	__sHaebV4Lufo1HlA4QLFQUq2l.sort_custom( func(a: Dictionary, b: Dictionary) -> bool:
		return int(a["slot"]) < int(b["slot"]))
	return __sHaebV4Lufo1HlA4QLFQUq2l
var __ZhyiLCIyqHoRZeY0UaFeTs3e: int = 0
static func __GZTWhWj5KdYoklE6k3RT7Hp2(mode: int) -> String:
	var __wIXq33jW0DvBl49P9lc9IHzx: String = __9bvqKDMT2IFXttS2HGV76zeD(mode)
	var translated: String = TranslationServer.translate(__wIXq33jW0DvBl49P9lc9IHzx)
	if translated != __wIXq33jW0DvBl49P9lc9IHzx:
		return translated
	match mode:
		__PqwHiMCiEKMg9bL_3LrzgjVT.__PLG2h02Fza5h2Njac1k_BipJ: return "齐射模式"
		__PqwHiMCiEKMg9bL_3LrzgjVT.__EoLOtxbBEbp6g1WLVe7W5fow: return "顺次射击模式"
		_: return "最大火力模式"
var __ws2s4Lfa3YoMJ_OoXIToq1w_: bool = false
const __BgNu6qlKbMFxOIduOfRw1lpN: = 2
var __EnRnlPve0Y145ZsCmTA3iWUI: int = 0
func x() -> int:
	return __gz4iZzIm1ic26sbX2dyDa0Lg["x"]
func __f7za886AvlhXWiw9RWTuNKng(__CpH2N6DQn6z52V0ZlLK9bwyP: int) -> bool:
	for g: Dictionary in __BJReFJ4ugditvprP9JFCx5S2:
		if int(g.get("seat", 0)) == __CpH2N6DQn6z52V0ZlLK9bwyP:
			return true
	for __0zh8KH118x9LLYvWqXupD0Mo: Dictionary in __bFJ1csmbpVraScDCZhw1ETZ5:
		if int(__0zh8KH118x9LLYvWqXupD0Mo["seat"]) == __CpH2N6DQn6z52V0ZlLK9bwyP:
			return true
	return false
func __4CMfwHAY4YJgIN_C4boQ2qiP(__QSOUm9qvFzRAdoaW34mwXZ5_: int, __oTZ8XTNZPanq8fQTF4JAER1I: int) -> void :
	if not __sfrhGgpP8JHW6nvd0GQRC91I:
		return
	__k2tNHcrJ7Ubu73oDndNmYPUU = __QSOUm9qvFzRAdoaW34mwXZ5_
	__PnHs8Uffgi24ue5O7EVvelTY = __oTZ8XTNZPanq8fQTF4JAER1I
	__aCAPgZOjbD1shm6WhpFLgjLA += 1
	__2mSX9u3Uv_8woBUECnpZM0xY()
var __1_VYwkJQtQVG29nVEi0IzFyr: int = 0
var __aD1qlnd4hnNTYgeXVdepDA_r: int = 0
var __NELIelBEafKRGQultNqYAbM7: Dictionary
func __8NOgOL41CVxb75P_V2_ouKa9() -> void :
	__NYbIaW78BNqdaS0BgoYwqAci.__i4EuEzddyB84rat1nCU61xDT(__NELIelBEafKRGQultNqYAbM7, __F41ZT8z_0zKKqYDFwqS1WGTs, __EnRnlPve0Y145ZsCmTA3iWUI)
var __TMaqDrkAeK6UVY6d4JshSgUc: int = 0
func __egEhGs_JGZBzwbo5g8bIAmPr(g: Dictionary) -> void :
	g["broken"] = true
	g["rotating"] = false
	g["elevating"] = false
	g["el_goal"] = -1
var __11jta_pen9MsoYrWopEHFcWy: int = 0
const __nlthqFBoqlwZmvAHBTPDGIYz: = 3
var __z0cWmVEHlOSDFrPoyOKsE_Uz: int = 0
var __PnHs8Uffgi24ue5O7EVvelTY: int = -1

func meti_convergence_active(g: Dictionary) -> bool:
	return __ZMgQrrB9zxLXJ4nY9DOrkD1m and __sfrhGgpP8JHW6nvd0GQRC91I and __k2tNHcrJ7Ubu73oDndNmYPUU >= 0 and not g.has("tp_row") and int(g.get("aa", 0)) == 0 and not (g.get("meti_convergence", {}) as Dictionary).is_empty()

func meti_converge_solution(g: Dictionary) -> Dictionary:
	if not __ZMgQrrB9zxLXJ4nY9DOrkD1m or not __sfrhGgpP8JHW6nvd0GQRC91I or __k2tNHcrJ7Ubu73oDndNmYPUU < 0 or g.has("tp_row") or int(g.get("aa", 0)) != 0:
		return {}
	var shell: Dictionary = g["shell"] if int(g["cargo"]) == 0 else g["shell_b"]
	var origin: Vector2i = __oc4DIMhqXqRDsyYDHkfod1e6(g)
	var key: Array = [__k2tNHcrJ7Ubu73oDndNmYPUU, __PnHs8Uffgi24ue5O7EVvelTY, int(g["cargo"]), int(shell.get("proj_row", -1)), int(g["V0"]), int(g["max_el"])]
	if key != g.get("meti_converge_key", []) or (origin != g.get("meti_converge_origin", Vector2i(-1, -1)) and meti_convergence_tick - int(g.get("meti_converge_tick", -100)) >= 10):
		if meti_convergence_solver == null:
			meti_convergence_solver = load("res://shared/sim/meti_convergence.gdc")
		if meti_convergence_solver == null:
			return {}
		var result: Dictionary = meti_convergence_solver.solve(g, shell, origin, Vector2i(__k2tNHcrJ7Ubu73oDndNmYPUU, __PnHs8Uffgi24ue5O7EVvelTY))
		g["meti_convergence"] = result
		g["meti_converge_key"] = key
		g["meti_converge_origin"] = origin
		g["meti_converge_tick"] = meti_convergence_tick
	return g.get("meti_convergence", {})
