class_name __NYbIaW78BNqdaS0BgoYwqAci
const __Z9EcfNLkWOLsCGSZe7wvGZo4: = 200
static func ___bw4ml0gwbxgfsM9S7qgu8mj(__Iiy2wA0Y5mEXykDguitG3Dy9: int) -> Dictionary:
	return {"order": 4, "notch": 0, "step": 1, "cap": 100, "speed": 0, "target": 0, "max_speed": __Iiy2wA0Y5mEXykDguitG3Dy9 * 100}
static func __DdZX1ptpc0zG1yeGDuXEKOqr(__6ygMJB82JDDt5GDy4WJTcdQ4: Dictionary) -> int:
	var __HvNIThIz4NG5aGGG4y0qrRle: int = __6ygMJB82JDDt5GDy4WJTcdQ4["max_speed"]
	if int(__6ygMJB82JDDt5GDy4WJTcdQ4.get("spd_pct", 100)) != 100:
		__HvNIThIz4NG5aGGG4y0qrRle = __HvNIThIz4NG5aGGG4y0qrRle * int(__6ygMJB82JDDt5GDy4WJTcdQ4["spd_pct"]) / 100
	return __HvNIThIz4NG5aGGG4y0qrRle
class __O1Urlr6IdUTnFWvioe6wcQrt:
	extends RefCounted
	var __2t68IkFCerCE1l3e41k2_Kp2: int
	var __VtBwOqrn_q8nEWVGDauasm8Q: int
	var __kbvokkj_iEL8SAJaDLyJSyIv: PackedByteArray
	var __9Zy5NwQKLR2WXbpStDOauEMz: int
	var __0xMwoIVfT_j6GZoLP_HkB6nE: int
	func _init(__5H_X2_Syrzobcs4th_H1iRu9: int, __tkpx51p0vlHMVCrHXVZT4cCr: int) -> void :
		__2t68IkFCerCE1l3e41k2_Kp2 = __5H_X2_Syrzobcs4th_H1iRu9
		__VtBwOqrn_q8nEWVGDauasm8Q = __tkpx51p0vlHMVCrHXVZT4cCr
		__kbvokkj_iEL8SAJaDLyJSyIv.resize(__2t68IkFCerCE1l3e41k2_Kp2 * __VtBwOqrn_q8nEWVGDauasm8Q)
		__9Zy5NwQKLR2WXbpStDOauEMz = __2t68IkFCerCE1l3e41k2_Kp2 * __3HUfrQEO6mWDeADaowMmBsJS
		__0xMwoIVfT_j6GZoLP_HkB6nE = __VtBwOqrn_q8nEWVGDauasm8Q * __3HUfrQEO6mWDeADaowMmBsJS
	func __gqBKCXcqTt4K3Vmce3XR6LHx(__DOc1pfIcheJX0009MsjGWRr3: int, __J57TjA7thG49ImPrlJvYoMb4: int) -> void :
		__kbvokkj_iEL8SAJaDLyJSyIv[__J57TjA7thG49ImPrlJvYoMb4 * __2t68IkFCerCE1l3e41k2_Kp2 + __DOc1pfIcheJX0009MsjGWRr3] = 1
	func __GEpxKjUHBFZP2qg19LlE_p1c(x: int, y: int) -> bool:
		var __Jksyr_sTIHmJ3abZuMuyYduD: int = x / __3HUfrQEO6mWDeADaowMmBsJS
		var __I43p6jvANWTowLpeTkY4BrTO: int = y / __3HUfrQEO6mWDeADaowMmBsJS
		if __Jksyr_sTIHmJ3abZuMuyYduD < 0 or __Jksyr_sTIHmJ3abZuMuyYduD >= __2t68IkFCerCE1l3e41k2_Kp2 or __I43p6jvANWTowLpeTkY4BrTO < 0 or __I43p6jvANWTowLpeTkY4BrTO >= __VtBwOqrn_q8nEWVGDauasm8Q:
			return false
		return __kbvokkj_iEL8SAJaDLyJSyIv[__I43p6jvANWTowLpeTkY4BrTO * __2t68IkFCerCE1l3e41k2_Kp2 + __Jksyr_sTIHmJ3abZuMuyYduD] != 0
const __oUg0mj2UMlXk3x_qZQqC_Bys: = {9: 40, 4: 60, 5: 60, 6: 50, 7: 50}
static func __xFhBsH_CiM4qJWi1cUo2fHki(__Lf7NBKBrBV29_IyHXm7QwGOu: int, __sz0EA7CrWEU3jVd3Tqgg3hub: int) -> PackedInt32Array:
	return __0DtuUlUzswt1M4wHr0iIGFkS(__Lf7NBKBrBV29_IyHXm7QwGOu, __sz0EA7CrWEU3jVd3Tqgg3hub, 36)
static func __2sWFTMVqasaRcdvV0b4W5_lZ(__9pUTQhwMuVPFsgWDShXm8Z2Y: int, __2rlDv5Xt1JDxjTaotnyzrrS1: int) -> PackedInt32Array:
	return __0DtuUlUzswt1M4wHr0iIGFkS(__9pUTQhwMuVPFsgWDShXm8Z2Y, __2rlDv5Xt1JDxjTaotnyzrrS1, 120)
const __660yt3_lAeOU7pLi0sdNwkgX: = 240
static func __RWH6xbYnbHrh4GpYPcCA_viz(a: Dictionary) -> int:
	return posmod(int(a["heading"]) - 900, 3600)
enum __f175MfZwVQGiKWRyJg8wlbn1{__1kps3a5hPQyAJwQHO5w03dDB, __yBKDCeeCwdEm1KosH4APJtPe, __aLRYuOKQE6yNrtNFEfx5hbQ5}
static func __0DtuUlUzswt1M4wHr0iIGFkS(__z2qtpp5U4eIdm97YPfQXNhLa: int, __6DG4KjZ8y_TPtv2i2iqMupwG: int, __shMf2PlSqPJyfHkFK6Sn70JO: int) -> PackedInt32Array:
	var w: int = __z2qtpp5U4eIdm97YPfQXNhLa
	var __EYsW6NjZRt25oYfTSARaatD9: int = __6DG4KjZ8y_TPtv2i2iqMupwG
	var __2K0aDvFG1x_jVOLv_E2cXG1P: Array[Vector2i] = [Vector2i( - w, __EYsW6NjZRt25oYfTSARaatD9), Vector2i( - w, - __EYsW6NjZRt25oYfTSARaatD9), Vector2i(w, - __EYsW6NjZRt25oYfTSARaatD9), Vector2i(w, __EYsW6NjZRt25oYfTSARaatD9), Vector2i( - w, 0), Vector2i(w, 0)]
	var __VlZWwcZv7rm19dgIdfzE1MMs: = PackedInt32Array()
	__VlZWwcZv7rm19dgIdfzE1MMs.resize(__shMf2PlSqPJyfHkFK6Sn70JO * 6 * 2)
	for __KKtkJdybyjxZoSyKrKAgJBzC: int in __shMf2PlSqPJyfHkFK6Sn70JO:
		var h: int = (3600 / __shMf2PlSqPJyfHkFK6Sn70JO * __KKtkJdybyjxZoSyKrKAgJBzC) % 3600
		var __eHyTrIj6WFeObdH3Vknk2c9O: int = __TXCdoY85HWzo9E7Qcf9l8raZ.__9nHAKAsjPH38LR2tAezCTqd_[h]
		var s: int = __TXCdoY85HWzo9E7Qcf9l8raZ.__7laIgLr3i8VN0D_tZnYT3p0D[h]
		for __S2PMO9bpPJd7vBRPQhJlaHTA: int in 6:
			var a: int = __2K0aDvFG1x_jVOLv_E2cXG1P[__S2PMO9bpPJd7vBRPQhJlaHTA].x
			var b: int = __2K0aDvFG1x_jVOLv_E2cXG1P[__S2PMO9bpPJd7vBRPQhJlaHTA].y
			__VlZWwcZv7rm19dgIdfzE1MMs[(__KKtkJdybyjxZoSyKrKAgJBzC * 6 + __S2PMO9bpPJd7vBRPQhJlaHTA) * 2] = a * __eHyTrIj6WFeObdH3Vknk2c9O / 1000 - b * s / 1000
			__VlZWwcZv7rm19dgIdfzE1MMs[(__KKtkJdybyjxZoSyKrKAgJBzC * 6 + __S2PMO9bpPJd7vBRPQhJlaHTA) * 2 + 1] = __3Tq2ik5KEj4Lk7AmUfvTWBZP(a * s / 1000 + b * __eHyTrIj6WFeObdH3Vknk2c9O / 1000)
	return __VlZWwcZv7rm19dgIdfzE1MMs
enum __oj0fZgh_8Nb6kwHfmU6ttWyD{NONE = -1, __7TaRBUTPMT5w6sBAE4Z5eYU1 = 0, ___5cGNZYOPQ3WBKBsiaIVEmQr = 1, __nEJZd5jRHX6UHFPYf15nGQEo = 2, __vZJOrF6IK6EU_Zydp0_BJyHm = 3, __pExmHZbh1pnHLlW16eo3jrv8 = 4, __iGBZNeOfZbFLPT8v0c4FXm5F = 5}
const __5xTStEWmmR_rwzBZlBbk9v8F: = 510
static func __KojNCs5E3fJteg0BP_ow8L2D(__Q02G9nmyA2aCf2cEwetI21Nj: int, __JcDawewbhlB8f3c2TyZYni5U: int) -> int:
	var __xIIt8Hmi7Xz7PJxPXb2qprI4: int = __Irz9hiGcyslSDsJT8BenfEt2.__r5IV7KGJPcXBU5ArrEZih0Yc(__Irz9hiGcyslSDsJT8BenfEt2.__r5IV7KGJPcXBU5ArrEZih0Yc(__Q02G9nmyA2aCf2cEwetI21Nj * __Q02G9nmyA2aCf2cEwetI21Nj) + __Irz9hiGcyslSDsJT8BenfEt2.__r5IV7KGJPcXBU5ArrEZih0Yc(__JcDawewbhlB8f3c2TyZYni5U * __JcDawewbhlB8f3c2TyZYni5U))
	var __G_VRnIzDbTc_Fa3jkWwtMIdo: int
	if __Q02G9nmyA2aCf2cEwetI21Nj >= 0:
		__G_VRnIzDbTc_Fa3jkWwtMIdo = 1 if __JcDawewbhlB8f3c2TyZYni5U <= 0 else 4
	else:
		__G_VRnIzDbTc_Fa3jkWwtMIdo = 3 if __JcDawewbhlB8f3c2TyZYni5U > 0 else 2
	var __2Prg_rDGc5HuJO6svTe0dsqU: int = __Irz9hiGcyslSDsJT8BenfEt2.__f8g2PjfN7nwJbTHn9ePhmeZH(__xIIt8Hmi7Xz7PJxPXb2qprI4) if __xIIt8Hmi7Xz7PJxPXb2qprI4 > 0 else 0
	if __2Prg_rDGc5HuJO6svTe0dsqU == 0:
		__2Prg_rDGc5HuJO6svTe0dsqU = 1
	var __HPotY4ODUy6PuptryK8uhR7n: int = __TXCdoY85HWzo9E7Qcf9l8raZ.__Xnu53rJiCu3FOfbyFPT_X4Wr( - __JcDawewbhlB8f3c2TyZYni5U, __2Prg_rDGc5HuJO6svTe0dsqU)
	if __HPotY4ODUy6PuptryK8uhR7n >= 0:
		if __G_VRnIzDbTc_Fa3jkWwtMIdo != 1:
			__HPotY4ODUy6PuptryK8uhR7n = 1800 - __HPotY4ODUy6PuptryK8uhR7n
	else:
		__HPotY4ODUy6PuptryK8uhR7n = (1800 - __HPotY4ODUy6PuptryK8uhR7n) if __G_VRnIzDbTc_Fa3jkWwtMIdo == 3 else (__HPotY4ODUy6PuptryK8uhR7n + 3600)
	return __HPotY4ODUy6PuptryK8uhR7n
static func __kqOm_ZCSIe1QlLbPW1PAJ2Ds(__UKnQFqT9jXdEoOAG_vCibSsz: int, __fYM0CKseIbqba3zlcJXtnNt9: int, __Ozl3vpb5b5s8YV3td3dPKBpE: int, max_speed: int, __X1fLD0oF6iy1LuOK_Sx20IHb: int) -> Dictionary:
	return {"x": __UKnQFqT9jXdEoOAG_vCibSsz, "y": __fYM0CKseIbqba3zlcJXtnNt9, "origin_x": __UKnQFqT9jXdEoOAG_vCibSsz, "origin_y": __fYM0CKseIbqba3zlcJXtnNt9, "acc_x": 0, "acc_y": 0, "dest_x": __UKnQFqT9jXdEoOAG_vCibSsz, "dest_y": __fYM0CKseIbqba3zlcJXtnNt9, "follow": 0, "speed": 0, "max_speed": max_speed, "rudder": __X1fLD0oF6iy1LuOK_Sx20IHb, "heading": posmod(__Ozl3vpb5b5s8YV3td3dPKBpE + 900, 3600), 
		"max_turn": 1, "turn_state": 1, "last_turn": 0, "arrived": 1073741824, "dx": 0, "dy": 0, "forced_back": 0, "coast": 0, }
static func __7cUj3z5t30yxrHXrICbEqcGv(a: Dictionary, __Bt3LI2qFPs67dkrxrfh3cAmA: PackedInt32Array, terrain: __O1Urlr6IdUTnFWvioe6wcQrt) -> __f175MfZwVQGiKWRyJg8wlbn1:
	var __k5UIMyKlzrWPbEPpm4FvJui5: int = a["x"]
	var __A6_vM8VH9pvAg4x7R_NghH3G: int = a["y"]
	var __wxq2gdR_OHX8mPefUYzexTMb: int = a["acc_x"]
	var __fnFBFY2sIJ2ZbcNalZNEzhDb: int = a["acc_y"]
	var __d8Jq7PSafxxsxogsfkGw9FMr: int = a["heading"]
	a["heading"] = posmod(int(a["heading"]), 3600)
	var __MoBly33NzIHS4pspg1q3Aafp: bool = false
	var __X9dl0dB2yiDi2SgykrNri_8N: int = a["arrived"]
	var __tyMwVzMzkxlx7iQHKj96qWiB: bool = false
	if __X9dl0dB2yiDi2SgykrNri_8N == 0:
		if absi(int(a["x"]) - int(a["dest_x"])) <= __2etxLfYzbimZRfgyFGKEtTUD and absi(int(a["y"]) - int(a["dest_y"])) <= __2etxLfYzbimZRfgyFGKEtTUD:
			a["arrived"] = 1073741824
			a["dest_x"] = a["x"]
			a["dest_y"] = a["y"]
			__X9dl0dB2yiDi2SgykrNri_8N = 1073741824
		elif int(a["speed"]) != 0:
			__w8Z0RyZHo_543_USgb9F7HSq(a, int(a["speed"]) * 100 / int(a["max_speed"]))
			__RRgqE9w6O3Rh24GqpWVUUz02(a)
			var h: int = posmod(int(a["heading"]), 3600)
			a["heading"] = h
			__tyMwVzMzkxlx7iQHKj96qWiB = true
	if __X9dl0dB2yiDi2SgykrNri_8N == 1073741824:
		if int(a["speed"]) == 0:
			a["coast"] = 0
		else:
			__tyMwVzMzkxlx7iQHKj96qWiB = true
	if __tyMwVzMzkxlx7iQHKj96qWiB:
		__ORqwIwPfsrSDsYgAOm7jWTne(a)
		__MoBly33NzIHS4pspg1q3Aafp = true
	var x: int = a["x"]
	var y: int = a["y"]
	if y >= terrain.__0xMwoIVfT_j6GZoLP_HkB6nE - 100 or y <= 100 or x >= terrain.__9Zy5NwQKLR2WXbpStDOauEMz - 64 or x <= 64:
		return __f175MfZwVQGiKWRyJg8wlbn1.__yBKDCeeCwdEm1KosH4APJtPe if __MoBly33NzIHS4pspg1q3Aafp else __f175MfZwVQGiKWRyJg8wlbn1.__1kps3a5hPQyAJwQHO5w03dDB
	var __Ypxk5IBvbNkDzJbe41lNASlt: int = int(a["heading"]) / 30
	var __9CscsjGzF4avpEMp8XBcjYRY: bool = false
	for __v4I_WOuQUQC9gXAhRdW0_zKs: int in 4:
		var __NE4H_VcQRIf6eUjJA8lKFFYA: int = (__Ypxk5IBvbNkDzJbe41lNASlt * 6 + __v4I_WOuQUQC9gXAhRdW0_zKs) * 2
		if terrain.__GEpxKjUHBFZP2qg19LlE_p1c(x + __Bt3LI2qFPs67dkrxrfh3cAmA[__NE4H_VcQRIf6eUjJA8lKFFYA], y + __Bt3LI2qFPs67dkrxrfh3cAmA[__NE4H_VcQRIf6eUjJA8lKFFYA + 1]):
			__9CscsjGzF4avpEMp8XBcjYRY = true
			break
	if __9CscsjGzF4avpEMp8XBcjYRY or (int(a["forced_back"]) == 1 and __32HYELBX058_f7gsFYGhGxZz(terrain, x, y) > __32HYELBX058_f7gsFYGhGxZz(terrain, __k5UIMyKlzrWPbEPpm4FvJui5, __A6_vM8VH9pvAg4x7R_NghH3G)):
		a["x"] = __k5UIMyKlzrWPbEPpm4FvJui5
		a["y"] = __A6_vM8VH9pvAg4x7R_NghH3G
		a["acc_x"] = __wxq2gdR_OHX8mPefUYzexTMb
		a["acc_y"] = __fnFBFY2sIJ2ZbcNalZNEzhDb
		a["heading"] = __d8Jq7PSafxxsxogsfkGw9FMr
		return __f175MfZwVQGiKWRyJg8wlbn1.__aLRYuOKQE6yNrtNFEfx5hbQ5
	return __f175MfZwVQGiKWRyJg8wlbn1.__yBKDCeeCwdEm1KosH4APJtPe if __MoBly33NzIHS4pspg1q3Aafp else __f175MfZwVQGiKWRyJg8wlbn1.__1kps3a5hPQyAJwQHO5w03dDB
const __3HUfrQEO6mWDeADaowMmBsJS: = 18
static func __vUuy3zr2zlR1gaJCTRVk5Agz(__ItIDC5m1nwFCMSBm706ToMKC: Dictionary, __CR3whhgfUi7K5B4PdCHq9UjP: int, __ES_qYXC3t8a07pAfGn3Bmojk: int, __UoVYUylL79Tj3Kg0_KADpzZ2: int, __EFg25IdCM2dnwbvPyKJSKBj5: int) -> void :
	__ItIDC5m1nwFCMSBm706ToMKC["model"] = true
	__ItIDC5m1nwFCMSBm706ToMKC["od"] = __CR3whhgfUi7K5B4PdCHq9UjP
	__ItIDC5m1nwFCMSBm706ToMKC["cap"] = 100 + __CR3whhgfUi7K5B4PdCHq9UjP
	__ItIDC5m1nwFCMSBm706ToMKC["heat"] = 0
	__ItIDC5m1nwFCMSBm706ToMKC["heat_max"] = __ES_qYXC3t8a07pAfGn3Bmojk
	__ItIDC5m1nwFCMSBm706ToMKC["broken"] = false
	__ItIDC5m1nwFCMSBm706ToMKC["fix"] = 0
	__ItIDC5m1nwFCMSBm706ToMKC["engine_a"] = __UoVYUylL79Tj3Kg0_KADpzZ2
	__ItIDC5m1nwFCMSBm706ToMKC["damage_threshold"] = __EFg25IdCM2dnwbvPyKJSKBj5
	__ItIDC5m1nwFCMSBm706ToMKC["v18"] = false
	__ItIDC5m1nwFCMSBm706ToMKC["v64"] = false
	__ItIDC5m1nwFCMSBm706ToMKC["v60"] = false
	__ItIDC5m1nwFCMSBm706ToMKC["evt"] = __oj0fZgh_8Nb6kwHfmU6ttWyD.NONE
static func __3Tq2ik5KEj4Lk7AmUfvTWBZP(v: int) -> int:
	return (v + (1 if v < 0 else 0)) >> 1
const __y3SktdWfDJ9axNmaUtMwJsuD: = 440
static func __ORqwIwPfsrSDsYgAOm7jWTne(a: Dictionary) -> void :
	var __uUIb4jGkUXIcnlOEcQN5dft2: int = a["last_turn"]
	a["turn_state"] = 1 if __uUIb4jGkUXIcnlOEcQN5dft2 == 0 else (2 if __uUIb4jGkUXIcnlOEcQN5dft2 > 0 else 4)
	var s: int = int(a["speed"]) / 10
	var h: int = a["heading"]
	a["dx"] = __TXCdoY85HWzo9E7Qcf9l8raZ.__9nHAKAsjPH38LR2tAezCTqd_[h] * s / 1000
	a["dy"] = __TXCdoY85HWzo9E7Qcf9l8raZ.__7laIgLr3i8VN0D_tZnYT3p0D[h] * s / 1000
	a["acc_x"] = int(a["acc_x"]) + int(a["dx"])
	a["acc_y"] = int(a["acc_y"]) - int(a["dy"])
	a["x"] = int(a["acc_x"]) / __660yt3_lAeOU7pLi0sdNwkgX + int(a["origin_x"])
	a["y"] = int(a["acc_y"]) / __LUoQGakqnydi71zyOjKsHIqa + int(a["origin_y"])
const __2etxLfYzbimZRfgyFGKEtTUD: = 30
static func __KrsSmgV_rDiZ33uCFtPv6OiV(__D8szaGsSG1qmFQCF8HjuV1bt: Dictionary) -> int:
	if __D8szaGsSG1qmFQCF8HjuV1bt.has("model"):
		return __JIcTqIdCtZb7eGTEitSAnvFv(__D8szaGsSG1qmFQCF8HjuV1bt)
	var __Tn7cl5X5gWycr69dEIJixtcU: int = __D8szaGsSG1qmFQCF8HjuV1bt["notch"]
	var __p7okl1alN1rEpiDrF9FKm8I0: int = __D8szaGsSG1qmFQCF8HjuV1bt["step"]
	var __fc9oIdpygeynEyWfWZFiqmMl: int = __D8szaGsSG1qmFQCF8HjuV1bt["cap"]
	if int(__D8szaGsSG1qmFQCF8HjuV1bt["order"]) == 1:
		__D8szaGsSG1qmFQCF8HjuV1bt["notch"] = maxi(__Tn7cl5X5gWycr69dEIJixtcU + __p7okl1alN1rEpiDrF9FKm8I0, 0) if __Tn7cl5X5gWycr69dEIJixtcU < 0 else mini(__Tn7cl5X5gWycr69dEIJixtcU + __p7okl1alN1rEpiDrF9FKm8I0, __fc9oIdpygeynEyWfWZFiqmMl)
	elif int(__D8szaGsSG1qmFQCF8HjuV1bt["order"]) == 2:
		__D8szaGsSG1qmFQCF8HjuV1bt["notch"] = maxi(__Tn7cl5X5gWycr69dEIJixtcU - __p7okl1alN1rEpiDrF9FKm8I0, 0) if __Tn7cl5X5gWycr69dEIJixtcU > 0 else maxi(__Tn7cl5X5gWycr69dEIJixtcU - __p7okl1alN1rEpiDrF9FKm8I0, - (__fc9oIdpygeynEyWfWZFiqmMl * 2) / 10)
	__D8szaGsSG1qmFQCF8HjuV1bt["target"] = __DdZX1ptpc0zG1yeGDuXEKOqr(__D8szaGsSG1qmFQCF8HjuV1bt) * int(__D8szaGsSG1qmFQCF8HjuV1bt["notch"]) / 100
	var __hkqMimncj2TD9PW78AfWdejx: int = __D8szaGsSG1qmFQCF8HjuV1bt["speed"]
	var __AC3qGma_k0xQJgwq38XPo6bc: int = __D8szaGsSG1qmFQCF8HjuV1bt["target"]
	if __hkqMimncj2TD9PW78AfWdejx < __AC3qGma_k0xQJgwq38XPo6bc:
		__D8szaGsSG1qmFQCF8HjuV1bt["speed"] = mini(__hkqMimncj2TD9PW78AfWdejx + 24, __AC3qGma_k0xQJgwq38XPo6bc)
	elif __hkqMimncj2TD9PW78AfWdejx > __AC3qGma_k0xQJgwq38XPo6bc:
		__D8szaGsSG1qmFQCF8HjuV1bt["speed"] = maxi(__hkqMimncj2TD9PW78AfWdejx - 16, __AC3qGma_k0xQJgwq38XPo6bc)
	return __D8szaGsSG1qmFQCF8HjuV1bt["speed"]
static func __iGECzm9BEXFrHekNgHDCTkaQ(terrain: __O1Urlr6IdUTnFWvioe6wcQrt, x: int, y: int) -> bool:
	return __Z9EcfNLkWOLsCGSZe7wvGZo4 <= x and x < terrain.__9Zy5NwQKLR2WXbpStDOauEMz - __Pq26JIdWS_3KiSAS6hAAYXbZ and __y3SktdWfDJ9axNmaUtMwJsuD <= y and y < terrain.__0xMwoIVfT_j6GZoLP_HkB6nE - __bX9NSuTieQlnITdjSsRxHqik
const __bX9NSuTieQlnITdjSsRxHqik: = 200
static func __w8Z0RyZHo_543_USgb9F7HSq(a: Dictionary, __Hr0zaxRXYZejF23bKhW5RFFG: int) -> int:
	var v: int = - __Hr0zaxRXYZejF23bKhW5RFFG if __Hr0zaxRXYZejF23bKhW5RFFG < 0 else __Hr0zaxRXYZejF23bKhW5RFFG
	a["max_turn"] = int(a["rudder"]) * 100 / __5xTStEWmmR_rwzBZlBbk9v8F * v / 100 + 1
	return a["max_turn"]
static func __32HYELBX058_f7gsFYGhGxZz(terrain: __O1Urlr6IdUTnFWvioe6wcQrt, x: int, y: int) -> int:
	var __1TMQ_LKR7zewtvppMVd1TYVr: int = maxi(maxi(__Z9EcfNLkWOLsCGSZe7wvGZo4 - x, x - (terrain.__9Zy5NwQKLR2WXbpStDOauEMz - __Pq26JIdWS_3KiSAS6hAAYXbZ - 1)), 0)
	var __9RiCerz7K11DRVWjQZ0A9mcK: int = maxi(maxi(__y3SktdWfDJ9axNmaUtMwJsuD - y, y - (terrain.__0xMwoIVfT_j6GZoLP_HkB6nE - __bX9NSuTieQlnITdjSsRxHqik - 1)), 0)
	return __1TMQ_LKR7zewtvppMVd1TYVr + __9RiCerz7K11DRVWjQZ0A9mcK
const __Pq26JIdWS_3KiSAS6hAAYXbZ: = 100
static func __i4EuEzddyB84rat1nCU61xDT(__meN2a2sOiG7Ix8JNWtAnNbmC: Dictionary, __hPTlTJaHQhjWEPATm4kMCGvt: int, __G6TtYaQDA5ecDtfi0iDShSrn: int) -> void :
	if not __meN2a2sOiG7Ix8JNWtAnNbmC.has("model"):
		return
	var __2USsPqwfmdCycJnuU0Lme3N8: int = 100 if __hPTlTJaHQhjWEPATm4kMCGvt >= __G6TtYaQDA5ecDtfi0iDShSrn else (__hPTlTJaHQhjWEPATm4kMCGvt * 100 / __G6TtYaQDA5ecDtfi0iDShSrn if __G6TtYaQDA5ecDtfi0iDShSrn > 0 else 0)
	var threshold: int = __meN2a2sOiG7Ix8JNWtAnNbmC["damage_threshold"]
	if __2USsPqwfmdCycJnuU0Lme3N8 < threshold:
		__meN2a2sOiG7Ix8JNWtAnNbmC["cap"] = 100 + (__2USsPqwfmdCycJnuU0Lme3N8 - threshold) * 100 / maxi(threshold, 1)
		__meN2a2sOiG7Ix8JNWtAnNbmC["notch"] = mini(int(__meN2a2sOiG7Ix8JNWtAnNbmC["notch"]), int(__meN2a2sOiG7Ix8JNWtAnNbmC["cap"]))
	else:
		__meN2a2sOiG7Ix8JNWtAnNbmC["cap"] = 100 + maxi(0, int(__meN2a2sOiG7Ix8JNWtAnNbmC["od"]))
	__meN2a2sOiG7Ix8JNWtAnNbmC["target"] = __DdZX1ptpc0zG1yeGDuXEKOqr(__meN2a2sOiG7Ix8JNWtAnNbmC) * int(__meN2a2sOiG7Ix8JNWtAnNbmC["notch"]) / 100
const __LUoQGakqnydi71zyOjKsHIqa: = 480
static func __RRgqE9w6O3Rh24GqpWVUUz02(a: Dictionary) -> int:
	var __SKYiFarE3fnvwW6TtQMO0gHz: int = __KojNCs5E3fJteg0BP_ow8L2D(int(a["dest_x"]) - int(a["x"]), int(a["dest_y"]) - int(a["y"]))
	var d: int = __SKYiFarE3fnvwW6TtQMO0gHz - int(a["heading"])
	if d > 1800:
		d -= 3600
	elif d < -1800:
		d += 3600
	var __JCmTMn3Nk6K65h5jmGb02byl: int = a["max_turn"]
	if d > __JCmTMn3Nk6K65h5jmGb02byl:
		d = __JCmTMn3Nk6K65h5jmGb02byl
	elif d < - __JCmTMn3Nk6K65h5jmGb02byl:
		d = - __JCmTMn3Nk6K65h5jmGb02byl
	var h: int = int(a["heading"]) + d
	if h < 0:
		h += 3600
	elif h >= 3600:
		h -= 3600
	a["last_turn"] = d
	a["heading"] = posmod(h, 3600)
	return d
static func __JIcTqIdCtZb7eGTEitSAnvFv(__D8szaGsSG1qmFQCF8HjuV1bt: Dictionary) -> int:
	var __KUXGLPVQMaQYv9nbc1FLHgk1: int = __D8szaGsSG1qmFQCF8HjuV1bt["notch"]
	var __KR7KppBvlmdPmOzmU7gaRqom: int = __D8szaGsSG1qmFQCF8HjuV1bt["step"]
	var __UNw1rXHWNdjG9IeU3jhoxta6: int = __D8szaGsSG1qmFQCF8HjuV1bt["cap"]
	if int(__D8szaGsSG1qmFQCF8HjuV1bt["order"]) == 1:
		__D8szaGsSG1qmFQCF8HjuV1bt["notch"] = maxi(__KUXGLPVQMaQYv9nbc1FLHgk1 + __KR7KppBvlmdPmOzmU7gaRqom, 0) if __KUXGLPVQMaQYv9nbc1FLHgk1 < 0 else mini(__KUXGLPVQMaQYv9nbc1FLHgk1 + __KR7KppBvlmdPmOzmU7gaRqom, __UNw1rXHWNdjG9IeU3jhoxta6)
	elif int(__D8szaGsSG1qmFQCF8HjuV1bt["order"]) == 2:
		__D8szaGsSG1qmFQCF8HjuV1bt["notch"] = maxi(__KUXGLPVQMaQYv9nbc1FLHgk1 - __KR7KppBvlmdPmOzmU7gaRqom, 0) if __KUXGLPVQMaQYv9nbc1FLHgk1 > 0 else maxi(__KUXGLPVQMaQYv9nbc1FLHgk1 - __KR7KppBvlmdPmOzmU7gaRqom, - (__UNw1rXHWNdjG9IeU3jhoxta6 * 2) / 10)
	__D8szaGsSG1qmFQCF8HjuV1bt["target"] = __DdZX1ptpc0zG1yeGDuXEKOqr(__D8szaGsSG1qmFQCF8HjuV1bt) * int(__D8szaGsSG1qmFQCF8HjuV1bt["notch"]) / 100
	var __Ad3wW_tN6nEhXbSLezNz8Ex7: int = __D8szaGsSG1qmFQCF8HjuV1bt["speed"]
	var __eZbKOOp0dFdQvNA8LwCMcq0n: int = __D8szaGsSG1qmFQCF8HjuV1bt["target"]
	if not __D8szaGsSG1qmFQCF8HjuV1bt["broken"]:
		if int(__D8szaGsSG1qmFQCF8HjuV1bt["notch"]) > 100:
			if int(__D8szaGsSG1qmFQCF8HjuV1bt["heat"]) >= int(__D8szaGsSG1qmFQCF8HjuV1bt["heat_max"]):
				__D8szaGsSG1qmFQCF8HjuV1bt["notch"] = 100
				__D8szaGsSG1qmFQCF8HjuV1bt["target"] = __DdZX1ptpc0zG1yeGDuXEKOqr(__D8szaGsSG1qmFQCF8HjuV1bt)
				__eZbKOOp0dFdQvNA8LwCMcq0n = __D8szaGsSG1qmFQCF8HjuV1bt["target"]
				if not __D8szaGsSG1qmFQCF8HjuV1bt["v64"]:
					__D8szaGsSG1qmFQCF8HjuV1bt["evt"] = __oj0fZgh_8Nb6kwHfmU6ttWyD.__nEJZd5jRHX6UHFPYf15nGQEo
					__D8szaGsSG1qmFQCF8HjuV1bt["v64"] = true
				__D8szaGsSG1qmFQCF8HjuV1bt["v18"] = false
			else:
				if not __D8szaGsSG1qmFQCF8HjuV1bt["v18"]:
					__D8szaGsSG1qmFQCF8HjuV1bt["evt"] = __oj0fZgh_8Nb6kwHfmU6ttWyD.__7TaRBUTPMT5w6sBAE4Z5eYU1 if int(__D8szaGsSG1qmFQCF8HjuV1bt["heat"]) == 0 else __oj0fZgh_8Nb6kwHfmU6ttWyD.___5cGNZYOPQ3WBKBsiaIVEmQr
					__D8szaGsSG1qmFQCF8HjuV1bt["v18"] = true
				__D8szaGsSG1qmFQCF8HjuV1bt["heat"] = int(__D8szaGsSG1qmFQCF8HjuV1bt["heat"]) + 1
		else:
			__D8szaGsSG1qmFQCF8HjuV1bt["heat"] = int(__D8szaGsSG1qmFQCF8HjuV1bt["heat"]) - 1
			if int(__D8szaGsSG1qmFQCF8HjuV1bt["heat"]) <= 0:
				__D8szaGsSG1qmFQCF8HjuV1bt["heat"] = 0
				__D8szaGsSG1qmFQCF8HjuV1bt["v18"] = false
		if __Ad3wW_tN6nEhXbSLezNz8Ex7 < __eZbKOOp0dFdQvNA8LwCMcq0n:
			__Ad3wW_tN6nEhXbSLezNz8Ex7 = mini(__Ad3wW_tN6nEhXbSLezNz8Ex7 + (36 if __D8szaGsSG1qmFQCF8HjuV1bt.get("meti_fleet_boost", false) else 24), __eZbKOOp0dFdQvNA8LwCMcq0n)
		elif __Ad3wW_tN6nEhXbSLezNz8Ex7 > __eZbKOOp0dFdQvNA8LwCMcq0n:
			__Ad3wW_tN6nEhXbSLezNz8Ex7 = maxi(__Ad3wW_tN6nEhXbSLezNz8Ex7 - (24 if __D8szaGsSG1qmFQCF8HjuV1bt.get("meti_fleet_boost", false) else 16), __eZbKOOp0dFdQvNA8LwCMcq0n)
	else:
		if int(__D8szaGsSG1qmFQCF8HjuV1bt["fix"]) > 0:
			__D8szaGsSG1qmFQCF8HjuV1bt["fix"] = int(__D8szaGsSG1qmFQCF8HjuV1bt["fix"]) - 1
			if __Ad3wW_tN6nEhXbSLezNz8Ex7 != __eZbKOOp0dFdQvNA8LwCMcq0n:
				__Ad3wW_tN6nEhXbSLezNz8Ex7 = __Ad3wW_tN6nEhXbSLezNz8Ex7 - 16 if __Ad3wW_tN6nEhXbSLezNz8Ex7 - 16 > __eZbKOOp0dFdQvNA8LwCMcq0n else __eZbKOOp0dFdQvNA8LwCMcq0n
				if int(__D8szaGsSG1qmFQCF8HjuV1bt["heat"]) > 0:
					__D8szaGsSG1qmFQCF8HjuV1bt["heat"] = int(__D8szaGsSG1qmFQCF8HjuV1bt["heat"]) - 1
		else:
			__D8szaGsSG1qmFQCF8HjuV1bt["broken"] = false
			__D8szaGsSG1qmFQCF8HjuV1bt["evt"] = __oj0fZgh_8Nb6kwHfmU6ttWyD.__iGBZNeOfZbFLPT8v0c4FXm5F
		__D8szaGsSG1qmFQCF8HjuV1bt["v64"] = false
	var __g8n4GucbXSSPAnGYKM30U13q: int = int(__D8szaGsSG1qmFQCF8HjuV1bt["max_speed"]) * __UNw1rXHWNdjG9IeU3jhoxta6 / 100
	if __Ad3wW_tN6nEhXbSLezNz8Ex7 >= __g8n4GucbXSSPAnGYKM30U13q:
		if not __D8szaGsSG1qmFQCF8HjuV1bt["v60"]:
			if int(__D8szaGsSG1qmFQCF8HjuV1bt["evt"]) == __oj0fZgh_8Nb6kwHfmU6ttWyD.NONE:
				__D8szaGsSG1qmFQCF8HjuV1bt["evt"] = __oj0fZgh_8Nb6kwHfmU6ttWyD.__vZJOrF6IK6EU_Zydp0_BJyHm
			__D8szaGsSG1qmFQCF8HjuV1bt["v60"] = true
	elif __D8szaGsSG1qmFQCF8HjuV1bt["v60"]:
		__D8szaGsSG1qmFQCF8HjuV1bt["v60"] = false
	__D8szaGsSG1qmFQCF8HjuV1bt["speed"] = __Ad3wW_tN6nEhXbSLezNz8Ex7
	return __Ad3wW_tN6nEhXbSLezNz8Ex7
static func __zQ9E7mate78Irh8XhqTJhd6J(__y2eNjvzuM5QQgJ2vcPtumFLW: Dictionary, __PcT40o63DJ0Dplr9zjJ4r5k0: int) -> void :
	__y2eNjvzuM5QQgJ2vcPtumFLW["broken"] = true
	__y2eNjvzuM5QQgJ2vcPtumFLW["fix"] = 10000 / (int(__y2eNjvzuM5QQgJ2vcPtumFLW["engine_a"]) + 100) * __PcT40o63DJ0Dplr9zjJ4r5k0 / 100
	__y2eNjvzuM5QQgJ2vcPtumFLW["evt"] = __oj0fZgh_8Nb6kwHfmU6ttWyD.__pExmHZbh1pnHLlW16eo3jrv8
