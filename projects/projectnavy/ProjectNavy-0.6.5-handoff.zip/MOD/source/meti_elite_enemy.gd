extends RefCounted

const FLAGSHIP_ROWS: Array[int] = [477,478,479,480,481,482,483]
const ENEMIES_PER_FLAGSHIP: int = 8
const MAX_FLAGSHIPS: int = 3

static func valid_rows() -> Array[int]:
    var catalog=App.__PtNURh2PaYHMgsPlkLtni90Y()
    var rows:Array[int]=[]
    for row:int in FLAGSHIP_ROWS:
        if not catalog.__S427rIy8YAPI_7NTPBneiPZH(row):continue
        var spec:Dictionary=catalog.__ofKSCLcCg7jWtqacDa153ehk(row)
        if int(spec.get("kind",0))!=7 or int(spec.get("level",0))!=125 or bool(spec.get("event",true)):continue
        var config=catalog.__vTRMq3igRP2hTt2npyhiJ5UU(row)
        if config.__dOsDavODOasdfPxqce2DEBC3.is_empty():continue
        if catalog.__BGxXnVzPsmPLUaUtEL38SXTm(config)!=0:continue
        rows.append(row)
    return rows

static func plan(setup:Dictionary,seed:int) -> Array[Dictionary]:
    var players:Array[int]=[]
    var ships:Array=setup.get("ships",[])
    for i:int in ships.size():
        if bool(ships[i].get("player",false)):players.append(i)
    if players.size()!=1:return []
    var player_side:int=int(ships[players[0]].get("side",-1))
    if player_side<0 or player_side>1:return []
    var catalog=App.__PtNURh2PaYHMgsPlkLtni90Y()
    var enemy:Array[int]=[]
    for i:int in ships.size():
        var ship:Dictionary=ships[i]
        if not bool(ship.get("player",false)) and int(ship.get("side",-1))==1-player_side and catalog.__S427rIy8YAPI_7NTPBneiPZH(int(ship.get("frame_row",-1))):enemy.append(i)
    # Replace surface combatants first. Native carriers/submarines keep their roles.
    var surface:Array[int]=[]
    for kind:int in [7,6,5,4,3,2,1]:
        for index:int in enemy:
            if catalog.__rIbrGNBQXI7CsdYVLpVwKrNI(int(ships[index]["frame_row"]))==kind:surface.append(index)
    var pool:Array[int]=valid_rows()
    if surface.is_empty() or pool.is_empty():return []
    var count:int=mini(mini(MAX_FLAGSHIPS,maxi(1,(enemy.size()+ENEMIES_PER_FLAGSHIP-1)/ENEMIES_PER_FLAGSHIP)),surface.size())
    var random=RandomNumberGenerator.new()
    random.seed=seed ^ 1296389193
    var first:int=random.randi_range(0,pool.size()-1)
    var changes:Array[Dictionary]=[]
    for j:int in count:
        changes.append({"index":surface[j],"old_frame":int(ships[surface[j]]["frame_row"]),"new_frame":pool[(first+j)%pool.size()]})
    return changes

static func apply(setup:Dictionary,seed:int) -> Dictionary:
    var changes:Array[Dictionary]=plan(setup,seed)
    if changes.is_empty():return setup
    var result:Dictionary=setup.duplicate(true)
    for change:Dictionary in changes:
        var index:int=int(change["index"])
        var previous:Dictionary=result["ships"][index]
        # Native replacement creates matching mounts, ammunition, engine and AI.
        __U7UMfwBewiXSLEeaDnywaCO7.___KNRA9fcUYxes85gBEbjrSXI(result,index,int(change["new_frame"]))
        var config=refit_config(int(change["new_frame"]))
        var slot=__rhxwC76k0CGcO3Ps90EGUa5M.new()
        slot.__ofKSCLcCg7jWtqacDa153ehk=config
        slot.__D_bua5LYiw2NWQUHMrFegHMC=int(previous["side"])
        var fleet=__XY42sSBYwWAYSKuMIziPcxY_.new()
        fleet.__M0ImV248NGNrBFXy9NCs5jwX.append(slot)
        result["ships"][index]=__Ti__RyaVjFAbq0eWKyiulRtX.__eC2Gef0hq8YlwrdVcs2tTLeg(fleet)["ships"][0]
        # Explicit elite combat crew. Values are effective abilities, not player multipliers.
        result["ships"][index]["crew"]=[[120,0,1350,1350],[120,900,360,0],[120,900,360,0],[120,900,360,0],[120,900,360,0]]
        result["ships"][index]["crew_men"]=[225,225,225,225,225]
        var one:Dictionary={"ships":[result["ships"][index]]}
        one=__U7UMfwBewiXSLEeaDnywaCO7.__NKM5L0xChll3cOZcEXnavPlj(one,seed ^ (index*104729))
        one=__U7UMfwBewiXSLEeaDnywaCO7.__EAS0DpTiSLR0ok88UEwWqG5z(one)
        result["ships"][index]=one["ships"][0]
        # Display/identity fields from the scenario remain attached to this slot.
        for key:String in ["key","side","player","pos","heading"]:
            if previous.has(key):result["ships"][index][key]=previous[key]
    return result

static var config_cache:Dictionary={}
static var ammo_cache:Dictionary={}

static func ammunition(catalog:Variant,gun:int) -> PackedInt32Array:
    if ammo_cache.has(gun):return ammo_cache[gun].duplicate()
    var ap:int=-1
    var he:int=-1
    var family:int=int(catalog.__Y7oNU_MxqAazQR74RzaCuaOa(gun).get("shell_fam",-1))
    for shell:Dictionary in catalog.__ritaOQGJ41mdoyi1RiyGUay7:
        if int(shell.get("fam",-2))!=family:continue
        if int(shell.get("kind",-1))==2 and ap<0:ap=int(shell["row"])
        if int(shell.get("kind",-1))==0 and he<0:he=int(shell["row"])
    var ammo:PackedInt32Array=PackedInt32Array([ap,3,he,1]) if ap>=0 and he>=0 else catalog.__WVITuZqO2rxQlepLgwdT6PaH(gun)
    ammo_cache[gun]=ammo
    return ammo.duplicate()

static func refit_config(row:int):
    if config_cache.has(row):return config_cache[row].__12ty6aWt7_v7eYEbKtP71Dlf()
    var C=App.__PtNURh2PaYHMgsPlkLtni90Y()
    var config=C.__vTRMq3igRP2hTt2npyhiJ5UU(row)
    var nation:int=C.__72kAp8sMQh2gIPcLl7onOgPE(row)
    var main:PackedInt32Array=config.__dOsDavODOasdfPxqce2DEBC3.duplicate()
    for i:int in main.size():
        var best:int=-1
        var score:int=-1
        for gun:Dictionary in C.__58lUntkRmb7WDhPj2wQK5S19:
            var g:int=int(gun["row"])
            if int(gun.get("nat",0))!=nation or int(gun["caliber"])<1450:continue
            if not C.__KiH4kugZwhz3cYeRXEGkq9JE(row,i,g):continue
            var ammo:PackedInt32Array=ammunition(C,g)
            if ammo[0]<0 or int(C.__Z1n6LQ0e8g_Sv5O7it1HPeiw(ammo[0]).get("kind",-1))!=2:continue
            var strength:int=int(gun["caliber"])*int(gun["caliber"])*int(gun["barrels"])*100000+int(gun["v0"])*100-maxi(30,int(gun["reload"]))
            if strength>score:score=strength;best=g
        if best>=0:main[i]=best
    config.__dOsDavODOasdfPxqce2DEBC3=main
    config.__ZCQBCv36ysTHU0iBaYX6GvwS=PackedInt32Array()
    for gun:int in main:config.__ZCQBCv36ysTHU0iBaYX6GvwS.append_array(ammunition(C,gun))
    var sides:PackedInt32Array=C.__PJZemYw0whDwrAt4vbBLpQ7w(config).duplicate()
    for i:int in sides.size():
        var best:int=sides[i]
        var score:int=-1
        for gun:Dictionary in C.__c8pMZHoqxjTbnIEdHvKqrxWw:
            var g:int=int(gun["row"])
            if int(gun.get("nat",0))!=nation or not C.__HjoKUKLM8g2zt3bTJxvqF5nf(row,i,g):continue
            var strength:int=int(gun["caliber"])*int(gun["caliber"])*int(gun["barrels"])*1000/maxi(30,int(gun["reload"]))
            if strength>score:score=strength;best=g
        sides[i]=best
    config.__t1UipS__8EvFgumrL932qeyd=sides
    config.__nQdkAoXs7wyREcSJQ0Beyel6=PackedInt32Array()
    for gun:int in sides:config.__nQdkAoXs7wyREcSJQ0Beyel6.append_array(ammunition(C,gun))
    var radar_score:int=-1
    for radar:Dictionary in C.__UZgr86jLLxe3Fj5_3AvQgrnl():
        var fcs:int=int(radar["row"])
        if int(radar.get("nat",0))!=nation or not C.__3Pn7DymjfgKdMoOkzsKaTunv(row,fcs):continue
        var strength:int=int(radar["hit"])*100000+int(radar["line"])*10+int(radar["track"])
        if strength>radar_score:radar_score=strength;config.__vwSAcybbCInOpnt2FbN4qz7L=fcs
    # Native armor material and legal total displacement; decrement thickness if necessary.
    var original:PackedInt32Array=C.__KtCbywgOvmHRjmrjlwbokzzu(row)
    var armor:PackedInt32Array=PackedInt32Array([nation,60,nation,160,nation,10,nation,10])
    for step:int in 101:
        for j:int in [1,3,5,7]:armor[j]=maxi(original[j],([0,60,0,160,0,10,0,10][j]*(100-step))/100)
        config.__cQ8JInnnrEoGxd_1jglej7pR=armor
        if C.__BGxXnVzPsmPLUaUtEL38SXTm(config)==0:break
    config_cache[row]=config
    return config
