extends PanelContainer

const TYPE_NAMES:Array[String]=["未知","偵察","戰鬥","魚雷","轟炸"]
var battle:Node
var ship:Variant
var flight:Variant
var native_panel:Variant
var gun_panel:WeakRef
var body:VBoxContainer
var group_grid:GridContainer
var group_buttons:Array[Button]=[]
var buttons:Dictionary={}
var deck_row:HBoxContainer
var flight_row:HBoxContainer
var flight_mode:bool=false
var status_label:Label
var hint_label:Label
var auto_button:Button
var gun_button:Button
var fold_button:Button
var folded:bool=false
var elapsed:float=0.0

func _ready() -> void:
    theme=__Wl_Qw9KUEfRrP_gP8ETPRbl4.get_theme()
    mouse_filter=Control.MOUSE_FILTER_STOP
    set_anchors_preset(Control.PRESET_TOP_RIGHT)
    custom_minimum_size=Vector2(294,0)
    var bg=StyleBoxFlat.new()
    bg.bg_color=Color(0.025,0.105,0.135,0.96)
    bg.border_color=Color(0.29,0.76,0.70,0.95)
    bg.set_border_width_all(1);bg.set_corner_radius_all(5)
    bg.content_margin_left=7;bg.content_margin_right=7;bg.content_margin_top=5;bg.content_margin_bottom=6
    add_theme_stylebox_override("panel",bg)
    var outer=VBoxContainer.new();outer.add_theme_constant_override("separation",3);add_child(outer)
    var heading=HBoxContainer.new();heading.add_theme_constant_override("separation",3);outer.add_child(heading)
    var title=Label.new();title.text="艦載機指揮";title.size_flags_horizontal=Control.SIZE_EXPAND_FILL
    title.add_theme_font_size_override("font_size",14);title.add_theme_color_override("font_color",Color8(121,225,200));heading.add_child(title)
    auto_button=make_button("自動",auto_toggle);auto_button.custom_minimum_size=Vector2(67,25);heading.add_child(auto_button)
    gun_button=make_button("火炮",open_guns);gun_button.custom_minimum_size=Vector2(45,25);heading.add_child(gun_button)
    fold_button=make_button("收起",toggle_fold);fold_button.custom_minimum_size=Vector2(45,25);heading.add_child(fold_button)
    body=VBoxContainer.new();body.add_theme_constant_override("separation",3);outer.add_child(body)
    group_grid=GridContainer.new();group_grid.columns=4
    group_grid.add_theme_constant_override("h_separation",3);group_grid.add_theme_constant_override("v_separation",3);body.add_child(group_grid)
    status_label=Label.new();status_label.add_theme_font_size_override("font_size",12)
    status_label.add_theme_color_override("font_color",Color8(216,235,242));status_label.clip_text=true;body.add_child(status_label)
    deck_row=HBoxContainer.new();deck_row.add_theme_constant_override("separation",3);body.add_child(deck_row)
    add_action(deck_row,"minus","−",func(): manual_deck("dn"),40)
    add_action(deck_row,"plus","＋",func(): manual_deck("up"),40)
    add_action(deck_row,"ready","準備",func(): manual_deck("big"),0)
    add_action(deck_row,"to_flight","飛行 ▸",func(): set_flight_mode(true),60)
    flight_row=HBoxContainer.new();flight_row.add_theme_constant_override("separation",3);body.add_child(flight_row)
    add_action(flight_row,"alt_up","上升",func(): manual_air("up"),0)
    add_action(flight_row,"alt_down","下降",func(): manual_air("down"),0)
    add_action(flight_row,"drop","投彈",func(): manual_air("drop"),0)
    add_action(flight_row,"to_deck","甲板 ▸",func(): set_flight_mode(false),60)
    flight_row.hide()
    var orders=HBoxContainer.new();orders.add_theme_constant_override("separation",3);body.add_child(orders)
    add_action(orders,"attack","攻擊近敵",attack_nearest,0)
    add_action(orders,"return","返回母艦",recall,0)
    add_action(orders,"focus","追蹤",focus_aircraft,48)
    hint_label=Label.new();hint_label.text="選擇編隊；手動命令會暫停自動"
    hint_label.add_theme_font_size_override("font_size",11);hint_label.add_theme_color_override("font_color",Color8(174,208,205));hint_label.clip_text=true;body.add_child(hint_label)
    buttons["attack"].tooltip_text="向最近且已被己方發現的敵艦下達攻擊命令；適用魚雷機、轟炸機。"
    buttons["return"].tooltip_text="讓目前選取的空中編隊返回母艦。"
    buttons["focus"].tooltip_text="鏡頭移到目前編隊；不會改變自動模式。"
    buttons["drop"].tooltip_text="在攻擊航段確認投彈／投雷。魚雷手動投放需低於 50；俯衝轟炸須進入可投彈階段。"
    get_viewport().size_changed.connect(update_layout)
    call_deferred("update_layout")

func make_button(label:String,callback:Callable) -> Button:
    var button=Button.new();button.text=label;button.focus_mode=Control.FOCUS_NONE
    button.mouse_filter=Control.MOUSE_FILTER_STOP;button.add_theme_font_size_override("font_size",12)
    button.add_theme_color_override("font_disabled_color",Color8(145,166,177))
    button.custom_minimum_size=Vector2(0,25);button.pressed.connect(callback)
    return button

func add_action(row:HBoxContainer,id:String,label:String,callback:Callable,width:float) -> void:
    var button=make_button(label,callback);button.name="action_"+id
    if width>0:button.custom_minimum_size.x=width
    else:button.size_flags_horizontal=Control.SIZE_EXPAND_FILL
    row.add_child(button);buttons[id]=button

func bind(owner_battle:Node,player:Variant,air:Variant,panel:Variant,gun:Variant) -> void:
    battle=owner_battle;ship=player;flight=air;native_panel=panel
    if is_instance_valid(gun):gun_panel=weakref(gun)
    gun_button.visible=is_instance_valid(gun)
    for i:int in native_panel.__OPzSULEP2bVV8NH0jjVnaa8t.size():
        var index:int=i
        var button=make_button("",func(): select_group(index));button.name="group_"+str(index)
        button.toggle_mode=true;button.size_flags_horizontal=Control.SIZE_EXPAND_FILL
        group_grid.add_child(button);group_buttons.append(button)
    refresh();call_deferred("update_layout")

func valid_battle() -> bool:
    return is_instance_valid(battle) and ship!=null and flight!=null and is_instance_valid(native_panel) and not battle.__898CZFX8zI40Huxp297h_lkH and battle.__5zsHBwGhnk5X3Ays_WuwIBnz==null and not battle.paused and native_panel.meti_auto_available()

func current_group() -> int:
    if not is_instance_valid(native_panel):return -1
    var i:int=int(native_panel.__bjbecUEmizoqbtCQsSOTcIww)
    return i if i>=0 and i<group_buttons.size() else -1

func select_group(i:int) -> void:
    if not valid_battle() or i<0 or i>=group_buttons.size():return
    native_panel.select(i)
    flight.__WzWWzwD5zNDoofywUKXrxhRo(i,false)
    refresh()

func manual_deck(action:String) -> void:
    if not valid_battle() or current_group()<0:return
    native_panel.__ib1LeDAVfmqeWT3J6wPc4WEm(action)
    refresh()

func auto_toggle() -> void:
    if not valid_battle():return
    native_panel.__ib1LeDAVfmqeWT3J6wPc4WEm("meti_auto")
    refresh()

func attack_nearest() -> void:
    if not valid_battle():return
    var group:int=current_group()
    if group<0:return
    var squad:Dictionary=ship.__g7JC3EJmfsOWnIyqLGGB93eB.__knUj879QWUN8clA4_f5YGzfw(group)
    if int(squad["type"])<3 or not group_attack_ready(group) or not group_has_ammo(group):return
    var target:int=flight.meti_auto_target()
    if target<0:return
    if native_panel.meti_auto_enabled:native_panel.meti_set_auto(false)
    flight.meti_auto_order(group,2,1,__cV1TfO9LYjqVJIVXjDHEK396.__pMiCouh0jcltI1aLSxpyjfv7(target))
    refresh()

func recall() -> void:
    if not valid_battle():return
    var group:int=current_group()
    if group<0 or not group_airborne(group):return
    if native_panel.meti_auto_enabled:native_panel.meti_set_auto(false)
    flight.meti_auto_return(group)
    refresh()

func focus_aircraft() -> void:
    if not valid_battle() or current_group()<0:return
    native_panel.__ib1LeDAVfmqeWT3J6wPc4WEm("focus")

func manual_air(action:String) -> void:
    if not valid_battle():return
    var group:int=current_group()
    if group<0 or not group_controllable(group):return
    var squad:Dictionary=ship.__g7JC3EJmfsOWnIyqLGGB93eB.__knUj879QWUN8clA4_f5YGzfw(group)
    if action=="drop" and (int(squad["type"])<3 or not group_has_ammo(group)):return
    if action=="drop":
        if not group_drop_ready(group):return
        var target:int=group_drop_target(group)
        if target>=0:
            if native_panel.meti_auto_enabled:native_panel.meti_set_auto(false)
            flight.meti_auto_order(group,2,1,__cV1TfO9LYjqVJIVXjDHEK396.__pMiCouh0jcltI1aLSxpyjfv7(target))
            refresh()
            return
    if action in ["up","down"] and not group_alt_ready(group):return
    var codes:Dictionary={
        "up":__ZHwJr3sB730Xm67xCNPRVjTe.__7p66fpI27Ejh1nHovTpHSGpN.__qlYRO2aLFEOnPtWkaJAGkfNX,
        "down":__ZHwJr3sB730Xm67xCNPRVjTe.__7p66fpI27Ejh1nHovTpHSGpN.__RJLHRlP34WLuEbRrYyGd_QBG,
        "drop":__ZHwJr3sB730Xm67xCNPRVjTe.__7p66fpI27Ejh1nHovTpHSGpN.__13xdeilLgdjil6FE_cmvWKMm,
    }
    if not codes.has(action):return
    flight.__WzWWzwD5zNDoofywUKXrxhRo(group,false)
    if native_panel.meti_auto_enabled:native_panel.meti_set_auto(false)
    flight.__NhyzmUA9yvICs3BYE9vRlcqw(int(codes[action]),true,null,native_panel)
    refresh()

func group_airborne(group:int) -> bool:
    for plane in ship.__g7JC3EJmfsOWnIyqLGGB93eB.__knUj879QWUN8clA4_f5YGzfw(group)["members"]:
        if plane.active and not plane.__jKXPrtchy4v7fjo9Z9kJG9SX:return true
    return false

func group_has_ammo(group:int) -> bool:
    for plane in ship.__g7JC3EJmfsOWnIyqLGGB93eB.__knUj879QWUN8clA4_f5YGzfw(group)["members"]:
        if plane.active and not plane.__jKXPrtchy4v7fjo9Z9kJG9SX and plane.__6ol9zXLNVbGS9s_iAdvMaxLC>0:return true
    return false

func group_controllable(group:int) -> bool:
    var found:bool=false
    for plane in ship.__g7JC3EJmfsOWnIyqLGGB93eB.__knUj879QWUN8clA4_f5YGzfw(group)["members"]:
        if plane.active and not plane.__jKXPrtchy4v7fjo9Z9kJG9SX:
            found=true
            if plane.state==__YCYnibBjVPRhMDf3YPwizbkN.State.__cqei2U9gqm0EDzpnZTAB5gor:return false
    return found

func group_attack_ready(group:int) -> bool:
    if not group_controllable(group):return false
    for plane in ship.__g7JC3EJmfsOWnIyqLGGB93eB.__knUj879QWUN8clA4_f5YGzfw(group)["members"]:
        if not plane.active or plane.__jKXPrtchy4v7fjo9Z9kJG9SX:return false
        if plane.state not in [0,1,100] or plane.__aBKovnuyCiI63tVuI2prB5MN<plane.__2cQt3I45k0XXwSr_0reYodT2:return false
    return true

func group_alt_ready(group:int) -> bool:
    if not group_controllable(group):return false
    for plane in ship.__g7JC3EJmfsOWnIyqLGGB93eB.__knUj879QWUN8clA4_f5YGzfw(group)["members"]:
        if plane.active and not plane.__jKXPrtchy4v7fjo9Z9kJG9SX and plane.state not in [0,1,100]:return false
    return true

func group_drop_target(group:int) -> int:
    for plane in ship.__g7JC3EJmfsOWnIyqLGGB93eB.__knUj879QWUN8clA4_f5YGzfw(group)["members"]:
        if plane.active and not plane.__jKXPrtchy4v7fjo9Z9kJG9SX and plane.__6ol9zXLNVbGS9s_iAdvMaxLC>0 and plane.state==4 and plane.sub==1 and plane.__TlWqW0m63x0ks40OasJLgdcp>=0:
            return plane.__TlWqW0m63x0ks40OasJLgdcp
    return -1

func group_drop_ready(group:int) -> bool:
    if not group_controllable(group):return false
    if group_drop_target(group)>=0:return true
    for plane in ship.__g7JC3EJmfsOWnIyqLGGB93eB.__knUj879QWUN8clA4_f5YGzfw(group)["members"]:
        if not plane.active or plane.__jKXPrtchy4v7fjo9Z9kJG9SX or plane.__6ol9zXLNVbGS9s_iAdvMaxLC<=0:continue
        if plane.type==3 and plane.__aBKovnuyCiI63tVuI2prB5MN/1000<50:return true
        if plane.type==4 and plane.state==4 and plane.sub==1 and plane.__eYCv0HeDvti_w5wj1jxJpmfT:return true
    return false

func open_guns() -> void:
    var panel=gun_panel.get_ref() if gun_panel!=null else null
    if is_instance_valid(panel):
        hide();panel.show();panel.call_deferred("update_layout")

func set_flight_mode(enabled:bool) -> void:
    flight_mode=enabled
    deck_row.visible=not enabled;flight_row.visible=enabled
    call_deferred("reset_size");call_deferred("update_layout")

func toggle_fold() -> void:
    folded=not folded;body.visible=not folded;fold_button.text="展開" if folded else "收起"
    call_deferred("reset_size");call_deferred("update_layout")

func update_layout() -> void:
    var vh:float=get_viewport_rect().size.y
    var height:float=maxf(30.0,get_combined_minimum_size().y)
    var bottom_margin:float=185.0 if get_viewport_rect().size.x<=1100.0 else 170.0
    var fit:float=clampf((vh-bottom_margin-374.0)/height,0.68,1.0)
    scale=Vector2.ONE*fit
    offset_left=-10.0-294.0*fit;offset_right=offset_left+294.0
    var top:float=minf(374.0,maxf(68.0,vh-bottom_margin-height*fit))
    offset_top=top;offset_bottom=top+height

func _process(delta:float) -> void:
    elapsed+=delta
    if elapsed>=0.2:
        elapsed=0.0;refresh()

func refresh() -> void:
    if not is_instance_valid(native_panel) or ship==null or group_buttons.is_empty():return
    auto_button.text="自動：開" if native_panel.meti_auto_enabled else "自動：關"
    var wing=ship.__g7JC3EJmfsOWnIyqLGGB93eB
    var index:int=current_group()
    if index<0:return
    for i:int in group_buttons.size():
        var kind:int=int(wing.__knUj879QWUN8clA4_f5YGzfw(i)["type"])
        group_buttons[i].text="%d %s" % [i+1,TYPE_NAMES[clampi(kind,0,TYPE_NAMES.size()-1)]]
        group_buttons[i].set_pressed_no_signal(i==index)
    var squad:Dictionary=wing.__knUj879QWUN8clA4_f5YGzfw(index)
    var cell:Dictionary=native_panel.__OPzSULEP2bVV8NH0jjVnaa8t[index]
    var state:int=int(cell["state"]);var kind:int=int(squad["type"])
    var airborne:int=0;var fuel:int=100;var flight_state:String="空中"
    for a in squad["members"]:
        if a.active and not a.__jKXPrtchy4v7fjo9Z9kJG9SX:
            airborne+=1
            if airborne==1:flight_state=str({0:"飛行中",1:"空中待命",2:"空戰中",4:"攻擊中",5:"返航中",100:"護航中"}.get(int(a.state),"空中"))
            var maximum:int=maxi(1,__cV1TfO9LYjqVJIVXjDHEK396.__tUnSLy1bkvGyKKeIrEiqbbcp(a))
            fuel=mini(fuel,clampi((maximum-a.__Grly1BvCsxoCuBf0E7OZOvtN)*100/maximum,0,100))
    var names:Dictionary={1:"待整備",2:"整備中",4:"可起飛",8:"空中",16:"空中"}
    var status:String=str(names.get(state,"待命"))
    var depot:Dictionary=wing.__0IiawbJUBQggkPsEIdPzmWda(kind)
    status_label.text="%s｜規劃 %d/%d｜機庫 %d" % [status,int(cell["planned"]),int(squad["size"]),maxi(0,int(depot["hangar"]))]
    if airborne>0:status_label.text="%s %d｜最低油量 %d%%" % [flight_state,airborne,fuel]
    var editable:bool=state==1
    buttons["minus"].disabled=not editable or int(cell["planned"])<=0
    buttons["plus"].disabled=not editable or not native_panel.__EZk0RnCx2LPuWUZW1ZGwxl0g(index)
    buttons["ready"].text="起飛" if state==4 else "準備" if state==1 else "整備中" if state==2 else "空中"
    buttons["ready"].disabled=not (state==4 or (state==1 and int(cell["planned"])>0))
    buttons["attack"].disabled=airborne==0 or kind<3 or not group_has_ammo(index) or not group_attack_ready(index) or flight.meti_auto_target()<0
    buttons["return"].disabled=airborne==0
    buttons["focus"].disabled=airborne==0
    buttons["alt_up"].disabled=not group_alt_ready(index)
    buttons["alt_down"].disabled=not group_alt_ready(index)
    buttons["drop"].disabled=kind<3 or not group_drop_ready(index)
    if airborne>0 and kind>=3 and not group_has_ammo(index):
        hint_label.text="彈藥已耗盡，請返航補給"
    elif flight_state=="攻擊中":
        hint_label.text="飛行頁按投彈確認" if group_drop_ready(index) else "攻擊中：等待進入投彈階段"
    elif airborne>0 and flight_state in ["返航中","空戰中"]:
        hint_label.text="編隊%s；手動命令會暫停自動" % flight_state
    elif airborne>0 and kind>=3 and not group_attack_ready(index):
        hint_label.text="編隊未就緒，完成起飛爬升後可攻擊"
    else:
        hint_label.text="選擇編隊；手動命令會暫停自動"
