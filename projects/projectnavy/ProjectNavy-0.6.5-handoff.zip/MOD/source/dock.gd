extends __8GTw5uMzf0oxhrK8dEroB4bz
func __f4WZ0f5YLsVN7ro5OfjrWn22() -> void :
	if __kinsDyUwBqfk_kcYtvIhl2eK:
		var __8pgqb290qeYDF8iKejRc4rai: int = __YJgAymCaLB78BrFx7OQpn545.__WeB9Hi0OxaFBUuwm2WU2qKEH if __DpM0JQWB6EqgMh3WJZSlHODu else -1
		__YJgAymCaLB78BrFx7OQpn545 = __U7UMfwBewiXSLEeaDnywaCO7.__V0erSRNWoPFGOr7bG6vGIpsK()
		if __YJgAymCaLB78BrFx7OQpn545.__WeB9Hi0OxaFBUuwm2WU2qKEH != __8pgqb290qeYDF8iKejRc4rai and App.__72kAp8sMQh2gIPcLl7onOgPE(__YJgAymCaLB78BrFx7OQpn545.__WeB9Hi0OxaFBUuwm2WU2qKEH) != __cG_zbW1sotj7reUf4u7FXswZ:
			__cG_zbW1sotj7reUf4u7FXswZ = App.__72kAp8sMQh2gIPcLl7onOgPE(__YJgAymCaLB78BrFx7OQpn545.__WeB9Hi0OxaFBUuwm2WU2qKEH)
			__U7UMfwBewiXSLEeaDnywaCO7.__PYsanWw1Gsza29vOAY89AxUL(__cG_zbW1sotj7reUf4u7FXswZ)
			if __WthKfcvjK4RJwtX6snlMJlVa != null:
				__WthKfcvjK4RJwtX6snlMJlVa.set_text(__ejjrmWDPOiCDSSON_WTtAS7w())
		__YahxYYsCSePibWCVlCnGhFI_()
		_load()
		__CZNkeeRfo0Z9Wuy80hOWdhXF(false)
		__4VH5P1TCUJzfLL55i2_8NhQh()
		if __zABAFBwuGIufBHjRN9OzcNUm != null:
			__zABAFBwuGIufBHjRN9OzcNUm.__Qa9GbnhM8GDjcw4fKszR0Ftz()
		__g6q9T1VmtoQE6bUvlCkH1PIZ(__aBhCjT5h4HuVdMnKzKKIXLBp)
var __ORPVAwaEZaG_WUKCzYPqV3CM: Array[__XZQIsX2REk1j2LWZtbLIAovG] = []
const __c7JT2pWXsKuTeLAJDg1Em0cn: = Vector2(50, 0)
var __X_kchlTgjXLrGf3SqqJZxguo: float = 0.0
var __aZ9T7TmaIvmS1Lo85UiNhrn8: Button
const __kfMZ6oUfTBEE3cf4diKyUxhN: = Vector2(265, 476)
func __JP9cOkhmwnT97LFapLTV6u08(d: Dictionary) -> String:
	match str(d.get("what", "")):
		"main", "side", "torp":
			return "m:%d" % int(d["slot"])
		"fcs":
			return "fcs"
		"air":
			return "air:%d" % int(d["air"])
		"armor":
			return "armor:%d" % int(d["zone"])
	return ""
var __5rz7a76K5lyi3GlEigYE8q9G: __pT6jZw1fUvWomUDaJvLtM_kC
const __1OBaxTiunLXQFo13Se2TAg0r: = 60.0
var __M3mMe5n3JrbgRvzvIt9w1QZt: __dr2CVyLJ3jYjG9eLwJgEkSvf
var __WthKfcvjK4RJwtX6snlMJlVa: __cqDq9BUy3jf_ObmeDukYBAN_
func __HuRyg1NMVNcEpLPmiIJdll32(__HLrYRdiOL6nEfNolC6cf36M2: String, __CoeHiNJIGKhomBi8B6NM6SBL: int) -> void :
	__M3mMe5n3JrbgRvzvIt9w1QZt.__wJZ16sGJMQNBMMTnwRkCh1h1.text = tr("UI_MARKET_BULK_ALL")
	var __qVHcBoaYiOXDLsbumQQd6jSi: __Se4EsxPBCHX48h1ZS5MexaMl = App.__PtNURh2PaYHMgsPlkLtni90Y()
	var __KUYPUWAgndjEJnVwOIS_e5D2: int = __YJgAymCaLB78BrFx7OQpn545.__WeB9Hi0OxaFBUuwm2WU2qKEH
	var __uSlzLNjFJd9mlCm5w2UgbJYC: Array[Dictionary] = []
	var __AWd89JpOeHBSeCa5aUQEAQw3: int = __s8yZigV26lPAvEmbOWzMbnjE.__1iBjWxIGtvWf0yGsmF7yzBIR
	var __vCduKg5sk0RXvyO955gbLBxX: int = 1
	var __Mr7SgxzI1ue3n8m0nusw3iNR: String = tr("UI_TRADE_UNIT_GUN")
	var __limxFPWCpXzJNi4hKoZVOmTv: Callable = func(__vR3xGEzohdh3Yp7peWvStq5_: int) -> int: return 1
	var title: String = ""
	match __HLrYRdiOL6nEfNolC6cf36M2:
		"L":
			__AWd89JpOeHBSeCa5aUQEAQw3 = __qVHcBoaYiOXDLsbumQQd6jSi.__7uBhyRNBJZP4s1InKu8Lo_y7(__YJgAymCaLB78BrFx7OQpn545)[__CoeHiNJIGKhomBi8B6NM6SBL]
			title = tr("UI_TRADE_TITLE_TP")
			for __5eduX1_lRJL7M0yrtX7YwTs1: Dictionary in __qVHcBoaYiOXDLsbumQQd6jSi.__JELXUtRv6OHlTdsobeAbVAPR(__KUYPUWAgndjEJnVwOIS_e5D2):
				__uSlzLNjFJd9mlCm5w2UgbJYC.append({"row": __5eduX1_lRJL7M0yrtX7YwTs1["row"], "name": __5eduX1_lRJL7M0yrtX7YwTs1["cn"], "cols": PackedStringArray(["—", __sadJuUS1UT0UzhHxF1koKG0C(int(__5eduX1_lRJL7M0yrtX7YwTs1["weight"])), __TYkQtj0KJU3imI91kByy1UpC(int(__5eduX1_lRJL7M0yrtX7YwTs1["space"]), 10), tr("UI_TRADE_TUBES") % int(__5eduX1_lRJL7M0yrtX7YwTs1["tubes"]), "—", ""]), "info": PackedStringArray([tr("UI_TRADE_TP_INFO") % [int(__5eduX1_lRJL7M0yrtX7YwTs1["tubes"]), int(__5eduX1_lRJL7M0yrtX7YwTs1["reload"])]])})
		"E":
			__AWd89JpOeHBSeCa5aUQEAQw3 = __qVHcBoaYiOXDLsbumQQd6jSi.__Qw3k08OnVM2mR_e4yUtGgVFs(__YJgAymCaLB78BrFx7OQpn545)
			title = tr("UI_TRADE_TITLE_ENGINE")
			var __i76TpsVTU8_bMzWiFYEjJb03: int = __qVHcBoaYiOXDLsbumQQd6jSi.__rIbrGNBQXI7CsdYVLpVwKrNI(__KUYPUWAgndjEJnVwOIS_e5D2)
			var __k7ZQtP9RkAUO1DcYhFmQnRgr: int = __qVHcBoaYiOXDLsbumQQd6jSi.__IvI9R3sxngPJtGG8BIfWJcTy(__KUYPUWAgndjEJnVwOIS_e5D2)
			var __MzTcB9HMr5sMwFykjWG0y_r9: int = App.__M0ImV248NGNrBFXy9NCs5jwX().__RuEf8sDpDtu0ArTJYzf6W0JG() if __kinsDyUwBqfk_kcYtvIhl2eK else 0
			var __PPICWKZ1xL2HQLK6fqzTsen7: int = __qVHcBoaYiOXDLsbumQQd6jSi.__77YZ0E3pilwCWMSZ5lHzv_es(__YJgAymCaLB78BrFx7OQpn545).x
			var __tnszyDQvfrqcOqWZgKHfhGkk: int = int(__qVHcBoaYiOXDLsbumQQd6jSi.__NELIelBEafKRGQultNqYAbM7(__AWd89JpOeHBSeCa5aUQEAQw3).get("weight", 0))
			for __6BlmfG4lPOAWMLkVOdU9v4RV: Dictionary in __qVHcBoaYiOXDLsbumQQd6jSi.__Yayx6szN1x0ff10kA2rip0Wh(__KUYPUWAgndjEJnVwOIS_e5D2):
				var __zd8wNYnkcMZ0GyjowvQqyINY: int = __2ZIL9u7_cM4KOmaAUAdneX5d.__rE0McfzbdQFKc4LopFW9XMAd(App.___qFCN2viGM2bPW1uGV9qys9h(), __KUYPUWAgndjEJnVwOIS_e5D2, int(__6BlmfG4lPOAWMLkVOdU9v4RV["row"]), __PPICWKZ1xL2HQLK6fqzTsen7 - __tnszyDQvfrqcOqWZgKHfhGkk + int(__6BlmfG4lPOAWMLkVOdU9v4RV["weight"]) + __MzTcB9HMr5sMwFykjWG0y_r9)
				var __HqvU1HogCyQHMT9uNFKC8NMR: int = __2ZIL9u7_cM4KOmaAUAdneX5d.__6JV8CAX2HqhD7_dopT9dfg_8(App.___qFCN2viGM2bPW1uGV9qys9h(), __KUYPUWAgndjEJnVwOIS_e5D2, int(__6BlmfG4lPOAWMLkVOdU9v4RV["row"]), __i76TpsVTU8_bMzWiFYEjJb03, __zd8wNYnkcMZ0GyjowvQqyINY)
				__uSlzLNjFJd9mlCm5w2UgbJYC.append({"row": __6BlmfG4lPOAWMLkVOdU9v4RV["row"], "name": __6BlmfG4lPOAWMLkVOdU9v4RV["name"], "cols": PackedStringArray(["—", __sadJuUS1UT0UzhHxF1koKG0C(int(__6BlmfG4lPOAWMLkVOdU9v4RV["weight"])), str(__6BlmfG4lPOAWMLkVOdU9v4RV["space"]), str(__6BlmfG4lPOAWMLkVOdU9v4RV["hp"]), "+%d%%" % __HqvU1HogCyQHMT9uNFKC8NMR, str(int(__6BlmfG4lPOAWMLkVOdU9v4RV["heat"]) * 50)]), "info": PackedStringArray([tr("UI_TRADE_ENGINE_INFO") % [int(__6BlmfG4lPOAWMLkVOdU9v4RV["hp"]), __HqvU1HogCyQHMT9uNFKC8NMR, int(__6BlmfG4lPOAWMLkVOdU9v4RV["heat"]) * 50, int(__6BlmfG4lPOAWMLkVOdU9v4RV["space"]), __k7ZQtP9RkAUO1DcYhFmQnRgr]])})
			if __AWd89JpOeHBSeCa5aUQEAQw3 >= 0 and not __qVHcBoaYiOXDLsbumQQd6jSi.__hOCt9i56mdn3vTmR0LpPQEK2(__KUYPUWAgndjEJnVwOIS_e5D2, __AWd89JpOeHBSeCa5aUQEAQw3):
				var __xQ5FqwgnOsinUIrTS12Ti379: Dictionary = __qVHcBoaYiOXDLsbumQQd6jSi.__NELIelBEafKRGQultNqYAbM7(__AWd89JpOeHBSeCa5aUQEAQw3)
				var __CtDs82HowlzAnnd3ZeaONjvq: int = __2ZIL9u7_cM4KOmaAUAdneX5d.__rE0McfzbdQFKc4LopFW9XMAd(App.___qFCN2viGM2bPW1uGV9qys9h(), __KUYPUWAgndjEJnVwOIS_e5D2, __AWd89JpOeHBSeCa5aUQEAQw3, __PPICWKZ1xL2HQLK6fqzTsen7 + __MzTcB9HMr5sMwFykjWG0y_r9)
				var __Ac_3Ippb6nA_bC96pWGNumzA: int = __2ZIL9u7_cM4KOmaAUAdneX5d.__6JV8CAX2HqhD7_dopT9dfg_8(App.___qFCN2viGM2bPW1uGV9qys9h(), __KUYPUWAgndjEJnVwOIS_e5D2, __AWd89JpOeHBSeCa5aUQEAQw3, __i76TpsVTU8_bMzWiFYEjJb03, __CtDs82HowlzAnnd3ZeaONjvq)
				__uSlzLNjFJd9mlCm5w2UgbJYC.push_front({"row": __AWd89JpOeHBSeCa5aUQEAQw3, "name": __xQ5FqwgnOsinUIrTS12Ti379.get("name", ""), "cols": PackedStringArray(["—", __sadJuUS1UT0UzhHxF1koKG0C(int(__xQ5FqwgnOsinUIrTS12Ti379.get("weight", 0))), str(__xQ5FqwgnOsinUIrTS12Ti379.get("space", 0)), str(__xQ5FqwgnOsinUIrTS12Ti379.get("hp", 0)), "+%d%%" % __Ac_3Ippb6nA_bC96pWGNumzA, str(int(__xQ5FqwgnOsinUIrTS12Ti379.get("heat", 0)) * 50)]), "info": PackedStringArray([tr("UI_TRADE_ENGINE_FACTORY")])})
		"F":
			__AWd89JpOeHBSeCa5aUQEAQw3 = __YJgAymCaLB78BrFx7OQpn545.__vwSAcybbCInOpnt2FbN4qz7L
			title = tr("UI_TRADE_TITLE_FCS")
			for __9_UTDf8CYw5zSYk_R8_5npeJ: Dictionary in __qVHcBoaYiOXDLsbumQQd6jSi.__dyrCsGiN2ktJ3lzUBZEGRxRd(__KUYPUWAgndjEJnVwOIS_e5D2):
				__uSlzLNjFJd9mlCm5w2UgbJYC.append({"row": __9_UTDf8CYw5zSYk_R8_5npeJ["row"], "name": __9_UTDf8CYw5zSYk_R8_5npeJ["name"], "cols": PackedStringArray(["—", __sadJuUS1UT0UzhHxF1koKG0C(int(__9_UTDf8CYw5zSYk_R8_5npeJ["weight"])), __TYkQtj0KJU3imI91kByy1UpC(int(__9_UTDf8CYw5zSYk_R8_5npeJ["space"]), 10), str(__9_UTDf8CYw5zSYk_R8_5npeJ["track"]), "%+d" % int(__9_UTDf8CYw5zSYk_R8_5npeJ["hit"]), str(__9_UTDf8CYw5zSYk_R8_5npeJ["line"])]), "info": PackedStringArray([tr("UI_TRADE_FCS_INFO") % [int(__9_UTDf8CYw5zSYk_R8_5npeJ["track"]), int(__9_UTDf8CYw5zSYk_R8_5npeJ["hit"]), int(__9_UTDf8CYw5zSYk_R8_5npeJ["line"])]])})
		"R":
			var __mzwb7iWNp5GW7TQu4y2nzexB: PackedInt32Array = __qVHcBoaYiOXDLsbumQQd6jSi.__uCNDLIyQQRLcwA3z5vXmUuAz(__YJgAymCaLB78BrFx7OQpn545)
			var __hDsaZclovbO_hluymTVmd3VC: int = __qVHcBoaYiOXDLsbumQQd6jSi.__eezCSxsQSp01HYni_60fHV16(__KUYPUWAgndjEJnVwOIS_e5D2)[__CoeHiNJIGKhomBi8B6NM6SBL]
			__AWd89JpOeHBSeCa5aUQEAQw3 = __mzwb7iWNp5GW7TQu4y2nzexB[2 * __CoeHiNJIGKhomBi8B6NM6SBL]
			__vCduKg5sk0RXvyO955gbLBxX = __mzwb7iWNp5GW7TQu4y2nzexB[2 * __CoeHiNJIGKhomBi8B6NM6SBL + 1] / __Se4EsxPBCHX48h1ZS5MexaMl.__MmvhtidBsePDvXycLyLNHv8h if __AWd89JpOeHBSeCa5aUQEAQw3 >= 0 else 0
			__Mr7SgxzI1ue3n8m0nusw3iNR = tr("UI_TRADE_UNIT_ARMOR")
			title = tr("UI_TRADE_TITLE_ARMOR") % tr("UI_ARMOR_ZONE_%d" % __CoeHiNJIGKhomBi8B6NM6SBL)
			__limxFPWCpXzJNi4hKoZVOmTv = func(__bMq0Y6Cmy3x_v0u3QA3JIATi: int) -> int: return __Se4EsxPBCHX48h1ZS5MexaMl.__TQxwsrRwLhWz1Ayw2UeZ0BV6 / __Se4EsxPBCHX48h1ZS5MexaMl.__MmvhtidBsePDvXycLyLNHv8h
			for a: Dictionary in __qVHcBoaYiOXDLsbumQQd6jSi.__u8uwRsn0jstZkphmFUNql6Ov(__KUYPUWAgndjEJnVwOIS_e5D2):
				var __IZi4ZI4j16EI0hvTFphl0IEv: int = __hDsaZclovbO_hluymTVmd3VC * int(a["weight"]) * 10
				__uSlzLNjFJd9mlCm5w2UgbJYC.append({"row": a["row"], "name": a["name"], "cols": PackedStringArray(["—", __sadJuUS1UT0UzhHxF1koKG0C(__IZi4ZI4j16EI0hvTFphl0IEv), "", "%.1f" % (int(a["ap"]) / 10.0), "%.1f" % (int(a["he"]) / 10.0), "%.1f" % (int(a["bulk"]) / 10.0) if __CoeHiNJIGKhomBi8B6NM6SBL == 2 else ("%d" % int(a["bulge"]) if __CoeHiNJIGKhomBi8B6NM6SBL == 3 else "")]), "info": PackedStringArray([tr("UI_TRADE_ARMOR_INFO_%d" % __CoeHiNJIGKhomBi8B6NM6SBL) % [int(a["ap"]), int(a["he"]), int(a["bulk"]), int(a["bulge"]), __hDsaZclovbO_hluymTVmd3VC]])})
		"P":
			var __tOVhsSjIcctqrL8rVpXKorGI: PackedInt32Array = __qVHcBoaYiOXDLsbumQQd6jSi.__mgdM7ycmi3DNHzWo0uObSaPX(__YJgAymCaLB78BrFx7OQpn545)
			var __12mLkZ9nOj4bbO96bIYO4Q4L: int = __Se4EsxPBCHX48h1ZS5MexaMl.__Uv7vWKACrD3IoOv6puOgq1PA[__CoeHiNJIGKhomBi8B6NM6SBL]
			__AWd89JpOeHBSeCa5aUQEAQw3 = __tOVhsSjIcctqrL8rVpXKorGI[__Se4EsxPBCHX48h1ZS5MexaMl.__7H3uQhAdVTbh0QLkQVDDP1bw * __CoeHiNJIGKhomBi8B6NM6SBL]
			__vCduKg5sk0RXvyO955gbLBxX = __tOVhsSjIcctqrL8rVpXKorGI[__Se4EsxPBCHX48h1ZS5MexaMl.__7H3uQhAdVTbh0QLkQVDDP1bw * __CoeHiNJIGKhomBi8B6NM6SBL + 1] if __AWd89JpOeHBSeCa5aUQEAQw3 >= 0 else 0
			__Mr7SgxzI1ue3n8m0nusw3iNR = tr("UI_TRADE_UNIT_PLANE")
			title = tr("UI_TRADE_TITLE_AIR") % tr("UI_AIR_TYPE_%d" % __Se4EsxPBCHX48h1ZS5MexaMl.__aisbIKkvoMoqILGpBPpi6cdU(__12mLkZ9nOj4bbO96bIYO4Q4L))
			var __QeV4RJkRmyxBUpLy2lkceq05: PackedInt32Array = __tOVhsSjIcctqrL8rVpXKorGI.duplicate()
			__QeV4RJkRmyxBUpLy2lkceq05[__Se4EsxPBCHX48h1ZS5MexaMl.__7H3uQhAdVTbh0QLkQVDDP1bw * __CoeHiNJIGKhomBi8B6NM6SBL + 1] = 0
			var free: int = __qVHcBoaYiOXDLsbumQQd6jSi.__81YJE8FiyM0jEbqQz7pBjlw6(__KUYPUWAgndjEJnVwOIS_e5D2) - __qVHcBoaYiOXDLsbumQQd6jSi.__9VnVU6sMpQ5nWzxSmhUGSRpD(__QeV4RJkRmyxBUpLy2lkceq05)
			__limxFPWCpXzJNi4hKoZVOmTv = func(r: int) -> int: return maxi(0, free / maxi(1, int(__qVHcBoaYiOXDLsbumQQd6jSi.__gobxGwIVlftvCfJ1fsNzSlj7(r).get("space", 1))))
			for __rak34hAHiw1bXZzz4nPxz4qq: Dictionary in __qVHcBoaYiOXDLsbumQQd6jSi.__c2tygBP_fP7QrsAiMOP39nyd(__KUYPUWAgndjEJnVwOIS_e5D2, __12mLkZ9nOj4bbO96bIYO4Q4L):
				__uSlzLNjFJd9mlCm5w2UgbJYC.append({"row": __rak34hAHiw1bXZzz4nPxz4qq["row"], "name": __rak34hAHiw1bXZzz4nPxz4qq["name"], "cols": PackedStringArray(["—", "Lv%d" % int(__rak34hAHiw1bXZzz4nPxz4qq["lv"]), str(__rak34hAHiw1bXZzz4nPxz4qq["space"]), str(__rak34hAHiw1bXZzz4nPxz4qq["spd"]), str(__rak34hAHiw1bXZzz4nPxz4qq["endu"]), "HP %d" % int(__rak34hAHiw1bXZzz4nPxz4qq["hp"])]), "info": PackedStringArray([tr("UI_TRADE_AIR_INFO") % [int(__rak34hAHiw1bXZzz4nPxz4qq["lv"]), int(__rak34hAHiw1bXZzz4nPxz4qq["space"]), int(__rak34hAHiw1bXZzz4nPxz4qq["spd"]), int(__rak34hAHiw1bXZzz4nPxz4qq["endu"]), maxi(0, free)]])})
		"M":
			var __ztfl1Ep0UZQ_gGReYnwVEf5l: PackedInt32Array = __qVHcBoaYiOXDLsbumQQd6jSi.__mgdM7ycmi3DNHzWo0uObSaPX(__YJgAymCaLB78BrFx7OQpn545)
			var __TezRywQCYdP8VxM3bY3hceiT: int = __Se4EsxPBCHX48h1ZS5MexaMl.__Uv7vWKACrD3IoOv6puOgq1PA[__CoeHiNJIGKhomBi8B6NM6SBL]
			var __0gkpO3h1nknU5nRasWvV7xIv: int = __ztfl1Ep0UZQ_gGReYnwVEf5l[__Se4EsxPBCHX48h1ZS5MexaMl.__7H3uQhAdVTbh0QLkQVDDP1bw * __CoeHiNJIGKhomBi8B6NM6SBL]
			__AWd89JpOeHBSeCa5aUQEAQw3 = __ztfl1Ep0UZQ_gGReYnwVEf5l[__Se4EsxPBCHX48h1ZS5MexaMl.__7H3uQhAdVTbh0QLkQVDDP1bw * __CoeHiNJIGKhomBi8B6NM6SBL + 2]
			__vCduKg5sk0RXvyO955gbLBxX = __ztfl1Ep0UZQ_gGReYnwVEf5l[__Se4EsxPBCHX48h1ZS5MexaMl.__7H3uQhAdVTbh0QLkQVDDP1bw * __CoeHiNJIGKhomBi8B6NM6SBL + 3] if __AWd89JpOeHBSeCa5aUQEAQw3 >= 0 else 0
			__Mr7SgxzI1ue3n8m0nusw3iNR = tr("UI_TRADE_UNIT_ARM")
			title = tr("UI_TRADE_TITLE_AIRARM")
			var __fDXltWBx4CbzBCi3yBe4JMMs: __s8yZigV26lPAvEmbOWzMbnjE = __YJgAymCaLB78BrFx7OQpn545.__12ty6aWt7_v7eYEbKtP71Dlf()
			__fDXltWBx4CbzBCi3yBe4JMMs.__g7JC3EJmfsOWnIyqLGGB93eB = __ztfl1Ep0UZQ_gGReYnwVEf5l.duplicate()
			__fDXltWBx4CbzBCi3yBe4JMMs.__g7JC3EJmfsOWnIyqLGGB93eB[__Se4EsxPBCHX48h1ZS5MexaMl.__7H3uQhAdVTbh0QLkQVDDP1bw * __CoeHiNJIGKhomBi8B6NM6SBL + 3] = 0
			var __0asTEJ4l7wpdWYA1grrX5s4c: int = __qVHcBoaYiOXDLsbumQQd6jSi.__eO4VHYjMVObwrueIqrahxQOQ(__KUYPUWAgndjEJnVwOIS_e5D2) - __qVHcBoaYiOXDLsbumQQd6jSi.__1CdXpyU1UJ8cmNMTd_g2_0od(__fDXltWBx4CbzBCi3yBe4JMMs) - __qVHcBoaYiOXDLsbumQQd6jSi.__rOWGpFmAQiG56ndfSgajANvH(__fDXltWBx4CbzBCi3yBe4JMMs)
			__limxFPWCpXzJNi4hKoZVOmTv = func(r: int) -> int:
				var a: Dictionary = __qVHcBoaYiOXDLsbumQQd6jSi.__J3yVFTJGIFg8UxUlZ9VcpBHF(__TezRywQCYdP8VxM3bY3hceiT, r)
				var __8BAszIIR4YyDZWSxaKhNwmI4: int = int(a.get("size", 0)) * (1 if a.get("table", "") == "Torpedo" else 10)
				if a.get("table", "") != "Torpedo" and int(a.get("kind", 0)) == __Se4EsxPBCHX48h1ZS5MexaMl.__d8xiL_JJ6KRqOmUd2Sqej_FE:
					__8BAszIIR4YyDZWSxaKhNwmI4 = 0
				return __xJ7FHmh8jL_D48rMHMR9dpIN if __8BAszIIR4YyDZWSxaKhNwmI4 <= 0 else mini(__xJ7FHmh8jL_D48rMHMR9dpIN, maxi(0, __0asTEJ4l7wpdWYA1grrX5s4c) / __8BAszIIR4YyDZWSxaKhNwmI4)
			for a: Dictionary in __qVHcBoaYiOXDLsbumQQd6jSi.__4_K_BQA8uki_xNpMaX03GmYp(__0gkpO3h1nknU5nRasWvV7xIv):
				__uSlzLNjFJd9mlCm5w2UgbJYC.append({"row": a["row"], "name": a["name"], "cols": PackedStringArray(["—", "", str(a["size"]), "", "", "HE %d" % int(a["he"])]), "info": PackedStringArray([tr("UI_TRADE_AIRARM_INFO") % [int(a["size"]), int(a["he"]), maxi(0, __0asTEJ4l7wpdWYA1grrX5s4c)]])})
		_:
			var __DyU2eMx5hQsIwKdNyDJiztIv: Array[Dictionary]
			if __HLrYRdiOL6nEfNolC6cf36M2 == "G":
				__AWd89JpOeHBSeCa5aUQEAQw3 = __YJgAymCaLB78BrFx7OQpn545.__dOsDavODOasdfPxqce2DEBC3[__CoeHiNJIGKhomBi8B6NM6SBL]
				__DyU2eMx5hQsIwKdNyDJiztIv = __qVHcBoaYiOXDLsbumQQd6jSi.__iwKc3asT1tigeb34iZxbGM5Z(__KUYPUWAgndjEJnVwOIS_e5D2, __CoeHiNJIGKhomBi8B6NM6SBL)
			else:
				__AWd89JpOeHBSeCa5aUQEAQw3 = __qVHcBoaYiOXDLsbumQQd6jSi.__PJZemYw0whDwrAt4vbBLpQ7w(__YJgAymCaLB78BrFx7OQpn545)[__CoeHiNJIGKhomBi8B6NM6SBL]
				__DyU2eMx5hQsIwKdNyDJiztIv = __qVHcBoaYiOXDLsbumQQd6jSi.__XdCF5mI8376TEoy5NMEQIkHc(__KUYPUWAgndjEJnVwOIS_e5D2, __CoeHiNJIGKhomBi8B6NM6SBL)
			title = tr("UI_TRADE_TITLE_GUN")
			for g: Dictionary in __DyU2eMx5hQsIwKdNyDJiztIv:
				var __Eo6Jd_C2_hTM8NUyqlCfy4Rx: PackedInt32Array = __qVHcBoaYiOXDLsbumQQd6jSi.__H4_XUgXYtfqP1FLYSK71bNbz(int(g["row"]))
				__uSlzLNjFJd9mlCm5w2UgbJYC.append({"row": g["row"], "name": g["cn"], "cols": PackedStringArray(["—", __sadJuUS1UT0UzhHxF1koKG0C(int(g["weight"])), __TYkQtj0KJU3imI91kByy1UpC(int(g["space"]), 10), tr("UI_TRADE_BARRELS") % int(g["barrels"]), __TYkQtj0KJU3imI91kByy1UpC(int(g["caliber"]), 100), tr("UI_TRADE_AA_YES") if not __Eo6Jd_C2_hTM8NUyqlCfy4Rx.is_empty() else "—"]), "good": [5] if not __Eo6Jd_C2_hTM8NUyqlCfy4Rx.is_empty() else [], "info": PackedStringArray([tr("UI_TRADE_GUN_INFO") % [__TYkQtj0KJU3imI91kByy1UpC(int(g["caliber"]), 100), int(g["barrels"]), int(g["reload"]), int(g["req_level"])], __vXTHIVg0n7R9rfqvSmsqgfMc(__Eo6Jd_C2_hTM8NUyqlCfy4Rx)])})
	if __uSlzLNjFJd9mlCm5w2UgbJYC.is_empty():
		UI.__Qyp4Js7J9ejl5FSF4pVpfEi5(tr("UI_TRADE_NONE"))
		return
	__MRgAcPuNvSjtNvNirEW1YRMP = {"kind": __HLrYRdiOL6nEfNolC6cf36M2, "index": __CoeHiNJIGKhomBi8B6NM6SBL}
	__H_kQDAV6SVBhX2avpZXAHYOV()
	var __fTyWdEfMP3BqSAvPqaxh8_Yh: PackedStringArray
	match __HLrYRdiOL6nEfNolC6cf36M2:
		"L":
			__fTyWdEfMP3BqSAvPqaxh8_Yh = __OxdJ_NoNx8kaEiMmhOb1YV2i(["DISP", "WEIGHT", "SPACE", "TUBES", "", ""])
		"F":
			__fTyWdEfMP3BqSAvPqaxh8_Yh = __OxdJ_NoNx8kaEiMmhOb1YV2i(["DISP", "WEIGHT", "SPACE", "TRACK", "HIT", "LINE"])
		"E":
			__fTyWdEfMP3BqSAvPqaxh8_Yh = __OxdJ_NoNx8kaEiMmhOb1YV2i(["DISP", "WEIGHT", "SPACE", "POWER", "OD", "HEAT"])
		"P":
			__fTyWdEfMP3BqSAvPqaxh8_Yh = __OxdJ_NoNx8kaEiMmhOb1YV2i(["DISP", "LEVEL", "SPACE", "SPEED", "ENDU", "HP"])
		"M":
			__fTyWdEfMP3BqSAvPqaxh8_Yh = __OxdJ_NoNx8kaEiMmhOb1YV2i(["DISP", "", "SIZE", "", "", "DMG"])
		"R":
			__fTyWdEfMP3BqSAvPqaxh8_Yh = __OxdJ_NoNx8kaEiMmhOb1YV2i(["DISP", "WEIGHT_IN", "", "AP_IN", "HE_IN", "BULK_IN" if __CoeHiNJIGKhomBi8B6NM6SBL == 2 else ("BULGE_IN" if __CoeHiNJIGKhomBi8B6NM6SBL == 3 else "")])
		_:
			__fTyWdEfMP3BqSAvPqaxh8_Yh = __OxdJ_NoNx8kaEiMmhOb1YV2i(["DISP", "WEIGHT", "SPACE", "BARRELS", "CAL", "AA"])
	__iDtSeet9d1hrG4U2QlY48W6q(__HLrYRdiOL6nEfNolC6cf36M2, __CoeHiNJIGKhomBi8B6NM6SBL, __uSlzLNjFJd9mlCm5w2UgbJYC, __vCduKg5sk0RXvyO955gbLBxX)
	for __wglQcQ7qvGpou7itkMZ2lQU7: Dictionary in __uSlzLNjFJd9mlCm5w2UgbJYC:
		__wglQcQ7qvGpou7itkMZ2lQU7["pic"] = __QDHCoKV3RWbBR7wXgexsZgHS(__HLrYRdiOL6nEfNolC6cf36M2, int(__wglQcQ7qvGpou7itkMZ2lQU7["row"]))
	__M3mMe5n3JrbgRvzvIt9w1QZt.__799M3JC0EaDgzpGgsujWtZDg(title, __uSlzLNjFJd9mlCm5w2UgbJYC, __AWd89JpOeHBSeCa5aUQEAQw3, __vCduKg5sk0RXvyO955gbLBxX, __Mr7SgxzI1ue3n8m0nusw3iNR, __limxFPWCpXzJNi4hKoZVOmTv, __fTyWdEfMP3BqSAvPqaxh8_Yh, __HLrYRdiOL6nEfNolC6cf36M2 in ["G", "S", "L", "F", "E"])
	if __HLrYRdiOL6nEfNolC6cf36M2 in __nDMzIIBfjfebkTT_IF92ffWF:
		var __ePIHPYx9DpJQ3v8YXm_JejX5: int = __NOGqr86hxqhZaYA6HjbWlY2N(__HLrYRdiOL6nEfNolC6cf36M2)
		var __maW1CfyWLEhp7X80NjrZf1C6: String = tr("UI_MARKET_BULK_MAIN" if __HLrYRdiOL6nEfNolC6cf36M2 == "G" else ("UI_MARKET_BULK_SIDE" if __HLrYRdiOL6nEfNolC6cf36M2 == "S" else "UI_MARKET_BULK_TORP"))
		__M3mMe5n3JrbgRvzvIt9w1QZt.__5x9DaBJhmToi9o_kaheLa6ti(tr("UI_MARKET_BULK_INFO") % [__ePIHPYx9DpJQ3v8YXm_JejX5, __maW1CfyWLEhp7X80NjrZf1C6], __ePIHPYx9DpJQ3v8YXm_JejX5 > 1)
	if __HLrYRdiOL6nEfNolC6cf36M2 == "G":
		var meti_count = meti_main_market_count()
		__M3mMe5n3JrbgRvzvIt9w1QZt.__5x9DaBJhmToi9o_kaheLa6ti("此區為%s，共 %d 個砲位" % ["副砲" if meti_main_market_role() == 1 else "主砲", meti_count], meti_count > 1)
	__M3mMe5n3JrbgRvzvIt9w1QZt.__3_xTsqGV9VjGQi22Qmd30tCZ = App.__M0ImV248NGNrBFXy9NCs5jwX().__ktyxvkLP8cTjwSfnZb3DAVcL
var __aBhCjT5h4HuVdMnKzKKIXLBp: String = "harbor"
func __ZFd4wePpEaVpfpGejOdwVKGR(y: String) -> void :
	if y == __DO5AS1j65TYeEwkGONIhQmLt:
		return
	__DO5AS1j65TYeEwkGONIhQmLt = y
	if __f3ySEJHZJ46_L34koIBeTfDe != null:
		__jKRAoSDLaIkEgmrqlSCQwgKI()
	__g6q9T1VmtoQE6bUvlCkH1PIZ(__aBhCjT5h4HuVdMnKzKKIXLBp)
const __nsQ7Pi0IYX9fc_6FN8VSm057: PackedInt32Array = [24, 25, 25, 23]
func __NOGqr86hxqhZaYA6HjbWlY2N(__QElhD835SgdpRFf9evCCTheE: String) -> int:
	var __KZyItLghI6sROXYTkTVOH5cU: __Se4EsxPBCHX48h1ZS5MexaMl = App.__PtNURh2PaYHMgsPlkLtni90Y()
	match __QElhD835SgdpRFf9evCCTheE:
		"G":
			return __YJgAymCaLB78BrFx7OQpn545.__dOsDavODOasdfPxqce2DEBC3.size()
		"S":
			return __KZyItLghI6sROXYTkTVOH5cU.__4mBhSAAMIt6DTsibdV0pC19W(__YJgAymCaLB78BrFx7OQpn545.__WeB9Hi0OxaFBUuwm2WU2qKEH).size()
		"L":
			return __KZyItLghI6sROXYTkTVOH5cU.__Hmr_a2CPvjknmgXnhmVu1vm9(__YJgAymCaLB78BrFx7OQpn545.__WeB9Hi0OxaFBUuwm2WU2qKEH).size()
	return 0
const __6XwTq56FAcq6zR97wsH9ZuXC: = 1.5
func __6pxkC4sNZa9WOALnv6p7pHFW() -> void :
	if __5rz7a76K5lyi3GlEigYE8q9G == null:
		return
	var __RRlmvzCEeZaLaP2pkQHB_u69: String = __FWw1MFcV48pcQszFug10_Wsq()
	__5rz7a76K5lyi3GlEigYE8q9G.disabled = __RRlmvzCEeZaLaP2pkQHB_u69 != ""
	__5rz7a76K5lyi3GlEigYE8q9G.tooltip_text = tr(__RRlmvzCEeZaLaP2pkQHB_u69) if __RRlmvzCEeZaLaP2pkQHB_u69 != "" else tr("UI_DOCK_LAUNCH")
	__zpodpOyA68LGBNJ48lap636B()
static func __NozPJAWtJodHtGY29mgmovub(rings: Array[Dictionary]) -> void :
	var root: Array[int] = []
	for __uecBY2HzxcHh5urlY2XAnlRp: int in rings.size():
		root.append(__uecBY2HzxcHh5urlY2XAnlRp)
	for __aaGtmEE920KMT38H43v6D4h8: int in rings.size() + 1:
		if not __A_t_k_qymKqzJY0izZpx5dx0(rings, root):
			break
	__awtgICygsB4J5VNPf86ioBCU(rings)
func __l9zi1_s2iBhZKQMLIuAIh7zA(__pQLUwxtDMFPx0MogZYxkaYdh: Dictionary) -> void :
	__iAbDeha6hgeEpDzp_OVLHMcN = __pQLUwxtDMFPx0MogZYxkaYdh
	__kinsDyUwBqfk_kcYtvIhl2eK = bool(__pQLUwxtDMFPx0MogZYxkaYdh.get("hub", false))
	__YJgAymCaLB78BrFx7OQpn545 = __U7UMfwBewiXSLEeaDnywaCO7.__V0erSRNWoPFGOr7bG6vGIpsK() if __kinsDyUwBqfk_kcYtvIhl2eK else __pQLUwxtDMFPx0MogZYxkaYdh.get("cfg")
	if __kinsDyUwBqfk_kcYtvIhl2eK:
		__cG_zbW1sotj7reUf4u7FXswZ = __U7UMfwBewiXSLEeaDnywaCO7.__OZL6Hf4GmrJ1L_snne2bmDE7()
		__YahxYYsCSePibWCVlCnGhFI_()
	%Night.toggled.connect( func(__RfCmOZR8PKzKQf4K5bAIf8Ds: bool) -> void :
		__g59CpE8YrzQ3c1AnhI3CYror = __RfCmOZR8PKzKQf4K5bAIf8Ds
		__LcEmKczmLrorVyOBaMDnHamK["night"] = __RfCmOZR8PKzKQf4K5bAIf8Ds
		_redraw())
	__CgtEZnFtJYvrLjlSjFnhNN9n = __tgldA7aC7YucWAFFe4bVx4oW.new()
	__CgtEZnFtJYvrLjlSjFnhNN9n.__aAn7HdDfa3n33OJef68IF8BW = false
	__CgtEZnFtJYvrLjlSjFnhNN9n.fit_margin = 1.0
	__CgtEZnFtJYvrLjlSjFnhNN9n.__d0IHJyvtuIdphI0Mfe6hZoCj = true
	( %ViewHost as Control).add_child(__CgtEZnFtJYvrLjlSjFnhNN9n)
	var __eSCkvdJl0IVr_IPxXcpiWudO: Control = %Overlay
	__bLKLb0Khmx9u_g9HRmoM6tG6 = __swIzeI0OCYp_Difwb9TQEYIt.new().setup(__swIzeI0OCYp_Difwb9TQEYIt.LEFT, __iAAZg_L1CIMXb2xD1_GMfROh, tr("UI_SPEC_TITLE"))
	__eSCkvdJl0IVr_IPxXcpiWudO.add_child(__bLKLb0Khmx9u_g9HRmoM6tG6)
	__h1tDxlSlZLzRDqez_H4rCrnn = __21NGacAISHpzjaKmV3CZK2Y6.new()
	__bLKLb0Khmx9u_g9HRmoM6tG6.__rrzdHgEyW9EL6dlyflQET5AV.add_child(__h1tDxlSlZLzRDqez_H4rCrnn)
	__h1tDxlSlZLzRDqez_H4rCrnn.__GM7CSPJaQDtDRbDnD39g1A8y.connect(__b3OT_DqwX0nLXYx0rgF1n9tz)
	__bLKLb0Khmx9u_g9HRmoM6tG6.toggled.connect( func(__6NAEHopOwWsJ_IIvdCH35f7l: bool) -> void :
		__zpodpOyA68LGBNJ48lap636B()
		__Ua_bI8NjP7cgYQVgxQBQi5FZ())
	var __nYEtAwmescOt59w1K_Lqy1i4: bool = __ZRS6lZJh1TuB38TS82wWLE09.enabled() and bool(Settings.get_value("sandbox_free_ships", false))
	if __kinsDyUwBqfk_kcYtvIhl2eK:
		%Pick.visible = __ZRS6lZJh1TuB38TS82wWLE09.__l3Wmkh46ZiXosiT69u4RlYls()
		%Pick.pressed.connect( func() -> void : UI.__EdWX1D1SE7QOmjDer1HHnYqo("ship_select", {"cfg": __YJgAymCaLB78BrFx7OQpn545, "offline": true}))
		%Back.text = "UI_QUIT"
		%Back.pressed.connect(__WOYaQyPSpqITLw4waP2ZLJFW)
		__vB6Uge3peTq8e97V0wYhk4lc = OptionButton.new()
		__vB6Uge3peTq8e97V0wYhk4lc.tooltip_text = tr("UI_HARBOR_LIST_TIP")
		__vB6Uge3peTq8e97V0wYhk4lc.focus_mode = Control.FOCUS_NONE
		__vB6Uge3peTq8e97V0wYhk4lc.item_selected.connect( func(__Nej3wtpzbG7fZoXwf6Nv3ueB: int) -> void : __4zShpYdxjssLWetcx0uNyHo_(__vB6Uge3peTq8e97V0wYhk4lc.get_item_id(__Nej3wtpzbG7fZoXwf6Nv3ueB)))
		( %TitleBox as Control).get_parent().add_child(__vB6Uge3peTq8e97V0wYhk4lc)
		( %TitleBox as Control).get_parent().move_child(__vB6Uge3peTq8e97V0wYhk4lc, ( %TitleBox as Control).get_index())
		__pndlxY_XCFFxBsvt9SrAMHXa = __swIzeI0OCYp_Difwb9TQEYIt.new().setup(__swIzeI0OCYp_Difwb9TQEYIt.RIGHT, __BIy11OarK8HlRREtRkZDAiNC, tr("UI_CREW_LIST_TITLE"))
		__eSCkvdJl0IVr_IPxXcpiWudO.add_child(__pndlxY_XCFFxBsvt9SrAMHXa)
		__pndlxY_XCFFxBsvt9SrAMHXa.toggled.connect( func(__BkHBxnju1EIHF5dQKYaXXPEO: bool) -> void : __Ua_bI8NjP7cgYQVgxQBQi5FZ())
		__Lnl7EUrWdzkuBnGqxTLllE5o = __JeprpcXyhqKlLNlwsQnYyWht.new()
		__Lnl7EUrWdzkuBnGqxTLllE5o.__pH46jJOp5V4hZ_ceBZP34pRy = __nYEtAwmescOt59w1K_Lqy1i4 and __ZRS6lZJh1TuB38TS82wWLE09.__l3Wmkh46ZiXosiT69u4RlYls()
		__eSCkvdJl0IVr_IPxXcpiWudO.add_child(__Lnl7EUrWdzkuBnGqxTLllE5o)
		__Lnl7EUrWdzkuBnGqxTLllE5o.__ayTeMD_HiBZsCY6K3dOSet2J.connect(__mqUFHwVuIEsH6CwazHRCsl7H)
		__Lnl7EUrWdzkuBnGqxTLllE5o.__Fbxdn1GVnU2S9jM23brkfMG7.connect(__ASK04gSWYtQFGQHJvx71Pi6v)
		__Lnl7EUrWdzkuBnGqxTLllE5o.__LyXvk9qsZSRs7CXgPW0DQkCP.connect(__N3KC95eWLPI7sAwuPnTXAPlz)
		__Lnl7EUrWdzkuBnGqxTLllE5o.__am8HCbmuS7JrU_CsbqAh4IW4.connect( func() -> void : UI.__EdWX1D1SE7QOmjDer1HHnYqo("ship_select", {"cfg": __YJgAymCaLB78BrFx7OQpn545, "offline": true}))
		__hDON5_Ak_v4LQsqfesSFUaa2 = __tALbI77Bj72RNkUjx1rJalbI.new()
		__eSCkvdJl0IVr_IPxXcpiWudO.add_child(__hDON5_Ak_v4LQsqfesSFUaa2)
		__hDON5_Ak_v4LQsqfesSFUaa2.__hjwdkOcfz3xI6m0cgps8MGo7.connect( func(__HvCKpjW72Gc6vRuhVtl2oKtY: Rect2) -> void : __Ua_bI8NjP7cgYQVgxQBQi5FZ.call_deferred())
		__eSCkvdJl0IVr_IPxXcpiWudO.resized.connect(__Ua_bI8NjP7cgYQVgxQBQi5FZ)
		__zABAFBwuGIufBHjRN9OzcNUm = __feayI5y05J3ON9FtctrJOCuc.new()
		__zABAFBwuGIufBHjRN9OzcNUm.__m2droanQa_cnhkVUiY4O4rtJ = __pndlxY_XCFFxBsvt9SrAMHXa.frame
		__zABAFBwuGIufBHjRN9OzcNUm.__uVHnM5LYJpwosw8V6yXdiPaJ = __eSCkvdJl0IVr_IPxXcpiWudO
		__zABAFBwuGIufBHjRN9OzcNUm.__h921njZsIgv8S2inn4WHx0zV = __9rpuzul8VrZczCjSFS7iCrOA
		__CgtEZnFtJYvrLjlSjFnhNN9n.add_child(__zABAFBwuGIufBHjRN9OzcNUm)
		__zABAFBwuGIufBHjRN9OzcNUm.setup(App.__M0ImV248NGNrBFXy9NCs5jwX())
		__g4VcMyfHpzn9RPSMtrItVE0s = __PRH8kkL2nSrpnpKj0kGyYFZt.new().setup(__zABAFBwuGIufBHjRN9OzcNUm)
		__pndlxY_XCFFxBsvt9SrAMHXa.__rrzdHgEyW9EL6dlyflQET5AV.add_child(__g4VcMyfHpzn9RPSMtrItVE0s)
		__zABAFBwuGIufBHjRN9OzcNUm.changed.connect( func() -> void :
			__6pxkC4sNZa9WOALnv6p7pHFW()
			__4VH5P1TCUJzfLL55i2_8NhQh()
			__l6GSBpoEn3a9XcT2fQAVy101()
			if not __DpM0JQWB6EqgMh3WJZSlHODu:
				__h1tDxlSlZLzRDqez_H4rCrnn.__Zs_NRND2aIHjT0QBiS5yVaRm(__YJgAymCaLB78BrFx7OQpn545, App.__M0ImV248NGNrBFXy9NCs5jwX()))
		__zABAFBwuGIufBHjRN9OzcNUm.__iB2UqUil5MwE5LrbAKsm0pxr.connect(__I25PS__nxrcT5ue1XHwV6CDj)
		__CgtEZnFtJYvrLjlSjFnhNN9n.resized.connect(__0enFPGinCOJKsiE7r2nLxhFA)
		__QGam_vw7iuxNHReFko2qucjH = __wjUQUfgQzSj2YNHkTbwcrJ9W.new()
		__CgtEZnFtJYvrLjlSjFnhNN9n.add_child(__QGam_vw7iuxNHReFko2qucjH)
		__QGam_vw7iuxNHReFko2qucjH.action.connect(__t1LFd_voc1X6LWRklLXhZb2U)
		__ezxmIHAAQKmXttLHPr9Bj08Z = __tG5b3HQggmn2rI2gIpXHDl4h("UI_SHIPYARDMODE_SHIP_TAB", "UI_SHIPYARDMODE_SHIP", "ship")
		__aZ9T7TmaIvmS1Lo85UiNhrn8 = __tG5b3HQggmn2rI2gIpXHDl4h("UI_SHIPYARDMODE_FORCE_TAB", "UI_SHIPYARDMODE_FORCE", "crew")
		__5rz7a76K5lyi3GlEigYE8q9G = __pT6jZw1fUvWomUDaJvLtM_kC.new().setup("Factory", __v9yDxVoBQ0rAqgaVqQaDJHaD)
		__5rz7a76K5lyi3GlEigYE8q9G.tooltip_text = tr("UI_DOCK_LAUNCH")
		__5rz7a76K5lyi3GlEigYE8q9G.pressed.connect(__gvVRFH6rUAOaLPJCVQsHcX2I)
		__CgtEZnFtJYvrLjlSjFnhNN9n.add_child(__5rz7a76K5lyi3GlEigYE8q9G)
		__AtE8nbDg8f4kT_S17xNL7a5N = __KBvSyqb0E64cDffp38Jzgf0n(__nsQ7Pi0IYX9fc_6FN8VSm057, "UI_DOCK_NEXT_SHIP", 1)
		__bqpvtk4llmiFJQmT5SzgWELV = __KBvSyqb0E64cDffp38Jzgf0n(__ZoLgIGfy8poU0XzpD9xZ3YZa, "UI_DOCK_PREV_SHIP", -1)
		__CgtEZnFtJYvrLjlSjFnhNN9n.resized.connect(__zpodpOyA68LGBNJ48lap636B)
		__Qy2_Yg19jJ_onLveAVf4WaQq(__eSCkvdJl0IVr_IPxXcpiWudO)
	else:
		%Pick.visible = false
		%Back.pressed.connect(UI.pop)
	__ORPVAwaEZaG_WUKCzYPqV3CM = __jnStooA8TeJLu1KviYiYtn7w(false)
	__dAGqnexg_IDbNw344d0sOBgZ = __jnStooA8TeJLu1KviYiYtn7w(true)
	if __kinsDyUwBqfk_kcYtvIhl2eK:
		__WthKfcvjK4RJwtX6snlMJlVa = __cqDq9BUy3jf_ObmeDukYBAN_.new()
		__CgtEZnFtJYvrLjlSjFnhNN9n.canvas.add_child(__WthKfcvjK4RJwtX6snlMJlVa)
		__WthKfcvjK4RJwtX6snlMJlVa.__AkmL5A2y6QWJqqkZ_vHhBlrE.connect( func() -> void : __g6q9T1VmtoQE6bUvlCkH1PIZ("shipyard"))
		__WthKfcvjK4RJwtX6snlMJlVa.__MdN0NIbf2sqsnGKxMEV8uA7f.connect( func() -> void : __g6q9T1VmtoQE6bUvlCkH1PIZ("harbor"))
		__WthKfcvjK4RJwtX6snlMJlVa.__SpR9K_fNPhZW8oQ7H4t8In6s.connect(__gvVRFH6rUAOaLPJCVQsHcX2I)
		__WthKfcvjK4RJwtX6snlMJlVa.__HUA0xu3vfrorgSlOiHyPc3k0.connect(App.__XA31hlcqDbRgIKg3l91mYJVw)
		__WthKfcvjK4RJwtX6snlMJlVa.set_text(__ejjrmWDPOiCDSSON_WTtAS7w())
		__4VH5P1TCUJzfLL55i2_8NhQh()
		__WthKfcvjK4RJwtX6snlMJlVa.__4lDqDGWbt7kuLeJA32SrS_z6(tr("UI_HARBOR_WELCOME") % __ejjrmWDPOiCDSSON_WTtAS7w())
	_load()
	if __kinsDyUwBqfk_kcYtvIhl2eK:
		__CZNkeeRfo0Z9Wuy80hOWdhXF(true)
		__wUr1p8hncnmDRLuW_MzmS99v.call_deferred()
		__g6q9T1VmtoQE6bUvlCkH1PIZ(str(__pQLUwxtDMFPx0MogZYxkaYdh.get("mode", "shipyard")))
		if __pQLUwxtDMFPx0MogZYxkaYdh.get("auto_create", false) or __pQLUwxtDMFPx0MogZYxkaYdh.get("auto_join", false) or __pQLUwxtDMFPx0MogZYxkaYdh.get("stay", false):
			__gvVRFH6rUAOaLPJCVQsHcX2I.call_deferred()
	if __pQLUwxtDMFPx0MogZYxkaYdh.get("opening", false):
		__btLunkU7FIRTm7JraVNus_7M.call_deferred()
func _load() -> void :
	if __DpM0JQWB6EqgMh3WJZSlHODu:
		%Title.text = tr("UI_DOCK_EMPTY")
		%Sub.visible = false
		__LcEmKczmLrorVyOBaMDnHamK = {"hull_a": null, "hull_b": null, "foam": null, "turrets": [], "turrets_far": [], "night": __g59CpE8YrzQ3c1AnhI3CYror, "nation": __6qODxp1VoZzlarYbuG6CVBNH()}
		var __bnQBCxqDgJwOSfxv7k4A6986: = __s8yZigV26lPAvEmbOWzMbnjE.new()
		__bnQBCxqDgJwOSfxv7k4A6986.__WeB9Hi0OxaFBUuwm2WU2qKEH = -1
		__h1tDxlSlZLzRDqez_H4rCrnn.__Zs_NRND2aIHjT0QBiS5yVaRm(__bnQBCxqDgJwOSfxv7k4A6986, null)
		__4pls2eyn7uV4ST2IGlXwuh6D()
	else:
		var __M4E1yamPggQYwJuCG7UhMeB8: Dictionary = App.__PtNURh2PaYHMgsPlkLtni90Y().__ofKSCLcCg7jWtqacDa153ehk(__YJgAymCaLB78BrFx7OQpn545.__WeB9Hi0OxaFBUuwm2WU2qKEH)
		%Title.text = App.__jDDjlLaS8SZXYc9osASNUrjv(__YJgAymCaLB78BrFx7OQpn545.__WeB9Hi0OxaFBUuwm2WU2qKEH)
		%Sub.text = __IAgjxk14dGPi74dqdcixCBZr(__M4E1yamPggQYwJuCG7UhMeB8)
		%Sub.visible = true
		_build(__M4E1yamPggQYwJuCG7UhMeB8)
		__h1tDxlSlZLzRDqez_H4rCrnn.__Zs_NRND2aIHjT0QBiS5yVaRm(__YJgAymCaLB78BrFx7OQpn545, App.__M0ImV248NGNrBFXy9NCs5jwX() if __kinsDyUwBqfk_kcYtvIhl2eK else null)
		if __QGam_vw7iuxNHReFko2qucjH != null:
			__QGam_vw7iuxNHReFko2qucjH.__77qZWaYOFrDj_8VpQsKxXSgK(__nH_Ui7JFNxgWXW_3iO9RuiFB())
		if __OLIvZVUTptJkSyJvw3VfbpFx != null and __f3ySEJHZJ46_L34koIBeTfDe.visible:
			__OLIvZVUTptJkSyJvw3VfbpFx.__Zs_NRND2aIHjT0QBiS5yVaRm(__YJgAymCaLB78BrFx7OQpn545)
	__l6GSBpoEn3a9XcT2fQAVy101()
	if __g4VcMyfHpzn9RPSMtrItVE0s != null:
		__g4VcMyfHpzn9RPSMtrItVE0s.__S12dAUkxTCGFYVkGzQ3W7K4g(__cG_zbW1sotj7reUf4u7FXswZ)
	if __f3ySEJHZJ46_L34koIBeTfDe != null:
		(__f3ySEJHZJ46_L34koIBeTfDe.get_meta("button") as Button).disabled = __DpM0JQWB6EqgMh3WJZSlHODu
	if __Lnl7EUrWdzkuBnGqxTLllE5o != null:
		__Lnl7EUrWdzkuBnGqxTLllE5o.__7UOhveRCaTsoEDa0ApcoO9Hc(__VkSeEGhVF0y6mvRsZYDTVhBy(), -1 if __DpM0JQWB6EqgMh3WJZSlHODu else __YJgAymCaLB78BrFx7OQpn545.__WeB9Hi0OxaFBUuwm2WU2qKEH)
		__Ua_bI8NjP7cgYQVgxQBQi5FZ.call_deferred()
	__CgtEZnFtJYvrLjlSjFnhNN9n.__TEOGpgkHmUUvlEe4nHnrWj6s = Rect2(Vector2.ZERO, __8ey3YOIS4Ufd_FwL8Ineryu9)
	__6pxkC4sNZa9WOALnv6p7pHFW()
	__UEBR9tHfREmwSw_VDgBW83Zc()
	__0enFPGinCOJKsiE7r2nLxhFA()
	_redraw()
func __0enFPGinCOJKsiE7r2nLxhFA() -> void :
	if __zABAFBwuGIufBHjRN9OzcNUm != null:
		var s: float = __CgtEZnFtJYvrLjlSjFnhNN9n.__GoH11sKPryvfRgY_yZp5fB4l()
		__zABAFBwuGIufBHjRN9OzcNUm.scale = Vector2(s, s)
		__zABAFBwuGIufBHjRN9OzcNUm.position = __CgtEZnFtJYvrLjlSjFnhNN9n.canvas.position + Vector2(__XwGmCs7gUex6WMx0F0Lapr6y.__sfj5QkTNl1KRF7NVZ8qmqdhO()) * s
		__zABAFBwuGIufBHjRN9OzcNUm.__08lUaVXHUgHst0KmvRmsCf5_()
	if __QGam_vw7iuxNHReFko2qucjH != null:
		var __E9OYoJgBKsXDZfHDlMUnCVf8: float = __CgtEZnFtJYvrLjlSjFnhNN9n.__GoH11sKPryvfRgY_yZp5fB4l()
		__QGam_vw7iuxNHReFko2qucjH.scale = Vector2(__E9OYoJgBKsXDZfHDlMUnCVf8, __E9OYoJgBKsXDZfHDlMUnCVf8)
		__QGam_vw7iuxNHReFko2qucjH.position = __CgtEZnFtJYvrLjlSjFnhNN9n.canvas.position + Vector2(__XwGmCs7gUex6WMx0F0Lapr6y.__sfj5QkTNl1KRF7NVZ8qmqdhO()) * __E9OYoJgBKsXDZfHDlMUnCVf8
		__QGam_vw7iuxNHReFko2qucjH.queue_redraw()
var __ZCxIMxSxCw6Qw0WQFirwHFdX: int = 0
func __spW6n6CC7iypuAD7crNfuCbF(__TuCqa1cDxIbSfWQbyH40OtG7: int) -> bool:
	if __U7UMfwBewiXSLEeaDnywaCO7.__nLbzJ3Nmhv4Cd4ilUMt2baQU(__TuCqa1cDxIbSfWQbyH40OtG7):
		UI.__FZyGB2TVbKGb1g8kgT4bm_x4(tr("UI_BUY_ERR_SAME_CLASS"))
		return false
	var __LWXN2e03RxkMQkM4puKBT6P5: __s8yZigV26lPAvEmbOWzMbnjE = App.__PtNURh2PaYHMgsPlkLtni90Y().__vTRMq3igRP2hTt2npyhiJ5UU(__TuCqa1cDxIbSfWQbyH40OtG7)
	var __eFsjrrcVuiLb2Jpt7yaq5o1M: int = App.__PtNURh2PaYHMgsPlkLtni90Y().__BGxXnVzPsmPLUaUtEL38SXTm(__LWXN2e03RxkMQkM4puKBT6P5)
	if __eFsjrrcVuiLb2Jpt7yaq5o1M != __Se4EsxPBCHX48h1ZS5MexaMl.__5CDMR1_ZY_Be5hesPdyczkNt.OK:
		UI.__FZyGB2TVbKGb1g8kgT4bm_x4(tr("UI_SS_ERR_%d" % __eFsjrrcVuiLb2Jpt7yaq5o1M))
		return false
	var __ZvthneHrTZ8NXk0BJvluQplD: int = __9MFWgnc8oYQpY6kqM0OFfhrH.__246QPi6By6rwimnh3Q59pbcA(__TuCqa1cDxIbSfWQbyH40OtG7)
	var __Y_2ETSk27sdvhtyA6aKFyIyg: String = App.__M0ImV248NGNrBFXy9NCs5jwX().__CwpKXs02n6e7mZnAMz9VvPw1(__ZvthneHrTZ8NXk0BJvluQplD, 0, __Bsl33jE0VgUtGf0ZDYkuZAkg.__dA5oug57cA2Y8McJNk8ERx32, __TuCqa1cDxIbSfWQbyH40OtG7)
	if __Y_2ETSk27sdvhtyA6aKFyIyg != "":
		UI.__FZyGB2TVbKGb1g8kgT4bm_x4(tr(__Y_2ETSk27sdvhtyA6aKFyIyg))
		return false
	__U7UMfwBewiXSLEeaDnywaCO7.__riw4yt6FVhwXZCOSVbmq_eV7(__LWXN2e03RxkMQkM4puKBT6P5)
	UI.__Qyp4Js7J9ejl5FSF4pVpfEi5(tr("UI_BUY_SHIP_DONE") % [App.__A6XI74bFN3243pFbSLAzzTVt(__TuCqa1cDxIbSfWQbyH40OtG7), __9MFWgnc8oYQpY6kqM0OFfhrH.__57yYqv9212r7qj7iu02kGdA8(__ZvthneHrTZ8NXk0BJvluQplD)])
	__4VH5P1TCUJzfLL55i2_8NhQh()
	__mqUFHwVuIEsH6CwazHRCsl7H(__LWXN2e03RxkMQkM4puKBT6P5)
	return true
const __8ey3YOIS4Ufd_FwL8Ineryu9: = Vector2(1024, 768)
const __VUbN2QpEwLpgQ0qZYkOnqtug: = __lAo0PsogaUvqHw4muTzPsHiR.__qYP_YAvOQ8TvQJjfN6xGqOuz / 1000.0
var __YJgAymCaLB78BrFx7OQpn545: __s8yZigV26lPAvEmbOWzMbnjE
var __dLFfKMSP4H8zZsNWU4JoHUfw: AudioStreamPlayer
const __PsVlZoS1bDNQtGQflwNZKZfH: = 24.0
func __ASK04gSWYtQFGQHJvx71Pi6v(__txcf07I4uZnb5WHatSPX6f0A: int) -> void :
	var __KFmXum8kQYXZXKLB_m_WKlUp: int = __9MFWgnc8oYQpY6kqM0OFfhrH.__DLuGo_AskcTmCYm7rcomZnIt(__txcf07I4uZnb5WHatSPX6f0A)
	var __7LB9MicB726JI1xaGpxmhmFG: int = await UI.__Dzq5SbxUBHUUe7FLUyy2rI_S(tr("UI_HANGAR_SELL"), tr("UI_HANGAR_SELL_ASK") % [App.__A6XI74bFN3243pFbSLAzzTVt(__txcf07I4uZnb5WHatSPX6f0A), __9MFWgnc8oYQpY6kqM0OFfhrH.__57yYqv9212r7qj7iu02kGdA8(__KFmXum8kQYXZXKLB_m_WKlUp)], [tr("UI_OK"), tr("UI_CANCEL")])
	if __7LB9MicB726JI1xaGpxmhmFG != 0:
		return
	var __YnmpWds7u1tlgGVIzdEs5iEg: int = __U7UMfwBewiXSLEeaDnywaCO7.__7GUZ3bU5qeMGglBHenrrrt1p().size()
	__U7UMfwBewiXSLEeaDnywaCO7.__ac0Y6FSbwoe8bGzazli1OY4Z(__txcf07I4uZnb5WHatSPX6f0A)
	if __U7UMfwBewiXSLEeaDnywaCO7.__7GUZ3bU5qeMGglBHenrrrt1p().size() < __YnmpWds7u1tlgGVIzdEs5iEg:
		App.__M0ImV248NGNrBFXy9NCs5jwX().__Iglm6KYHkU_C_pzeHfOvxeYS(__txcf07I4uZnb5WHatSPX6f0A)
		App.__M0ImV248NGNrBFXy9NCs5jwX().__hN4a7punGT3ktCMQCiR5zjz7(__KFmXum8kQYXZXKLB_m_WKlUp, 0, __Bsl33jE0VgUtGf0ZDYkuZAkg.__3IxiYgOF74g2qW6il82D8V5P, __txcf07I4uZnb5WHatSPX6f0A)
		UI.__Qyp4Js7J9ejl5FSF4pVpfEi5(tr("UI_SELL_DONE") % [App.__A6XI74bFN3243pFbSLAzzTVt(__txcf07I4uZnb5WHatSPX6f0A), __9MFWgnc8oYQpY6kqM0OFfhrH.__57yYqv9212r7qj7iu02kGdA8(__KFmXum8kQYXZXKLB_m_WKlUp)])
		__4VH5P1TCUJzfLL55i2_8NhQh()
		if __zABAFBwuGIufBHjRN9OzcNUm != null:
			__zABAFBwuGIufBHjRN9OzcNUm.__Qa9GbnhM8GDjcw4fKszR0Ftz()
	var __hh24pHZmh25Dbf6gLlcmw887: Array[__s8yZigV26lPAvEmbOWzMbnjE] = __VkSeEGhVF0y6mvRsZYDTVhBy()
	if __DpM0JQWB6EqgMh3WJZSlHODu or __txcf07I4uZnb5WHatSPX6f0A != __YJgAymCaLB78BrFx7OQpn545.__WeB9Hi0OxaFBUuwm2WU2qKEH:
		__Lnl7EUrWdzkuBnGqxTLllE5o.__7UOhveRCaTsoEDa0ApcoO9Hc(__hh24pHZmh25Dbf6gLlcmw887, -1 if __DpM0JQWB6EqgMh3WJZSlHODu else __YJgAymCaLB78BrFx7OQpn545.__WeB9Hi0OxaFBUuwm2WU2qKEH)
		__UEBR9tHfREmwSw_VDgBW83Zc()
	elif __hh24pHZmh25Dbf6gLlcmw887.is_empty():
		__DpM0JQWB6EqgMh3WJZSlHODu = true
		_load()
		__g6q9T1VmtoQE6bUvlCkH1PIZ(__aBhCjT5h4HuVdMnKzKKIXLBp)
	else:
		__XviRMKHdbGnEMaTN0kgBw5GT(__hh24pHZmh25Dbf6gLlcmw887[0])
const __mOIKXCImd8wL9QEMRay3qaCq: = 6
func _build(__BBjwSoNyISAMnDCBVespw4iN: Dictionary) -> void :
	var __S_7IyzWSdWQ_KiEnQbvvdj2D: Array[Array] = []
	var __rA1CDXXtjFGqQuX3h7GhLNuC: Array[Array] = []
	var __QIuPeUkCZkXIHDBiGFMvDZqE: __bzxMmNAcE_RKMny5gklgDglw = App.___qFCN2viGM2bPW1uGV9qys9h()
	var __L7GZjoO1MWe0tYBNaXnbkLnG: String = "ShipStructureF%03d" % int(__BBjwSoNyISAMnDCBVespw4iN.get("f_pack", 0))
	var __cjmjw_jNHbxV2y3zA4K9Y_MM: __H2jKfddttLiR1Mfv697VtMqG = null
	var __d6_ziLVhDLGYHun8Uac6jQ2R: int = int(App.__PtNURh2PaYHMgsPlkLtni90Y().__vwSAcybbCInOpnt2FbN4qz7L(__YJgAymCaLB78BrFx7OQpn545.__vwSAcybbCInOpnt2FbN4qz7L).get("art", -1))
	if __YJgAymCaLB78BrFx7OQpn545.__vwSAcybbCInOpnt2FbN4qz7L >= 0 and __d6_ziLVhDLGYHun8Uac6jQ2R >= 0 and Assets.__QiUGArjHDhwcrWbH3BB0K8c5("ComponentsFCS", __d6_ziLVhDLGYHun8Uac6jQ2R):
		__cjmjw_jNHbxV2y3zA4K9Y_MM = Assets.__MUCguPydNQwl8ZRXUX2ciJ44("ComponentsFCS", __d6_ziLVhDLGYHun8Uac6jQ2R)
	var __fiP3BAwTotZMUqJWPCJLN0_t: Dictionary = {"hull_a": Assets.__MUCguPydNQwl8ZRXUX2ciJ44(__L7GZjoO1MWe0tYBNaXnbkLnG, 0) if Assets.__QiUGArjHDhwcrWbH3BB0K8c5(__L7GZjoO1MWe0tYBNaXnbkLnG, 0) else null, "hull_b": Assets.__MUCguPydNQwl8ZRXUX2ciJ44(__L7GZjoO1MWe0tYBNaXnbkLnG, 1) if Assets.__QiUGArjHDhwcrWbH3BB0K8c5(__L7GZjoO1MWe0tYBNaXnbkLnG, 1) else null, "foam": Assets.__MUCguPydNQwl8ZRXUX2ciJ44(__L7GZjoO1MWe0tYBNaXnbkLnG, 6) if Assets.__QiUGArjHDhwcrWbH3BB0K8c5(__L7GZjoO1MWe0tYBNaXnbkLnG, 6) else null, "turrets": __S_7IyzWSdWQ_KiEnQbvvdj2D, "turrets_far": __rA1CDXXtjFGqQuX3h7GhLNuC, "fcs": __cjmjw_jNHbxV2y3zA4K9Y_MM, "fcs_at": __fnparxNE3vp0MWoTiWaLXq8T + Vector2(__QIuPeUkCZkXIHDBiGFMvDZqE.__HjH6rEN8pyt_TMZ3GUM09N6A("Location", __YJgAymCaLB78BrFx7OQpn545.__WeB9Hi0OxaFBUuwm2WU2qKEH, 10), __QIuPeUkCZkXIHDBiGFMvDZqE.__HjH6rEN8pyt_TMZ3GUM09N6A("Location", __YJgAymCaLB78BrFx7OQpn545.__WeB9Hi0OxaFBUuwm2WU2qKEH, 12)), "night": __g59CpE8YrzQ3c1AnhI3CYror, "nation": __6qODxp1VoZzlarYbuG6CVBNH(), }
	var __jofPSruqOfCu8ERXonkGESft: __Se4EsxPBCHX48h1ZS5MexaMl = App.__PtNURh2PaYHMgsPlkLtni90Y()
	var __OQJchzmm2h6bWLwbqQ0HYi_s: int = __YJgAymCaLB78BrFx7OQpn545.__WeB9Hi0OxaFBUuwm2WU2qKEH
	var ___Ygs760EsECtowK_t81wa3id: int = 0
	var __y1olK2SBBihK6qP_pefpyisU: Array = []
	var __Ab4SZ5lveXbVDuyjEmyZlfvY: PackedInt32Array = __jofPSruqOfCu8ERXonkGESft.__1y_c36LINhCmyTQh_Ii1WqjM(__OQJchzmm2h6bWLwbqQ0HYi_s)
	for __de91qzJ6QHNYVAskuyDrkCBc: int in mini(__YJgAymCaLB78BrFx7OQpn545.__dOsDavODOasdfPxqce2DEBC3.size(), __Ab4SZ5lveXbVDuyjEmyZlfvY.size()):
		if __YJgAymCaLB78BrFx7OQpn545.__dOsDavODOasdfPxqce2DEBC3[__de91qzJ6QHNYVAskuyDrkCBc] >= 0:
			__y1olK2SBBihK6qP_pefpyisU.append([__Ab4SZ5lveXbVDuyjEmyZlfvY[__de91qzJ6QHNYVAskuyDrkCBc], 5, __YJgAymCaLB78BrFx7OQpn545.__dOsDavODOasdfPxqce2DEBC3[__de91qzJ6QHNYVAskuyDrkCBc]])
	var sides: PackedInt32Array = __jofPSruqOfCu8ERXonkGESft.__4mBhSAAMIt6DTsibdV0pC19W(__OQJchzmm2h6bWLwbqQ0HYi_s)
	var __Pr60ubIKupOOMPdy9L3Mgnac: PackedInt32Array = __jofPSruqOfCu8ERXonkGESft.__PJZemYw0whDwrAt4vbBLpQ7w(__YJgAymCaLB78BrFx7OQpn545)
	for __FumwgugLvCtgfzjE2x5UXF_1: int in sides.size():
		if __Pr60ubIKupOOMPdy9L3Mgnac[__FumwgugLvCtgfzjE2x5UXF_1] >= 0:
			__y1olK2SBBihK6qP_pefpyisU.append([sides[__FumwgugLvCtgfzjE2x5UXF_1], 5, __Pr60ubIKupOOMPdy9L3Mgnac[__FumwgugLvCtgfzjE2x5UXF_1]])
	var __OKBZMfC2S4LKsKOJKMWpT_Q0: PackedInt32Array = __jofPSruqOfCu8ERXonkGESft.__Hmr_a2CPvjknmgXnhmVu1vm9(__OQJchzmm2h6bWLwbqQ0HYi_s)
	var __aqIFDD24bwgj4i9ouCHv3htg: PackedInt32Array = __jofPSruqOfCu8ERXonkGESft.__7uBhyRNBJZP4s1InKu8Lo_y7(__YJgAymCaLB78BrFx7OQpn545)
	for __Dfh_aFAvu7uCMSz96cj2VmEh: int in __OKBZMfC2S4LKsKOJKMWpT_Q0.size():
		if __aqIFDD24bwgj4i9ouCHv3htg[__Dfh_aFAvu7uCMSz96cj2VmEh] >= 0:
			__y1olK2SBBihK6qP_pefpyisU.append([__OKBZMfC2S4LKsKOJKMWpT_Q0[__Dfh_aFAvu7uCMSz96cj2VmEh], 6, __aqIFDD24bwgj4i9ouCHv3htg[__Dfh_aFAvu7uCMSz96cj2VmEh]])
	for __4doKr8NZE4sziLMnxXglHNCY: Array in __y1olK2SBBihK6qP_pefpyisU:
		var __2cj0mnGiR9EtIgTEgzTf88K4: int = __4doKr8NZE4sziLMnxXglHNCY[0]
		var x: int = __QIuPeUkCZkXIHDBiGFMvDZqE.__HjH6rEN8pyt_TMZ3GUM09N6A("Location", __OQJchzmm2h6bWLwbqQ0HYi_s, 14 + 2 * __2cj0mnGiR9EtIgTEgzTf88K4)
		var y: int = __QIuPeUkCZkXIHDBiGFMvDZqE.__HjH6rEN8pyt_TMZ3GUM09N6A("Location", __OQJchzmm2h6bWLwbqQ0HYi_s, 78 + 2 * __2cj0mnGiR9EtIgTEgzTf88K4)
		var z: int = __QIuPeUkCZkXIHDBiGFMvDZqE.__HjH6rEN8pyt_TMZ3GUM09N6A("Location", __OQJchzmm2h6bWLwbqQ0HYi_s, 142 + 2 * __2cj0mnGiR9EtIgTEgzTf88K4)
		if x == 0 and y == 0 and z == 0:
			___Ygs760EsECtowK_t81wa3id += 1
			continue
		var pack: String
		var __z1HPrHSpY6QsAC3qqd3n5eQb: int
		var __v9VjT860ExIHH0kbW9fhtIvX: int
		if int(__4doKr8NZE4sziLMnxXglHNCY[1]) == 5:
			pack = "ComponentsTuret"
			var __n73arcHHwiQeru0n5mDttGUm: int = (__QIuPeUkCZkXIHDBiGFMvDZqE.__pGLr1ud1V6XsMMJoSyeTRFjY("Frame", __OQJchzmm2h6bWLwbqQ0HYi_s, 620) >> (31 - __2cj0mnGiR9EtIgTEgzTf88K4)) & 1
			var __EC8aIvoPHzDxck98hwNJlgqQ: int = __QIuPeUkCZkXIHDBiGFMvDZqE.__Jy2hcMM9emCF3iBBkLMyeUr7("Gunset", int(__4doKr8NZE4sziLMnxXglHNCY[2]), 4)
			__z1HPrHSpY6QsAC3qqd3n5eQb = __EC8aIvoPHzDxck98hwNJlgqQ + 3 + __n73arcHHwiQeru0n5mDttGUm
			__v9VjT860ExIHH0kbW9fhtIvX = __EC8aIvoPHzDxck98hwNJlgqQ + 5 + __n73arcHHwiQeru0n5mDttGUm
			if not Assets.__QiUGArjHDhwcrWbH3BB0K8c5(pack, __z1HPrHSpY6QsAC3qqd3n5eQb):
				__z1HPrHSpY6QsAC3qqd3n5eQb = __EC8aIvoPHzDxck98hwNJlgqQ + 3 + (1 - __n73arcHHwiQeru0n5mDttGUm)
				__v9VjT860ExIHH0kbW9fhtIvX = __EC8aIvoPHzDxck98hwNJlgqQ + 5 + (1 - __n73arcHHwiQeru0n5mDttGUm)
		else:
			pack = "ComponentsTpLauncher"
			var __mo1uVAljGs6Bcm0bsHB04CpD: int = __QIuPeUkCZkXIHDBiGFMvDZqE.__Jy2hcMM9emCF3iBBkLMyeUr7("TpLauncher", int(__4doKr8NZE4sziLMnxXglHNCY[2]), 4)
			__z1HPrHSpY6QsAC3qqd3n5eQb = __mo1uVAljGs6Bcm0bsHB04CpD + 3
			__v9VjT860ExIHH0kbW9fhtIvX = __mo1uVAljGs6Bcm0bsHB04CpD + 4
		if not Assets.__QiUGArjHDhwcrWbH3BB0K8c5(pack, __z1HPrHSpY6QsAC3qqd3n5eQb):
			___Ygs760EsECtowK_t81wa3id += 1
			continue
		var __inovAHAjnaGTUf3YqO9wJt1F: __H2jKfddttLiR1Mfv697VtMqG = Assets.__MUCguPydNQwl8ZRXUX2ciJ44(pack, __v9VjT860ExIHH0kbW9fhtIvX) if Assets.__QiUGArjHDhwcrWbH3BB0K8c5(pack, __v9VjT860ExIHH0kbW9fhtIvX) else null
		var __nN_p6mWFA45LUzcNTzwz1AwJ: Array = [z, Assets.__MUCguPydNQwl8ZRXUX2ciJ44(pack, __z1HPrHSpY6QsAC3qqd3n5eQb), __inovAHAjnaGTUf3YqO9wJt1F, __fnparxNE3vp0MWoTiWaLXq8T + Vector2(x, y)]
		var __oSf5FckxYbUzSfgYR41sd8rp: bool = __QIuPeUkCZkXIHDBiGFMvDZqE.__HjH6rEN8pyt_TMZ3GUM09N6A("Frame", __OQJchzmm2h6bWLwbqQ0HYi_s, 700 + 2 * __2cj0mnGiR9EtIgTEgzTf88K4) > 0 and __jofPSruqOfCu8ERXonkGESft.__rIbrGNBQXI7CsdYVLpVwKrNI(__OQJchzmm2h6bWLwbqQ0HYi_s) != __Se4EsxPBCHX48h1ZS5MexaMl.__UdurGu7NlLw_5NC5J7D7nIXj
		if __OKBZMfC2S4LKsKOJKMWpT_Q0.has(__2cj0mnGiR9EtIgTEgzTf88K4):
			__oSf5FckxYbUzSfgYR41sd8rp = false
		if __oSf5FckxYbUzSfgYR41sd8rp:
			__rA1CDXXtjFGqQuX3h7GhLNuC.append(__nN_p6mWFA45LUzcNTzwz1AwJ)
		else:
			__S_7IyzWSdWQ_KiEnQbvvdj2D.append(__nN_p6mWFA45LUzcNTzwz1AwJ)
	var __ac497aW5DqoVBB929tFTs17Y: PackedInt32Array = __jofPSruqOfCu8ERXonkGESft.__mgdM7ycmi3DNHzWo0uObSaPX(__YJgAymCaLB78BrFx7OQpn545)
	for s: int in __jofPSruqOfCu8ERXonkGESft.__GQ9LLolLcENvLp870dW_HjRn(__OQJchzmm2h6bWLwbqQ0HYi_s):
		var __ylU4Lat6p5ta3YjnzCQVYsEg: int = __Se4EsxPBCHX48h1ZS5MexaMl.__Uv7vWKACrD3IoOv6puOgq1PA.find(s)
		if __ylU4Lat6p5ta3YjnzCQVYsEg < 0 or __ac497aW5DqoVBB929tFTs17Y.size() < __Se4EsxPBCHX48h1ZS5MexaMl.__7H3uQhAdVTbh0QLkQVDDP1bw * (__ylU4Lat6p5ta3YjnzCQVYsEg + 1):
			continue
		var __jJhZjYySD_75aOzxHvDgcI1k: int = __ac497aW5DqoVBB929tFTs17Y[__Se4EsxPBCHX48h1ZS5MexaMl.__7H3uQhAdVTbh0QLkQVDDP1bw * __ylU4Lat6p5ta3YjnzCQVYsEg]
		if __jJhZjYySD_75aOzxHvDgcI1k < 0 or __ac497aW5DqoVBB929tFTs17Y[__Se4EsxPBCHX48h1ZS5MexaMl.__7H3uQhAdVTbh0QLkQVDDP1bw * __ylU4Lat6p5ta3YjnzCQVYsEg + 1] <= 0:
			continue
		var __04n_ZToUnb9Q3iqKJL014DAl: int = int(__jofPSruqOfCu8ERXonkGESft.__gobxGwIVlftvCfJ1fsNzSlj7(__jJhZjYySD_75aOzxHvDgcI1k).get("spr", -1))
		if __04n_ZToUnb9Q3iqKJL014DAl < 0 or not Assets.__QiUGArjHDhwcrWbH3BB0K8c5("ComponentsAircraft", __04n_ZToUnb9Q3iqKJL014DAl + 3):
			___Ygs760EsECtowK_t81wa3id += 1
			continue
		var __S_ZFaAV5H51ocwzuJwWiwoBW: __H2jKfddttLiR1Mfv697VtMqG = Assets.__MUCguPydNQwl8ZRXUX2ciJ44("ComponentsAircraft", __04n_ZToUnb9Q3iqKJL014DAl + 4) if Assets.__QiUGArjHDhwcrWbH3BB0K8c5("ComponentsAircraft", __04n_ZToUnb9Q3iqKJL014DAl + 4) else null
		__S_7IyzWSdWQ_KiEnQbvvdj2D.append([__QIuPeUkCZkXIHDBiGFMvDZqE.__HjH6rEN8pyt_TMZ3GUM09N6A("Location", __OQJchzmm2h6bWLwbqQ0HYi_s, 142 + 2 * s), Assets.__MUCguPydNQwl8ZRXUX2ciJ44("ComponentsAircraft", __04n_ZToUnb9Q3iqKJL014DAl + 3), __S_ZFaAV5H51ocwzuJwWiwoBW, __fnparxNE3vp0MWoTiWaLXq8T + Vector2(__QIuPeUkCZkXIHDBiGFMvDZqE.__HjH6rEN8pyt_TMZ3GUM09N6A("Location", __OQJchzmm2h6bWLwbqQ0HYi_s, 14 + 2 * s), __QIuPeUkCZkXIHDBiGFMvDZqE.__HjH6rEN8pyt_TMZ3GUM09N6A("Location", __OQJchzmm2h6bWLwbqQ0HYi_s, 78 + 2 * s))])
	var __UBpyxpIzBfy9akXpOAxfJF8O: = func(a: Array, b: Array) -> bool: return int(a[0]) < int(b[0])
	__S_7IyzWSdWQ_KiEnQbvvdj2D.sort_custom(__UBpyxpIzBfy9akXpOAxfJF8O)
	__rA1CDXXtjFGqQuX3h7GhLNuC.sort_custom(__UBpyxpIzBfy9akXpOAxfJF8O)
	__LcEmKczmLrorVyOBaMDnHamK = __fiP3BAwTotZMUqJWPCJLN0_t
	%Title.tooltip_text = tr("UI_DOCK_INFO") % [__L7GZjoO1MWe0tYBNaXnbkLnG, __S_7IyzWSdWQ_KiEnQbvvdj2D.size() + __rA1CDXXtjFGqQuX3h7GhLNuC.size(), ___Ygs760EsECtowK_t81wa3id]
	%Sub.tooltip_text = %Title.tooltip_text
var __ezxmIHAAQKmXttLHPr9Bj08Z: Button
func __9iFcUUuz7hxSygPtA9oE6aBm(__B_8tvjJKZaGpn06Infeh1fAC: __s8yZigV26lPAvEmbOWzMbnjE) -> int:
	var __bdcBC5U1aSAWEcx3v0psCKXv: __Se4EsxPBCHX48h1ZS5MexaMl = App.__PtNURh2PaYHMgsPlkLtni90Y()
	var __UPLfEDxMtNDVC48HyQoPXnpi: int = __bdcBC5U1aSAWEcx3v0psCKXv.__BGxXnVzPsmPLUaUtEL38SXTm(__B_8tvjJKZaGpn06Infeh1fAC)
	if __UPLfEDxMtNDVC48HyQoPXnpi == __Se4EsxPBCHX48h1ZS5MexaMl.__5CDMR1_ZY_Be5hesPdyczkNt.__zG959bwdOwL5xL4s3PeplU46 and __bdcBC5U1aSAWEcx3v0psCKXv.__77YZ0E3pilwCWMSZ5lHzv_es(__B_8tvjJKZaGpn06Infeh1fAC).x <= __bdcBC5U1aSAWEcx3v0psCKXv.__77YZ0E3pilwCWMSZ5lHzv_es(__YJgAymCaLB78BrFx7OQpn545).x:
		return __Se4EsxPBCHX48h1ZS5MexaMl.__5CDMR1_ZY_Be5hesPdyczkNt.OK
	return __UPLfEDxMtNDVC48HyQoPXnpi
func __Ua_bI8NjP7cgYQVgxQBQi5FZ() -> void :
	if __Lnl7EUrWdzkuBnGqxTLllE5o == null:
		return
	var __zOoN1OJyZyKkYz1GgJYQ53mG: Control = %Overlay
	var __f6ZLGKY9LRPrsbF__z1nG95P: Vector2 = __zOoN1OJyZyKkYz1GgJYQ53mG.global_position
	var left: float = __bLKLb0Khmx9u_g9HRmoM6tG6.__Gc9pvpcX3aEx1tMHweM0N4bO().end.x - __f6ZLGKY9LRPrsbF__z1nG95P.x + 8.0 if __bLKLb0Khmx9u_g9HRmoM6tG6.open else 48.0
	var right: float = __pndlxY_XCFFxBsvt9SrAMHXa.__Gc9pvpcX3aEx1tMHweM0N4bO().position.x - __f6ZLGKY9LRPrsbF__z1nG95P.x - 8.0 if __pndlxY_XCFFxBsvt9SrAMHXa.open else __zOoN1OJyZyKkYz1GgJYQ53mG.size.x - 48.0
	var h: float = __Lnl7EUrWdzkuBnGqxTLllE5o.get_combined_minimum_size().y
	__Lnl7EUrWdzkuBnGqxTLllE5o.position = Vector2(left, __zOoN1OJyZyKkYz1GgJYQ53mG.size.y - h - 8.0)
	__Lnl7EUrWdzkuBnGqxTLllE5o.size = Vector2(maxf(160.0, right - left), h)
	if __aZ9T7TmaIvmS1Lo85UiNhrn8 != null:
		var x: float = __Lnl7EUrWdzkuBnGqxTLllE5o.position.x
		for __BwHSysnCkXZzXSL0uPGgmhOh: Button in [__aZ9T7TmaIvmS1Lo85UiNhrn8, __ezxmIHAAQKmXttLHPr9Bj08Z]:
			var __goRiakeSLkFVLvdLkFb4t7LJ: Vector2 = __BwHSysnCkXZzXSL0uPGgmhOh.get_combined_minimum_size()
			__BwHSysnCkXZzXSL0uPGgmhOh.size = __goRiakeSLkFVLvdLkFb4t7LJ
			__BwHSysnCkXZzXSL0uPGgmhOh.position = Vector2(x, __Lnl7EUrWdzkuBnGqxTLllE5o.position.y - __goRiakeSLkFVLvdLkFb4t7LJ.y)
			x += __goRiakeSLkFVLvdLkFb4t7LJ.x + 3.0
	if __hDON5_Ak_v4LQsqfesSFUaa2 != null:
		var __ahvCcyLf1xem11Xm5f2jFhwt: float = __hDON5_Ak_v4LQsqfesSFUaa2.__TEOGpgkHmUUvlEe4nHnrWj6s().size.x
		if __ahvCcyLf1xem11Xm5f2jFhwt <= 0.0:
			__ahvCcyLf1xem11Xm5f2jFhwt = __tALbI77Bj72RNkUjx1rJalbI.__qkI9rzzPHG3olOfJc5DxIE0c * __hDON5_Ak_v4LQsqfesSFUaa2.__Z8aK7Eyb3fsxTT_r4WaSY0z4
		__hDON5_Ak_v4LQsqfesSFUaa2.__ANJC4cgwRZ92XcUJzlGxwpBx(__Lnl7EUrWdzkuBnGqxTLllE5o.position.x + __Lnl7EUrWdzkuBnGqxTLllE5o.size.x - __ahvCcyLf1xem11Xm5f2jFhwt)
		__hDON5_Ak_v4LQsqfesSFUaa2.__Wyr5Sp0tN8bHzibHqH1GlzVn(__zOoN1OJyZyKkYz1GgJYQ53mG.size.y - __Lnl7EUrWdzkuBnGqxTLllE5o.position.y + 5.0)
func __Z_Ja8I3PvbMOluuRp9xx0IIH(__EpuOQkB89mQyPBJzAl1DFdh8: int) -> void :
	__xorSo_i34n5tNZmGntPVcw5H.clear()
	__cG_zbW1sotj7reUf4u7FXswZ = __EpuOQkB89mQyPBJzAl1DFdh8
	__U7UMfwBewiXSLEeaDnywaCO7.__PYsanWw1Gsza29vOAY89AxUL(__EpuOQkB89mQyPBJzAl1DFdh8)
	__YJgAymCaLB78BrFx7OQpn545 = __U7UMfwBewiXSLEeaDnywaCO7.__V0erSRNWoPFGOr7bG6vGIpsK()
	__YahxYYsCSePibWCVlCnGhFI_()
	_load()
	__CZNkeeRfo0Z9Wuy80hOWdhXF(true)
	if __zABAFBwuGIufBHjRN9OzcNUm != null:
		__zABAFBwuGIufBHjRN9OzcNUm.__Qa9GbnhM8GDjcw4fKszR0Ftz()
	if __WthKfcvjK4RJwtX6snlMJlVa != null:
		__WthKfcvjK4RJwtX6snlMJlVa.set_text(__ejjrmWDPOiCDSSON_WTtAS7w())
		__WthKfcvjK4RJwtX6snlMJlVa.__4lDqDGWbt7kuLeJA32SrS_z6(tr("UI_HARBOR_WELCOME") % __ejjrmWDPOiCDSSON_WTtAS7w())
	__g6q9T1VmtoQE6bUvlCkH1PIZ(__aBhCjT5h4HuVdMnKzKKIXLBp)
func __UxRH136qCscJz2DBq4WJgk9g() -> void :
	while not __xorSo_i34n5tNZmGntPVcw5H.is_empty():
		var __4lr9vZCw3c4s1n723KKeyB67: Variant = __xorSo_i34n5tNZmGntPVcw5H.pop_front()
		var __XxTaQsavbZfgyp7mds375lzg: Array[__s8yZigV26lPAvEmbOWzMbnjE] = __VkSeEGhVF0y6mvRsZYDTVhBy()
		var __e6fQ7zmv81L2oXIBu5tds4Fh: int = -1 if __DpM0JQWB6EqgMh3WJZSlHODu else __i9hHpabGq0vj3HV9AiaCAWeq(__XxTaQsavbZfgyp7mds375lzg, __YJgAymCaLB78BrFx7OQpn545.__WeB9Hi0OxaFBUuwm2WU2qKEH)
		if __DpM0JQWB6EqgMh3WJZSlHODu and __4lr9vZCw3c4s1n723KKeyB67 is __s8yZigV26lPAvEmbOWzMbnjE and __i9hHpabGq0vj3HV9AiaCAWeq(__XxTaQsavbZfgyp7mds375lzg, (__4lr9vZCw3c4s1n723KKeyB67 as __s8yZigV26lPAvEmbOWzMbnjE).__WeB9Hi0OxaFBUuwm2WU2qKEH) >= 0:
			__Sll1pjvntU3_a41waOOS2VpP(__4lr9vZCw3c4s1n723KKeyB67, 1)
			return
		var __ctR1rEqtKIMGgi0WYukf0kdv: int = __i9hHpabGq0vj3HV9AiaCAWeq(__XxTaQsavbZfgyp7mds375lzg, (__4lr9vZCw3c4s1n723KKeyB67 as __s8yZigV26lPAvEmbOWzMbnjE).__WeB9Hi0OxaFBUuwm2WU2qKEH) if __4lr9vZCw3c4s1n723KKeyB67 is __s8yZigV26lPAvEmbOWzMbnjE else __e6fQ7zmv81L2oXIBu5tds4Fh + int(__4lr9vZCw3c4s1n723KKeyB67)
		if __e6fQ7zmv81L2oXIBu5tds4Fh < 0 or __ctR1rEqtKIMGgi0WYukf0kdv < 0 or __ctR1rEqtKIMGgi0WYukf0kdv >= __XxTaQsavbZfgyp7mds375lzg.size() or __ctR1rEqtKIMGgi0WYukf0kdv == __e6fQ7zmv81L2oXIBu5tds4Fh:
			continue
		__Sll1pjvntU3_a41waOOS2VpP(__XxTaQsavbZfgyp7mds375lzg[__ctR1rEqtKIMGgi0WYukf0kdv], 1 if __ctR1rEqtKIMGgi0WYukf0kdv > __e6fQ7zmv81L2oXIBu5tds4Fh else -1)
		return
func __kSFTyf6nLIFkdB6li7_pZbjR(__5QCTbPd7cZ6iZE6jan8WH3pR: __s8yZigV26lPAvEmbOWzMbnjE, __RASgiWXPBBiwurm3ohSjrnSt: String, __Iz9CEZoZXF_OBrfZHWFcJYc1: int, __yZhRw10Fso0qwi3W3d2zW80r: int, count: int) -> __s8yZigV26lPAvEmbOWzMbnjE:
	if __RASgiWXPBBiwurm3ohSjrnSt in ["A", "B", "SA", "SB"] and bool(__MRgAcPuNvSjtNvNirEW1YRMP.get("bulk", false)):
		return meti_ammo_candidate(__5QCTbPd7cZ6iZE6jan8WH3pR, __RASgiWXPBBiwurm3ohSjrnSt, __Iz9CEZoZXF_OBrfZHWFcJYc1, __yZhRw10Fso0qwi3W3d2zW80r, count)
	var __UHmaz30gQF4GJpY2yhXDqSZk: __Se4EsxPBCHX48h1ZS5MexaMl = App.__PtNURh2PaYHMgsPlkLtni90Y()
	var __GBdV76LaWQTB3wHaJjuK_QUv: __s8yZigV26lPAvEmbOWzMbnjE = __5QCTbPd7cZ6iZE6jan8WH3pR.__12ty6aWt7_v7eYEbKtP71Dlf()
	if __RASgiWXPBBiwurm3ohSjrnSt in __nDMzIIBfjfebkTT_IF92ffWF and bool(__MRgAcPuNvSjtNvNirEW1YRMP.get("bulk", false)):
		for __JgmNmph7OFjJ4GD7jEQ1dN0Q: int in __7Mjw8rGwZR13HeV6a47gwnIG(__RASgiWXPBBiwurm3ohSjrnSt, __yZhRw10Fso0qwi3W3d2zW80r):
			__artOxTBmv0igp4KCRm6SwQqa(__GBdV76LaWQTB3wHaJjuK_QUv, __RASgiWXPBBiwurm3ohSjrnSt, __JgmNmph7OFjJ4GD7jEQ1dN0Q, __yZhRw10Fso0qwi3W3d2zW80r, count)
	elif __eIpp4vouyAkAw9Ef1LuxCpw8.has(__RASgiWXPBBiwurm3ohSjrnSt):
		__artOxTBmv0igp4KCRm6SwQqa(__GBdV76LaWQTB3wHaJjuK_QUv, __RASgiWXPBBiwurm3ohSjrnSt, __Iz9CEZoZXF_OBrfZHWFcJYc1, __yZhRw10Fso0qwi3W3d2zW80r, count)
	elif __RASgiWXPBBiwurm3ohSjrnSt == "T":
		__GBdV76LaWQTB3wHaJjuK_QUv.__t3YSlOfvQe4R_b9rHMAz7hq0 = __UHmaz30gQF4GJpY2yhXDqSZk.__El7brR86C9a6x0hMgLnIgY3e(__GBdV76LaWQTB3wHaJjuK_QUv)
		__GBdV76LaWQTB3wHaJjuK_QUv.__t3YSlOfvQe4R_b9rHMAz7hq0[2 * __Iz9CEZoZXF_OBrfZHWFcJYc1] = __yZhRw10Fso0qwi3W3d2zW80r if count > 0 else __s8yZigV26lPAvEmbOWzMbnjE.__1iBjWxIGtvWf0yGsmF7yzBIR
		__GBdV76LaWQTB3wHaJjuK_QUv.__t3YSlOfvQe4R_b9rHMAz7hq0[2 * __Iz9CEZoZXF_OBrfZHWFcJYc1 + 1] = count
	elif __RASgiWXPBBiwurm3ohSjrnSt == "SA" or __RASgiWXPBBiwurm3ohSjrnSt == "SB":
		__GBdV76LaWQTB3wHaJjuK_QUv.__nQdkAoXs7wyREcSJQ0Beyel6 = __UHmaz30gQF4GJpY2yhXDqSZk.__Xs0yLUqBQ7TVWSHzfx4EiUAr(__GBdV76LaWQTB3wHaJjuK_QUv)
		var __WuCmE3BVLYY3AFhlUc25sssz: int = 0 if __RASgiWXPBBiwurm3ohSjrnSt == "SA" else 1
		__GBdV76LaWQTB3wHaJjuK_QUv.__nQdkAoXs7wyREcSJQ0Beyel6[4 * __Iz9CEZoZXF_OBrfZHWFcJYc1 + 2 * __WuCmE3BVLYY3AFhlUc25sssz] = __yZhRw10Fso0qwi3W3d2zW80r if count > 0 else __s8yZigV26lPAvEmbOWzMbnjE.__1iBjWxIGtvWf0yGsmF7yzBIR
		__GBdV76LaWQTB3wHaJjuK_QUv.__nQdkAoXs7wyREcSJQ0Beyel6[4 * __Iz9CEZoZXF_OBrfZHWFcJYc1 + 2 * __WuCmE3BVLYY3AFhlUc25sssz + 1] = count
	else:
		__GBdV76LaWQTB3wHaJjuK_QUv.__ZCQBCv36ysTHU0iBaYX6GvwS = __UHmaz30gQF4GJpY2yhXDqSZk.__RgxkBWnYRjC44wuJnI7BKnV_(__GBdV76LaWQTB3wHaJjuK_QUv)
		var __MUobDHzv_Ub2dNCu0WDklX9l: int = 0 if __RASgiWXPBBiwurm3ohSjrnSt == "A" else 1
		__GBdV76LaWQTB3wHaJjuK_QUv.__ZCQBCv36ysTHU0iBaYX6GvwS[4 * __Iz9CEZoZXF_OBrfZHWFcJYc1 + 2 * __MUobDHzv_Ub2dNCu0WDklX9l] = __yZhRw10Fso0qwi3W3d2zW80r if count > 0 else __s8yZigV26lPAvEmbOWzMbnjE.__1iBjWxIGtvWf0yGsmF7yzBIR
		__GBdV76LaWQTB3wHaJjuK_QUv.__ZCQBCv36ysTHU0iBaYX6GvwS[4 * __Iz9CEZoZXF_OBrfZHWFcJYc1 + 2 * __MUobDHzv_Ub2dNCu0WDklX9l + 1] = count
	return __GBdV76LaWQTB3wHaJjuK_QUv
func __YahxYYsCSePibWCVlCnGhFI_() -> void :
	__DpM0JQWB6EqgMh3WJZSlHODu = false
	if App.__72kAp8sMQh2gIPcLl7onOgPE(__YJgAymCaLB78BrFx7OQpn545.__WeB9Hi0OxaFBUuwm2WU2qKEH) == __cG_zbW1sotj7reUf4u7FXswZ:
		return
	var __KiANbBf3U1W_XrQBMkAKmlIf: Array[__s8yZigV26lPAvEmbOWzMbnjE] = __U7UMfwBewiXSLEeaDnywaCO7.__vwjNIITOPVtRhfVJi6Wz56IY(__cG_zbW1sotj7reUf4u7FXswZ)
	if __KiANbBf3U1W_XrQBMkAKmlIf.is_empty():
		__DpM0JQWB6EqgMh3WJZSlHODu = true
		return
	__U7UMfwBewiXSLEeaDnywaCO7.__VvG2q5CwvCNDjBta5Gspay17(__KiANbBf3U1W_XrQBMkAKmlIf[0])
	App.__M0ImV248NGNrBFXy9NCs5jwX().__g7F3EfgE1iugY6qyUxtrpa1X(__KiANbBf3U1W_XrQBMkAKmlIf[0])
	__YJgAymCaLB78BrFx7OQpn545 = __U7UMfwBewiXSLEeaDnywaCO7.__V0erSRNWoPFGOr7bG6vGIpsK()
var __h1tDxlSlZLzRDqez_H4rCrnn: __21NGacAISHpzjaKmV3CZK2Y6
const __fnparxNE3vp0MWoTiWaLXq8T: = Vector2(512, 444)
var __DpM0JQWB6EqgMh3WJZSlHODu: bool = false
var __CgtEZnFtJYvrLjlSjFnhNN9n: __tgldA7aC7YucWAFFe4bVx4oW
func __gvVRFH6rUAOaLPJCVQsHcX2I() -> void :
	var __WJTaa3Nm4ezkBtcQtW3QAVNO: String = __FWw1MFcV48pcQszFug10_Wsq()
	if __WJTaa3Nm4ezkBtcQtW3QAVNO != "":
		print("出港校验不过：%s" % tr(__WJTaa3Nm4ezkBtcQtW3QAVNO))
		UI.__FZyGB2TVbKGb1g8kgT4bm_x4(tr(__WJTaa3Nm4ezkBtcQtW3QAVNO))
		if __WthKfcvjK4RJwtX6snlMJlVa != null:
			__WthKfcvjK4RJwtX6snlMJlVa.__4lDqDGWbt7kuLeJA32SrS_z6(tr(__WJTaa3Nm4ezkBtcQtW3QAVNO), Color8(255, 150, 120))
		return
	var __e7oIot_mGQ0Vd7QFNYsC95Jg: Dictionary = __iAbDeha6hgeEpDzp_OVLHMcN.duplicate()
	__e7oIot_mGQ0Vd7QFNYsC95Jg.erase("hub")
	__e7oIot_mGQ0Vd7QFNYsC95Jg.erase("mode")
	UI.replace("sandbox", __e7oIot_mGQ0Vd7QFNYsC95Jg)
const __xJ7FHmh8jL_D48rMHMR9dpIN: = 200
var __iAbDeha6hgeEpDzp_OVLHMcN: Dictionary = {}
var __kinsDyUwBqfk_kcYtvIhl2eK: bool = false
func __tG5b3HQggmn2rI2gIpXHDl4h(text: String, __HGEpq8PSIoPU2jBN40McVg2_: String, __NEvGoPw5onMvcu5S5GJF1Nhe: String) -> Button:
	var __SMS1Wx_bFnWloJyEsI84Y3tx: = Button.new()
	__SMS1Wx_bFnWloJyEsI84Y3tx.text = tr(text)
	__SMS1Wx_bFnWloJyEsI84Y3tx.tooltip_text = tr(__HGEpq8PSIoPU2jBN40McVg2_)
	__SMS1Wx_bFnWloJyEsI84Y3tx.focus_mode = Control.FOCUS_NONE
	__SMS1Wx_bFnWloJyEsI84Y3tx.custom_minimum_size = __I1lngIcnmU9bwkK71K8d67NT
	__SMS1Wx_bFnWloJyEsI84Y3tx.add_theme_font_size_override("font_size", 17)
	__SMS1Wx_bFnWloJyEsI84Y3tx.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	__SMS1Wx_bFnWloJyEsI84Y3tx.pressed.connect( func() -> void : __ZFd4wePpEaVpfpGejOdwVKGR(__NEvGoPw5onMvcu5S5GJF1Nhe))
	( %Overlay as Control).add_child(__SMS1Wx_bFnWloJyEsI84Y3tx)
	return __SMS1Wx_bFnWloJyEsI84Y3tx
func __ydCl5L2QyDKE2SDpVsMZ5fEb(__ljWbwXfT9jpJ6jWzKk4vV7NL: String, __AhZx4d1jRwtnx4oNJ7SGiGQ0: int, __OwoxqIVjNaxcbZZJSa3DUAuA: int, count: int) -> int:
	var ___bT3qljkWIkUUi2TIajUiT3B: __Se4EsxPBCHX48h1ZS5MexaMl = App.__PtNURh2PaYHMgsPlkLtni90Y()
	var __3EIR4QAsb2UnqgystQjCL8ve: int = -1
	var __W9an9i9O56HAjDyd5qS0QWzr: int = 0
	var __NMloQllKXsVeJCULQv6Om7e_: int = 0
	if __ljWbwXfT9jpJ6jWzKk4vV7NL == "T":
		var __9mau4p5Dwo_Hg0_mXa4Y3x8y: PackedInt32Array = ___bT3qljkWIkUUi2TIajUiT3B.__El7brR86C9a6x0hMgLnIgY3e(__YJgAymCaLB78BrFx7OQpn545)
		__3EIR4QAsb2UnqgystQjCL8ve = __9mau4p5Dwo_Hg0_mXa4Y3x8y[2 * __AhZx4d1jRwtnx4oNJ7SGiGQ0]
		__W9an9i9O56HAjDyd5qS0QWzr = __9mau4p5Dwo_Hg0_mXa4Y3x8y[2 * __AhZx4d1jRwtnx4oNJ7SGiGQ0 + 1]
		__NMloQllKXsVeJCULQv6Om7e_ = __9MFWgnc8oYQpY6kqM0OFfhrH.__RqJZeOtqPPYKlwE68mX9QyHo(___bT3qljkWIkUUi2TIajUiT3B.__zhHTezbt3nPUGWVaU6OaVpvy(__OwoxqIVjNaxcbZZJSa3DUAuA))
	elif __ljWbwXfT9jpJ6jWzKk4vV7NL in ["A", "B", "SA", "SB"]:
		var __qhHwfilxoL_hHtHeTSIKoHJM: int = 0 if __ljWbwXfT9jpJ6jWzKk4vV7NL == "A" or __ljWbwXfT9jpJ6jWzKk4vV7NL == "SA" else 1
		var __KgVAAjsG8zX9v4oTGrOO5b6C: PackedInt32Array = ___bT3qljkWIkUUi2TIajUiT3B.__Xs0yLUqBQ7TVWSHzfx4EiUAr(__YJgAymCaLB78BrFx7OQpn545) if __ljWbwXfT9jpJ6jWzKk4vV7NL.begins_with("S") else ___bT3qljkWIkUUi2TIajUiT3B.__RgxkBWnYRjC44wuJnI7BKnV_(__YJgAymCaLB78BrFx7OQpn545)
		__3EIR4QAsb2UnqgystQjCL8ve = __KgVAAjsG8zX9v4oTGrOO5b6C[4 * __AhZx4d1jRwtnx4oNJ7SGiGQ0 + 2 * __qhHwfilxoL_hHtHeTSIKoHJM]
		__W9an9i9O56HAjDyd5qS0QWzr = __KgVAAjsG8zX9v4oTGrOO5b6C[4 * __AhZx4d1jRwtnx4oNJ7SGiGQ0 + 2 * __qhHwfilxoL_hHtHeTSIKoHJM + 1]
		__NMloQllKXsVeJCULQv6Om7e_ = __9MFWgnc8oYQpY6kqM0OFfhrH.__TLcNJZF14QZ0UbxJjxI3AtuW(___bT3qljkWIkUUi2TIajUiT3B.__Z1n6LQ0e8g_Sv5O7it1HPeiw(__OwoxqIVjNaxcbZZJSa3DUAuA))
	else:
		return 0
	var delta: int = count - (__W9an9i9O56HAjDyd5qS0QWzr if __3EIR4QAsb2UnqgystQjCL8ve == __OwoxqIVjNaxcbZZJSa3DUAuA else 0)
	return maxi(0, delta) * __NMloQllKXsVeJCULQv6Om7e_
const __BIy11OarK8HlRREtRkZDAiNC: = __iAAZg_L1CIMXb2xD1_GMfROh
func __XviRMKHdbGnEMaTN0kgBw5GT(__aJXaUDnJaPsXH6vHXQ8fwhdh: __s8yZigV26lPAvEmbOWzMbnjE) -> void :
	__U7UMfwBewiXSLEeaDnywaCO7.__VvG2q5CwvCNDjBta5Gspay17(__aJXaUDnJaPsXH6vHXQ8fwhdh)
	App.__M0ImV248NGNrBFXy9NCs5jwX().__g7F3EfgE1iugY6qyUxtrpa1X(__aJXaUDnJaPsXH6vHXQ8fwhdh)
	__YJgAymCaLB78BrFx7OQpn545 = __U7UMfwBewiXSLEeaDnywaCO7.__V0erSRNWoPFGOr7bG6vGIpsK()
	var __OAo5pcGAv2FZ4vWUPg8O95DV: bool = __DpM0JQWB6EqgMh3WJZSlHODu
	__DpM0JQWB6EqgMh3WJZSlHODu = false
	_load()
	__CZNkeeRfo0Z9Wuy80hOWdhXF(false)
	if __zABAFBwuGIufBHjRN9OzcNUm != null:
		__zABAFBwuGIufBHjRN9OzcNUm.__Qa9GbnhM8GDjcw4fKszR0Ftz()
	if __OAo5pcGAv2FZ4vWUPg8O95DV:
		__g6q9T1VmtoQE6bUvlCkH1PIZ(__aBhCjT5h4HuVdMnKzKKIXLBp)
const __8ttsfVTKv2GQMNELL7rvBI7m: = Color8(150, 240, 255)
const __t0NbhkC_eocFXs9HdejK9HTs: = Color(0.62, 0.72, 0.82)
static func __TYkQtj0KJU3imI91kByy1UpC(v: int, __3DsMx18EmX9TFGcvWAqQNBHr: int) -> String:
	return "%d.%d" % [v / __3DsMx18EmX9TFGcvWAqQNBHr, v % __3DsMx18EmX9TFGcvWAqQNBHr]
const __AKcEUb3llykBn01zEwjd6Fxk: = Vector2(-33, -29)
const __xxmB0C1mVHhNScnhHpjuF4zI: = ["T", "A", "B", "SA", "SB"]
func __NJiRcQ_010d3zGothv6OVgV4() -> void :
	var __sOIgMK8HoD0DNNf0sJCcPhAL: = Vector2(__XwGmCs7gUex6WMx0F0Lapr6y.__sfj5QkTNl1KRF7NVZ8qmqdhO())
	var __Nh_rlL5WWFWc1P6ceG363x7s: = Vector2(__XwGmCs7gUex6WMx0F0Lapr6y.__NShsvrWsDyi1jHcNYxybWdBS())
	var __8QhiDXv3b5L99ZzG4HXImTxQ: float = __XwGmCs7gUex6WMx0F0Lapr6y.__nlU65Fue9_WonsbxuDdu8mW4() / float(__AULjCEkcKgaRzYRXGAcwDg5F.__Y_H11Dpoc5qv4igyN104Fjdb)
	var __vUMPqY_lXHV0DkN2tKRS3GrO: float = __XwGmCs7gUex6WMx0F0Lapr6y.__njVZw8qHnp2EjeL2LmhyEQs8 / float(__AULjCEkcKgaRzYRXGAcwDg5F.__Y_H11Dpoc5qv4igyN104Fjdb)
	for __3nLxlB27uIK95f3inZ5UrxqC: __XZQIsX2REk1j2LWZtbLIAovG in __ORPVAwaEZaG_WUKCzYPqV3CM:
		__3nLxlB27uIK95f3inZ5UrxqC.position = __sOIgMK8HoD0DNNf0sJCcPhAL
		__hXETMci8tRCb5H43aZxU11kA(__3nLxlB27uIK95f3inZ5UrxqC, __8QhiDXv3b5L99ZzG4HXImTxQ)
	for __NkUCwji78h_LpMhPv80tEv8K: __XZQIsX2REk1j2LWZtbLIAovG in __dAGqnexg_IDbNw344d0sOBgZ:
		__NkUCwji78h_LpMhPv80tEv8K.position = __Nh_rlL5WWFWc1P6ceG363x7s
		__hXETMci8tRCb5H43aZxU11kA(__NkUCwji78h_LpMhPv80tEv8K, __vUMPqY_lXHV0DkN2tKRS3GrO)
	__0enFPGinCOJKsiE7r2nLxhFA()
var __Lnl7EUrWdzkuBnGqxTLllE5o: __JeprpcXyhqKlLNlwsQnYyWht
var __bqpvtk4llmiFJQmT5SzgWELV: __pT6jZw1fUvWomUDaJvLtM_kC
const __eIpp4vouyAkAw9Ef1LuxCpw8: Array[String] = ["G", "S", "L", "F", "E", "P", "M", "R"]
func __IAgjxk14dGPi74dqdcixCBZr(__F3rTIYdzB2C5f1kKZRGqxED0: Dictionary) -> String:
	var __Lp3oKehWfsW0XfkhBsa1wJgz: int = maxi(App.__iJzy1hAJBRqw29e5Qa_DWSi0(str(__F3rTIYdzB2C5f1kKZRGqxED0["label"])), 1)
	return "%s　%s" % [tr("UI_DOCK_SUB_LEVEL") % int(__F3rTIYdzB2C5f1kKZRGqxED0["level"]), tr("UI_DOCK_SUB_SEQ") % __Lp3oKehWfsW0XfkhBsa1wJgz]
func __VhgAU76GZ_WNQC3t9XYyVMlb(__tn4I4XCZV9WTVd75Fs1DvJyF: CanvasItem, __EjCSuOC3ZWjwm2mUeSU6Vnhk: Dictionary, far: bool) -> void :
	for __arPGyb9NEdKD0uH_gHqi_YQA: Array in __EjCSuOC3ZWjwm2mUeSU6Vnhk.get("turrets_far" if far else "turrets", []):
		var s: __H2jKfddttLiR1Mfv697VtMqG = __arPGyb9NEdKD0uH_gHqi_YQA[2]
		if s != null:
			s.frame(0).__XWs5ocCZJFqvH9sw_eqvYZ_N(__tn4I4XCZV9WTVd75Fs1DvJyF, (__arPGyb9NEdKD0uH_gHqi_YQA[3] as Vector2) + Vector2(s.__2ZhP3pgJkeplzgK9Ky4cqSZb))
func __6RQ0Bs9HbjVqBcTvXPELn4ea(__IvLvb38mZGkDZQkjkDY3weup: CanvasItem, __C2v1BN8t1DqomdLD4fxvN6T0: Dictionary, far: bool) -> void :
	for __Kg03XsWr_X7iR8dLJxoVwCWS: Array in __C2v1BN8t1DqomdLD4fxvN6T0.get("turrets_far" if far else "turrets", []):
		var b: __H2jKfddttLiR1Mfv697VtMqG = __Kg03XsWr_X7iR8dLJxoVwCWS[1]
		b.frame(0).__XWs5ocCZJFqvH9sw_eqvYZ_N(__IvLvb38mZGkDZQkjkDY3weup, (__Kg03XsWr_X7iR8dLJxoVwCWS[3] as Vector2) + Vector2(b.__2ZhP3pgJkeplzgK9Ky4cqSZb))
var __zABAFBwuGIufBHjRN9OzcNUm: __feayI5y05J3ON9FtctrJOCuc
const __ZoLgIGfy8poU0XzpD9xZ3YZa: PackedInt32Array = [21, 22, 22, 20]
var __AtE8nbDg8f4kT_S17xNL7a5N: __pT6jZw1fUvWomUDaJvLtM_kC
func _redraw() -> void :
	for __evPjhWO9oRNvWGx1hwHpU9dB: __XZQIsX2REk1j2LWZtbLIAovG in __ORPVAwaEZaG_WUKCzYPqV3CM:
		__evPjhWO9oRNvWGx1hwHpU9dB.queue_redraw()
	for __joaNnwCR5tB0UzFCK135RX48: __XZQIsX2REk1j2LWZtbLIAovG in __dAGqnexg_IDbNw344d0sOBgZ:
		__joaNnwCR5tB0UzFCK135RX48.queue_redraw()
func __eNTrtKMaBccTBl_Mai1EhOMV(__goWeUeRjM3mb_bFcwpxdaLXw: int, count: int) -> Dictionary:
	var __OjFkL1MKo4LHzETjHE9qy7Vy: __Se4EsxPBCHX48h1ZS5MexaMl = App.__PtNURh2PaYHMgsPlkLtni90Y()
	var __Jx8L9N0w7qKEwICG8xYyW73d: String = __MRgAcPuNvSjtNvNirEW1YRMP.get("kind", "")
	var __Kyha0XRGeIyJ4t4bBHuZCT3G: int = int(__MRgAcPuNvSjtNvNirEW1YRMP.get("index", 0))
	var __rQRbwkRDefzXJBiMtxwBnwpw: __s8yZigV26lPAvEmbOWzMbnjE = __kSFTyf6nLIFkdB6li7_pZbjR(__YJgAymCaLB78BrFx7OQpn545, __Jx8L9N0w7qKEwICG8xYyW73d, __Kyha0XRGeIyJ4t4bBHuZCT3G, __goWeUeRjM3mb_bFcwpxdaLXw, count)
	var __U0mMTfqrTkpRGcGpDPyTQcP2: int = App.__M0ImV248NGNrBFXy9NCs5jwX().__RuEf8sDpDtu0ArTJYzf6W0JG() if __kinsDyUwBqfk_kcYtvIhl2eK else 0
	var __sgq5Mw4f7turT23hZOS8eRLW: Vector2i = __OjFkL1MKo4LHzETjHE9qy7Vy.__77YZ0E3pilwCWMSZ5lHzv_es(__YJgAymCaLB78BrFx7OQpn545)
	var __4hrHlX5Q2eR4zjac0igiSFZU: Vector2i = __OjFkL1MKo4LHzETjHE9qy7Vy.__77YZ0E3pilwCWMSZ5lHzv_es(__rQRbwkRDefzXJBiMtxwBnwpw)
	var __dCPtspRLnkQJ2UNIWMZmDjHh: String = ""
	if __Jx8L9N0w7qKEwICG8xYyW73d == "G" or __Jx8L9N0w7qKEwICG8xYyW73d == "S":
		__dCPtspRLnkQJ2UNIWMZmDjHh = tr("UI_MARKET_BULK_FIT") % [__7Mjw8rGwZR13HeV6a47gwnIG(__Jx8L9N0w7qKEwICG8xYyW73d, __goWeUeRjM3mb_bFcwpxdaLXw).size(), (meti_main_market_count() if __Jx8L9N0w7qKEwICG8xYyW73d == "G" else __NOGqr86hxqhZaYA6HjbWlY2N(__Jx8L9N0w7qKEwICG8xYyW73d))]
	elif __Jx8L9N0w7qKEwICG8xYyW73d == "L":
		__dCPtspRLnkQJ2UNIWMZmDjHh = tr("UI_MARKET_BULK_FIT_TORP") % __NOGqr86hxqhZaYA6HjbWlY2N(__Jx8L9N0w7qKEwICG8xYyW73d)
	if __Jx8L9N0w7qKEwICG8xYyW73d in ["A", "B", "SA", "SB"]:
		var meti_count = meti_ammo_targets(__YJgAymCaLB78BrFx7OQpn545, __Jx8L9N0w7qKEwICG8xYyW73d, __Kyha0XRGeIyJ4t4bBHuZCT3G, __goWeUeRjM3mb_bFcwpxdaLXw).size() if bool(__MRgAcPuNvSjtNvNirEW1YRMP.get("bulk", false)) else 1
		__dCPtspRLnkQJ2UNIWMZmDjHh = "套用 %d 座火砲的 %s 彈艙，每座 %d 箱；另一彈艙保留" % [meti_count, "A" if __Jx8L9N0w7qKEwICG8xYyW73d.ends_with("A") else "B", count]
	return {"bulk_note": __dCPtspRLnkQJ2UNIWMZmDjHh, "before": __sgq5Mw4f7turT23hZOS8eRLW.x + __U0mMTfqrTkpRGcGpDPyTQcP2, "after": __4hrHlX5Q2eR4zjac0igiSFZU.x + __U0mMTfqrTkpRGcGpDPyTQcP2, "limit": __sgq5Mw4f7turT23hZOS8eRLW.y, "cost": __JwSiZuZjR6gRSDzlX_9CypDI(__Jx8L9N0w7qKEwICG8xYyW73d, __Kyha0XRGeIyJ4t4bBHuZCT3G, __goWeUeRjM3mb_bFcwpxdaLXw, count), "unit": __bdSuhO73wCElsaHHBK60fLLA(__Jx8L9N0w7qKEwICG8xYyW73d, __goWeUeRjM3mb_bFcwpxdaLXw), "charged": __Jx8L9N0w7qKEwICG8xYyW73d in __xxmB0C1mVHhNScnhHpjuF4zI or __9MFWgnc8oYQpY6kqM0OFfhrH.__FAd2LSsW1U_L7jgbNmhezEmO(), "err": __OjFkL1MKo4LHzETjHE9qy7Vy.__BGxXnVzPsmPLUaUtEL38SXTm(__rQRbwkRDefzXJBiMtxwBnwpw), "credits": App.__M0ImV248NGNrBFXy9NCs5jwX().__ktyxvkLP8cTjwSfnZb3DAVcL}
func __g6q9T1VmtoQE6bUvlCkH1PIZ(__aAEE_YsTamAYOknD0o9OBKCp: String) -> void :
	__aBhCjT5h4HuVdMnKzKKIXLBp = __aAEE_YsTamAYOknD0o9OBKCp
	var __MFdTDKdpBaKWFRVtQcd0zzLV: bool = __aAEE_YsTamAYOknD0o9OBKCp == "shipyard"
	__bLKLb0Khmx9u_g9HRmoM6tG6.visible = __MFdTDKdpBaKWFRVtQcd0zzLV
	if __pndlxY_XCFFxBsvt9SrAMHXa != null:
		__pndlxY_XCFFxBsvt9SrAMHXa.visible = __MFdTDKdpBaKWFRVtQcd0zzLV
	if __Lnl7EUrWdzkuBnGqxTLllE5o != null:
		__Lnl7EUrWdzkuBnGqxTLllE5o.visible = __MFdTDKdpBaKWFRVtQcd0zzLV
	if __5rz7a76K5lyi3GlEigYE8q9G != null:
		__5rz7a76K5lyi3GlEigYE8q9G.visible = __MFdTDKdpBaKWFRVtQcd0zzLV
	if __bqpvtk4llmiFJQmT5SzgWELV != null:
		__bqpvtk4llmiFJQmT5SzgWELV.visible = __MFdTDKdpBaKWFRVtQcd0zzLV
		__AtE8nbDg8f4kT_S17xNL7a5N.visible = __MFdTDKdpBaKWFRVtQcd0zzLV
	if __zABAFBwuGIufBHjRN9OzcNUm != null:
		__zABAFBwuGIufBHjRN9OzcNUm.visible = __MFdTDKdpBaKWFRVtQcd0zzLV and not __DpM0JQWB6EqgMh3WJZSlHODu and __DO5AS1j65TYeEwkGONIhQmLt == "crew"
	if __QGam_vw7iuxNHReFko2qucjH != null:
		__QGam_vw7iuxNHReFko2qucjH.visible = __MFdTDKdpBaKWFRVtQcd0zzLV and not __DpM0JQWB6EqgMh3WJZSlHODu and __DO5AS1j65TYeEwkGONIhQmLt == "ship"
		__QGam_vw7iuxNHReFko2qucjH.__UdSBpj0iQgfcszOtAZdxp8FV()
	if __aZ9T7TmaIvmS1Lo85UiNhrn8 != null:
		__aZ9T7TmaIvmS1Lo85UiNhrn8.visible = __MFdTDKdpBaKWFRVtQcd0zzLV
		__ezxmIHAAQKmXttLHPr9Bj08Z.visible = __MFdTDKdpBaKWFRVtQcd0zzLV
		__CRSM2ZrcdfHkm8J0BLnWEhoo()
	if __f3ySEJHZJ46_L34koIBeTfDe != null and not __MFdTDKdpBaKWFRVtQcd0zzLV:
		__4pls2eyn7uV4ST2IGlXwuh6D()
	( %TopBar as Control).visible = __MFdTDKdpBaKWFRVtQcd0zzLV or not __kinsDyUwBqfk_kcYtvIhl2eK
	if __WthKfcvjK4RJwtX6snlMJlVa != null:
		__WthKfcvjK4RJwtX6snlMJlVa.visible = not __MFdTDKdpBaKWFRVtQcd0zzLV
		__WthKfcvjK4RJwtX6snlMJlVa.set_title(__cqDq9BUy3jf_ObmeDukYBAN_.__OONHyCTSR21XSZCPih5eP_C2.__BDIHp_oicX29_FZP8YTDA5sS)
	__zpodpOyA68LGBNJ48lap636B()
	__Ua_bI8NjP7cgYQVgxQBQi5FZ()
func __67BernrIZLOOyCrtH1sZIznx() -> float:
	var __J7GhH73wnJFE0soRiIk34Diw: Control = %TopBar
	if __J7GhH73wnJFE0soRiIk34Diw.visible:
		return __J7GhH73wnJFE0soRiIk34Diw.get_global_rect().end.y + 8.0
	if __CgtEZnFtJYvrLjlSjFnhNN9n != null:
		return __CgtEZnFtJYvrLjlSjFnhNN9n.canvas.position.y + __ygqZC5GYwvDxRK4lKL33IS35 * __CgtEZnFtJYvrLjlSjFnhNN9n.__GoH11sKPryvfRgY_yZp5fB4l() + 8.0
	return super ()
func __dt7YLmSt2r4RMGTdtdpBlSzA(__CB0VYp9BXzdxN8Cy6I1Ltedh: Control) -> void :
	__24qhWIUVEfyan5lj70t1BnRb = Control.new()
	__24qhWIUVEfyan5lj70t1BnRb.set_anchors_preset(Control.PRESET_FULL_RECT)
	__24qhWIUVEfyan5lj70t1BnRb.mouse_filter = Control.MOUSE_FILTER_STOP
	__24qhWIUVEfyan5lj70t1BnRb.visible = false
	__CB0VYp9BXzdxN8Cy6I1Ltedh.add_child(__24qhWIUVEfyan5lj70t1BnRb)
	var __VRtoP8D7PdcPdqOh9tURppLR: = ColorRect.new()
	__VRtoP8D7PdcPdqOh9tURppLR.color = Color(0, 0, 0, 0.45)
	__VRtoP8D7PdcPdqOh9tURppLR.set_anchors_preset(Control.PRESET_FULL_RECT)
	__VRtoP8D7PdcPdqOh9tURppLR.mouse_filter = Control.MOUSE_FILTER_IGNORE
	__24qhWIUVEfyan5lj70t1BnRb.add_child(__VRtoP8D7PdcPdqOh9tURppLR)
	var __QhbVCrugd01PQbmMAysRscd6: = __1GzxRRq_riXfZWJxreGQ01mB.new()
	__QhbVCrugd01PQbmMAysRscd6.__YkxOHCRPfVhEt9AOYmz_M5tL = Vector2(__pDD4VW1FqZzXRK1m9Ft3JOAG.__qkI9rzzPHG3olOfJc5DxIE0c, __pDD4VW1FqZzXRK1m9Ft3JOAG.__leD6A5XRn3zKfwhALPi2EQS0)
	__QhbVCrugd01PQbmMAysRscd6.anchor_mode = "center"
	__QhbVCrugd01PQbmMAysRscd6.__d0IHJyvtuIdphI0Mfe6hZoCj = true
	__QhbVCrugd01PQbmMAysRscd6.__1gDX01ISoTyfnXw16aX6FHOJ = 1.6
	__24qhWIUVEfyan5lj70t1BnRb.add_child(__QhbVCrugd01PQbmMAysRscd6)
	__cINzBwGjtqDi2gNY5uWxxKya = __pDD4VW1FqZzXRK1m9Ft3JOAG.new()
	__cINzBwGjtqDi2gNY5uWxxKya.__KK1ZJYgA5tZw7EWXPDpHTXDo = __Rn1CNZSh1cBqnYuSO_5A3gqA
	__cINzBwGjtqDi2gNY5uWxxKya.confirmed.connect(__4y42iv09gwsmIpETTIbo7IZO)
	__cINzBwGjtqDi2gNY5uWxxKya.closed.connect( func() -> void : __24qhWIUVEfyan5lj70t1BnRb.visible = false)
	__QhbVCrugd01PQbmMAysRscd6.__8TnddZOxzOy43QYORM4CVDuX.add_child(__cINzBwGjtqDi2gNY5uWxxKya)
	__QhbVCrugd01PQbmMAysRscd6.resized.connect( func() -> void : __cINzBwGjtqDi2gNY5uWxxKya.queue_redraw())
func __jKRAoSDLaIkEgmrqlSCQwgKI() -> void :
	__M3mMe5n3JrbgRvzvIt9w1QZt.visible = false
	__OLIvZVUTptJkSyJvw3VfbpFx.mouse_filter = Control.MOUSE_FILTER_STOP
	__OLIvZVUTptJkSyJvw3VfbpFx.process_mode = Node.PROCESS_MODE_INHERIT
const __zlnz5mNlmBKUv1G0odTuawbp: = Color(0.11, 0.21, 0.32, 0.95)
var __QGam_vw7iuxNHReFko2qucjH: __wjUQUfgQzSj2YNHkTbwcrJ9W
const __MRdyzRlkxacGIHdEISIwXvvZ: = Vector2(50, -19)
var __DO5AS1j65TYeEwkGONIhQmLt: String = "crew"
func __zpodpOyA68LGBNJ48lap636B() -> void :
	if __5rz7a76K5lyi3GlEigYE8q9G != null:
		var __go5eoYcsnFiV9wbBwg0p7kIH: float = __CgtEZnFtJYvrLjlSjFnhNN9n.__GoH11sKPryvfRgY_yZp5fB4l()
		__5rz7a76K5lyi3GlEigYE8q9G.scale = Vector2(__R5d7t9GbgflrBdLy_NZHGRej, __R5d7t9GbgflrBdLy_NZHGRej)
		var __dv5fbX8wolRS1HrysJpyjINK: Vector2 = __CgtEZnFtJYvrLjlSjFnhNN9n.canvas.position + __5HupLyuedvtW1LzkmaCuR4xT * __go5eoYcsnFiV9wbBwg0p7kIH - __5rz7a76K5lyi3GlEigYE8q9G.size * (__R5d7t9GbgflrBdLy_NZHGRej - 1.0) * 0.5 - Vector2(0, __1OBaxTiunLXQFo13Se2TAg0r)
		var __c52axmlClR9J7hKdsNcpiXmN: float = 0.0
		if __bLKLb0Khmx9u_g9HRmoM6tG6 != null and __bLKLb0Khmx9u_g9HRmoM6tG6.open:
			var r: Rect2 = __bLKLb0Khmx9u_g9HRmoM6tG6.__Gc9pvpcX3aEx1tMHweM0N4bO()
			__c52axmlClR9J7hKdsNcpiXmN = maxf(0.0, r.end.x - __CgtEZnFtJYvrLjlSjFnhNN9n.global_position.x + 12.0 - __dv5fbX8wolRS1HrysJpyjINK.x)
		__5rz7a76K5lyi3GlEigYE8q9G.position = (__dv5fbX8wolRS1HrysJpyjINK + Vector2(__c52axmlClR9J7hKdsNcpiXmN, 0)).round()
		if __bqpvtk4llmiFJQmT5SzgWELV != null:
			for __6pGyoaZI6lolnzk307fWk4TJ: Array in [[__bqpvtk4llmiFJQmT5SzgWELV, __GmL2pr1EhdpRkHDFmLem52M6], [__AtE8nbDg8f4kT_S17xNL7a5N, __eyxnY3dCgzNC6UWKdyRM1uNn]]:
				var b: __pT6jZw1fUvWomUDaJvLtM_kC = __6pGyoaZI6lolnzk307fWk4TJ[0]
				b.scale = Vector2(__6XwTq56FAcq6zR97wsH9ZuXC, __6XwTq56FAcq6zR97wsH9ZuXC)
				b.position = (__CgtEZnFtJYvrLjlSjFnhNN9n.canvas.position + (__6pGyoaZI6lolnzk307fWk4TJ[1] as Vector2) * __go5eoYcsnFiV9wbBwg0p7kIH - b.size * __6XwTq56FAcq6zR97wsH9ZuXC * 0.5).round()
	if __kinsDyUwBqfk_kcYtvIhl2eK and __CgtEZnFtJYvrLjlSjFnhNN9n != null:
		( %TopBar as Control).offset_top = 8.0 if __aBhCjT5h4HuVdMnKzKKIXLBp == "shipyard" else __CgtEZnFtJYvrLjlSjFnhNN9n.canvas.position.y + __ygqZC5GYwvDxRK4lKL33IS35 * __CgtEZnFtJYvrLjlSjFnhNN9n.__GoH11sKPryvfRgY_yZp5fB4l() + 6.0
func __HGdwN5tTR0yrgGd9chZehaPO() -> void :
	__OLIvZVUTptJkSyJvw3VfbpFx.__Zs_NRND2aIHjT0QBiS5yVaRm(__YJgAymCaLB78BrFx7OQpn545)
	__f3ySEJHZJ46_L34koIBeTfDe.visible = true
func __oUqJV9BoP5jehKHsmHxmIDXm(__AAJPjlOMUexxyvBFqpmZ5hMz: CanvasItem, near: bool, __PXpsJzgKf_UYqgjfW06ZN0M0: Dictionary) -> void :
	if __PXpsJzgKf_UYqgjfW06ZN0M0.is_empty():
		return
	var __c6nAySalHVbDFSmakrxjORwR: int = int(__PXpsJzgKf_UYqgjfW06ZN0M0.get("nation", 1))
	var __K1U1DIdFMayjaNcOr1iicHcj: Texture2D = Assets.__5jsDzv03vcgcph1KhyTBrwXv(__c6nAySalHVbDFSmakrxjORwR, bool(__PXpsJzgKf_UYqgjfW06ZN0M0.get("night", false)), near)
	if __K1U1DIdFMayjaNcOr1iicHcj == null:
		return
	var __LVJFlbEqa97zKBU5E6_ItQuJ: Vector2 = Assets.__2VhOwFJtK2PwytTVuRg2CqHM(__c6nAySalHVbDFSmakrxjORwR)
	if __XwGmCs7gUex6WMx0F0Lapr6y.__XjGaUOWs0Np2e5CRYzKY4VNU():
		__AAJPjlOMUexxyvBFqpmZ5hMz.draw_texture(__K1U1DIdFMayjaNcOr1iicHcj, __LVJFlbEqa97zKBU5E6_ItQuJ)
	else:
		__AAJPjlOMUexxyvBFqpmZ5hMz.draw_texture_rect_region(__K1U1DIdFMayjaNcOr1iicHcj, Rect2(Vector2.ZERO, __8ey3YOIS4Ufd_FwL8Ineryu9), Rect2( - __LVJFlbEqa97zKBU5E6_ItQuJ, __8ey3YOIS4Ufd_FwL8Ineryu9))
func __nghmrWgGzA35SxZI2P1Anffp(s: Dictionary, ___EVm3aik62buuql7bcaMBsFJ: String) -> String:
	if int(s["kind"]) == __Se4EsxPBCHX48h1ZS5MexaMl.__4Pcd1OiOt0B8w5S3xs6Gpm_P:
		return "%s HE %d" % [___EVm3aik62buuql7bcaMBsFJ, int(s["he"])]
	return "HE: %d" % int(s["he"]) if int(s["he"]) > 0 else ___EVm3aik62buuql7bcaMBsFJ
func __Qy2_Yg19jJ_onLveAVf4WaQq(___5TiTly6hdM_faPBrIoUxtJa: Control) -> void :
	var __XSJg6h9nhVJDfKgV5d6BRLVE: = Button.new()
	__XSJg6h9nhVJDfKgV5d6BRLVE.text = tr("UI_EQUIP_BTN")
	__XSJg6h9nhVJDfKgV5d6BRLVE.toggle_mode = true
	__XSJg6h9nhVJDfKgV5d6BRLVE.toggled.connect( func(__9wPR9t6xfDViMza7L8x0sZB4: bool) -> void :
		if __9wPR9t6xfDViMza7L8x0sZB4:
			__HGdwN5tTR0yrgGd9chZehaPO()
		else:
			__4pls2eyn7uV4ST2IGlXwuh6D())
	( %Pick as Control).get_parent().add_child(__XSJg6h9nhVJDfKgV5d6BRLVE)
	( %Pick as Control).get_parent().move_child(__XSJg6h9nhVJDfKgV5d6BRLVE, ( %Pick as Control).get_index() + 1)
	var __Te5pM75_I0ZR_fisLtpKXUaU: = Button.new()
	__Te5pM75_I0ZR_fisLtpKXUaU.text = tr("UI_NEW_SHIP_BTN")
	__Te5pM75_I0ZR_fisLtpKXUaU.tooltip_text = tr("UI_BUY_SHIP_FRAME")
	__Te5pM75_I0ZR_fisLtpKXUaU.pressed.connect(__GmRW88Xewr0JBlHpbJsjuBQm)
	__XSJg6h9nhVJDfKgV5d6BRLVE.get_parent().add_child(__Te5pM75_I0ZR_fisLtpKXUaU)
	__XSJg6h9nhVJDfKgV5d6BRLVE.get_parent().move_child(__Te5pM75_I0ZR_fisLtpKXUaU, __XSJg6h9nhVJDfKgV5d6BRLVE.get_index() + 1)
	__f3ySEJHZJ46_L34koIBeTfDe = __1GzxRRq_riXfZWJxreGQ01mB.new()
	__f3ySEJHZJ46_L34koIBeTfDe.anchor_mode = "center"
	__f3ySEJHZJ46_L34koIBeTfDe.__d0IHJyvtuIdphI0Mfe6hZoCj = true
	__f3ySEJHZJ46_L34koIBeTfDe.__1gDX01ISoTyfnXw16aX6FHOJ = 2.0
	__f3ySEJHZJ46_L34koIBeTfDe.visible = false
	___5TiTly6hdM_faPBrIoUxtJa.add_child(__f3ySEJHZJ46_L34koIBeTfDe)
	__OLIvZVUTptJkSyJvw3VfbpFx = __vkUw3hIvnFxkI0lKRsW_x52c.new()
	__OLIvZVUTptJkSyJvw3VfbpFx.position = __kfMZ6oUfTBEE3cf4diKyUxhN
	__OLIvZVUTptJkSyJvw3VfbpFx.closed.connect( func() -> void : __XSJg6h9nhVJDfKgV5d6BRLVE.button_pressed = false)
	__OLIvZVUTptJkSyJvw3VfbpFx.__5dOpWU_ha4oiYZpAS9KePUB4.connect(__vBWmMEhTlUHMKip4iGCUpqeV)
	__f3ySEJHZJ46_L34koIBeTfDe.__8TnddZOxzOy43QYORM4CVDuX.add_child(__OLIvZVUTptJkSyJvw3VfbpFx)
	__M3mMe5n3JrbgRvzvIt9w1QZt = __dr2CVyLJ3jYjG9eLwJgEkSvf.new()
	__M3mMe5n3JrbgRvzvIt9w1QZt.closed.connect(__jKRAoSDLaIkEgmrqlSCQwgKI)
	__M3mMe5n3JrbgRvzvIt9w1QZt.__ZJpLWmdiFfMQRYFFW25n6R28.connect(__oNXMHUSsPA1w6ptv1axRE83e)
	__M3mMe5n3JrbgRvzvIt9w1QZt.__KK1ZJYgA5tZw7EWXPDpHTXDo = __eNTrtKMaBccTBl_Mai1EhOMV
	__M3mMe5n3JrbgRvzvIt9w1QZt.__pWV6tPzqRR1jsRTC__ReP87r.connect(__ootmMmOyDzknp1ZTjZr6AIDH)
	___5TiTly6hdM_faPBrIoUxtJa.add_child(__M3mMe5n3JrbgRvzvIt9w1QZt)
	__dt7YLmSt2r4RMGTdtdpBlSzA(___5TiTly6hdM_faPBrIoUxtJa)
	__f3ySEJHZJ46_L34koIBeTfDe.set_meta("button", __XSJg6h9nhVJDfKgV5d6BRLVE)
	__f3ySEJHZJ46_L34koIBeTfDe.resized.connect( func() -> void :
		__OLIvZVUTptJkSyJvw3VfbpFx.queue_redraw())
const __zAqqHx7kS6MXSwnhecUSxyVu: = 520.0
func __6qODxp1VoZzlarYbuG6CVBNH() -> int:
	return __cG_zbW1sotj7reUf4u7FXswZ if __kinsDyUwBqfk_kcYtvIhl2eK else (App.__72kAp8sMQh2gIPcLl7onOgPE(__YJgAymCaLB78BrFx7OQpn545.__WeB9Hi0OxaFBUuwm2WU2qKEH) if __YJgAymCaLB78BrFx7OQpn545 != null else 0)
var __MRgAcPuNvSjtNvNirEW1YRMP: Dictionary = {}
var __24qhWIUVEfyan5lj70t1BnRb: Control
func __t1LFd_voc1X6LWRklLXhZb2U(id: String, d: Dictionary) -> void :
	var __B2WUWSjDT54nUipm3mRNXZI0: int = int(d.get("main", -1))
	var __LuT2VUVARKh9bAkRxSsnSV7b: int = int(d.get("side", -1))
	var __YIEG7Mi_VReN8MRzWrOaH1PM: int = int(d.get("torp", -1))
	match id:
		"gun":
			if __B2WUWSjDT54nUipm3mRNXZI0 >= 0:
				__HuRyg1NMVNcEpLPmiIJdll32("G", __B2WUWSjDT54nUipm3mRNXZI0)
			elif __LuT2VUVARKh9bAkRxSsnSV7b >= 0:
				__HuRyg1NMVNcEpLPmiIJdll32("S", __LuT2VUVARKh9bAkRxSsnSV7b)
		"tp":
			__HuRyg1NMVNcEpLPmiIJdll32("L", __YIEG7Mi_VReN8MRzWrOaH1PM)
		"cargo_a", "cargo_b", "torpedo":
			__H_kQDAV6SVBhX2avpZXAHYOV()
			if id == "torpedo":
				__vBWmMEhTlUHMKip4iGCUpqeV("T", __YIEG7Mi_VReN8MRzWrOaH1PM)
			elif __B2WUWSjDT54nUipm3mRNXZI0 >= 0:
				__vBWmMEhTlUHMKip4iGCUpqeV("A" if id == "cargo_a" else "B", __B2WUWSjDT54nUipm3mRNXZI0)
			else:
				__vBWmMEhTlUHMKip4iGCUpqeV("SA" if id == "cargo_a" else "SB", __LuT2VUVARKh9bAkRxSsnSV7b)
		"fcs":
			__HuRyg1NMVNcEpLPmiIJdll32("F", 0)
		"air":
			__HuRyg1NMVNcEpLPmiIJdll32("P", int(d["air"]))
		"airarm":
			__HuRyg1NMVNcEpLPmiIJdll32("M", int(d["air"]))
		"armor":
			__HuRyg1NMVNcEpLPmiIJdll32("R", int(d["zone"]))
		"sell":
			__bW6UZkb_vKAZo4WNoJk8Av2K(d)
var __xorSo_i34n5tNZmGntPVcw5H: Array = []
func __Rn1CNZSh1cBqnYuSO_5A3gqA(__i23P7rta5K9ovvSvKxE4VQ_J: PackedInt32Array) -> Dictionary:
	var __S3Y8lueFexuG65uqLslSpX8W: __Se4EsxPBCHX48h1ZS5MexaMl = App.__PtNURh2PaYHMgsPlkLtni90Y()
	var __76eEN0CC4v77CkgCQhcRsrSr: __s8yZigV26lPAvEmbOWzMbnjE = __YJgAymCaLB78BrFx7OQpn545.__12ty6aWt7_v7eYEbKtP71Dlf()
	__76eEN0CC4v77CkgCQhcRsrSr.__cQ8JInnnrEoGxd_1jglej7pR = __i23P7rta5K9ovvSvKxE4VQ_J if __i23P7rta5K9ovvSvKxE4VQ_J != __Se4EsxPBCHX48h1ZS5MexaMl.__z60ooVwI9Q0G4gXJuZ_QzkIy([]) else PackedInt32Array()
	var __F9sO9e2OyaIVDo3vads3uEul: int = App.__M0ImV248NGNrBFXy9NCs5jwX().__RuEf8sDpDtu0ArTJYzf6W0JG() if __kinsDyUwBqfk_kcYtvIhl2eK else 0
	var __NHI3bOe6dpax5bFnZ6TBCl1T: Vector2i = __S3Y8lueFexuG65uqLslSpX8W.__77YZ0E3pilwCWMSZ5lHzv_es(__YJgAymCaLB78BrFx7OQpn545)
	var __hReFUonSItm4NFP0OcAC3kvam: Vector2i = __S3Y8lueFexuG65uqLslSpX8W.__77YZ0E3pilwCWMSZ5lHzv_es(__76eEN0CC4v77CkgCQhcRsrSr)
	var __5D1OinWDydSlTHOKYvTVP8Ci: int = int(__S3Y8lueFexuG65uqLslSpX8W.__ofKSCLcCg7jWtqacDa153ehk(__YJgAymCaLB78BrFx7OQpn545.__WeB9Hi0OxaFBUuwm2WU2qKEH).get("hp", 0))
	return {"before": __NHI3bOe6dpax5bFnZ6TBCl1T.x + __F9sO9e2OyaIVDo3vads3uEul, "after": __hReFUonSItm4NFP0OcAC3kvam.x + __F9sO9e2OyaIVDo3vads3uEul, "limit": __NHI3bOe6dpax5bFnZ6TBCl1T.y, "hp": __5D1OinWDydSlTHOKYvTVP8Ci, "hp_max": __5D1OinWDydSlTHOKYvTVP8Ci, "speed": int(__2ZIL9u7_cM4KOmaAUAdneX5d.__bNPpeuRkyJLCHe1DdXcSlDqu.get(__S3Y8lueFexuG65uqLslSpX8W.__rIbrGNBQXI7CsdYVLpVwKrNI(__YJgAymCaLB78BrFx7OQpn545.__WeB9Hi0OxaFBUuwm2WU2qKEH), __2ZIL9u7_cM4KOmaAUAdneX5d.__7LAX6iA_3EiLvNuT8tdV7o0O)), "err": __9iFcUUuz7hxSygPtA9oE6aBm(__76eEN0CC4v77CkgCQhcRsrSr), "credits": App.__M0ImV248NGNrBFXy9NCs5jwX().__ktyxvkLP8cTjwSfnZb3DAVcL if __kinsDyUwBqfk_kcYtvIhl2eK else 2147483647}
func __4zShpYdxjssLWetcx0uNyHo_(__umkYe0IJ31n2p2tSk96EdDVd: int) -> void :
	if __umkYe0IJ31n2p2tSk96EdDVd == __cG_zbW1sotj7reUf4u7FXswZ:
		return
	if not App.__M0ImV248NGNrBFXy9NCs5jwX().__aGKFFuWZttAOryPti7pfE3iP(__umkYe0IJ31n2p2tSk96EdDVd) or __Se4EsxPBCHX48h1ZS5MexaMl.__G8VgBybQlmXf2sdRasT3PwJT(__umkYe0IJ31n2p2tSk96EdDVd):
		UI.__FZyGB2TVbKGb1g8kgT4bm_x4(tr("UI_HARBOR_ERR_NO_CAPTAIN"))
		__l6GSBpoEn3a9XcT2fQAVy101()
		return
	if __LRKxUAEiOJmq3fPx9v5YOJtM.__o2yns4wyfNjWTsFheBhDAKxk():
		__l6GSBpoEn3a9XcT2fQAVy101()
		return
	if not __LRKxUAEiOJmq3fPx9v5YOJtM.__iACWPc5DDT8VteTDbO1HsjHg(__iAbDeha6hgeEpDzp_OVLHMcN) or not __LRKxUAEiOJmq3fPx9v5YOJtM.__pvKMMrRygmONo5HWHCDueUsI(get_tree(), __CgtEZnFtJYvrLjlSjFnhNN9n.canvas, __Z_Ja8I3PvbMOluuRp9xx0IIH.bind(__umkYe0IJ31n2p2tSk96EdDVd)):
		__Z_Ja8I3PvbMOluuRp9xx0IIH(__umkYe0IJ31n2p2tSk96EdDVd)
func __JwSiZuZjR6gRSDzlX_9CypDI(__BBXO4psz1i0Ep8qWdZxd6A5g: String, __JTggAb5eY84iDbzzGgkfz0KL: int, __sbUexePpkWUCd346ZtfhxEXt: int, count: int) -> int:
	if __BBXO4psz1i0Ep8qWdZxd6A5g in ["A", "B", "SA", "SB"] and bool(__MRgAcPuNvSjtNvNirEW1YRMP.get("bulk", false)):
		return meti_ammo_cost(__BBXO4psz1i0Ep8qWdZxd6A5g, __JTggAb5eY84iDbzzGgkfz0KL, __sbUexePpkWUCd346ZtfhxEXt, count)
	if __BBXO4psz1i0Ep8qWdZxd6A5g in __xxmB0C1mVHhNScnhHpjuF4zI:
		return __ydCl5L2QyDKE2SDpVsMZ5fEb(__BBXO4psz1i0Ep8qWdZxd6A5g, __JTggAb5eY84iDbzzGgkfz0KL, __sbUexePpkWUCd346ZtfhxEXt, count)
	if not __9MFWgnc8oYQpY6kqM0OFfhrH.__FAd2LSsW1U_L7jgbNmhezEmO():
		return 0
	var __GDOCuwRn1HZfTN_AVvOd4cr5: __Se4EsxPBCHX48h1ZS5MexaMl = App.__PtNURh2PaYHMgsPlkLtni90Y()
	if __BBXO4psz1i0Ep8qWdZxd6A5g in __nDMzIIBfjfebkTT_IF92ffWF and bool(__MRgAcPuNvSjtNvNirEW1YRMP.get("bulk", false)):
		var __vaLtQOrE0qXfcdMc1T0TEMgC: PackedInt32Array = __5S8plTABm1PqgD2ocfAKazy2(__BBXO4psz1i0Ep8qWdZxd6A5g)
		var __ZgaB9qgAqB_GGLnmDiZOt5Gw: int = 0
		for __E_Xs0dBDokh7d6G60WC48UFo: int in __7Mjw8rGwZR13HeV6a47gwnIG(__BBXO4psz1i0Ep8qWdZxd6A5g, __sbUexePpkWUCd346ZtfhxEXt):
			if __vaLtQOrE0qXfcdMc1T0TEMgC[__E_Xs0dBDokh7d6G60WC48UFo] != __sbUexePpkWUCd346ZtfhxEXt:
				__ZgaB9qgAqB_GGLnmDiZOt5Gw += 1
		return __ZgaB9qgAqB_GGLnmDiZOt5Gw * __bdSuhO73wCElsaHHBK60fLLA(__BBXO4psz1i0Ep8qWdZxd6A5g, __sbUexePpkWUCd346ZtfhxEXt)
	match __BBXO4psz1i0Ep8qWdZxd6A5g:
		"R":
			var __Xr5Ppjj_bW3RDT9z8cE41p9z: PackedInt32Array = App.__PtNURh2PaYHMgsPlkLtni90Y().__uCNDLIyQQRLcwA3z5vXmUuAz(__YJgAymCaLB78BrFx7OQpn545)
			var __2Qg9GwT1gplnzyLNtW3Jm7rq: int = __Xr5Ppjj_bW3RDT9z8cE41p9z[2 * __JTggAb5eY84iDbzzGgkfz0KL + 1] if __Xr5Ppjj_bW3RDT9z8cE41p9z[2 * __JTggAb5eY84iDbzzGgkfz0KL] == __sbUexePpkWUCd346ZtfhxEXt else 0
			return __9MFWgnc8oYQpY6kqM0OFfhrH.__DML16gO8cwjCLXpZX4VG3A4V(App.__PtNURh2PaYHMgsPlkLtni90Y().__eezCSxsQSp01HYni_60fHV16(__YJgAymCaLB78BrFx7OQpn545.__WeB9Hi0OxaFBUuwm2WU2qKEH)[__JTggAb5eY84iDbzzGgkfz0KL], count * __Se4EsxPBCHX48h1ZS5MexaMl.__MmvhtidBsePDvXycLyLNHv8h, __2Qg9GwT1gplnzyLNtW3Jm7rq)
		"G":
			return 0 if __YJgAymCaLB78BrFx7OQpn545.__dOsDavODOasdfPxqce2DEBC3[__JTggAb5eY84iDbzzGgkfz0KL] == __sbUexePpkWUCd346ZtfhxEXt else __bdSuhO73wCElsaHHBK60fLLA(__BBXO4psz1i0Ep8qWdZxd6A5g, __sbUexePpkWUCd346ZtfhxEXt)
		"S":
			return 0 if __GDOCuwRn1HZfTN_AVvOd4cr5.__PJZemYw0whDwrAt4vbBLpQ7w(__YJgAymCaLB78BrFx7OQpn545)[__JTggAb5eY84iDbzzGgkfz0KL] == __sbUexePpkWUCd346ZtfhxEXt else __bdSuhO73wCElsaHHBK60fLLA(__BBXO4psz1i0Ep8qWdZxd6A5g, __sbUexePpkWUCd346ZtfhxEXt)
		"L":
			return 0 if __GDOCuwRn1HZfTN_AVvOd4cr5.__7uBhyRNBJZP4s1InKu8Lo_y7(__YJgAymCaLB78BrFx7OQpn545)[__JTggAb5eY84iDbzzGgkfz0KL] == __sbUexePpkWUCd346ZtfhxEXt else __bdSuhO73wCElsaHHBK60fLLA(__BBXO4psz1i0Ep8qWdZxd6A5g, __sbUexePpkWUCd346ZtfhxEXt)
		"F":
			return 0 if __YJgAymCaLB78BrFx7OQpn545.__vwSAcybbCInOpnt2FbN4qz7L == __sbUexePpkWUCd346ZtfhxEXt else __bdSuhO73wCElsaHHBK60fLLA(__BBXO4psz1i0Ep8qWdZxd6A5g, __sbUexePpkWUCd346ZtfhxEXt)
		"E":
			return 0 if __GDOCuwRn1HZfTN_AVvOd4cr5.__Qw3k08OnVM2mR_e4yUtGgVFs(__YJgAymCaLB78BrFx7OQpn545) == __sbUexePpkWUCd346ZtfhxEXt else __bdSuhO73wCElsaHHBK60fLLA(__BBXO4psz1i0Ep8qWdZxd6A5g, __sbUexePpkWUCd346ZtfhxEXt)
		"P", "M":
			var __OvTQ32DfUDh4tyg3E0wFf2Yd: PackedInt32Array = __GDOCuwRn1HZfTN_AVvOd4cr5.__mgdM7ycmi3DNHzWo0uObSaPX(__YJgAymCaLB78BrFx7OQpn545)
			var __BOQXTfuROA0cnqWJNb0YeCJI: int = __Se4EsxPBCHX48h1ZS5MexaMl.__7H3uQhAdVTbh0QLkQVDDP1bw * __JTggAb5eY84iDbzzGgkfz0KL + (0 if __BBXO4psz1i0Ep8qWdZxd6A5g == "P" else 2)
			var __ejKNOlofZL_MjBM7rLDhiYjk: int = __OvTQ32DfUDh4tyg3E0wFf2Yd[__BOQXTfuROA0cnqWJNb0YeCJI + 1] if __OvTQ32DfUDh4tyg3E0wFf2Yd.size() > __BOQXTfuROA0cnqWJNb0YeCJI + 1 and __OvTQ32DfUDh4tyg3E0wFf2Yd[__BOQXTfuROA0cnqWJNb0YeCJI] == __sbUexePpkWUCd346ZtfhxEXt else 0
			return maxi(0, count - __ejKNOlofZL_MjBM7rLDhiYjk) * __bdSuhO73wCElsaHHBK60fLLA(__BBXO4psz1i0Ep8qWdZxd6A5g, __sbUexePpkWUCd346ZtfhxEXt)
	return 0
func __mqUFHwVuIEsH6CwazHRCsl7H(target: Variant) -> void :
	__xorSo_i34n5tNZmGntPVcw5H.append(target)
	if not __XwGmCs7gUex6WMx0F0Lapr6y.__XjGaUOWs0Np2e5CRYzKY4VNU():
		__UxRH136qCscJz2DBq4WJgk9g()
static func __sadJuUS1UT0UzhHxF1koKG0C(w: int) -> String:
	return "%.1f" % (w / 1000.0)
func __ukK0_ZksN9PJ7jluNvwiulpw(__hfqwen9T7ZpNc6HMT2VeSjro: __s8yZigV26lPAvEmbOWzMbnjE, __rYFEu7JdmiGUvPS12TME8Q0O: int) -> void :
	__hfqwen9T7ZpNc6HMT2VeSjro.__g7JC3EJmfsOWnIyqLGGB93eB = App.__PtNURh2PaYHMgsPlkLtni90Y().__mgdM7ycmi3DNHzWo0uObSaPX(__hfqwen9T7ZpNc6HMT2VeSjro).duplicate()
	var __0XBKk9KeN346Dif3pXWtxdcz: int = __Se4EsxPBCHX48h1ZS5MexaMl.__7H3uQhAdVTbh0QLkQVDDP1bw * __rYFEu7JdmiGUvPS12TME8Q0O
	__hfqwen9T7ZpNc6HMT2VeSjro.__g7JC3EJmfsOWnIyqLGGB93eB[__0XBKk9KeN346Dif3pXWtxdcz] = __s8yZigV26lPAvEmbOWzMbnjE.__1iBjWxIGtvWf0yGsmF7yzBIR
	__hfqwen9T7ZpNc6HMT2VeSjro.__g7JC3EJmfsOWnIyqLGGB93eB[__0XBKk9KeN346Dif3pXWtxdcz + 1] = 0
	__hfqwen9T7ZpNc6HMT2VeSjro.__g7JC3EJmfsOWnIyqLGGB93eB[__0XBKk9KeN346Dif3pXWtxdcz + 2] = __s8yZigV26lPAvEmbOWzMbnjE.__1iBjWxIGtvWf0yGsmF7yzBIR
	__hfqwen9T7ZpNc6HMT2VeSjro.__g7JC3EJmfsOWnIyqLGGB93eB[__0XBKk9KeN346Dif3pXWtxdcz + 3] = 0
	__hfqwen9T7ZpNc6HMT2VeSjro.__gyktaSCba5fvGkS2KC4ukPix = PackedInt32Array()
func __CRSM2ZrcdfHkm8J0BLnWEhoo() -> void :
	for __wWCh0y6Sw9HpGyUHeMTKomWW: Array in [[__aZ9T7TmaIvmS1Lo85UiNhrn8, "crew"], [__ezxmIHAAQKmXttLHPr9Bj08Z, "ship"]]:
		var __3wUblBSxThSiFhVbA76Gp_U_: Button = __wWCh0y6Sw9HpGyUHeMTKomWW[0]
		var __uxAMEdMcG464psMfqIurMszP: bool = __DO5AS1j65TYeEwkGONIhQmLt == __wWCh0y6Sw9HpGyUHeMTKomWW[1]
		var normal: StyleBoxFlat = __cl8LJq2mOhc3fU4d1Nb_BXOu(__yimngiolRStzqVnnRpqZIR9I, __eBt5HIxcCIYFCRhcyd21idU2.GOLD, 3) if __uxAMEdMcG464psMfqIurMszP else __cl8LJq2mOhc3fU4d1Nb_BXOu(__KzqJxC0rjxwigqZQErAFUdbv, __QztUZScy642DTR6_l0cQ30yE, 1)
		var hover: StyleBoxFlat = normal if __uxAMEdMcG464psMfqIurMszP else __cl8LJq2mOhc3fU4d1Nb_BXOu(__zlnz5mNlmBKUv1G0odTuawbp, __Wl_Qw9KUEfRrP_gP8ETPRbl4.__ZchexuGq1CyY27UYzkX1Ka2w, 1)
		for __3O2g1cmd0XAQmyO9r3mqJMHa: String in ["normal", "pressed", "focus"]:
			__3wUblBSxThSiFhVbA76Gp_U_.add_theme_stylebox_override(__3O2g1cmd0XAQmyO9r3mqJMHa, normal)
		for __p4G86RyN3gLiv7ampWXcltW_: String in ["hover", "hover_pressed"]:
			__3wUblBSxThSiFhVbA76Gp_U_.add_theme_stylebox_override(__p4G86RyN3gLiv7ampWXcltW_, hover)
		var __Zd45QbC5QbEEeXqa3D_wP7g8: Color = __eBt5HIxcCIYFCRhcyd21idU2.GOLD if __uxAMEdMcG464psMfqIurMszP else __t0NbhkC_eocFXs9HdejK9HTs
		for __9vUxH9mqzkKJ6aiwfeiWcnNH: String in ["font_color", "font_pressed_color", "font_focus_color"]:
			__3wUblBSxThSiFhVbA76Gp_U_.add_theme_color_override(__9vUxH9mqzkKJ6aiwfeiWcnNH, __Zd45QbC5QbEEeXqa3D_wP7g8)
		__3wUblBSxThSiFhVbA76Gp_U_.add_theme_color_override("font_hover_color", __eBt5HIxcCIYFCRhcyd21idU2.GOLD if __uxAMEdMcG464psMfqIurMszP else __Wl_Qw9KUEfRrP_gP8ETPRbl4.__pCUi6LToFPukNiGDrBwJ7It8)
		__3wUblBSxThSiFhVbA76Gp_U_.add_theme_color_override("font_hover_pressed_color", __eBt5HIxcCIYFCRhcyd21idU2.GOLD if __uxAMEdMcG464psMfqIurMszP else __Wl_Qw9KUEfRrP_gP8ETPRbl4.__pCUi6LToFPukNiGDrBwJ7It8)
func __blI3OKMoz5eY7cONdkS5OvD2(__U14oc1ytAHWmYjxRS0kLkGNX: String, __AfCaZskgFcKQWHpG3l2EMDeb: int, __wf5nesIbfIxYWEBJVUnWB0nG: int, count: int) -> void :
	var __qEx08x2yPtOQfC6Af4Ib1u3f: __Se4EsxPBCHX48h1ZS5MexaMl = App.__PtNURh2PaYHMgsPlkLtni90Y()
	var __RIhTmefW7zjOJIsL7Zi3S_N5: int = __YJgAymCaLB78BrFx7OQpn545.__WeB9Hi0OxaFBUuwm2WU2qKEH
	match __U14oc1ytAHWmYjxRS0kLkGNX:
		"G", "S", "L":
			var __eeGSwtODDGd1p8sulPOutQ5U: bool = bool(__MRgAcPuNvSjtNvNirEW1YRMP.get("bulk", false))
			var __3eMPPZBLT4Ij2aM_jO8a7O6f: PackedInt32Array = __5S8plTABm1PqgD2ocfAKazy2(__U14oc1ytAHWmYjxRS0kLkGNX)
			for __hKSfCRPWyVbqBIRnizvnzQuA: int in (__7Mjw8rGwZR13HeV6a47gwnIG(__U14oc1ytAHWmYjxRS0kLkGNX, __wf5nesIbfIxYWEBJVUnWB0nG) if __eeGSwtODDGd1p8sulPOutQ5U else PackedInt32Array([__AfCaZskgFcKQWHpG3l2EMDeb])):
				if __3eMPPZBLT4Ij2aM_jO8a7O6f[__hKSfCRPWyVbqBIRnizvnzQuA] != __wf5nesIbfIxYWEBJVUnWB0nG:
					__U7UMfwBewiXSLEeaDnywaCO7.__mzf94JP_Dp5fS1BWTUB50MxE(__RIhTmefW7zjOJIsL7Zi3S_N5, ___l8BVmKnenFDKyyKSS6nkhs2(__U14oc1ytAHWmYjxRS0kLkGNX, __hKSfCRPWyVbqBIRnizvnzQuA), __bdSuhO73wCElsaHHBK60fLLA(__U14oc1ytAHWmYjxRS0kLkGNX, __wf5nesIbfIxYWEBJVUnWB0nG), true)
		"F":
			__U7UMfwBewiXSLEeaDnywaCO7.__mzf94JP_Dp5fS1BWTUB50MxE(__RIhTmefW7zjOJIsL7Zi3S_N5, "fcs", __bdSuhO73wCElsaHHBK60fLLA(__U14oc1ytAHWmYjxRS0kLkGNX, __wf5nesIbfIxYWEBJVUnWB0nG), true)
		"P", "M":
			var __hRULhunzdLMesEksxDLdaZmY: PackedInt32Array = __qEx08x2yPtOQfC6Af4Ib1u3f.__mgdM7ycmi3DNHzWo0uObSaPX(__YJgAymCaLB78BrFx7OQpn545)
			var __00jPExU0OZ7k6lBfdiUbIGom: int = __Se4EsxPBCHX48h1ZS5MexaMl.__7H3uQhAdVTbh0QLkQVDDP1bw * __AfCaZskgFcKQWHpG3l2EMDeb + (0 if __U14oc1ytAHWmYjxRS0kLkGNX == "P" else 2)
			var __kGPlWbGYFwgq64sYt0hwuZkn: bool = __hRULhunzdLMesEksxDLdaZmY.size() > __00jPExU0OZ7k6lBfdiUbIGom + 1 and __hRULhunzdLMesEksxDLdaZmY[__00jPExU0OZ7k6lBfdiUbIGom] == __wf5nesIbfIxYWEBJVUnWB0nG
			__U7UMfwBewiXSLEeaDnywaCO7.__mzf94JP_Dp5fS1BWTUB50MxE(__RIhTmefW7zjOJIsL7Zi3S_N5, "air:%d" % __AfCaZskgFcKQWHpG3l2EMDeb, __JwSiZuZjR6gRSDzlX_9CypDI(__U14oc1ytAHWmYjxRS0kLkGNX, __AfCaZskgFcKQWHpG3l2EMDeb, __wf5nesIbfIxYWEBJVUnWB0nG, count), not __kGPlWbGYFwgq64sYt0hwuZkn and __U14oc1ytAHWmYjxRS0kLkGNX == "P")
		"R":
			var __BxeJQBTrxYCY8JgDPcT8cAS9: PackedInt32Array = __qEx08x2yPtOQfC6Af4Ib1u3f.__uCNDLIyQQRLcwA3z5vXmUuAz(__YJgAymCaLB78BrFx7OQpn545)
			__U7UMfwBewiXSLEeaDnywaCO7.__mzf94JP_Dp5fS1BWTUB50MxE(__RIhTmefW7zjOJIsL7Zi3S_N5, "armor:%d" % __AfCaZskgFcKQWHpG3l2EMDeb, __JwSiZuZjR6gRSDzlX_9CypDI(__U14oc1ytAHWmYjxRS0kLkGNX, __AfCaZskgFcKQWHpG3l2EMDeb, __wf5nesIbfIxYWEBJVUnWB0nG, count), __BxeJQBTrxYCY8JgDPcT8cAS9[2 * __AfCaZskgFcKQWHpG3l2EMDeb] != __wf5nesIbfIxYWEBJVUnWB0nG)
func __CZNkeeRfo0Z9Wuy80hOWdhXF(restart: bool) -> void :
	Music.play(Music.__evW2tId4SNKXX66cJhD9a0fv(__6qODxp1VoZzlarYbuG6CVBNH()), restart)
func __VkSeEGhVF0y6mvRsZYDTVhBy() -> Array[__s8yZigV26lPAvEmbOWzMbnjE]:
	return __U7UMfwBewiXSLEeaDnywaCO7.__vwjNIITOPVtRhfVJi6Wz56IY(__cG_zbW1sotj7reUf4u7FXswZ)
var __1oElkVOacHIBcLWKCKhilZGK: float = 0.0
func __jnStooA8TeJLu1KviYiYtn7w(__qauozn4KhinUPiznDXJo0UnX: bool) -> Array[__XZQIsX2REk1j2LWZtbLIAovG]:
	var __ndwMMdeWn_KuhlvG0339pUrS: Callable = ( func() -> Dictionary: return __v9ZnZMSMzoVWGyPBRc8ApWfd) if __qauozn4KhinUPiznDXJo0UnX else ( func() -> Dictionary: return __LcEmKczmLrorVyOBaMDnHamK)
	var __fpDtqFlZ8Jx_5dz9y50Wvqte: Array[__XZQIsX2REk1j2LWZtbLIAovG] = []
	__fpDtqFlZ8Jx_5dz9y50Wvqte.append(__JWQadZaoFI3ZbIo96MrrodHp(false, __ndwMMdeWn_KuhlvG0339pUrS))
	for far: bool in [true, false]:
		var ___z5CSrBdjt9CgQwAJbiV4elM: __XZQIsX2REk1j2LWZtbLIAovG = __Rco5woHwXiTlm6FD8ey5jNa8("mul", func(__zAAVWXTNcXohAuEVvHKZuUkc: CanvasItem) -> void : __VhgAU76GZ_WNQC3t9XYyVMlb(__zAAVWXTNcXohAuEVvHKZuUkc, __ndwMMdeWn_KuhlvG0339pUrS.call(), far))
		___z5CSrBdjt9CgQwAJbiV4elM.modulate = Color(0, 0, 0, 0.45)
		__fpDtqFlZ8Jx_5dz9y50Wvqte.append(___z5CSrBdjt9CgQwAJbiV4elM)
		__fpDtqFlZ8Jx_5dz9y50Wvqte.append(__Rco5woHwXiTlm6FD8ey5jNa8("alpha", func(__fAmmxbGS2vGkyLgFniyrd3fb: CanvasItem) -> void : __6RQ0Bs9HbjVqBcTvXPELn4ea(__fAmmxbGS2vGkyLgFniyrd3fb, __ndwMMdeWn_KuhlvG0339pUrS.call(), far)))
		if far:
			__fpDtqFlZ8Jx_5dz9y50Wvqte.append(__Rco5woHwXiTlm6FD8ey5jNa8("alpha", func(__ruEi78TZKPExFJmFkdyh_IbC: CanvasItem) -> void : __3VrZVwOZRlbabKn4WyXjjosd(__ruEi78TZKPExFJmFkdyh_IbC, __ndwMMdeWn_KuhlvG0339pUrS.call())))
	__fpDtqFlZ8Jx_5dz9y50Wvqte.append(__Rco5woHwXiTlm6FD8ey5jNa8("add", func(__yhrDg6lBl3PZRhB49RIeey3w: CanvasItem) -> void : __zzDwgebyDflDIvGdolf3Y07D(__yhrDg6lBl3PZRhB49RIeey3w, __ndwMMdeWn_KuhlvG0339pUrS.call())))
	__fpDtqFlZ8Jx_5dz9y50Wvqte.append(__Rco5woHwXiTlm6FD8ey5jNa8("alpha", func(__XAkqU4hRX5hq5jaByoQxokrJ: CanvasItem) -> void : __Q6NrDwYmtTJN8wYKH9Jgb0rw(__XAkqU4hRX5hq5jaByoQxokrJ, __ndwMMdeWn_KuhlvG0339pUrS.call())))
	__fpDtqFlZ8Jx_5dz9y50Wvqte.append(__JWQadZaoFI3ZbIo96MrrodHp(true, __ndwMMdeWn_KuhlvG0339pUrS))
	for __1pSzpv4UMXCUliIMJp_5vFr3: int in __fpDtqFlZ8Jx_5dz9y50Wvqte.size():
		__fpDtqFlZ8Jx_5dz9y50Wvqte[__1pSzpv4UMXCUliIMJp_5vFr3].set_meta("depth", __HN0NJbb6Q_9lIDlS9Nhmdl07[__1pSzpv4UMXCUliIMJp_5vFr3])
		__fpDtqFlZ8Jx_5dz9y50Wvqte[__1pSzpv4UMXCUliIMJp_5vFr3].set_meta("mod", __fpDtqFlZ8Jx_5dz9y50Wvqte[__1pSzpv4UMXCUliIMJp_5vFr3].modulate)
		__fpDtqFlZ8Jx_5dz9y50Wvqte[__1pSzpv4UMXCUliIMJp_5vFr3].visible = not __qauozn4KhinUPiznDXJo0UnX
	return __fpDtqFlZ8Jx_5dz9y50Wvqte
var __cG_zbW1sotj7reUf4u7FXswZ: int = 0
func __UEBR9tHfREmwSw_VDgBW83Zc() -> void :
	if __bqpvtk4llmiFJQmT5SzgWELV == null:
		return
	var __HoXmlbOGzCw5gseYCUwIOQJr: Array[__s8yZigV26lPAvEmbOWzMbnjE] = __VkSeEGhVF0y6mvRsZYDTVhBy()
	var __xDADGK1lgGHlUe96op2Qtt2l: int = -1 if __DpM0JQWB6EqgMh3WJZSlHODu else __i9hHpabGq0vj3HV9AiaCAWeq(__HoXmlbOGzCw5gseYCUwIOQJr, __YJgAymCaLB78BrFx7OQpn545.__WeB9Hi0OxaFBUuwm2WU2qKEH)
	__bqpvtk4llmiFJQmT5SzgWELV.disabled = __xDADGK1lgGHlUe96op2Qtt2l <= 0
	__AtE8nbDg8f4kT_S17xNL7a5N.disabled = __xDADGK1lgGHlUe96op2Qtt2l < 0 or __xDADGK1lgGHlUe96op2Qtt2l >= __HoXmlbOGzCw5gseYCUwIOQJr.size() - 1
const __iyXQN8g3iSlyBnDeXZtdYNFb: = 12
func __4pls2eyn7uV4ST2IGlXwuh6D() -> void :
	__jKRAoSDLaIkEgmrqlSCQwgKI()
	if __cINzBwGjtqDi2gNY5uWxxKya != null:
		__cINzBwGjtqDi2gNY5uWxxKya.close()
	__f3ySEJHZJ46_L34koIBeTfDe.visible = false
	var __kGU7ycDYe7ly9FhFa6vZxJIx: Button = __f3ySEJHZJ46_L34koIBeTfDe.get_meta("button")
	if __kGU7ycDYe7ly9FhFa6vZxJIx.button_pressed:
		__kGU7ycDYe7ly9FhFa6vZxJIx.set_pressed_no_signal(false)
func __vXTHIVg0n7R9rfqvSmsqgfMc(__7np_ZZj3tBXvNklGiPuQTAuk: PackedInt32Array) -> String:
	if __7np_ZZj3tBXvNklGiPuQTAuk.is_empty():
		return tr("UI_TRADE_AA_NONE")
	var __EQaDZe2CmnjBBwIwoprrS99o: __Se4EsxPBCHX48h1ZS5MexaMl = App.__PtNURh2PaYHMgsPlkLtni90Y()
	var names: PackedStringArray = []
	for __YzWa59IZXangd8xo_0M9inWx: int in mini(__7np_ZZj3tBXvNklGiPuQTAuk.size(), 3):
		names.append(str(__EQaDZe2CmnjBBwIwoprrS99o.__Z1n6LQ0e8g_Sv5O7it1HPeiw(__7np_ZZj3tBXvNklGiPuQTAuk[__YzWa59IZXangd8xo_0M9inWx]).get("name", "")))
	var s: String = "、".join(names) + ("…" if __7np_ZZj3tBXvNklGiPuQTAuk.size() > 3 else "")
	return tr("UI_TRADE_AA_SHELLS") % s
func __wCvCb3wyZ_rtEzAlllKjt9au(d: Dictionary) -> int:
	var __sQ6zvdJYBdE4Y8a3Qtf9my6d: __Se4EsxPBCHX48h1ZS5MexaMl = App.__PtNURh2PaYHMgsPlkLtni90Y()
	match str(d.get("what", "")):
		"main":
			return __bdSuhO73wCElsaHHBK60fLLA("G", __YJgAymCaLB78BrFx7OQpn545.__dOsDavODOasdfPxqce2DEBC3[int(d["main"])])
		"side":
			return __bdSuhO73wCElsaHHBK60fLLA("S", __sQ6zvdJYBdE4Y8a3Qtf9my6d.__PJZemYw0whDwrAt4vbBLpQ7w(__YJgAymCaLB78BrFx7OQpn545)[int(d["side"])])
		"torp":
			return __bdSuhO73wCElsaHHBK60fLLA("L", __sQ6zvdJYBdE4Y8a3Qtf9my6d.__7uBhyRNBJZP4s1InKu8Lo_y7(__YJgAymCaLB78BrFx7OQpn545)[int(d["torp"])])
		"fcs":
			return __bdSuhO73wCElsaHHBK60fLLA("F", __YJgAymCaLB78BrFx7OQpn545.__vwSAcybbCInOpnt2FbN4qz7L)
		"armor":
			var z: int = int(d["zone"])
			var __RuXHQM9HRU8Nq91I_JzThDwG: PackedInt32Array = __sQ6zvdJYBdE4Y8a3Qtf9my6d.__uCNDLIyQQRLcwA3z5vXmUuAz(__YJgAymCaLB78BrFx7OQpn545)
			return __9MFWgnc8oYQpY6kqM0OFfhrH.__DML16gO8cwjCLXpZX4VG3A4V(__sQ6zvdJYBdE4Y8a3Qtf9my6d.__eezCSxsQSp01HYni_60fHV16(__YJgAymCaLB78BrFx7OQpn545.__WeB9Hi0OxaFBUuwm2WU2qKEH)[z], __RuXHQM9HRU8Nq91I_JzThDwG[2 * z + 1], 0) if __RuXHQM9HRU8Nq91I_JzThDwG[2 * z] >= 0 else 0
		"air":
			var __dnoKTCTFlcK1NM1IQtyvU0lK: int = int(d["air"])
			var __b_B9lxqXpzlXKU01G6ppMwau: PackedInt32Array = __sQ6zvdJYBdE4Y8a3Qtf9my6d.__mgdM7ycmi3DNHzWo0uObSaPX(__YJgAymCaLB78BrFx7OQpn545)
			var __vxlwKwC3MABJESYFkrUUWS7c: int = __Se4EsxPBCHX48h1ZS5MexaMl.__7H3uQhAdVTbh0QLkQVDDP1bw * __dnoKTCTFlcK1NM1IQtyvU0lK
			var v: int = __b_B9lxqXpzlXKU01G6ppMwau[__vxlwKwC3MABJESYFkrUUWS7c + 1] * __9MFWgnc8oYQpY6kqM0OFfhrH.__FuqnpRY0H37YA_Ulwj8fJpaq(__sQ6zvdJYBdE4Y8a3Qtf9my6d.__gobxGwIVlftvCfJ1fsNzSlj7(__b_B9lxqXpzlXKU01G6ppMwau[__vxlwKwC3MABJESYFkrUUWS7c]))
			if __b_B9lxqXpzlXKU01G6ppMwau[__vxlwKwC3MABJESYFkrUUWS7c + 2] >= 0:
				v += __b_B9lxqXpzlXKU01G6ppMwau[__vxlwKwC3MABJESYFkrUUWS7c + 3] * __9MFWgnc8oYQpY6kqM0OFfhrH.__ghwoJ5UFJ3Y1ZKvfBWWXPwOi(__sQ6zvdJYBdE4Y8a3Qtf9my6d.__J3yVFTJGIFg8UxUlZ9VcpBHF(__Se4EsxPBCHX48h1ZS5MexaMl.__Uv7vWKACrD3IoOv6puOgq1PA[__dnoKTCTFlcK1NM1IQtyvU0lK], __b_B9lxqXpzlXKU01G6ppMwau[__vxlwKwC3MABJESYFkrUUWS7c + 2]))
			return v
	return 0
func __ZBgdLfAUaOUa6XyG2otMcWz3() -> void :
	if __cINzBwGjtqDi2gNY5uWxxKya == null or __DpM0JQWB6EqgMh3WJZSlHODu:
		return
	__24qhWIUVEfyan5lj70t1BnRb.visible = true
	__cINzBwGjtqDi2gNY5uWxxKya.open(__YJgAymCaLB78BrFx7OQpn545.__WeB9Hi0OxaFBUuwm2WU2qKEH, App.__PtNURh2PaYHMgsPlkLtni90Y().__uCNDLIyQQRLcwA3z5vXmUuAz(__YJgAymCaLB78BrFx7OQpn545))
func __4y42iv09gwsmIpETTIbo7IZO(__amDrE_uRIRjlyXg3ABn8BNLu: PackedInt32Array) -> void :
	var __p8gV6yC801F2WLRWhkW3niI8: __s8yZigV26lPAvEmbOWzMbnjE = __YJgAymCaLB78BrFx7OQpn545.__12ty6aWt7_v7eYEbKtP71Dlf()
	__p8gV6yC801F2WLRWhkW3niI8.__cQ8JInnnrEoGxd_1jglej7pR = __amDrE_uRIRjlyXg3ABn8BNLu if __amDrE_uRIRjlyXg3ABn8BNLu != __Se4EsxPBCHX48h1ZS5MexaMl.__z60ooVwI9Q0G4gXJuZ_QzkIy([]) else PackedInt32Array()
	var __pddhwV0bkPRfJ0o0Bojqfr2x: int = __9iFcUUuz7hxSygPtA9oE6aBm(__p8gV6yC801F2WLRWhkW3niI8)
	if __pddhwV0bkPRfJ0o0Bojqfr2x != __Se4EsxPBCHX48h1ZS5MexaMl.__5CDMR1_ZY_Be5hesPdyczkNt.OK:
		UI.__FZyGB2TVbKGb1g8kgT4bm_x4(tr("UI_SS_ERR_%d" % __pddhwV0bkPRfJ0o0Bojqfr2x))
		return
	var __z2yU2JGJgAwD1bOHDKTV69YP: PackedInt32Array = App.__PtNURh2PaYHMgsPlkLtni90Y().__uCNDLIyQQRLcwA3z5vXmUuAz(__YJgAymCaLB78BrFx7OQpn545)
	var __sY1Z6VbmeIbR4shYY0A6n1jF: PackedInt32Array = __Se4EsxPBCHX48h1ZS5MexaMl.__z60ooVwI9Q0G4gXJuZ_QzkIy(__amDrE_uRIRjlyXg3ABn8BNLu)
	var __Dv4DT7OSr0O40LFQGl2cllte: int = __pDD4VW1FqZzXRK1m9Ft3JOAG.__ue9en_otjIhPR2KBQIuC1B38(__YJgAymCaLB78BrFx7OQpn545.__WeB9Hi0OxaFBUuwm2WU2qKEH, __z2yU2JGJgAwD1bOHDKTV69YP, __sY1Z6VbmeIbR4shYY0A6n1jF)
	if __Dv4DT7OSr0O40LFQGl2cllte > 0:
		var __2x3_1iJxUIUrtJ24QNPiDmRo: String = App.__M0ImV248NGNrBFXy9NCs5jwX().__CwpKXs02n6e7mZnAMz9VvPw1(__Dv4DT7OSr0O40LFQGl2cllte, 0, __Bsl33jE0VgUtGf0ZDYkuZAkg.__MAuObtKplQF6qga2KCMkBh19, __p8gV6yC801F2WLRWhkW3niI8.__WeB9Hi0OxaFBUuwm2WU2qKEH)
		if __2x3_1iJxUIUrtJ24QNPiDmRo != "":
			UI.__FZyGB2TVbKGb1g8kgT4bm_x4(tr(__2x3_1iJxUIUrtJ24QNPiDmRo))
			return
	for z: int in __Se4EsxPBCHX48h1ZS5MexaMl.__3VNgI6oIA6AwAG0zr8lLs1ZW:
		var changed: bool = __sY1Z6VbmeIbR4shYY0A6n1jF[2 * z] != __z2yU2JGJgAwD1bOHDKTV69YP[2 * z] or __sY1Z6VbmeIbR4shYY0A6n1jF[2 * z + 1] <= 0
		__U7UMfwBewiXSLEeaDnywaCO7.__mzf94JP_Dp5fS1BWTUB50MxE(__YJgAymCaLB78BrFx7OQpn545.__WeB9Hi0OxaFBUuwm2WU2qKEH, "armor:%d" % z, __pDD4VW1FqZzXRK1m9Ft3JOAG.__DibIkwncUWTmgA1Q2brLsYCR(__YJgAymCaLB78BrFx7OQpn545.__WeB9Hi0OxaFBUuwm2WU2qKEH, __z2yU2JGJgAwD1bOHDKTV69YP, __sY1Z6VbmeIbR4shYY0A6n1jF, z), changed)
	__cINzBwGjtqDi2gNY5uWxxKya.close()
	__FqUftbENBVycK58vij71NAQ6(__p8gV6yC801F2WLRWhkW3niI8, true)
func __cl8LJq2mOhc3fU4d1Nb_BXOu(__NUQcofmcJppMnEGqYP0bJhn5: Color, __ZzGl9h4KlnBmu6uL7f_eyJe9: Color, __wSUYx4LDOVTy5j9mQRRJfauw: int) -> StyleBoxFlat:
	var s: = StyleBoxFlat.new()
	s.bg_color = __NUQcofmcJppMnEGqYP0bJhn5
	s.border_color = __ZzGl9h4KlnBmu6uL7f_eyJe9
	s.border_width_left = 1
	s.border_width_right = 1
	s.border_width_top = __wSUYx4LDOVTy5j9mQRRJfauw
	s.border_width_bottom = 0
	s.corner_radius_top_left = 6
	s.corner_radius_top_right = 6
	s.set_content_margin_all(4)
	s.content_margin_left = 14
	s.content_margin_right = 14
	return s
func __3VrZVwOZRlbabKn4WyXjjosd(__bbgIgg8rwVKZXYxISRf48bBj: CanvasItem, __LTAzUpQ02IeySdscI3_dq4Ui: Dictionary) -> void :
	if __LTAzUpQ02IeySdscI3_dq4Ui.is_empty():
		return
	for b: __H2jKfddttLiR1Mfv697VtMqG in [__LTAzUpQ02IeySdscI3_dq4Ui["hull_a"], __LTAzUpQ02IeySdscI3_dq4Ui["hull_b"]]:
		if b != null:
			b.frame(0).__XWs5ocCZJFqvH9sw_eqvYZ_N(__bbgIgg8rwVKZXYxISRf48bBj, __fnparxNE3vp0MWoTiWaLXq8T + Vector2(b.__2ZhP3pgJkeplzgK9Ky4cqSZb))
const __5HupLyuedvtW1LzkmaCuR4xT: = Vector2(66, 590)
func __ejjrmWDPOiCDSSON_WTtAS7w() -> String:
	var __IdPYPAc144kiDWukCJufkR4o: String = tr("UI_HARBOR_NAME_%d" % __cG_zbW1sotj7reUf4u7FXswZ)
	if App.__GtkTK7qTutmHKfVnGFduJfcl():
		return __IdPYPAc144kiDWukCJufkR4o + "　" + tr("UI_HARBOR_ONLINE") % str(Settings.get_value("server_addr", ""))
	return __IdPYPAc144kiDWukCJufkR4o
const __yimngiolRStzqVnnRpqZIR9I: = Color(0.14, 0.26, 0.4, 0.97)
var __g59CpE8YrzQ3c1AnhI3CYror: bool = false
const __ddYJ_F4TuBySIEY5POO5wxej: = 3.0
func __Nr08CaoCcAMr_GFSY2lMjw8a() -> void :
	for __tzgsxQ5QKZdFJKZmXq8OpsYX: __XZQIsX2REk1j2LWZtbLIAovG in __dAGqnexg_IDbNw344d0sOBgZ:
		__tzgsxQ5QKZdFJKZmXq8OpsYX.visible = false
	for __yPMVnDfKayK_tTVWxdM970Db: __XZQIsX2REk1j2LWZtbLIAovG in __ORPVAwaEZaG_WUKCzYPqV3CM:
		__yPMVnDfKayK_tTVWxdM970Db.position = Vector2.ZERO
		__hXETMci8tRCb5H43aZxU11kA(__yPMVnDfKayK_tTVWxdM970Db, 1.0)
	__v9ZnZMSMzoVWGyPBRc8ApWfd = {}
	__0enFPGinCOJKsiE7r2nLxhFA()
	_redraw()
	__UxRH136qCscJz2DBq4WJgk9g()
func __zzDwgebyDflDIvGdolf3Y07D(__qdZ_flBjZEYeTlZCmAgWOwKE: CanvasItem, __sQaz_d9j5ZdeptgTyZYoR58A: Dictionary) -> void :
	var __sT9A2m3OA9YWcKBZ3xIzZzEY: __H2jKfddttLiR1Mfv697VtMqG = __sQaz_d9j5ZdeptgTyZYoR58A.get("foam")
	if __sT9A2m3OA9YWcKBZ3xIzZzEY != null and __sT9A2m3OA9YWcKBZ3xIzZzEY.__ChBBhlNyW1jE3vuUv5SaoQUk() > 0:
		__sT9A2m3OA9YWcKBZ3xIzZzEY.frame(__ZCxIMxSxCw6Qw0WQFirwHFdX % __sT9A2m3OA9YWcKBZ3xIzZzEY.__ChBBhlNyW1jE3vuUv5SaoQUk()).__XWs5ocCZJFqvH9sw_eqvYZ_N(__qdZ_flBjZEYeTlZCmAgWOwKE, __fnparxNE3vp0MWoTiWaLXq8T + Vector2(__sT9A2m3OA9YWcKBZ3xIzZzEY.__2ZhP3pgJkeplzgK9Ky4cqSZb))
func __btLunkU7FIRTm7JraVNus_7M() -> void :
	await get_tree().process_frame
	__LRKxUAEiOJmq3fPx9v5YOJtM.play(__CgtEZnFtJYvrLjlSjFnhNN9n.canvas)
const __I1lngIcnmU9bwkK71K8d67NT: = Vector2(104, 34)
func __QDHCoKV3RWbBR7wXgexsZgHS(__fQKdsc1j2i1kUXjZXXdYvwnW: String, __Hn0aa_zr1KfleaIKvFBFGrZ9: int) -> Array:
	var __OSxOlIInqd8KT9VkapqbGO49: __Se4EsxPBCHX48h1ZS5MexaMl = App.__PtNURh2PaYHMgsPlkLtni90Y()
	var __jiq0eIj9gQQLNgs2r0wRywVh: __bzxMmNAcE_RKMny5gklgDglw = App.___qFCN2viGM2bPW1uGV9qys9h()
	match __fQKdsc1j2i1kUXjZXXdYvwnW:
		"G", "S":
			return ["ComponentsTuret", __jiq0eIj9gQQLNgs2r0wRywVh.__Jy2hcMM9emCF3iBBkLMyeUr7("Gunset", __Hn0aa_zr1KfleaIKvFBFGrZ9, 4) + 2]
		"L":
			return ["ComponentsTpLauncher", __jiq0eIj9gQQLNgs2r0wRywVh.__Jy2hcMM9emCF3iBBkLMyeUr7("TpLauncher", __Hn0aa_zr1KfleaIKvFBFGrZ9, 4) + 5]
		"F":
			return ["ComponentsFCS", int(__OSxOlIInqd8KT9VkapqbGO49.__vwSAcybbCInOpnt2FbN4qz7L(__Hn0aa_zr1KfleaIKvFBFGrZ9).get("art", -10)) + 1]
		"E":
			return ["ComponentsEng", int(__OSxOlIInqd8KT9VkapqbGO49.__NELIelBEafKRGQultNqYAbM7(__Hn0aa_zr1KfleaIKvFBFGrZ9).get("art", -10)) + 1]
		"P":
			return ["ComponentsAircraft", int(__OSxOlIInqd8KT9VkapqbGO49.__gobxGwIVlftvCfJ1fsNzSlj7(__Hn0aa_zr1KfleaIKvFBFGrZ9).get("spr", -10)) + 2]
	return []
var __vB6Uge3peTq8e97V0wYhk4lc: OptionButton
static func __A_t_k_qymKqzJY0izZpx5dx0(rings: Array[Dictionary], root: Array[int]) -> bool:
	var __10OGZvrP_mM8_Wza0moqswOG: int = rings.size()
	var find: = func(__pQbCGoUyTSrNX0RrBsDcJLVS: int) -> int:
		while root[__pQbCGoUyTSrNX0RrBsDcJLVS] != __pQbCGoUyTSrNX0RrBsDcJLVS:
			__pQbCGoUyTSrNX0RrBsDcJLVS = root[__pQbCGoUyTSrNX0RrBsDcJLVS]
		return __pQbCGoUyTSrNX0RrBsDcJLVS
	var any: bool = false
	for __f_231Zp3_hlhoXCVw_c221Ls: int in __10OGZvrP_mM8_Wza0moqswOG:
		for __ZpN55WgPyBLovzatvFSsN4JV: int in range(__f_231Zp3_hlhoXCVw_c221Ls + 1, __10OGZvrP_mM8_Wza0moqswOG):
			var d: Vector2 = (rings[__f_231Zp3_hlhoXCVw_c221Ls]["pos"] as Vector2) - (rings[__ZpN55WgPyBLovzatvFSsN4JV]["pos"] as Vector2)
			if absf(d.x) < __MFxRMYlL0G8y0Dw2Fzt_Gu5p - 0.5 and absf(d.y) < __PsVlZoS1bDNQtGQflwNZKZfH - 0.5:
				var __oL0wrTkfLxkezTiroWmkiGMb: int = find.call(__f_231Zp3_hlhoXCVw_c221Ls)
				var __VMLx3U2uqYD0TwsI2vlPwhQV: int = find.call(__ZpN55WgPyBLovzatvFSsN4JV)
				if __oL0wrTkfLxkezTiroWmkiGMb != __VMLx3U2uqYD0TwsI2vlPwhQV:
					root[__VMLx3U2uqYD0TwsI2vlPwhQV] = __oL0wrTkfLxkezTiroWmkiGMb
				any = true
	if not any:
		return false
	var __PTlc_wbIwyhS5oVwJI0P8NfB: = func(__8L3UIdSBhOaUaLPrVrDlWF5l: int) -> Vector2:
		return rings[__8L3UIdSBhOaUaLPrVrDlWF5l].get("mount_pos", rings[__8L3UIdSBhOaUaLPrVrDlWF5l]["pos"])
	var __nVLUL083DI1H4tYKnsg4ZGd8: Dictionary = {}
	for __rp3nR1OpGF7oeTTmBA5JdOJf: int in __10OGZvrP_mM8_Wza0moqswOG:
		var r: int = find.call(__rp3nR1OpGF7oeTTmBA5JdOJf)
		if not __nVLUL083DI1H4tYKnsg4ZGd8.has(r):
			__nVLUL083DI1H4tYKnsg4ZGd8[r] = []
		(__nVLUL083DI1H4tYKnsg4ZGd8[r] as Array).append(__rp3nR1OpGF7oeTTmBA5JdOJf)
	for __PKB9w4eVVJa9qlb644NnCYKd: Variant in __nVLUL083DI1H4tYKnsg4ZGd8:
		var __0NXoYMSEw1o9JdILhNwaFg4f: Array = __nVLUL083DI1H4tYKnsg4ZGd8[__PKB9w4eVVJa9qlb644NnCYKd]
		if __0NXoYMSEw1o9JdILhNwaFg4f.size() < 2:
			continue
		var __K1bSy8MBm0_FTUpIkvk1o0By: = Vector2.ZERO
		for __vEB_IuLcYCnuYSXXmwHx6Zzn: int in __0NXoYMSEw1o9JdILhNwaFg4f:
			__K1bSy8MBm0_FTUpIkvk1o0By += __PTlc_wbIwyhS5oVwJI0P8NfB.call(__vEB_IuLcYCnuYSXXmwHx6Zzn) as Vector2
		__K1bSy8MBm0_FTUpIkvk1o0By /= float(__0NXoYMSEw1o9JdILhNwaFg4f.size())
		var __PhNQe78qWPB4C1EieQUePVj5: Array = __0NXoYMSEw1o9JdILhNwaFg4f.duplicate()
		__PhNQe78qWPB4C1EieQUePVj5.sort_custom( func(a: int, b: int) -> bool:
			var __61PdA7f3YEWMYA9J0pv20AXk: Vector2 = __PTlc_wbIwyhS5oVwJI0P8NfB.call(a)
			var __MALqGZ_5I3inaxAbGXe8Ybs0: Vector2 = __PTlc_wbIwyhS5oVwJI0P8NfB.call(b)
			return __61PdA7f3YEWMYA9J0pv20AXk.y < __MALqGZ_5I3inaxAbGXe8Ybs0.y if __61PdA7f3YEWMYA9J0pv20AXk.y != __MALqGZ_5I3inaxAbGXe8Ybs0.y else a < b)
		var __GB1RRmN5iJK73tueXrRFurR8: Array = [[], []]
		var __RBFgVg2pILZMU90rTWJpSam0: Array = []
		for __YBV0QvvfsnFqPO_dcaNG1prC: int in __PhNQe78qWPB4C1EieQUePVj5:
			var __1JvK70V_ChjKklsWurJspDfm: int = int(rings[__YBV0QvvfsnFqPO_dcaNG1prC].get("beam", 0))
			if __1JvK70V_ChjKklsWurJspDfm < 0:
				(__GB1RRmN5iJK73tueXrRFurR8[0] as Array).append(__YBV0QvvfsnFqPO_dcaNG1prC)
			elif __1JvK70V_ChjKklsWurJspDfm > 0:
				(__GB1RRmN5iJK73tueXrRFurR8[1] as Array).append(__YBV0QvvfsnFqPO_dcaNG1prC)
			else:
				__RBFgVg2pILZMU90rTWJpSam0.append(__YBV0QvvfsnFqPO_dcaNG1prC)
		if (__GB1RRmN5iJK73tueXrRFurR8[0] as Array).is_empty() or (__GB1RRmN5iJK73tueXrRFurR8[1] as Array).is_empty():
			__GB1RRmN5iJK73tueXrRFurR8 = [[], []]
			__RBFgVg2pILZMU90rTWJpSam0 = __PhNQe78qWPB4C1EieQUePVj5
		for __ZFQkYKjPCGgDycRds8X7kJDk: int in __RBFgVg2pILZMU90rTWJpSam0:
			(__GB1RRmN5iJK73tueXrRFurR8[0 if (__GB1RRmN5iJK73tueXrRFurR8[0] as Array).size() <= (__GB1RRmN5iJK73tueXrRFurR8[1] as Array).size() else 1] as Array).append(__ZFQkYKjPCGgDycRds8X7kJDk)
		for __T6l0UUqg8uhoqkyk7P0u2zca: int in 2:
			(__GB1RRmN5iJK73tueXrRFurR8[__T6l0UUqg8uhoqkyk7P0u2zca] as Array).sort_custom( func(a: int, b: int) -> bool:
				var __oWo6YDoezJcp26xL2qRFK4QK: Vector2 = __PTlc_wbIwyhS5oVwJI0P8NfB.call(a)
				var __yOAmJIzugZSzAG9n9xhbFrwd: Vector2 = __PTlc_wbIwyhS5oVwJI0P8NfB.call(b)
				return __oWo6YDoezJcp26xL2qRFK4QK.y < __yOAmJIzugZSzAG9n9xhbFrwd.y if __oWo6YDoezJcp26xL2qRFK4QK.y != __yOAmJIzugZSzAG9n9xhbFrwd.y else a < b)
		var step: Vector2 = __MRdyzRlkxacGIHdEISIwXvvZ if __K1bSy8MBm0_FTUpIkvk1o0By.x < 512.0 else - __MRdyzRlkxacGIHdEISIwXvvZ
		var __1vZw8ss1RfnUuYwof4BZjcA4: Dictionary = {}
		var __Ud_C33jjd2lUByR_An_LqyCf: = Vector2.ZERO
		for __2b1XjSRXdUYEe_UIKV5smXaD: int in 2:
			var __cPCGcuP9cfLvm892Ebbh756o: Array = __GB1RRmN5iJK73tueXrRFurR8[__2b1XjSRXdUYEe_UIKV5smXaD]
			for __DrhhTZmyB0OgDKbgiLY8vHlE: int in __cPCGcuP9cfLvm892Ebbh756o.size():
				var __ykGiBXwSDsploc4_ePNMqDI4: Vector2 = step * __DrhhTZmyB0OgDKbgiLY8vHlE + (__AKcEUb3llykBn01zEwjd6Fxk if __2b1XjSRXdUYEe_UIKV5smXaD == 0 else Vector2.ZERO)
				__1vZw8ss1RfnUuYwof4BZjcA4[__cPCGcuP9cfLvm892Ebbh756o[__DrhhTZmyB0OgDKbgiLY8vHlE]] = __ykGiBXwSDsploc4_ePNMqDI4
				__Ud_C33jjd2lUByR_An_LqyCf += __ykGiBXwSDsploc4_ePNMqDI4
		var __nhzszR5qw8dNq75yNuUpJhDF: Vector2 = __K1bSy8MBm0_FTUpIkvk1o0By - __Ud_C33jjd2lUByR_An_LqyCf / float(__0NXoYMSEw1o9JdILhNwaFg4f.size())
		var __kGtv6dKnEhCVRydZduuEQBg5: = Vector2(INF, INF)
		var __kr5HUthAMxSE7EFdg4bE2K_m: = Vector2( - INF, - INF)
		for __MYOr3QUQLzekKYU9ZcD0eRMP: Variant in __1vZw8ss1RfnUuYwof4BZjcA4:
			var __qciGlnARgjefcMeYt9JybIUH: Vector2 = (__1vZw8ss1RfnUuYwof4BZjcA4[__MYOr3QUQLzekKYU9ZcD0eRMP] as Vector2) + __nhzszR5qw8dNq75yNuUpJhDF
			__kGtv6dKnEhCVRydZduuEQBg5 = __kGtv6dKnEhCVRydZduuEQBg5.min(__qciGlnARgjefcMeYt9JybIUH)
			__kr5HUthAMxSE7EFdg4bE2K_m = __kr5HUthAMxSE7EFdg4bE2K_m.max(__qciGlnARgjefcMeYt9JybIUH)
		if __kr5HUthAMxSE7EFdg4bE2K_m.y > __zAqqHx7kS6MXSwnhecUSxyVu:
			__nhzszR5qw8dNq75yNuUpJhDF.y -= __kr5HUthAMxSE7EFdg4bE2K_m.y - __zAqqHx7kS6MXSwnhecUSxyVu
			__kGtv6dKnEhCVRydZduuEQBg5.y -= __kr5HUthAMxSE7EFdg4bE2K_m.y - __zAqqHx7kS6MXSwnhecUSxyVu
			__kr5HUthAMxSE7EFdg4bE2K_m.y = __zAqqHx7kS6MXSwnhecUSxyVu
		__nhzszR5qw8dNq75yNuUpJhDF.x += maxf(0.0, 24.0 - __kGtv6dKnEhCVRydZduuEQBg5.x) - maxf(0.0, __kr5HUthAMxSE7EFdg4bE2K_m.x - 1000.0)
		__nhzszR5qw8dNq75yNuUpJhDF.y += maxf(0.0, 12.0 - __kGtv6dKnEhCVRydZduuEQBg5.y)
		for __iWiu6LxUrcGNRsXT1z7cA3fK: Variant in __1vZw8ss1RfnUuYwof4BZjcA4:
			var d: Dictionary = rings[int(__iWiu6LxUrcGNRsXT1z7cA3fK)]
			if not d.has("mount_pos"):
				d["mount_pos"] = d["pos"]
			d["pos"] = (__1vZw8ss1RfnUuYwof4BZjcA4[__iWiu6LxUrcGNRsXT1z7cA3fK] as Vector2) + __nhzszR5qw8dNq75yNuUpJhDF
	return true
func __GmRW88Xewr0JBlHpbJsjuBQm() -> void :
	var __tt7ljvatQgYu5IqnPRyaYmFu: int = __U7UMfwBewiXSLEeaDnywaCO7.__0DtrIf4XbXW11PGsdzQ8KaJ8(__cG_zbW1sotj7reUf4u7FXswZ)
	if __tt7ljvatQgYu5IqnPRyaYmFu >= __U7UMfwBewiXSLEeaDnywaCO7.__zwT6e_lC3lvDDAou2Y8oukR3:
		UI.__FZyGB2TVbKGb1g8kgT4bm_x4(tr("UI_BUY_ERR_NATION_FULL") % __U7UMfwBewiXSLEeaDnywaCO7.__zwT6e_lC3lvDDAou2Y8oukR3)
		return
	var __yY1SGgNR7o1i9sF_q87R6d75: PackedInt32Array = __U7UMfwBewiXSLEeaDnywaCO7.__BLtJfypujn8nNJncnZHSb3Fy(__cG_zbW1sotj7reUf4u7FXswZ)
	if __yY1SGgNR7o1i9sF_q87R6d75.is_empty():
		UI.__FZyGB2TVbKGb1g8kgT4bm_x4(tr("UI_BUY_ERR_NONE"))
		return
	__4pls2eyn7uV4ST2IGlXwuh6D()
	var __2l9P_WUDSRnt4WN6KHRkWFyU: __2HFBtj8zizjjoD1qOpMx65pX = __2HFBtj8zizjjoD1qOpMx65pX.new().setup(__ejjrmWDPOiCDSSON_WTtAS7w(), __yY1SGgNR7o1i9sF_q87R6d75, __tt7ljvatQgYu5IqnPRyaYmFu, __U7UMfwBewiXSLEeaDnywaCO7.__zwT6e_lC3lvDDAou2Y8oukR3, -1 if __DpM0JQWB6EqgMh3WJZSlHODu else __YJgAymCaLB78BrFx7OQpn545.__WeB9Hi0OxaFBUuwm2WU2qKEH)
	( %Overlay as Control).add_child(__2l9P_WUDSRnt4WN6KHRkWFyU)
	__2l9P_WUDSRnt4WN6KHRkWFyU.closed.connect(__2l9P_WUDSRnt4WN6KHRkWFyU.queue_free)
	__2l9P_WUDSRnt4WN6KHRkWFyU.__34fWqa9h0inw1YpR7r5umcLg.connect( func(__oeNOXv38Hc1Dy0c_JRntoYkx: int) -> void :
		if __spW6n6CC7iypuAD7crNfuCbF(__oeNOXv38Hc1Dy0c_JRntoYkx):
			__2l9P_WUDSRnt4WN6KHRkWFyU.queue_free())
func __Q6NrDwYmtTJN8wYKH9Jgb0rw(__JDYuCxU4Pw9RwutCRbgrrR5F: CanvasItem, __5zTGI3Xm5cxb0QdqrKcKxmda: Dictionary) -> void :
	var b: __H2jKfddttLiR1Mfv697VtMqG = __5zTGI3Xm5cxb0QdqrKcKxmda.get("fcs")
	if b != null:
		b.frame(0).__XWs5ocCZJFqvH9sw_eqvYZ_N(__JDYuCxU4Pw9RwutCRbgrrR5F, (__5zTGI3Xm5cxb0QdqrKcKxmda["fcs_at"] as Vector2) + Vector2(b.__2ZhP3pgJkeplzgK9Ky4cqSZb))
func __5S8plTABm1PqgD2ocfAKazy2(__jPlVnc7JvMf9cIp_0zzOU1ca: String) -> PackedInt32Array:
	var __hiJOr8B2mHGgCzLvjMZBblf_: __Se4EsxPBCHX48h1ZS5MexaMl = App.__PtNURh2PaYHMgsPlkLtni90Y()
	match __jPlVnc7JvMf9cIp_0zzOU1ca:
		"G":
			return __YJgAymCaLB78BrFx7OQpn545.__dOsDavODOasdfPxqce2DEBC3
		"S":
			return __hiJOr8B2mHGgCzLvjMZBblf_.__PJZemYw0whDwrAt4vbBLpQ7w(__YJgAymCaLB78BrFx7OQpn545)
		"L":
			return __hiJOr8B2mHGgCzLvjMZBblf_.__7uBhyRNBJZP4s1InKu8Lo_y7(__YJgAymCaLB78BrFx7OQpn545)
	return PackedInt32Array()
const __nDMzIIBfjfebkTT_IF92ffWF: = ["G", "S", "L"]
func __JrSwqiFlyEfIMrWTSwBBfy5w(__keKq7ixJyXonxsAiIOw_r4fo: __s8yZigV26lPAvEmbOWzMbnjE, __xOoCrxR3Y2HCkemyoiIX9sER: String, __RZRv8Wr8el103PKUYYdkFPRm: int) -> void :
	var __lESZQkSPnuWDET99PPgW2kWB: __Se4EsxPBCHX48h1ZS5MexaMl = App.__PtNURh2PaYHMgsPlkLtni90Y()
	if __xOoCrxR3Y2HCkemyoiIX9sER == "torp":
		var __JaoskSaqy1ep50nDTjJYgohZ: int = __lESZQkSPnuWDET99PPgW2kWB.__Hmr_a2CPvjknmgXnhmVu1vm9(__keKq7ixJyXonxsAiIOw_r4fo.__WeB9Hi0OxaFBUuwm2WU2qKEH).find(__RZRv8Wr8el103PKUYYdkFPRm)
		if __JaoskSaqy1ep50nDTjJYgohZ >= 0:
			__keKq7ixJyXonxsAiIOw_r4fo.__t3YSlOfvQe4R_b9rHMAz7hq0 = __lESZQkSPnuWDET99PPgW2kWB.__El7brR86C9a6x0hMgLnIgY3e(__keKq7ixJyXonxsAiIOw_r4fo)
			__keKq7ixJyXonxsAiIOw_r4fo.__mqMCtdrkbQOwk3Mp57NCIW7w = __lESZQkSPnuWDET99PPgW2kWB.__7uBhyRNBJZP4s1InKu8Lo_y7(__keKq7ixJyXonxsAiIOw_r4fo)
			__keKq7ixJyXonxsAiIOw_r4fo.__mqMCtdrkbQOwk3Mp57NCIW7w[__JaoskSaqy1ep50nDTjJYgohZ] = __s8yZigV26lPAvEmbOWzMbnjE.__1iBjWxIGtvWf0yGsmF7yzBIR
			__keKq7ixJyXonxsAiIOw_r4fo.__t3YSlOfvQe4R_b9rHMAz7hq0[2 * __JaoskSaqy1ep50nDTjJYgohZ] = __s8yZigV26lPAvEmbOWzMbnjE.__1iBjWxIGtvWf0yGsmF7yzBIR
			__keKq7ixJyXonxsAiIOw_r4fo.__t3YSlOfvQe4R_b9rHMAz7hq0[2 * __JaoskSaqy1ep50nDTjJYgohZ + 1] = 0
	else:
		var __pcVWQgYDrzVBFpyTJbi0eBV_: int = __lESZQkSPnuWDET99PPgW2kWB.__4mBhSAAMIt6DTsibdV0pC19W(__keKq7ixJyXonxsAiIOw_r4fo.__WeB9Hi0OxaFBUuwm2WU2qKEH).find(__RZRv8Wr8el103PKUYYdkFPRm)
		if __pcVWQgYDrzVBFpyTJbi0eBV_ >= 0:
			__keKq7ixJyXonxsAiIOw_r4fo.__nQdkAoXs7wyREcSJQ0Beyel6 = __lESZQkSPnuWDET99PPgW2kWB.__Xs0yLUqBQ7TVWSHzfx4EiUAr(__keKq7ixJyXonxsAiIOw_r4fo)
			__keKq7ixJyXonxsAiIOw_r4fo.__t1UipS__8EvFgumrL932qeyd = __lESZQkSPnuWDET99PPgW2kWB.__PJZemYw0whDwrAt4vbBLpQ7w(__keKq7ixJyXonxsAiIOw_r4fo)
			__keKq7ixJyXonxsAiIOw_r4fo.__t1UipS__8EvFgumrL932qeyd[__pcVWQgYDrzVBFpyTJbi0eBV_] = __s8yZigV26lPAvEmbOWzMbnjE.__1iBjWxIGtvWf0yGsmF7yzBIR
			for __PBQFq_LvVGmWpVrtEpo7RCsl: int in 4:
				__keKq7ixJyXonxsAiIOw_r4fo.__nQdkAoXs7wyREcSJQ0Beyel6[4 * __pcVWQgYDrzVBFpyTJbi0eBV_ + __PBQFq_LvVGmWpVrtEpo7RCsl] = __s8yZigV26lPAvEmbOWzMbnjE.__1iBjWxIGtvWf0yGsmF7yzBIR if __PBQFq_LvVGmWpVrtEpo7RCsl % 2 == 0 else 0
func __9rpuzul8VrZczCjSFS7iCrOA(__mC6Opfbk9L4WHjkrXSzfgmJ3: Vector2) -> Vector2:
	var __cNy9CayyTR80ArXYG6GCUY6Z: Control = %Overlay
	var right: float = __pndlxY_XCFFxBsvt9SrAMHXa.__Gc9pvpcX3aEx1tMHweM0N4bO().position.x if __pndlxY_XCFFxBsvt9SrAMHXa != null and __pndlxY_XCFFxBsvt9SrAMHXa.open else __cNy9CayyTR80ArXYG6GCUY6Z.global_position.x + __cNy9CayyTR80ArXYG6GCUY6Z.size.x
	var __SBtt7xuncVVWwBvObqe7BHfu: float = ( %TopBar as Control).get_global_rect().end.y + 8.0
	var y: float = maxf(8.0, minf(__SBtt7xuncVVWwBvObqe7BHfu, __cNy9CayyTR80ArXYG6GCUY6Z.size.y - __mC6Opfbk9L4WHjkrXSzfgmJ3.y - 8.0))
	return Vector2(right - __mC6Opfbk9L4WHjkrXSzfgmJ3.x - 8.0, y) - __cNy9CayyTR80ArXYG6GCUY6Z.global_position
var __pndlxY_XCFFxBsvt9SrAMHXa: __swIzeI0OCYp_Difwb9TQEYIt
func __Rco5woHwXiTlm6FD8ey5jNa8(blend: String, __NLFeOfOZr8NmIyz3WmVyQeyk: Callable) -> __XZQIsX2REk1j2LWZtbLIAovG:
	var __wdhu3xIY1qWZmgdpnB6a2fW9: = __XZQIsX2REk1j2LWZtbLIAovG.new().setup(blend, __NLFeOfOZr8NmIyz3WmVyQeyk)
	__CgtEZnFtJYvrLjlSjFnhNN9n.canvas.add_child(__wdhu3xIY1qWZmgdpnB6a2fW9)
	return __wdhu3xIY1qWZmgdpnB6a2fW9
const __iAAZg_L1CIMXb2xD1_GMfROh: = 300.0
func __JWQadZaoFI3ZbIo96MrrodHp(near: bool, __sw4smEwe88zx0f1kvSCUnray: Callable) -> __XZQIsX2REk1j2LWZtbLIAovG:
	var __5DQjJZDVaKL977k5ag3Ei3hQ: __XZQIsX2REk1j2LWZtbLIAovG = __Rco5woHwXiTlm6FD8ey5jNa8("alpha", func(__bU5JFIn7ZaI92bYEffrbsNy6: CanvasItem) -> void : __oUqJV9BoP5jehKHsmHxmIDXm(__bU5JFIn7ZaI92bYEffrbsNy6, near, __sw4smEwe88zx0f1kvSCUnray.call()))
	__5DQjJZDVaKL977k5ag3Ei3hQ.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
	return __5DQjJZDVaKL977k5ag3Ei3hQ
const __GmL2pr1EhdpRkHDFmLem52M6: = Vector2(828.1, 406.8)
func __I25PS__nxrcT5ue1XHwV6CDj(id: String, __dvs0MLvlYdZDLL4lsT3l2QSZ: __CgOl36_UCxYZW5PzufCcS4dS) -> void :
	var __XEWwBeJZr2f0E1PrhLNzMlAg: __F4kscdCfLUw02HL8Nfie7uTc
	var __HH7f9Yuw1k40PFOblbbQmP31: = Vector2(339, 290)
	match id:
		"crew_recruit":
			__XEWwBeJZr2f0E1PrhLNzMlAg = __Yhtjf6iNuuOlPMKYYcWPcH_E.__8yu8GD_ZgOog4dbaHoAeo0ZT.new()
			__HH7f9Yuw1k40PFOblbbQmP31 = __Yhtjf6iNuuOlPMKYYcWPcH_E.__8yu8GD_ZgOog4dbaHoAeo0ZT.__kD5MpGbGI03ItQXuZAiXJBoV
		"crew_class":
			if __o4BlGoLwjfAD3TYKD8Kt7FzU.__jImD0sut02cad96nddoNN3be(App.__M0ImV248NGNrBFXy9NCs5jwX().__LVCMU4xMBMMHO5bxpAYeHYWt(__dvs0MLvlYdZDLL4lsT3l2QSZ)):
				__XEWwBeJZr2f0E1PrhLNzMlAg = __EpTvmaXol3cFft69bdnVvE47.new()
				(__XEWwBeJZr2f0E1PrhLNzMlAg as __EpTvmaXol3cFft69bdnVvE47).__V0pOn5Sa7N2eQmRM4kwRkT34 = __dvs0MLvlYdZDLL4lsT3l2QSZ
				__XEWwBeJZr2f0E1PrhLNzMlAg.open(self, App.__M0ImV248NGNrBFXy9NCs5jwX(), __EpTvmaXol3cFft69bdnVvE47.__kD5MpGbGI03ItQXuZAiXJBoV)
				__XEWwBeJZr2f0E1PrhLNzMlAg.closed.connect( func(_changed: bool) -> void :
					__zABAFBwuGIufBHjRN9OzcNUm.__Qa9GbnhM8GDjcw4fKszR0Ftz()
					__6pxkC4sNZa9WOALnv6p7pHFW())
				return
			__XEWwBeJZr2f0E1PrhLNzMlAg = __Yhtjf6iNuuOlPMKYYcWPcH_E.__xXbVr55THU92NdaPxzeEXd_h.new()
			(__XEWwBeJZr2f0E1PrhLNzMlAg as __Yhtjf6iNuuOlPMKYYcWPcH_E.__xXbVr55THU92NdaPxzeEXd_h).__V0pOn5Sa7N2eQmRM4kwRkT34 = __dvs0MLvlYdZDLL4lsT3l2QSZ
			(__XEWwBeJZr2f0E1PrhLNzMlAg as __Yhtjf6iNuuOlPMKYYcWPcH_E.__xXbVr55THU92NdaPxzeEXd_h).__ODueSvGeVnWggM8WyoKBoh4p = func() -> void :
				__XEWwBeJZr2f0E1PrhLNzMlAg.close()
				__I25PS__nxrcT5ue1XHwV6CDj("crew_class_tree", __dvs0MLvlYdZDLL4lsT3l2QSZ)
			__HH7f9Yuw1k40PFOblbbQmP31 = __Yhtjf6iNuuOlPMKYYcWPcH_E.__xXbVr55THU92NdaPxzeEXd_h.__kD5MpGbGI03ItQXuZAiXJBoV
		"crew_class_tree":
			__XEWwBeJZr2f0E1PrhLNzMlAg = __A9siWowpicq5H3l6WhnZGACT.new()
			(__XEWwBeJZr2f0E1PrhLNzMlAg as __A9siWowpicq5H3l6WhnZGACT).__V0pOn5Sa7N2eQmRM4kwRkT34 = __dvs0MLvlYdZDLL4lsT3l2QSZ
			__HH7f9Yuw1k40PFOblbbQmP31 = __A9siWowpicq5H3l6WhnZGACT.__kD5MpGbGI03ItQXuZAiXJBoV
		"crew_rct":
			__XEWwBeJZr2f0E1PrhLNzMlAg = __Yhtjf6iNuuOlPMKYYcWPcH_E.__1UIbDU5PBDW9zTROIk0EOypE.new()
			(__XEWwBeJZr2f0E1PrhLNzMlAg as __Yhtjf6iNuuOlPMKYYcWPcH_E.__1UIbDU5PBDW9zTROIk0EOypE).__V0pOn5Sa7N2eQmRM4kwRkT34 = __dvs0MLvlYdZDLL4lsT3l2QSZ
			__HH7f9Yuw1k40PFOblbbQmP31 = __Yhtjf6iNuuOlPMKYYcWPcH_E.__1UIbDU5PBDW9zTROIk0EOypE.__kD5MpGbGI03ItQXuZAiXJBoV
		"crew_rename":
			__XEWwBeJZr2f0E1PrhLNzMlAg = __Yhtjf6iNuuOlPMKYYcWPcH_E.__a81Vt_Q1MjjhXO3fdlyOiBFi.new()
			(__XEWwBeJZr2f0E1PrhLNzMlAg as __Yhtjf6iNuuOlPMKYYcWPcH_E.__a81Vt_Q1MjjhXO3fdlyOiBFi).__V0pOn5Sa7N2eQmRM4kwRkT34 = __dvs0MLvlYdZDLL4lsT3l2QSZ
			__HH7f9Yuw1k40PFOblbbQmP31 = __Yhtjf6iNuuOlPMKYYcWPcH_E.__a81Vt_Q1MjjhXO3fdlyOiBFi.__kD5MpGbGI03ItQXuZAiXJBoV
		_:
			return
	__XEWwBeJZr2f0E1PrhLNzMlAg.open(self, App.__M0ImV248NGNrBFXy9NCs5jwX(), __HH7f9Yuw1k40PFOblbbQmP31)
	__XEWwBeJZr2f0E1PrhLNzMlAg.closed.connect( func(_changed: bool) -> void : __zABAFBwuGIufBHjRN9OzcNUm.__Qa9GbnhM8GDjcw4fKszR0Ftz())
func _process(delta: float) -> void :
	__1oElkVOacHIBcLWKCKhilZGK += delta
	if __1oElkVOacHIBcLWKCKhilZGK >= __iyXQN8g3iSlyBnDeXZtdYNFb * __lAo0PsogaUvqHw4muTzPsHiR.__qYP_YAvOQ8TvQJjfN6xGqOuz / 1000.0:
		__1oElkVOacHIBcLWKCKhilZGK = 0.0
		__ZCxIMxSxCw6Qw0WQFirwHFdX += 1
		__ORPVAwaEZaG_WUKCzYPqV3CM[__mOIKXCImd8wL9QEMRay3qaCq].queue_redraw()
		__dAGqnexg_IDbNw344d0sOBgZ[__mOIKXCImd8wL9QEMRay3qaCq].queue_redraw()
	if __XwGmCs7gUex6WMx0F0Lapr6y.__XjGaUOWs0Np2e5CRYzKY4VNU():
		__X_kchlTgjXLrGf3SqqJZxguo += delta
		while __X_kchlTgjXLrGf3SqqJZxguo >= __VUbN2QpEwLpgQ0qZYkOnqtug and __XwGmCs7gUex6WMx0F0Lapr6y.__XjGaUOWs0Np2e5CRYzKY4VNU():
			__X_kchlTgjXLrGf3SqqJZxguo -= __VUbN2QpEwLpgQ0qZYkOnqtug
			if __XwGmCs7gUex6WMx0F0Lapr6y.__kC6zD903kIOB35eRqjx8Rhn6():
				__NJiRcQ_010d3zGothv6OVgV4()
			else:
				__Nr08CaoCcAMr_GFSY2lMjw8a()
func __xl8CsL_efSUi0ouukZP0cFvu() -> void :
	var all: Array[__XZQIsX2REk1j2LWZtbLIAovG] = []
	all.append_array(__ORPVAwaEZaG_WUKCzYPqV3CM)
	all.append_array(__dAGqnexg_IDbNw344d0sOBgZ)
	all.sort_custom( func(a: __XZQIsX2REk1j2LWZtbLIAovG, b: __XZQIsX2REk1j2LWZtbLIAovG) -> bool: return int(a.get_meta("depth")) < int(b.get_meta("depth")))
	for __cN3WbQX_iaFUbCTUKGQmlXY4: int in all.size():
		__CgtEZnFtJYvrLjlSjFnhNN9n.canvas.move_child(all[__cN3WbQX_iaFUbCTUKGQmlXY4], __cN3WbQX_iaFUbCTUKGQmlXY4)
const __QztUZScy642DTR6_l0cQ30yE: = Color(0.3, 0.45, 0.6, 0.7)
var __v9ZnZMSMzoVWGyPBRc8ApWfd: Dictionary = {}
func __l6GSBpoEn3a9XcT2fQAVy101() -> void :
	if __vB6Uge3peTq8e97V0wYhk4lc == null:
		return
	var __oHWQuZUHvSzOa4DzRu_JfSI2: __MxRtF5kMQ2PhDOJRxJ1ej8ie = App.__M0ImV248NGNrBFXy9NCs5jwX()
	__vB6Uge3peTq8e97V0wYhk4lc.clear()
	for __OnOlj0YvoFwYmeyVBhFVQtij: int in __U7UMfwBewiXSLEeaDnywaCO7.__cJgd6eKF6AH0LnYDzJxWJpYq:
		if __Se4EsxPBCHX48h1ZS5MexaMl.__G8VgBybQlmXf2sdRasT3PwJT(__OnOlj0YvoFwYmeyVBhFVQtij) and __OnOlj0YvoFwYmeyVBhFVQtij != __cG_zbW1sotj7reUf4u7FXswZ:
			continue
		__vB6Uge3peTq8e97V0wYhk4lc.add_item("%s　%s" % [tr("UI_HARBOR_NAME_%d" % __OnOlj0YvoFwYmeyVBhFVQtij), tr("UI_HARBOR_LIST_OWNED") % __U7UMfwBewiXSLEeaDnywaCO7.__vwjNIITOPVtRhfVJi6Wz56IY(__OnOlj0YvoFwYmeyVBhFVQtij).size()], __OnOlj0YvoFwYmeyVBhFVQtij)
		var __JAk00oi3O_J_6pdYoVFcdWnF: int = __vB6Uge3peTq8e97V0wYhk4lc.get_item_index(__OnOlj0YvoFwYmeyVBhFVQtij)
		var __qTj2ngGPuV_FU50aTwWaBDIH: bool = __oHWQuZUHvSzOa4DzRu_JfSI2.__aGKFFuWZttAOryPti7pfE3iP(__OnOlj0YvoFwYmeyVBhFVQtij)
		__vB6Uge3peTq8e97V0wYhk4lc.set_item_disabled(__JAk00oi3O_J_6pdYoVFcdWnF, not __qTj2ngGPuV_FU50aTwWaBDIH)
		__vB6Uge3peTq8e97V0wYhk4lc.set_item_tooltip(__JAk00oi3O_J_6pdYoVFcdWnF, tr("UI_HARBOR_TIP_NEUTRAL") if __OnOlj0YvoFwYmeyVBhFVQtij == 0
			else (tr("UI_HARBOR_TIP_NATION") if __qTj2ngGPuV_FU50aTwWaBDIH else tr("UI_HARBOR_ERR_NO_CAPTAIN")))
	__vB6Uge3peTq8e97V0wYhk4lc.select(__vB6Uge3peTq8e97V0wYhk4lc.get_item_index(__cG_zbW1sotj7reUf4u7FXswZ))
func __WOYaQyPSpqITLw4waP2ZLJFW() -> void :
	var __0MYlqm36yHDHPl3g4GR5QuFD: int = await UI.__Dzq5SbxUBHUUe7FLUyy2rI_S(tr("UI_QUIT"), tr("UI_DOCK_QUIT_ASK"), [tr("UI_OK"), tr("UI_CANCEL")])
	if __0MYlqm36yHDHPl3g4GR5QuFD == 0:
		App.__XA31hlcqDbRgIKg3l91mYJVw()
func __oNXMHUSsPA1w6ptv1axRE83e(__XHBGPXSkZEuTqdJQDZuUcEtm: int, count: int) -> void :
	var __2slxKVaWt4rdClLVaENvRIrO: __Se4EsxPBCHX48h1ZS5MexaMl = App.__PtNURh2PaYHMgsPlkLtni90Y()
	var __F97aBDkPkJIC0g1uEqOktehg: String = __MRgAcPuNvSjtNvNirEW1YRMP.get("kind", "")
	var __YcwuKEwAe2fO8BZggmyqDG_F: int = int(__MRgAcPuNvSjtNvNirEW1YRMP.get("index", 0))
	var __OBjUyNmRVGx6YnhG8NPrzvAS: __s8yZigV26lPAvEmbOWzMbnjE = __kSFTyf6nLIFkdB6li7_pZbjR(__YJgAymCaLB78BrFx7OQpn545, __F97aBDkPkJIC0g1uEqOktehg, __YcwuKEwAe2fO8BZggmyqDG_F, __XHBGPXSkZEuTqdJQDZuUcEtm, count)
	var __CAYSNeuSGqbW_8ai5FEAbfHM: int = __9iFcUUuz7hxSygPtA9oE6aBm(__OBjUyNmRVGx6YnhG8NPrzvAS)
	if __CAYSNeuSGqbW_8ai5FEAbfHM != __Se4EsxPBCHX48h1ZS5MexaMl.__5CDMR1_ZY_Be5hesPdyczkNt.OK:
		UI.__FZyGB2TVbKGb1g8kgT4bm_x4(tr("UI_SS_ERR_%d" % __CAYSNeuSGqbW_8ai5FEAbfHM))
		return
	var __1YgHTtOrehha5t1ZDeqnZvAt: int = __JwSiZuZjR6gRSDzlX_9CypDI(__F97aBDkPkJIC0g1uEqOktehg, __YcwuKEwAe2fO8BZggmyqDG_F, __XHBGPXSkZEuTqdJQDZuUcEtm, count)
	if __1YgHTtOrehha5t1ZDeqnZvAt > 0:
		var __1IkuLC6CssfMg6NUce5hnJJr: String = App.__M0ImV248NGNrBFXy9NCs5jwX().__CwpKXs02n6e7mZnAMz9VvPw1(__1YgHTtOrehha5t1ZDeqnZvAt, 0, __Bsl33jE0VgUtGf0ZDYkuZAkg.__MAuObtKplQF6qga2KCMkBh19, __OBjUyNmRVGx6YnhG8NPrzvAS.__WeB9Hi0OxaFBUuwm2WU2qKEH)
		if __1IkuLC6CssfMg6NUce5hnJJr != "":
			UI.__FZyGB2TVbKGb1g8kgT4bm_x4(tr(__1IkuLC6CssfMg6NUce5hnJJr))
			return
		__blI3OKMoz5eY7cONdkS5OvD2(__F97aBDkPkJIC0g1uEqOktehg, __YcwuKEwAe2fO8BZggmyqDG_F, __XHBGPXSkZEuTqdJQDZuUcEtm, count)
	__jKRAoSDLaIkEgmrqlSCQwgKI()
	__FqUftbENBVycK58vij71NAQ6(__OBjUyNmRVGx6YnhG8NPrzvAS, __eIpp4vouyAkAw9Ef1LuxCpw8.has(__F97aBDkPkJIC0g1uEqOktehg))
func __ootmMmOyDzknp1ZTjZr6AIDH(__yn_RKVeE2WxX_K0e6qarMoy1: bool) -> void :
	__MRgAcPuNvSjtNvNirEW1YRMP["bulk"] = __yn_RKVeE2WxX_K0e6qarMoy1
	var __gAypEPyZ7UdQsC44FbR8bhvp: String = __MRgAcPuNvSjtNvNirEW1YRMP.get("kind", "")
	__iDtSeet9d1hrG4U2QlY48W6q(__gAypEPyZ7UdQsC44FbR8bhvp, int(__MRgAcPuNvSjtNvNirEW1YRMP.get("index", 0)), __M3mMe5n3JrbgRvzvIt9w1QZt.__SKkzt2V9VwSl4moBh6ItGWoR, int(__M3mMe5n3JrbgRvzvIt9w1QZt.__pGYPnCjsxdL6L5pwoYNpA3ej.value) if __gAypEPyZ7UdQsC44FbR8bhvp in ["A", "B", "SA", "SB"] else 1)
	__M3mMe5n3JrbgRvzvIt9w1QZt.__dZVaFt72SjKeVnqq5qEAr_1C()
func __bdSuhO73wCElsaHHBK60fLLA(__P6whji0AUo2CboBKI0MFYgm4: String, __bzlzvzQqplqKZB9fJRq8Awck: int) -> int:
	var __HcbQXr_y2WjO4UvYqlZSC_5c: __Se4EsxPBCHX48h1ZS5MexaMl = App.__PtNURh2PaYHMgsPlkLtni90Y()
	match __P6whji0AUo2CboBKI0MFYgm4:
		"R":
			return __9MFWgnc8oYQpY6kqM0OFfhrH.__DML16gO8cwjCLXpZX4VG3A4V(__HcbQXr_y2WjO4UvYqlZSC_5c.__eezCSxsQSp01HYni_60fHV16(__YJgAymCaLB78BrFx7OQpn545.__WeB9Hi0OxaFBUuwm2WU2qKEH)[int(__MRgAcPuNvSjtNvNirEW1YRMP.get("index", 0))], __Se4EsxPBCHX48h1ZS5MexaMl.__MmvhtidBsePDvXycLyLNHv8h, 0)
		"G", "S":
			return __9MFWgnc8oYQpY6kqM0OFfhrH.__oIlEwgCjkKEdMkJiDlZRhfe7("gun", __HcbQXr_y2WjO4UvYqlZSC_5c.__Y7oNU_MxqAazQR74RzaCuaOa(__bzlzvzQqplqKZB9fJRq8Awck))
		"L":
			return __9MFWgnc8oYQpY6kqM0OFfhrH.__oIlEwgCjkKEdMkJiDlZRhfe7("launcher", __HcbQXr_y2WjO4UvYqlZSC_5c.__GP_inhBqbirtrHNQn7xXbKG_(__bzlzvzQqplqKZB9fJRq8Awck))
		"F":
			return __9MFWgnc8oYQpY6kqM0OFfhrH.__oIlEwgCjkKEdMkJiDlZRhfe7("fcs", __HcbQXr_y2WjO4UvYqlZSC_5c.__vwSAcybbCInOpnt2FbN4qz7L(__bzlzvzQqplqKZB9fJRq8Awck))
		"E":
			return __9MFWgnc8oYQpY6kqM0OFfhrH.__oIlEwgCjkKEdMkJiDlZRhfe7("engine", __HcbQXr_y2WjO4UvYqlZSC_5c.__NELIelBEafKRGQultNqYAbM7(__bzlzvzQqplqKZB9fJRq8Awck))
		"P":
			return __9MFWgnc8oYQpY6kqM0OFfhrH.__FuqnpRY0H37YA_Ulwj8fJpaq(__HcbQXr_y2WjO4UvYqlZSC_5c.__gobxGwIVlftvCfJ1fsNzSlj7(__bzlzvzQqplqKZB9fJRq8Awck))
		"M":
			var __m5A4yEo70LBa7LvHKRIwD8EA: int = __Se4EsxPBCHX48h1ZS5MexaMl.__Uv7vWKACrD3IoOv6puOgq1PA[int(__MRgAcPuNvSjtNvNirEW1YRMP.get("index", 0))]
			return __9MFWgnc8oYQpY6kqM0OFfhrH.__ghwoJ5UFJ3Y1ZKvfBWWXPwOi(__HcbQXr_y2WjO4UvYqlZSC_5c.__J3yVFTJGIFg8UxUlZ9VcpBHF(__m5A4yEo70LBa7LvHKRIwD8EA, __bzlzvzQqplqKZB9fJRq8Awck))
		"T":
			return __9MFWgnc8oYQpY6kqM0OFfhrH.__RqJZeOtqPPYKlwE68mX9QyHo(__HcbQXr_y2WjO4UvYqlZSC_5c.__zhHTezbt3nPUGWVaU6OaVpvy(__bzlzvzQqplqKZB9fJRq8Awck))
		"A", "B", "SA", "SB":
			return __9MFWgnc8oYQpY6kqM0OFfhrH.__TLcNJZF14QZ0UbxJjxI3AtuW(__HcbQXr_y2WjO4UvYqlZSC_5c.__Z1n6LQ0e8g_Sv5O7it1HPeiw(__bzlzvzQqplqKZB9fJRq8Awck))
	return 0
var __LcEmKczmLrorVyOBaMDnHamK: Dictionary = {}
var __g4VcMyfHpzn9RPSMtrItVE0s: __PRH8kkL2nSrpnpKj0kGyYFZt
func __iDtSeet9d1hrG4U2QlY48W6q(__6KABF7zfrZ_PqK2KCDEXUm3h: String, __qDXLhFmYYMG4bgpkH7l9DP_7: int, __6USUfVTCJ1tjUDdy_E79NCeR: Array[Dictionary], count: int) -> void :
	var __o__esd7WEh5kWg23bovbQOA5: __Se4EsxPBCHX48h1ZS5MexaMl = App.__PtNURh2PaYHMgsPlkLtni90Y()
	var __QwXEsd2SrI02bku5S0ys2jfG: int = App.__M0ImV248NGNrBFXy9NCs5jwX().__RuEf8sDpDtu0ArTJYzf6W0JG() if __kinsDyUwBqfk_kcYtvIhl2eK else 0
	var __RzQMCb5MtDmIjTDrp7mmkn9U: int = __o__esd7WEh5kWg23bovbQOA5.__77YZ0E3pilwCWMSZ5lHzv_es(__YJgAymCaLB78BrFx7OQpn545).y
	for __oSfrAXexu0Wjayum1KoVXcly: Dictionary in __6USUfVTCJ1tjUDdy_E79NCeR:
		var __xbF9NVBjTDceKDwvzKbCZ3TT: int = __o__esd7WEh5kWg23bovbQOA5.__77YZ0E3pilwCWMSZ5lHzv_es(__kSFTyf6nLIFkdB6li7_pZbjR(__YJgAymCaLB78BrFx7OQpn545, __6KABF7zfrZ_PqK2KCDEXUm3h, __qDXLhFmYYMG4bgpkH7l9DP_7, int(__oSfrAXexu0Wjayum1KoVXcly["row"]), maxi(1, count))).x + __QwXEsd2SrI02bku5S0ys2jfG
		var __pXPjh4ghEBdDDXqtAZfOI549: PackedStringArray = __oSfrAXexu0Wjayum1KoVXcly["cols"]
		__pXPjh4ghEBdDDXqtAZfOI549[0] = __9MFWgnc8oYQpY6kqM0OFfhrH.__57yYqv9212r7qj7iu02kGdA8(__xbF9NVBjTDceKDwvzKbCZ3TT / 1000)
		__oSfrAXexu0Wjayum1KoVXcly["cols"] = __pXPjh4ghEBdDDXqtAZfOI549
		__oSfrAXexu0Wjayum1KoVXcly["warn"] = [0] if __xbF9NVBjTDceKDwvzKbCZ3TT > __RzQMCb5MtDmIjTDrp7mmkn9U else []
static func __awtgICygsB4J5VNPf86ioBCU(rings: Array[Dictionary]) -> void :
	var __2lfNX8yjYRffgO_AKfP9MCQE: Array[Dictionary] = []
	for d: Dictionary in rings:
		if d.has("mount_pos") and (d["mount_pos"] as Vector2).x < 512.0:
			var __5WIQRXKJpwmn1Vzhrjouegoz: Vector2 = __c7JT2pWXsKuTeLAJDg1Em0cn
			var s: int = int(d.get("slot", -1))
			if s >= 0:
				__5WIQRXKJpwmn1Vzhrjouegoz.y += __ddYJ_F4TuBySIEY5POO5wxej * float(s >> 1)
			d["pos"] = (d["pos"] as Vector2) + __5WIQRXKJpwmn1Vzhrjouegoz
			__2lfNX8yjYRffgO_AKfP9MCQE.append(d)
	if __2lfNX8yjYRffgO_AKfP9MCQE.is_empty():
		return
	for r: Dictionary in rings:
		if r.has("mount_pos") and (r["mount_pos"] as Vector2).x < 512.0:
			continue
		var __ALxnoRKhRqSsQJts6tE0P_lp: Vector2 = r["pos"]
		var __tYmwbxpRZnkIaj_2rkIzpQk_: = Vector2.ZERO
		for b: Dictionary in __2lfNX8yjYRffgO_AKfP9MCQE:
			var d: Vector2 = __ALxnoRKhRqSsQJts6tE0P_lp - (b["pos"] as Vector2)
			if absf(d.x) >= __MFxRMYlL0G8y0Dw2Fzt_Gu5p - 0.5 or absf(d.y) >= __PsVlZoS1bDNQtGQflwNZKZfH - 0.5:
				continue
			var __JxdZKYb_IM9lzhXqVBwzAt6s: float = __MFxRMYlL0G8y0Dw2Fzt_Gu5p - 0.5 - absf(d.x)
			var __ljQDG_v256onU62nw62gpV5O: float = __PsVlZoS1bDNQtGQflwNZKZfH - 0.5 - absf(d.y)
			if __ljQDG_v256onU62nw62gpV5O <= __JxdZKYb_IM9lzhXqVBwzAt6s:
				__tYmwbxpRZnkIaj_2rkIzpQk_.y = (-1.0 if d.y < 0.0 else 1.0) * maxf(absf(__tYmwbxpRZnkIaj_2rkIzpQk_.y), __ljQDG_v256onU62nw62gpV5O)
			else:
				__tYmwbxpRZnkIaj_2rkIzpQk_.x = (-1.0 if d.x < 0.0 else 1.0) * maxf(absf(__tYmwbxpRZnkIaj_2rkIzpQk_.x), __JxdZKYb_IM9lzhXqVBwzAt6s)
		if __tYmwbxpRZnkIaj_2rkIzpQk_.length_squared() == 0.0:
			continue
		if not r.has("mount_pos"):
			r["mount_pos"] = r["pos"]
		r["pos"] = __ALxnoRKhRqSsQJts6tE0P_lp + __tYmwbxpRZnkIaj_2rkIzpQk_
static func __i9hHpabGq0vj3HV9AiaCAWeq(__Siqiey3ldqwSsrGKWkjGxCEE: Array[__s8yZigV26lPAvEmbOWzMbnjE], __TJeRHUYuORV5rjLn65aCpViE: int) -> int:
	for __OOTOl2lP36ONeIXmerjYIFqA: int in __Siqiey3ldqwSsrGKWkjGxCEE.size():
		if __Siqiey3ldqwSsrGKWkjGxCEE[__OOTOl2lP36ONeIXmerjYIFqA].__WeB9Hi0OxaFBUuwm2WU2qKEH == __TJeRHUYuORV5rjLn65aCpViE:
			return __OOTOl2lP36ONeIXmerjYIFqA
	return -1
const __R5d7t9GbgflrBdLy_NZHGRej: = 1.5
var __XwGmCs7gUex6WMx0F0Lapr6y: = __AULjCEkcKgaRzYRXGAcwDg5F.new()
static func __OxdJ_NoNx8kaEiMmhOb1YV2i(keys: Array) -> PackedStringArray:
	var __s50Taw0N7mGcv1GIG7y5rAoL: = PackedStringArray()
	for ___cR8mZ8nkTBnpAnYxwSZKKHm: String in keys:
		__s50Taw0N7mGcv1GIG7y5rAoL.append("" if ___cR8mZ8nkTBnpAnYxwSZKKHm == "" else TranslationServer.translate("UI_MKH_" + ___cR8mZ8nkTBnpAnYxwSZKKHm))
	return __s50Taw0N7mGcv1GIG7y5rAoL
func __vBWmMEhTlUHMKip4iGCUpqeV(__J8hlVGyode128ucs7mpJyfSI: String, index: int) -> void :
	var __DHzskTsCads2JL8DF21kHDgQ: __Se4EsxPBCHX48h1ZS5MexaMl = App.__PtNURh2PaYHMgsPlkLtni90Y()
	__MRgAcPuNvSjtNvNirEW1YRMP = {"kind": __J8hlVGyode128ucs7mpJyfSI, "index": index}
	var __Pm2edSb2krP_Td3DSs5g3I5J: Array[Dictionary] = []
	if __J8hlVGyode128ucs7mpJyfSI == "T":
		var __BML14cOqnl0JN50DqMccNcML: int = index
		var __kv4nampDJjRuGM0bcTE5x3tZ: int = __DHzskTsCads2JL8DF21kHDgQ.__7uBhyRNBJZP4s1InKu8Lo_y7(__YJgAymCaLB78BrFx7OQpn545)[__BML14cOqnl0JN50DqMccNcML]
		var __MEpvEl8mvvUbRgUnnWhsQiso: Dictionary = __DHzskTsCads2JL8DF21kHDgQ.__GP_inhBqbirtrHNQn7xXbKG_(__kv4nampDJjRuGM0bcTE5x3tZ)
		var __OF3XPCtZCKdIpFBGeil4p8Kp: PackedInt32Array = __DHzskTsCads2JL8DF21kHDgQ.__El7brR86C9a6x0hMgLnIgY3e(__YJgAymCaLB78BrFx7OQpn545)
		for __R2A50CbSS9mIgVleulMIUUvt: Dictionary in __DHzskTsCads2JL8DF21kHDgQ.__Eq6dO6M6_7MWAPU_wDTxG86o(__kv4nampDJjRuGM0bcTE5x3tZ):
			var __eCHCHbjlLAa7MBpWggxLUSBD: int = __9MFWgnc8oYQpY6kqM0OFfhrH.__RqJZeOtqPPYKlwE68mX9QyHo(__R2A50CbSS9mIgVleulMIUUvt)
			__Pm2edSb2krP_Td3DSs5g3I5J.append({"row": __R2A50CbSS9mIgVleulMIUUvt["row"], "name": __R2A50CbSS9mIgVleulMIUUvt["name"], "cols": PackedStringArray([str(__eCHCHbjlLAa7MBpWggxLUSBD), __sadJuUS1UT0UzhHxF1koKG0C(int(__R2A50CbSS9mIgVleulMIUUvt["weight"])), __TYkQtj0KJU3imI91kByy1UpC(int(__R2A50CbSS9mIgVleulMIUUvt["size"]), 10), "—", __TYkQtj0KJU3imI91kByy1UpC(int(__R2A50CbSS9mIgVleulMIUUvt["inch"]), 100), "HE: %d" % int(__R2A50CbSS9mIgVleulMIUUvt["dmg"])]), "info": PackedStringArray([tr("UI_MARKET_TORP_INFO") % [int(__R2A50CbSS9mIgVleulMIUUvt["spd_slow"]) / 10, int(__R2A50CbSS9mIgVleulMIUUvt["spd_fast"]) / 10, __R2A50CbSS9mIgVleulMIUUvt["r_slow"], __R2A50CbSS9mIgVleulMIUUvt["r_fast"]], tr("UI_MARKET_TORP_INFO2") % [int(__MEpvEl8mvvUbRgUnnWhsQiso.get("tubes", 0)), __DHzskTsCads2JL8DF21kHDgQ.__1CdXpyU1UJ8cmNMTd_g2_0od(__YJgAymCaLB78BrFx7OQpn545), __DHzskTsCads2JL8DF21kHDgQ.__eO4VHYjMVObwrueIqrahxQOQ(__YJgAymCaLB78BrFx7OQpn545.__WeB9Hi0OxaFBUuwm2WU2qKEH)]])})
		__iDtSeet9d1hrG4U2QlY48W6q("T", __BML14cOqnl0JN50DqMccNcML, __Pm2edSb2krP_Td3DSs5g3I5J, __OF3XPCtZCKdIpFBGeil4p8Kp[2 * __BML14cOqnl0JN50DqMccNcML + 1])
		__M3mMe5n3JrbgRvzvIt9w1QZt.__799M3JC0EaDgzpGgsujWtZDg(tr("UI_EQUIP_BUY_TORP"), __Pm2edSb2krP_Td3DSs5g3I5J, __OF3XPCtZCKdIpFBGeil4p8Kp[2 * __BML14cOqnl0JN50DqMccNcML], __OF3XPCtZCKdIpFBGeil4p8Kp[2 * __BML14cOqnl0JN50DqMccNcML + 1], tr("UI_MARKET_UNIT_TORP"), func(__QLaWiGFzMUqRsy0eJVcHTzqU: int) -> int: return __DHzskTsCads2JL8DF21kHDgQ.__NF17pkeCRjppVnRyjoaErSBP(__YJgAymCaLB78BrFx7OQpn545, __BML14cOqnl0JN50DqMccNcML, __QLaWiGFzMUqRsy0eJVcHTzqU), __OxdJ_NoNx8kaEiMmhOb1YV2i(["DISP", "WEIGHT", "SIZE", "", "CAL", "DMG"]))
	else:
		var __EOlJ3Sd7mCGmmpb_ZzJDFqxj: int = index
		var __XQRfbRunCPYeVtdsXjjFT1ea: int = 0 if __J8hlVGyode128ucs7mpJyfSI == "A" or __J8hlVGyode128ucs7mpJyfSI == "SA" else 1
		var __WT7nNamhKluC0le0xo0pf2vn: bool = __J8hlVGyode128ucs7mpJyfSI == "SA" or __J8hlVGyode128ucs7mpJyfSI == "SB"
		var __dhUJF96lmnmgVah0TFuSHhTi: PackedInt32Array = __DHzskTsCads2JL8DF21kHDgQ.__Xs0yLUqBQ7TVWSHzfx4EiUAr(__YJgAymCaLB78BrFx7OQpn545) if __WT7nNamhKluC0le0xo0pf2vn else __DHzskTsCads2JL8DF21kHDgQ.__RgxkBWnYRjC44wuJnI7BKnV_(__YJgAymCaLB78BrFx7OQpn545)
		var grow: int = __DHzskTsCads2JL8DF21kHDgQ.__PJZemYw0whDwrAt4vbBLpQ7w(__YJgAymCaLB78BrFx7OQpn545)[__EOlJ3Sd7mCGmmpb_ZzJDFqxj] if __WT7nNamhKluC0le0xo0pf2vn else __YJgAymCaLB78BrFx7OQpn545.__dOsDavODOasdfPxqce2DEBC3[__EOlJ3Sd7mCGmmpb_ZzJDFqxj]
		for s: Dictionary in __DHzskTsCads2JL8DF21kHDgQ.__WAgRVTs1_HQp6rDVY1IrTH4R(grow):
			var __m1ZmhEKizp3C02FX6_gnXwTI: String = tr(__Se4EsxPBCHX48h1ZS5MexaMl.__t9BykvPbNOqdOsY2A_MmTW3G.get(int(s["kind"]), "UI_SHELL_HE"))
			var __N2rhy6Wigfi1J3Anu8U9LjYo: int = __9MFWgnc8oYQpY6kqM0OFfhrH.__TLcNJZF14QZ0UbxJjxI3AtuW(s)
			__Pm2edSb2krP_Td3DSs5g3I5J.append({"row": s["row"], "name": s["name"], "cols": PackedStringArray([str(__N2rhy6Wigfi1J3Anu8U9LjYo), __sadJuUS1UT0UzhHxF1koKG0C(int(s["weight"])), __TYkQtj0KJU3imI91kByy1UpC(int(s["size"]), 10), tr("UI_MARKET_PER_BOX") % int(s["per_box"]), __TYkQtj0KJU3imI91kByy1UpC(int(s["cal"]), 100), __nghmrWgGzA35SxZI2P1Anffp(s, __m1ZmhEKizp3C02FX6_gnXwTI)]), "info": PackedStringArray([tr("UI_MARKET_SHELL_INFO") % [__m1ZmhEKizp3C02FX6_gnXwTI, int(s["per_box"]), int(s["he"]), int(s["ms"])]])})
		__iDtSeet9d1hrG4U2QlY48W6q(__J8hlVGyode128ucs7mpJyfSI, __EOlJ3Sd7mCGmmpb_ZzJDFqxj, __Pm2edSb2krP_Td3DSs5g3I5J, __dhUJF96lmnmgVah0TFuSHhTi[4 * __EOlJ3Sd7mCGmmpb_ZzJDFqxj + 2 * __XQRfbRunCPYeVtdsXjjFT1ea + 1])
		__M3mMe5n3JrbgRvzvIt9w1QZt.__799M3JC0EaDgzpGgsujWtZDg(tr("UI_MARKET_TITLE_SHELL") % ("A" if __XQRfbRunCPYeVtdsXjjFT1ea == 0 else "B"), __Pm2edSb2krP_Td3DSs5g3I5J, __dhUJF96lmnmgVah0TFuSHhTi[4 * __EOlJ3Sd7mCGmmpb_ZzJDFqxj + 2 * __XQRfbRunCPYeVtdsXjjFT1ea], __dhUJF96lmnmgVah0TFuSHhTi[4 * __EOlJ3Sd7mCGmmpb_ZzJDFqxj + 2 * __XQRfbRunCPYeVtdsXjjFT1ea + 1], tr("UI_MARKET_UNIT_BOX"), func(__lIEHMt4GHxXl8wbUZpcqVg0g: int) -> int: return __DHzskTsCads2JL8DF21kHDgQ.__S1JkThXHxWQxwiLptqbTPmWF(__lIEHMt4GHxXl8wbUZpcqVg0g), __OxdJ_NoNx8kaEiMmhOb1YV2i(["DISP", "WEIGHT", "SIZE", "PER_BOX", "CAL", "DMG"]))
	if __J8hlVGyode128ucs7mpJyfSI in ["A", "B", "SA", "SB"]:
		var meti_targets = meti_ammo_targets(__YJgAymCaLB78BrFx7OQpn545, __J8hlVGyode128ucs7mpJyfSI, index)
		__M3mMe5n3JrbgRvzvIt9w1QZt.__wJZ16sGJMQNBMMTnwRkCh1h1.text = "同型火砲全部套用此彈種與箱數"
		__M3mMe5n3JrbgRvzvIt9w1QZt.__5x9DaBJhmToi9o_kaheLa6ti("全艦相同型號火砲：%d 座（含目前砲位）" % meti_targets.size(), meti_targets.size() > 1)
	__M3mMe5n3JrbgRvzvIt9w1QZt.__3_xTsqGV9VjGQi22Qmd30tCZ = App.__M0ImV248NGNrBFXy9NCs5jwX().__ktyxvkLP8cTjwSfnZb3DAVcL
	__OLIvZVUTptJkSyJvw3VfbpFx.mouse_filter = Control.MOUSE_FILTER_IGNORE
	__OLIvZVUTptJkSyJvw3VfbpFx.process_mode = Node.PROCESS_MODE_DISABLED
func __N3KC95eWLPI7sAwuPnTXAPlz(__g2yIWaHFkockPJ0pHt27_7qW: int, __YX5F8A2U8JMmeEh8_Xq6Gt7P: int) -> void :
	__U7UMfwBewiXSLEeaDnywaCO7.__YxJ2LFlowlWru2boLJzQxnDR(__g2yIWaHFkockPJ0pHt27_7qW, __YX5F8A2U8JMmeEh8_Xq6Gt7P)
	__Lnl7EUrWdzkuBnGqxTLllE5o.__7UOhveRCaTsoEDa0ApcoO9Hc(__VkSeEGhVF0y6mvRsZYDTVhBy(), -1 if __DpM0JQWB6EqgMh3WJZSlHODu else __YJgAymCaLB78BrFx7OQpn545.__WeB9Hi0OxaFBUuwm2WU2qKEH)
	__UEBR9tHfREmwSw_VDgBW83Zc()
const __HN0NJbb6Q_9lIDlS9Nhmdl07: PackedInt32Array = [64, 72, 73, 74, 78, 79, 80, 89, 264]
var __hDON5_Ak_v4LQsqfesSFUaa2: __tALbI77Bj72RNkUjx1rJalbI
func ___l8BVmKnenFDKyyKSS6nkhs2(__AvwTqqBREg4CW3E0nMMzbhf8: String, __Syq8BeLrGhBTwUcUoRrb_9ou: int) -> String:
	var __O3q5je0ltmOd4dal6MGnCHjC: __Se4EsxPBCHX48h1ZS5MexaMl = App.__PtNURh2PaYHMgsPlkLtni90Y()
	var __VjfLN4kBe6Uhz3bw3ITh8K7B: int = __YJgAymCaLB78BrFx7OQpn545.__WeB9Hi0OxaFBUuwm2WU2qKEH
	match __AvwTqqBREg4CW3E0nMMzbhf8:
		"G":
			return "m:%d" % __O3q5je0ltmOd4dal6MGnCHjC.__1y_c36LINhCmyTQh_Ii1WqjM(__VjfLN4kBe6Uhz3bw3ITh8K7B)[__Syq8BeLrGhBTwUcUoRrb_9ou]
		"S":
			return "m:%d" % __O3q5je0ltmOd4dal6MGnCHjC.__4mBhSAAMIt6DTsibdV0pC19W(__VjfLN4kBe6Uhz3bw3ITh8K7B)[__Syq8BeLrGhBTwUcUoRrb_9ou]
		"L":
			return "m:%d" % __O3q5je0ltmOd4dal6MGnCHjC.__Hmr_a2CPvjknmgXnhmVu1vm9(__VjfLN4kBe6Uhz3bw3ITh8K7B)[__Syq8BeLrGhBTwUcUoRrb_9ou]
	return ""
func __FqUftbENBVycK58vij71NAQ6(__GBQHzJTzC1SVJlwyXV5EWKB6: __s8yZigV26lPAvEmbOWzMbnjE, __atZaHnhHp9QheMGfDbH0VT2x: bool) -> void :
	__U7UMfwBewiXSLEeaDnywaCO7.__VvG2q5CwvCNDjBta5Gspay17(__GBQHzJTzC1SVJlwyXV5EWKB6)
	App.__M0ImV248NGNrBFXy9NCs5jwX().__g7F3EfgE1iugY6qyUxtrpa1X(__GBQHzJTzC1SVJlwyXV5EWKB6)
	__YJgAymCaLB78BrFx7OQpn545 = __U7UMfwBewiXSLEeaDnywaCO7.__V0erSRNWoPFGOr7bG6vGIpsK()
	__h1tDxlSlZLzRDqez_H4rCrnn.__Zs_NRND2aIHjT0QBiS5yVaRm(__YJgAymCaLB78BrFx7OQpn545, App.__M0ImV248NGNrBFXy9NCs5jwX())
	__OLIvZVUTptJkSyJvw3VfbpFx.__Zs_NRND2aIHjT0QBiS5yVaRm(__YJgAymCaLB78BrFx7OQpn545)
	__6pxkC4sNZa9WOALnv6p7pHFW()
	__4VH5P1TCUJzfLL55i2_8NhQh()
	__pe4qYEePbdwmW4PHgEKOMRvQ("efit_026")
	if __atZaHnhHp9QheMGfDbH0VT2x:
		_load()
		if __zABAFBwuGIufBHjRN9OzcNUm != null:
			__zABAFBwuGIufBHjRN9OzcNUm.__Qa9GbnhM8GDjcw4fKszR0Ftz()
var __OLIvZVUTptJkSyJvw3VfbpFx: __vkUw3hIvnFxkI0lKRsW_x52c
static func __hXETMci8tRCb5H43aZxU11kA(__JbI6WAubZRVTLJ5E6RCtXkCS: __XZQIsX2REk1j2LWZtbLIAovG, __kK7Wn6MhlWSkUcrBFeRZpyvG: float) -> void :
	var __zdVjexir1BovZ_Pi4uxEGRVG: Color = __JbI6WAubZRVTLJ5E6RCtXkCS.get_meta("mod")
	__JbI6WAubZRVTLJ5E6RCtXkCS.modulate = Color(__zdVjexir1BovZ_Pi4uxEGRVG.r, __zdVjexir1BovZ_Pi4uxEGRVG.g, __zdVjexir1BovZ_Pi4uxEGRVG.b, __zdVjexir1BovZ_Pi4uxEGRVG.a * __kK7Wn6MhlWSkUcrBFeRZpyvG)
func __KBvSyqb0E64cDffp38Jzgf0n(frames: PackedInt32Array, __bBjUWtaLwg0VvrcReJWoA6EF: String, __jCdG6Qdn7Q0C7fAk5JuP7aNY: int) -> __pT6jZw1fUvWomUDaJvLtM_kC:
	var b: __pT6jZw1fUvWomUDaJvLtM_kC = __pT6jZw1fUvWomUDaJvLtM_kC.new().setup("Factory", frames)
	b.__9RXKdE_gtl2sb_GdIlIDy4Tb = __8ttsfVTKv2GQMNELL7rvBI7m
	b.tooltip_text = tr(__bBjUWtaLwg0VvrcReJWoA6EF)
	b.pressed.connect( func() -> void : __mqUFHwVuIEsH6CwazHRCsl7H(__jCdG6Qdn7Q0C7fAk5JuP7aNY))
	__CgtEZnFtJYvrLjlSjFnhNN9n.add_child(b)
	return b
func __H_kQDAV6SVBhX2avpZXAHYOV() -> void :
	pass
func __b3OT_DqwX0nLXYx0rgF1n9tz(__IKR90d2BNpi_pfHeae52vLvu: String) -> void :
	if __DpM0JQWB6EqgMh3WJZSlHODu or __QGam_vw7iuxNHReFko2qucjH == null:
		return
	if __IKR90d2BNpi_pfHeae52vLvu == "engine" or __IKR90d2BNpi_pfHeae52vLvu == "armor":
		if __PIgmWxhh53prim2mxCzKxY1r():
			UI.__FZyGB2TVbKGb1g8kgT4bm_x4(tr("UI_TRADE_ERR_UNIQUE"))
			return
		if __IKR90d2BNpi_pfHeae52vLvu == "engine":
			__HuRyg1NMVNcEpLPmiIJdll32("E", 0)
		else:
			__ZBgdLfAUaOUa6XyG2otMcWz3()
		return
	if __aBhCjT5h4HuVdMnKzKKIXLBp != "shipyard":
		return
	__ZFd4wePpEaVpfpGejOdwVKGR("ship")
	__QGam_vw7iuxNHReFko2qucjH.__oaByrCEPubELPUhaG5FJq8wQ(__IKR90d2BNpi_pfHeae52vLvu)
const __ygqZC5GYwvDxRK4lKL33IS35: = 53.0
const __MFxRMYlL0G8y0Dw2Fzt_Gu5p: = 48.0
var __dAGqnexg_IDbNw344d0sOBgZ: Array[__XZQIsX2REk1j2LWZtbLIAovG] = []
func __pe4qYEePbdwmW4PHgEKOMRvQ(name: String) -> void :
	var s: AudioStream = Assets.__VWTz_3tco6FMqwI4IUjhdite(name)
	if s == null:
		return
	if __dLFfKMSP4H8zZsNWU4JoHUfw == null:
		__dLFfKMSP4H8zZsNWU4JoHUfw = AudioStreamPlayer.new()
		add_child(__dLFfKMSP4H8zZsNWU4JoHUfw)
	__dLFfKMSP4H8zZsNWU4JoHUfw.stream = s
	__dLFfKMSP4H8zZsNWU4JoHUfw.volume_db = __aAsznirtmGYBj3M14TNZD1Cc.__1MgKhkxufTzhTeEAZI9p2Rhd()
	__dLFfKMSP4H8zZsNWU4JoHUfw.play()
func __nH_Ui7JFNxgWXW_3iO9RuiFB() -> Array[Dictionary]:
	var __RoqGI7ICgRD9q3k11bYpdtW_: Array[Dictionary] = []
	var __45xBjMQ4YLHtPTFZwYFtF2N6: __bzxMmNAcE_RKMny5gklgDglw = App.___qFCN2viGM2bPW1uGV9qys9h()
	var __NS2OAyjTxQvb8EWE5Nb0vByM: __Se4EsxPBCHX48h1ZS5MexaMl = App.__PtNURh2PaYHMgsPlkLtni90Y()
	var __DHw7nvVg2Jz6zw2_6hTuIann: int = __YJgAymCaLB78BrFx7OQpn545.__WeB9Hi0OxaFBUuwm2WU2qKEH
	var __vkfBXgeczTbc9TrFuMfiOcwa: int = mini((__45xBjMQ4YLHtPTFZwYFtF2N6.__Jy2hcMM9emCF3iBBkLMyeUr7("Frame", __DHw7nvVg2Jz6zw2_6hTuIann, 12) >> 10) & 31, 28)
	var __09_l_fZod9hOqwdZgNesmiSt: int = __45xBjMQ4YLHtPTFZwYFtF2N6.__pGLr1ud1V6XsMMJoSyeTRFjY("Frame", __DHw7nvVg2Jz6zw2_6hTuIann, 616)
	var __FMc75HP3Nf2OmE9wjTa_6Vqg: int = __45xBjMQ4YLHtPTFZwYFtF2N6.__Jy2hcMM9emCF3iBBkLMyeUr7("Frame", __DHw7nvVg2Jz6zw2_6hTuIann, 4)
	var __2sR1C2FCfSCz2WayYscd_CRS: bool = ((__FMc75HP3Nf2OmE9wjTa_6Vqg >> 5) & 31) == 2
	var __lre3C8jfHRp8ykKj8Vv5_d0x: bool = ((__FMc75HP3Nf2OmE9wjTa_6Vqg >> 5) & 31) == 5 and (__FMc75HP3Nf2OmE9wjTa_6Vqg & 31) == 7 and (__45xBjMQ4YLHtPTFZwYFtF2N6.__Jy2hcMM9emCF3iBBkLMyeUr7("Frame", __DHw7nvVg2Jz6zw2_6hTuIann, 14) >> 4) >= 120
	var __RBfxADFUEjVgkL4CvlST7RKA: PackedInt32Array = __NS2OAyjTxQvb8EWE5Nb0vByM.__1y_c36LINhCmyTQh_Ii1WqjM(__DHw7nvVg2Jz6zw2_6hTuIann)
	var sides: PackedInt32Array = __NS2OAyjTxQvb8EWE5Nb0vByM.__4mBhSAAMIt6DTsibdV0pC19W(__DHw7nvVg2Jz6zw2_6hTuIann)
	var __gNAusJ6FNN59JQblPNtHMQ_2: PackedInt32Array = __NS2OAyjTxQvb8EWE5Nb0vByM.__Hmr_a2CPvjknmgXnhmVu1vm9(__DHw7nvVg2Jz6zw2_6hTuIann)
	var __wcff_d90hj9upnLq_h184Y4P: PackedInt32Array = __NS2OAyjTxQvb8EWE5Nb0vByM.__PJZemYw0whDwrAt4vbBLpQ7w(__YJgAymCaLB78BrFx7OQpn545)
	var __OCWGexk2jWCF4di4d_DxV0HJ: PackedInt32Array = __NS2OAyjTxQvb8EWE5Nb0vByM.__7uBhyRNBJZP4s1InKu8Lo_y7(__YJgAymCaLB78BrFx7OQpn545)
	for __B_zTG6eNXIHdE5YCYsEEdSn8: int in __vkfBXgeczTbc9TrFuMfiOcwa:
		var d: Dictionary = {"slot": __B_zTG6eNXIHdE5YCYsEEdSn8, "red": false, "pos": __fnparxNE3vp0MWoTiWaLXq8T + Vector2(__45xBjMQ4YLHtPTFZwYFtF2N6.__HjH6rEN8pyt_TMZ3GUM09N6A("Location", __DHw7nvVg2Jz6zw2_6hTuIann, 14 + 2 * __B_zTG6eNXIHdE5YCYsEEdSn8), __45xBjMQ4YLHtPTFZwYFtF2N6.__HjH6rEN8pyt_TMZ3GUM09N6A("Location", __DHw7nvVg2Jz6zw2_6hTuIann, 78 + 2 * __B_zTG6eNXIHdE5YCYsEEdSn8)), "beam": signi(__45xBjMQ4YLHtPTFZwYFtF2N6.__HjH6rEN8pyt_TMZ3GUM09N6A("Frame", __DHw7nvVg2Jz6zw2_6hTuIann, 700 + 2 * __B_zTG6eNXIHdE5YCYsEEdSn8)), 
			"space": __45xBjMQ4YLHtPTFZwYFtF2N6.__Jy2hcMM9emCF3iBBkLMyeUr7("Frame", __DHw7nvVg2Jz6zw2_6hTuIann, 218 + 2 * __B_zTG6eNXIHdE5YCYsEEdSn8), "t": ((__09_l_fZod9hOqwdZgNesmiSt >> (31 - __B_zTG6eNXIHdE5YCYsEEdSn8)) & 1) == 1, "main": __RBfxADFUEjVgkL4CvlST7RKA.find(__B_zTG6eNXIHdE5YCYsEEdSn8), "side": sides.find(__B_zTG6eNXIHdE5YCYsEEdSn8), "torp": __gNAusJ6FNN59JQblPNtHMQ_2.find(__B_zTG6eNXIHdE5YCYsEEdSn8), "cat": __wjUQUfgQzSj2YNHkTbwcrJ9W.__8WN8NAnedTbczvHXWHiyaPrE, "name": "", "buttons": {}, "what": "", }
		var b: Dictionary = d["buttons"]
		var __t9iHRxxlev014KBmGO3iw51v: int = int(d["main"])
		var __VSMyyPMw6JnBlA7vJ6AHeCmK: int = int(d["side"])
		var __StetGh8xIdZZt1IGW7Hszuig: int = int(d["torp"])
		if __t9iHRxxlev014KBmGO3iw51v >= 0 and __t9iHRxxlev014KBmGO3iw51v < __YJgAymCaLB78BrFx7OQpn545.__dOsDavODOasdfPxqce2DEBC3.size():
			d["what"] = "main"
			b["gun"] = true
			if __YJgAymCaLB78BrFx7OQpn545.__dOsDavODOasdfPxqce2DEBC3[__t9iHRxxlev014KBmGO3iw51v] >= 0:
				d["cat"] = __wjUQUfgQzSj2YNHkTbwcrJ9W.__w9F0f1gHL1hYs5raphKXBJr9
				d["name"] = str(__NS2OAyjTxQvb8EWE5Nb0vByM.__Y7oNU_MxqAazQR74RzaCuaOa(__YJgAymCaLB78BrFx7OQpn545.__dOsDavODOasdfPxqce2DEBC3[__t9iHRxxlev014KBmGO3iw51v]).get("cn", ""))
				for id: String in ["sell", "cargo_a", "cargo_b"]:
					b[id] = true
		else:
			if __StetGh8xIdZZt1IGW7Hszuig >= 0 and __OCWGexk2jWCF4di4d_DxV0HJ[__StetGh8xIdZZt1IGW7Hszuig] >= 0:
				d["cat"] = __wjUQUfgQzSj2YNHkTbwcrJ9W.__vc58M4qw4FX6PX3bgDqKxDpY
				d["what"] = "torp"
				d["name"] = str(__NS2OAyjTxQvb8EWE5Nb0vByM.__GP_inhBqbirtrHNQn7xXbKG_(__OCWGexk2jWCF4di4d_DxV0HJ[__StetGh8xIdZZt1IGW7Hszuig]).get("cn", ""))
				b["torpedo"] = true
			elif __VSMyyPMw6JnBlA7vJ6AHeCmK >= 0 and __wcff_d90hj9upnLq_h184Y4P[__VSMyyPMw6JnBlA7vJ6AHeCmK] >= 0:
				d["cat"] = __wjUQUfgQzSj2YNHkTbwcrJ9W.__w9F0f1gHL1hYs5raphKXBJr9
				d["what"] = "side"
				d["name"] = str(__NS2OAyjTxQvb8EWE5Nb0vByM.__Y7oNU_MxqAazQR74RzaCuaOa(__wcff_d90hj9upnLq_h184Y4P[__VSMyyPMw6JnBlA7vJ6AHeCmK]).get("cn", ""))
				b["cargo_a"] = true
				b["cargo_b"] = true
			if __VSMyyPMw6JnBlA7vJ6AHeCmK >= 0:
				b["gun"] = true
			if __StetGh8xIdZZt1IGW7Hszuig >= 0 and __NS2OAyjTxQvb8EWE5Nb0vByM.__NPXI07EYJ2EN2n799MAU30we(__DHw7nvVg2Jz6zw2_6hTuIann, __B_zTG6eNXIHdE5YCYsEEdSn8):
				b["tp"] = true
			if int(d["cat"]) != __wjUQUfgQzSj2YNHkTbwcrJ9W.__8WN8NAnedTbczvHXWHiyaPrE:
				b["sell"] = true
		if __2sR1C2FCfSCz2WayYscd_CRS:
			d["deny"] = "UI_TRADE_ERR_UNIQUE"
		elif __lre3C8jfHRp8ykKj8Vv5_d0x and int(d["cat"]) == __wjUQUfgQzSj2YNHkTbwcrJ9W.__w9F0f1gHL1hYs5raphKXBJr9 and not bool(d["t"]):
			d["deny"] = "UI_TRADE_ERR_FIXED_MAIN"
		__RoqGI7ICgRD9q3k11bYpdtW_.append(d)
	var __tZZn2ovdlYMFQmx_2aVDd0me: Dictionary = {"slot": -1, "red": true, "what": "fcs", "space": __NS2OAyjTxQvb8EWE5Nb0vByM.__71vqCim5H12hN39hbXv9N83E(__DHw7nvVg2Jz6zw2_6hTuIann), "buttons": {}, "tip": tr("UI_RING_FCS") + """
""" + tr("UI_RING_SPACE") % __NS2OAyjTxQvb8EWE5Nb0vByM.__71vqCim5H12hN39hbXv9N83E(__DHw7nvVg2Jz6zw2_6hTuIann), 
		"pos": __fnparxNE3vp0MWoTiWaLXq8T + Vector2(__45xBjMQ4YLHtPTFZwYFtF2N6.__HjH6rEN8pyt_TMZ3GUM09N6A("Location", __DHw7nvVg2Jz6zw2_6hTuIann, 10), __45xBjMQ4YLHtPTFZwYFtF2N6.__HjH6rEN8pyt_TMZ3GUM09N6A("Location", __DHw7nvVg2Jz6zw2_6hTuIann, 12))}
	if __YJgAymCaLB78BrFx7OQpn545.__vwSAcybbCInOpnt2FbN4qz7L >= 0:
		__tZZn2ovdlYMFQmx_2aVDd0me["cat"] = __wjUQUfgQzSj2YNHkTbwcrJ9W.__NIGdUtHreWXykS38BnI42W76
		__tZZn2ovdlYMFQmx_2aVDd0me["name"] = str(__NS2OAyjTxQvb8EWE5Nb0vByM.__vwSAcybbCInOpnt2FbN4qz7L(__YJgAymCaLB78BrFx7OQpn545.__vwSAcybbCInOpnt2FbN4qz7L).get("name", ""))
		__tZZn2ovdlYMFQmx_2aVDd0me["buttons"] = {"sell": true}
	else:
		__tZZn2ovdlYMFQmx_2aVDd0me["cat"] = __wjUQUfgQzSj2YNHkTbwcrJ9W.__8WN8NAnedTbczvHXWHiyaPrE
		__tZZn2ovdlYMFQmx_2aVDd0me["name"] = tr("UI_SPEC_NOT_FITTED")
		__tZZn2ovdlYMFQmx_2aVDd0me["direct"] = "fcs"
	if __2sR1C2FCfSCz2WayYscd_CRS:
		__tZZn2ovdlYMFQmx_2aVDd0me["deny"] = "UI_TRADE_ERR_UNIQUE"
	__RoqGI7ICgRD9q3k11bYpdtW_.append(__tZZn2ovdlYMFQmx_2aVDd0me)
	var __QgQnxDhVbbtV6CFDwvxyoQ8W: PackedInt32Array = __NS2OAyjTxQvb8EWE5Nb0vByM.__mgdM7ycmi3DNHzWo0uObSaPX(__YJgAymCaLB78BrFx7OQpn545)
	for s: int in __NS2OAyjTxQvb8EWE5Nb0vByM.__GQ9LLolLcENvLp870dW_HjRn(__DHw7nvVg2Jz6zw2_6hTuIann):
		var __zJoI8k46sSwuVdEYDk6QSK15: int = __Se4EsxPBCHX48h1ZS5MexaMl.__Uv7vWKACrD3IoOv6puOgq1PA.find(s)
		var __GHHBBtjnC0JYq6agvua4fRdL: Dictionary = {"slot": s, "air": __zJoI8k46sSwuVdEYDk6QSK15, "red": true, "what": "air", "space": __45xBjMQ4YLHtPTFZwYFtF2N6.__Jy2hcMM9emCF3iBBkLMyeUr7("Frame", __DHw7nvVg2Jz6zw2_6hTuIann, 218 + 2 * s), "buttons": {}, "tip": tr("UI_RING_AIR") % tr("UI_AIR_TYPE_%d" % __Se4EsxPBCHX48h1ZS5MexaMl.__aisbIKkvoMoqILGpBPpi6cdU(s)) + """
""" + tr("UI_RING_SPACE") % __45xBjMQ4YLHtPTFZwYFtF2N6.__Jy2hcMM9emCF3iBBkLMyeUr7("Frame", __DHw7nvVg2Jz6zw2_6hTuIann, 218 + 2 * s), "pos": __fnparxNE3vp0MWoTiWaLXq8T + Vector2(__45xBjMQ4YLHtPTFZwYFtF2N6.__HjH6rEN8pyt_TMZ3GUM09N6A("Location", __DHw7nvVg2Jz6zw2_6hTuIann, 14 + 2 * s), __45xBjMQ4YLHtPTFZwYFtF2N6.__HjH6rEN8pyt_TMZ3GUM09N6A("Location", __DHw7nvVg2Jz6zw2_6hTuIann, 78 + 2 * s))}
		var __jH1olTCDNKEcmn4TybNMsckY: int = __QgQnxDhVbbtV6CFDwvxyoQ8W[__Se4EsxPBCHX48h1ZS5MexaMl.__7H3uQhAdVTbh0QLkQVDDP1bw * __zJoI8k46sSwuVdEYDk6QSK15] if __QgQnxDhVbbtV6CFDwvxyoQ8W.size() == __Se4EsxPBCHX48h1ZS5MexaMl.__7H3uQhAdVTbh0QLkQVDDP1bw * __Se4EsxPBCHX48h1ZS5MexaMl.__Uv7vWKACrD3IoOv6puOgq1PA.size() else -1
		if __jH1olTCDNKEcmn4TybNMsckY >= 0:
			__GHHBBtjnC0JYq6agvua4fRdL["cat"] = __wjUQUfgQzSj2YNHkTbwcrJ9W.__LQFcUtLoRLfruKyuhCnu4u9L
			__GHHBBtjnC0JYq6agvua4fRdL["name"] = tr("UI_RING_AIR_LOADED") % [__NS2OAyjTxQvb8EWE5Nb0vByM.__gobxGwIVlftvCfJ1fsNzSlj7(__jH1olTCDNKEcmn4TybNMsckY).get("name", "—"), __QgQnxDhVbbtV6CFDwvxyoQ8W[__Se4EsxPBCHX48h1ZS5MexaMl.__7H3uQhAdVTbh0QLkQVDDP1bw * __zJoI8k46sSwuVdEYDk6QSK15 + 1]]
			__GHHBBtjnC0JYq6agvua4fRdL["buttons"] = {"sell": true, "air": true}
			if not __NS2OAyjTxQvb8EWE5Nb0vByM.__4_K_BQA8uki_xNpMaX03GmYp(__jH1olTCDNKEcmn4TybNMsckY).is_empty():
				__GHHBBtjnC0JYq6agvua4fRdL["buttons"]["airarm"] = true
		else:
			__GHHBBtjnC0JYq6agvua4fRdL["cat"] = __wjUQUfgQzSj2YNHkTbwcrJ9W.__8WN8NAnedTbczvHXWHiyaPrE
			__GHHBBtjnC0JYq6agvua4fRdL["direct"] = "air"
		__RoqGI7ICgRD9q3k11bYpdtW_.append(__GHHBBtjnC0JYq6agvua4fRdL)
	if __NS2OAyjTxQvb8EWE5Nb0vByM.__rIbrGNBQXI7CsdYVLpVwKrNI(__DHw7nvVg2Jz6zw2_6hTuIann) == __Se4EsxPBCHX48h1ZS5MexaMl.__4cYyo29DcWFPcLdEsHACapS4:
		__NozPJAWtJodHtGY29mgmovub(__RoqGI7ICgRD9q3k11bYpdtW_)
	return __RoqGI7ICgRD9q3k11bYpdtW_
func __FWw1MFcV48pcQszFug10_Wsq() -> String:
	if __DpM0JQWB6EqgMh3WJZSlHODu:
		return "UI_DOCK_ERR_NO_SHIP"
	if App.__PtNURh2PaYHMgsPlkLtni90Y().__BGxXnVzPsmPLUaUtEL38SXTm(__YJgAymCaLB78BrFx7OQpn545) != __Se4EsxPBCHX48h1ZS5MexaMl.__5CDMR1_ZY_Be5hesPdyczkNt.OK:
		return "UI_SS_ERR_%d" % App.__PtNURh2PaYHMgsPlkLtni90Y().__BGxXnVzPsmPLUaUtEL38SXTm(__YJgAymCaLB78BrFx7OQpn545)
	return App.__M0ImV248NGNrBFXy9NCs5jwX().__vUM5mIHX8VViD73nWxABeJ0J(__YJgAymCaLB78BrFx7OQpn545, false)
var __f3ySEJHZJ46_L34koIBeTfDe: __1GzxRRq_riXfZWJxreGQ01mB
const __eyxnY3dCgzNC6UWKdyRM1uNn: = Vector2(618.1, 235.8)
func __bW6UZkb_vKAZo4WNoJk8Av2K(d: Dictionary) -> void :
	var __O4VA32gLDD_FlWLqbnYtfnJi: __Se4EsxPBCHX48h1ZS5MexaMl = App.__PtNURh2PaYHMgsPlkLtni90Y()
	var __H5Qhr3aC6pF7XnI_dOSZO7as: __s8yZigV26lPAvEmbOWzMbnjE = __YJgAymCaLB78BrFx7OQpn545.__12ty6aWt7_v7eYEbKtP71Dlf()
	match str(d.get("what", "")):
		"main":
			var __oeEeHVSW4_148lqRpYlHP4VN: int = int(d["main"])
			__H5Qhr3aC6pF7XnI_dOSZO7as.__ZCQBCv36ysTHU0iBaYX6GvwS = __O4VA32gLDD_FlWLqbnYtfnJi.__RgxkBWnYRjC44wuJnI7BKnV_(__H5Qhr3aC6pF7XnI_dOSZO7as)
			__H5Qhr3aC6pF7XnI_dOSZO7as.__dOsDavODOasdfPxqce2DEBC3[__oeEeHVSW4_148lqRpYlHP4VN] = __s8yZigV26lPAvEmbOWzMbnjE.__1iBjWxIGtvWf0yGsmF7yzBIR
			for __DPSOzCrOvOjKQEu7CgWNB2sY: int in 4:
				__H5Qhr3aC6pF7XnI_dOSZO7as.__ZCQBCv36ysTHU0iBaYX6GvwS[4 * __oeEeHVSW4_148lqRpYlHP4VN + __DPSOzCrOvOjKQEu7CgWNB2sY] = __s8yZigV26lPAvEmbOWzMbnjE.__1iBjWxIGtvWf0yGsmF7yzBIR if __DPSOzCrOvOjKQEu7CgWNB2sY % 2 == 0 else 0
		"fcs":
			__H5Qhr3aC6pF7XnI_dOSZO7as.__vwSAcybbCInOpnt2FbN4qz7L = __s8yZigV26lPAvEmbOWzMbnjE.__1iBjWxIGtvWf0yGsmF7yzBIR
		"armor":
			__artOxTBmv0igp4KCRm6SwQqa(__H5Qhr3aC6pF7XnI_dOSZO7as, "R", int(d["zone"]), -1, 0)
		"air":
			__ukK0_ZksN9PJ7jluNvwiulpw(__H5Qhr3aC6pF7XnI_dOSZO7as, int(d["air"]))
		"torp":
			__JrSwqiFlyEfIMrWTSwBBfy5w(__H5Qhr3aC6pF7XnI_dOSZO7as, "torp", int(d["slot"]))
		_:
			__JrSwqiFlyEfIMrWTSwBBfy5w(__H5Qhr3aC6pF7XnI_dOSZO7as, "side", int(d["slot"]))
	var __ACbnAgMtg689j2r1mgNjxPvo: int = __9iFcUUuz7hxSygPtA9oE6aBm(__H5Qhr3aC6pF7XnI_dOSZO7as)
	if __ACbnAgMtg689j2r1mgNjxPvo != __Se4EsxPBCHX48h1ZS5MexaMl.__5CDMR1_ZY_Be5hesPdyczkNt.OK:
		UI.__FZyGB2TVbKGb1g8kgT4bm_x4(tr("UI_SS_ERR_%d" % __ACbnAgMtg689j2r1mgNjxPvo))
		return
	var __WQhZlLPigIJomlA0uCXEOitl: int = __U7UMfwBewiXSLEeaDnywaCO7.__Z9_EaMidC9WMDEaUyGmEqMDQ(__H5Qhr3aC6pF7XnI_dOSZO7as.__WeB9Hi0OxaFBUuwm2WU2qKEH, __JP9cOkhmwnT97LFapLTV6u08(d))
	var __Lgr39NGeX9XNkZ6NSEBq8FTu: int = mini(__9MFWgnc8oYQpY6kqM0OFfhrH.__JO_lDGhzQyOUyx2DWULIGYDV(__wCvCb3wyZ_rtEzAlllKjt9au(d)), __9MFWgnc8oYQpY6kqM0OFfhrH.__JO_lDGhzQyOUyx2DWULIGYDV(__WQhZlLPigIJomlA0uCXEOitl))
	__U7UMfwBewiXSLEeaDnywaCO7.__VvG2q5CwvCNDjBta5Gspay17(__H5Qhr3aC6pF7XnI_dOSZO7as)
	App.__M0ImV248NGNrBFXy9NCs5jwX().__g7F3EfgE1iugY6qyUxtrpa1X(__H5Qhr3aC6pF7XnI_dOSZO7as)
	__YJgAymCaLB78BrFx7OQpn545 = __U7UMfwBewiXSLEeaDnywaCO7.__V0erSRNWoPFGOr7bG6vGIpsK()
	if __Lgr39NGeX9XNkZ6NSEBq8FTu > 0:
		App.__M0ImV248NGNrBFXy9NCs5jwX().__hN4a7punGT3ktCMQCiR5zjz7(__Lgr39NGeX9XNkZ6NSEBq8FTu, 0, __Bsl33jE0VgUtGf0ZDYkuZAkg.__jsHKcANVTDoh22Fdmruyj1ja, __H5Qhr3aC6pF7XnI_dOSZO7as.__WeB9Hi0OxaFBUuwm2WU2qKEH)
		__4VH5P1TCUJzfLL55i2_8NhQh()
		UI.__Qyp4Js7J9ejl5FSF4pVpfEi5(tr("UI_TRADE_SOLD_REFUND") % [str(d.get("name", "")), __9MFWgnc8oYQpY6kqM0OFfhrH.__57yYqv9212r7qj7iu02kGdA8(__Lgr39NGeX9XNkZ6NSEBq8FTu)])
	else:
		UI.__Qyp4Js7J9ejl5FSF4pVpfEi5(tr("UI_TRADE_SOLD") % str(d.get("name", "")))
	_load()
	if __zABAFBwuGIufBHjRN9OzcNUm != null:
		__zABAFBwuGIufBHjRN9OzcNUm.__Qa9GbnhM8GDjcw4fKszR0Ftz()
func __4VH5P1TCUJzfLL55i2_8NhQh() -> void :
	if __WthKfcvjK4RJwtX6snlMJlVa != null:
		__WthKfcvjK4RJwtX6snlMJlVa.__RnZjcbFeClHTY03QDBApzLyG(App.__M0ImV248NGNrBFXy9NCs5jwX().__ktyxvkLP8cTjwSfnZb3DAVcL, App.__M0ImV248NGNrBFXy9NCs5jwX().points)
func __wUr1p8hncnmDRLuW_MzmS99v() -> void :
	var __Fz2nxelkfeZOq3pwzJOVaf3m: __k8pdL_GB8yADpq0vqeDWpz5v = __k8pdL_GB8yADpq0vqeDWpz5v.__EQSSy6KHEM37BgV1J4KGqz8Y()
	match __Fz2nxelkfeZOq3pwzJOVaf3m.__yy311ORBDqjetYDXzItwePv1():
		"UI_SAVE_TAMPERED":
			await UI.__Dzq5SbxUBHUUe7FLUyy2rI_S(tr("UI_SAVE_TITLE"), tr("UI_SAVE_TAMPERED") % ProjectSettings.globalize_path(__Fz2nxelkfeZOq3pwzJOVaf3m.__W3rvnHwkblNBpH9sFGxJKoXr), [tr("UI_OK")])
const __v9yDxVoBQ0rAqgaVqQaDJHaD: PackedInt32Array = [26, 327, 328, 320]
func __artOxTBmv0igp4KCRm6SwQqa(__RQdGXcCeDCZizYh_pkfqch2M: __s8yZigV26lPAvEmbOWzMbnjE, __oFTV_L4pWodAcdi3yECq28uI: String, __GomWDfTn86KPVDhfoj49fr1v: int, __MAACxZrFZm8wBn8_NM74zrwV: int, count: int = 1) -> void :
	var __ilB5G1r4AjzGMyJFysUN0OSQ: __Se4EsxPBCHX48h1ZS5MexaMl = App.__PtNURh2PaYHMgsPlkLtni90Y()
	match __oFTV_L4pWodAcdi3yECq28uI:
		"R":
			var __d8UuszVF42boryyp_wXpRetZ: PackedInt32Array = __ilB5G1r4AjzGMyJFysUN0OSQ.__uCNDLIyQQRLcwA3z5vXmUuAz(__RQdGXcCeDCZizYh_pkfqch2M)
			__d8UuszVF42boryyp_wXpRetZ[2 * __GomWDfTn86KPVDhfoj49fr1v] = __MAACxZrFZm8wBn8_NM74zrwV if count > 0 else __s8yZigV26lPAvEmbOWzMbnjE.__1iBjWxIGtvWf0yGsmF7yzBIR
			__d8UuszVF42boryyp_wXpRetZ[2 * __GomWDfTn86KPVDhfoj49fr1v + 1] = count * __Se4EsxPBCHX48h1ZS5MexaMl.__MmvhtidBsePDvXycLyLNHv8h if count > 0 else 0
			__RQdGXcCeDCZizYh_pkfqch2M.__cQ8JInnnrEoGxd_1jglej7pR = __d8UuszVF42boryyp_wXpRetZ if __d8UuszVF42boryyp_wXpRetZ != __Se4EsxPBCHX48h1ZS5MexaMl.__z60ooVwI9Q0G4gXJuZ_QzkIy([]) else PackedInt32Array()
			return
		"G":
			if __RQdGXcCeDCZizYh_pkfqch2M.__dOsDavODOasdfPxqce2DEBC3[__GomWDfTn86KPVDhfoj49fr1v] == __MAACxZrFZm8wBn8_NM74zrwV:
				return
			__RQdGXcCeDCZizYh_pkfqch2M.__ZCQBCv36ysTHU0iBaYX6GvwS = __ilB5G1r4AjzGMyJFysUN0OSQ.__RgxkBWnYRjC44wuJnI7BKnV_(__RQdGXcCeDCZizYh_pkfqch2M)
			__RQdGXcCeDCZizYh_pkfqch2M.__dOsDavODOasdfPxqce2DEBC3[__GomWDfTn86KPVDhfoj49fr1v] = __MAACxZrFZm8wBn8_NM74zrwV
			var __N558onrrBTd3uWF6tQgXCQ39: PackedInt32Array = __ilB5G1r4AjzGMyJFysUN0OSQ.__WVITuZqO2rxQlepLgwdT6PaH(__MAACxZrFZm8wBn8_NM74zrwV)
			for __9OS6ZOFWlaTsxR1iGt31Uyss: int in 4:
				__RQdGXcCeDCZizYh_pkfqch2M.__ZCQBCv36ysTHU0iBaYX6GvwS[4 * __GomWDfTn86KPVDhfoj49fr1v + __9OS6ZOFWlaTsxR1iGt31Uyss] = __N558onrrBTd3uWF6tQgXCQ39[__9OS6ZOFWlaTsxR1iGt31Uyss]
		"S":
			if __ilB5G1r4AjzGMyJFysUN0OSQ.__PJZemYw0whDwrAt4vbBLpQ7w(__RQdGXcCeDCZizYh_pkfqch2M)[__GomWDfTn86KPVDhfoj49fr1v] == __MAACxZrFZm8wBn8_NM74zrwV:
				return
			__RQdGXcCeDCZizYh_pkfqch2M.__nQdkAoXs7wyREcSJQ0Beyel6 = __ilB5G1r4AjzGMyJFysUN0OSQ.__Xs0yLUqBQ7TVWSHzfx4EiUAr(__RQdGXcCeDCZizYh_pkfqch2M)
			__RQdGXcCeDCZizYh_pkfqch2M.__t1UipS__8EvFgumrL932qeyd = __ilB5G1r4AjzGMyJFysUN0OSQ.__PJZemYw0whDwrAt4vbBLpQ7w(__RQdGXcCeDCZizYh_pkfqch2M)
			__RQdGXcCeDCZizYh_pkfqch2M.__t1UipS__8EvFgumrL932qeyd[__GomWDfTn86KPVDhfoj49fr1v] = __MAACxZrFZm8wBn8_NM74zrwV
			var __XC8_fvZyiBEGh1GpaXpc_NAh: PackedInt32Array = __ilB5G1r4AjzGMyJFysUN0OSQ.__WVITuZqO2rxQlepLgwdT6PaH(__MAACxZrFZm8wBn8_NM74zrwV)
			for __XHSNKWk551jnfK46lDFrOB_b: int in 4:
				__RQdGXcCeDCZizYh_pkfqch2M.__nQdkAoXs7wyREcSJQ0Beyel6[4 * __GomWDfTn86KPVDhfoj49fr1v + __XHSNKWk551jnfK46lDFrOB_b] = __XC8_fvZyiBEGh1GpaXpc_NAh[__XHSNKWk551jnfK46lDFrOB_b]
			__JrSwqiFlyEfIMrWTSwBBfy5w(__RQdGXcCeDCZizYh_pkfqch2M, "torp", __ilB5G1r4AjzGMyJFysUN0OSQ.__4mBhSAAMIt6DTsibdV0pC19W(__RQdGXcCeDCZizYh_pkfqch2M.__WeB9Hi0OxaFBUuwm2WU2qKEH)[__GomWDfTn86KPVDhfoj49fr1v])
		"L":
			if __ilB5G1r4AjzGMyJFysUN0OSQ.__7uBhyRNBJZP4s1InKu8Lo_y7(__RQdGXcCeDCZizYh_pkfqch2M)[__GomWDfTn86KPVDhfoj49fr1v] == __MAACxZrFZm8wBn8_NM74zrwV:
				return
			__RQdGXcCeDCZizYh_pkfqch2M.__t3YSlOfvQe4R_b9rHMAz7hq0 = __ilB5G1r4AjzGMyJFysUN0OSQ.__El7brR86C9a6x0hMgLnIgY3e(__RQdGXcCeDCZizYh_pkfqch2M)
			__RQdGXcCeDCZizYh_pkfqch2M.__mqMCtdrkbQOwk3Mp57NCIW7w = __ilB5G1r4AjzGMyJFysUN0OSQ.__7uBhyRNBJZP4s1InKu8Lo_y7(__RQdGXcCeDCZizYh_pkfqch2M)
			__RQdGXcCeDCZizYh_pkfqch2M.__mqMCtdrkbQOwk3Mp57NCIW7w[__GomWDfTn86KPVDhfoj49fr1v] = __MAACxZrFZm8wBn8_NM74zrwV
			var __MB0eek_McMRGIaPFMCcbzsnJ: PackedInt32Array = __ilB5G1r4AjzGMyJFysUN0OSQ.__q4597h81BUWWU3DmjxVYYvH9(__MAACxZrFZm8wBn8_NM74zrwV)
			__RQdGXcCeDCZizYh_pkfqch2M.__t3YSlOfvQe4R_b9rHMAz7hq0[2 * __GomWDfTn86KPVDhfoj49fr1v] = __MB0eek_McMRGIaPFMCcbzsnJ[0]
			__RQdGXcCeDCZizYh_pkfqch2M.__t3YSlOfvQe4R_b9rHMAz7hq0[2 * __GomWDfTn86KPVDhfoj49fr1v + 1] = __MB0eek_McMRGIaPFMCcbzsnJ[1]
			__JrSwqiFlyEfIMrWTSwBBfy5w(__RQdGXcCeDCZizYh_pkfqch2M, "side", __ilB5G1r4AjzGMyJFysUN0OSQ.__Hmr_a2CPvjknmgXnhmVu1vm9(__RQdGXcCeDCZizYh_pkfqch2M.__WeB9Hi0OxaFBUuwm2WU2qKEH)[__GomWDfTn86KPVDhfoj49fr1v])
		"F":
			__RQdGXcCeDCZizYh_pkfqch2M.__vwSAcybbCInOpnt2FbN4qz7L = __MAACxZrFZm8wBn8_NM74zrwV
		"E":
			__RQdGXcCeDCZizYh_pkfqch2M.__NELIelBEafKRGQultNqYAbM7 = __s8yZigV26lPAvEmbOWzMbnjE.__gzDclDFgoL3uDH5vfZQtcFjr if __MAACxZrFZm8wBn8_NM74zrwV == App.__PtNURh2PaYHMgsPlkLtni90Y().__iwsr3PVrq6Krppgo4C53PG1F(__RQdGXcCeDCZizYh_pkfqch2M.__WeB9Hi0OxaFBUuwm2WU2qKEH) else __MAACxZrFZm8wBn8_NM74zrwV
		"P":
			__RQdGXcCeDCZizYh_pkfqch2M.__g7JC3EJmfsOWnIyqLGGB93eB = __ilB5G1r4AjzGMyJFysUN0OSQ.__mgdM7ycmi3DNHzWo0uObSaPX(__RQdGXcCeDCZizYh_pkfqch2M).duplicate()
			var __vcTiuhl1JJlSzu6lIk9nJtiR: int = __Se4EsxPBCHX48h1ZS5MexaMl.__7H3uQhAdVTbh0QLkQVDDP1bw * __GomWDfTn86KPVDhfoj49fr1v
			if count <= 0:
				__ukK0_ZksN9PJ7jluNvwiulpw(__RQdGXcCeDCZizYh_pkfqch2M, __GomWDfTn86KPVDhfoj49fr1v)
				return
			var changed: bool = __RQdGXcCeDCZizYh_pkfqch2M.__g7JC3EJmfsOWnIyqLGGB93eB[__vcTiuhl1JJlSzu6lIk9nJtiR] != __MAACxZrFZm8wBn8_NM74zrwV
			__RQdGXcCeDCZizYh_pkfqch2M.__g7JC3EJmfsOWnIyqLGGB93eB[__vcTiuhl1JJlSzu6lIk9nJtiR] = __MAACxZrFZm8wBn8_NM74zrwV
			__RQdGXcCeDCZizYh_pkfqch2M.__g7JC3EJmfsOWnIyqLGGB93eB[__vcTiuhl1JJlSzu6lIk9nJtiR + 1] = count
			if changed:
				__RQdGXcCeDCZizYh_pkfqch2M.__g7JC3EJmfsOWnIyqLGGB93eB[__vcTiuhl1JJlSzu6lIk9nJtiR + 2] = __s8yZigV26lPAvEmbOWzMbnjE.__1iBjWxIGtvWf0yGsmF7yzBIR
				__RQdGXcCeDCZizYh_pkfqch2M.__g7JC3EJmfsOWnIyqLGGB93eB[__vcTiuhl1JJlSzu6lIk9nJtiR + 3] = 0
				var __HH4gJtsXTuwMHlMWbPAdIUHE: Array[Dictionary] = __ilB5G1r4AjzGMyJFysUN0OSQ.__4_K_BQA8uki_xNpMaX03GmYp(__MAACxZrFZm8wBn8_NM74zrwV)
				if not __HH4gJtsXTuwMHlMWbPAdIUHE.is_empty():
					__RQdGXcCeDCZizYh_pkfqch2M.__g7JC3EJmfsOWnIyqLGGB93eB[__vcTiuhl1JJlSzu6lIk9nJtiR + 2] = int(__HH4gJtsXTuwMHlMWbPAdIUHE[0]["row"])
					__RQdGXcCeDCZizYh_pkfqch2M.__g7JC3EJmfsOWnIyqLGGB93eB[__vcTiuhl1JJlSzu6lIk9nJtiR + 3] = count * 4
					while __RQdGXcCeDCZizYh_pkfqch2M.__g7JC3EJmfsOWnIyqLGGB93eB[__vcTiuhl1JJlSzu6lIk9nJtiR + 3] > 0 and __ilB5G1r4AjzGMyJFysUN0OSQ.__1CdXpyU1UJ8cmNMTd_g2_0od(__RQdGXcCeDCZizYh_pkfqch2M) + __ilB5G1r4AjzGMyJFysUN0OSQ.__rOWGpFmAQiG56ndfSgajANvH(__RQdGXcCeDCZizYh_pkfqch2M) > __ilB5G1r4AjzGMyJFysUN0OSQ.__eO4VHYjMVObwrueIqrahxQOQ(__RQdGXcCeDCZizYh_pkfqch2M.__WeB9Hi0OxaFBUuwm2WU2qKEH):
						__RQdGXcCeDCZizYh_pkfqch2M.__g7JC3EJmfsOWnIyqLGGB93eB[__vcTiuhl1JJlSzu6lIk9nJtiR + 3] -= 1
			__RQdGXcCeDCZizYh_pkfqch2M.__gyktaSCba5fvGkS2KC4ukPix = PackedInt32Array()
		"M":
			__RQdGXcCeDCZizYh_pkfqch2M.__g7JC3EJmfsOWnIyqLGGB93eB = __ilB5G1r4AjzGMyJFysUN0OSQ.__mgdM7ycmi3DNHzWo0uObSaPX(__RQdGXcCeDCZizYh_pkfqch2M).duplicate()
			var __2uq0TLGde1Wg_KhfZG18OBe_: int = __Se4EsxPBCHX48h1ZS5MexaMl.__7H3uQhAdVTbh0QLkQVDDP1bw * __GomWDfTn86KPVDhfoj49fr1v
			__RQdGXcCeDCZizYh_pkfqch2M.__g7JC3EJmfsOWnIyqLGGB93eB[__2uq0TLGde1Wg_KhfZG18OBe_ + 2] = __MAACxZrFZm8wBn8_NM74zrwV if count > 0 else __s8yZigV26lPAvEmbOWzMbnjE.__1iBjWxIGtvWf0yGsmF7yzBIR
			__RQdGXcCeDCZizYh_pkfqch2M.__g7JC3EJmfsOWnIyqLGGB93eB[__2uq0TLGde1Wg_KhfZG18OBe_ + 3] = count if count > 0 else 0
const __KzqJxC0rjxwigqZQErAFUdbv: = Color(0.05, 0.1, 0.16, 0.9)
var __bLKLb0Khmx9u_g9HRmoM6tG6: __swIzeI0OCYp_Difwb9TQEYIt
func __7Mjw8rGwZR13HeV6a47gwnIG(__DQlRo_QARdMx7R4nnigJEkyV: String, __4zmCqsHtkZTUV_ftc8hfuC9e: int) -> PackedInt32Array:
	var __KXIBEQeT9kDFcpXRSE0FekwB: __Se4EsxPBCHX48h1ZS5MexaMl = App.__PtNURh2PaYHMgsPlkLtni90Y()
	var __btpCvNKwoDd3didMC9dvU9IU: = PackedInt32Array()
	if __DQlRo_QARdMx7R4nnigJEkyV == "L":
		if not __KXIBEQeT9kDFcpXRSE0FekwB.__fR6dUKZvszx5XWkKuSUGmHrY(__YJgAymCaLB78BrFx7OQpn545.__WeB9Hi0OxaFBUuwm2WU2qKEH, __4zmCqsHtkZTUV_ftc8hfuC9e):
			return __btpCvNKwoDd3didMC9dvU9IU
		for __QN9iqQO4ktaC_zij6xwN9CAo: int in __NOGqr86hxqhZaYA6HjbWlY2N(__DQlRo_QARdMx7R4nnigJEkyV):
			__btpCvNKwoDd3didMC9dvU9IU.append(__QN9iqQO4ktaC_zij6xwN9CAo)
		return __btpCvNKwoDd3didMC9dvU9IU
	var g: Dictionary = __KXIBEQeT9kDFcpXRSE0FekwB.__Y7oNU_MxqAazQR74RzaCuaOa(__4zmCqsHtkZTUV_ftc8hfuC9e)
	if g.is_empty():
		return __btpCvNKwoDd3didMC9dvU9IU
	for __OgawNicSJ0PVnHbyTYOhu6aQ: int in __NOGqr86hxqhZaYA6HjbWlY2N(__DQlRo_QARdMx7R4nnigJEkyV):
		if __DQlRo_QARdMx7R4nnigJEkyV == "G" and __2ZIL9u7_cM4KOmaAUAdneX5d.meti_catalog_main_seat(__KXIBEQeT9kDFcpXRSE0FekwB, __YJgAymCaLB78BrFx7OQpn545.__WeB9Hi0OxaFBUuwm2WU2qKEH, __OgawNicSJ0PVnHbyTYOhu6aQ) != meti_main_market_role(): continue
		var __NEk0uRiS308WY7WglKiXJWGK: int = __KXIBEQeT9kDFcpXRSE0FekwB.__JSFuWDdaNcyjLKGCOC2Crlxp(__YJgAymCaLB78BrFx7OQpn545.__WeB9Hi0OxaFBUuwm2WU2qKEH, __OgawNicSJ0PVnHbyTYOhu6aQ) if __DQlRo_QARdMx7R4nnigJEkyV == "G" else __KXIBEQeT9kDFcpXRSE0FekwB.__VaNU6Dd0LtUmwJuwAl_Jc1g9(__YJgAymCaLB78BrFx7OQpn545.__WeB9Hi0OxaFBUuwm2WU2qKEH, __OgawNicSJ0PVnHbyTYOhu6aQ)
		if __Se4EsxPBCHX48h1ZS5MexaMl.__HhH2YvlxLDmc6EokVgGFC27L(__NEk0uRiS308WY7WglKiXJWGK, g):
			__btpCvNKwoDd3didMC9dvU9IU.append(__OgawNicSJ0PVnHbyTYOhu6aQ)
	return __btpCvNKwoDd3didMC9dvU9IU
func __PIgmWxhh53prim2mxCzKxY1r() -> bool:
	return ((App.___qFCN2viGM2bPW1uGV9qys9h().__Jy2hcMM9emCF3iBBkLMyeUr7("Frame", __YJgAymCaLB78BrFx7OQpn545.__WeB9Hi0OxaFBUuwm2WU2qKEH, 4) >> 5) & 31) == 2
var __cINzBwGjtqDi2gNY5uWxxKya: __pDD4VW1FqZzXRK1m9Ft3JOAG
func __Sll1pjvntU3_a41waOOS2VpP(__zK2IqF6YgScBvdxnPrksMLBl: __s8yZigV26lPAvEmbOWzMbnjE, __yx7DkYZNb5tJKypZU5sk8HsV: int) -> void :
	__v9ZnZMSMzoVWGyPBRc8ApWfd = __LcEmKczmLrorVyOBaMDnHamK
	for __oGl7eBnoGs09IPb4FKx7Ysrx: int in __dAGqnexg_IDbNw344d0sOBgZ.size():
		__dAGqnexg_IDbNw344d0sOBgZ[__oGl7eBnoGs09IPb4FKx7Ysrx].set_meta("depth", __HN0NJbb6Q_9lIDlS9Nhmdl07[__oGl7eBnoGs09IPb4FKx7Ysrx] + __AULjCEkcKgaRzYRXGAcwDg5F.__12EayduUr8JXxKEoTqaCpEXL * __yx7DkYZNb5tJKypZU5sk8HsV)
		__dAGqnexg_IDbNw344d0sOBgZ[__oGl7eBnoGs09IPb4FKx7Ysrx].visible = true
	__xl8CsL_efSUi0ouukZP0cFvu()
	__XviRMKHdbGnEMaTN0kgBw5GT(__zK2IqF6YgScBvdxnPrksMLBl)
	__XwGmCs7gUex6WMx0F0Lapr6y.begin(__yx7DkYZNb5tJKypZU5sk8HsV)
	__X_kchlTgjXLrGf3SqqJZxguo = 0.0
	__NJiRcQ_010d3zGothv6OVgV4()
	_redraw()




func meti_ammo_targets(cfg: __s8yZigV26lPAvEmbOWzMbnjE, kind: String, index: int, shell_row: int = -1) -> Array[Dictionary]:
	var targets: Array[Dictionary] = []
	if kind not in ["A", "B", "SA", "SB"]: return targets
	var catalog = App.__PtNURh2PaYHMgsPlkLtni90Y()
	var main: PackedInt32Array = cfg.__dOsDavODOasdfPxqce2DEBC3
	var side: PackedInt32Array = catalog.__PJZemYw0whDwrAt4vbBLpQ7w(cfg)
	var source: PackedInt32Array = side if kind.begins_with("S") else main
	if index < 0 or index >= source.size() or source[index] < 0: return targets
	var gun_row: int = source[index]
	if shell_row >= 0:
		var compatible = false
		for shell: Dictionary in catalog.__WAgRVTs1_HQp6rDVY1IrTH4R(gun_row):
			if int(shell["row"]) == shell_row: compatible = true;break
		if not compatible: return targets
	var compartment = "A" if kind.ends_with("A") else "B"
	for group: Dictionary in [{"prefix": "", "guns": main}, {"prefix": "S", "guns": side}]:
		var guns: PackedInt32Array = group["guns"]
		for slot in guns.size():
			if guns[slot] == gun_row: targets.append({"kind": str(group["prefix"]) + compartment, "index": slot})
	return targets

func meti_ammo_candidate(cfg: __s8yZigV26lPAvEmbOWzMbnjE, kind: String, index: int, shell_row: int, count: int) -> __s8yZigV26lPAvEmbOWzMbnjE:
	var candidate = cfg.__12ty6aWt7_v7eYEbKtP71Dlf()
	var catalog = App.__PtNURh2PaYHMgsPlkLtni90Y()
	var main: PackedInt32Array = catalog.__RgxkBWnYRjC44wuJnI7BKnV_(candidate).duplicate()
	var side: PackedInt32Array = catalog.__Xs0yLUqBQ7TVWSHzfx4EiUAr(candidate).duplicate()
	var main_changed = false
	var side_changed = false
	var amount = maxi(0, count)
	for target: Dictionary in meti_ammo_targets(cfg, kind, index, shell_row):
		var rounds: PackedInt32Array = side if str(target["kind"]).begins_with("S") else main
		var offset = 4 * int(target["index"]) + (0 if kind.ends_with("A") else 2)
		rounds[offset] = shell_row if amount > 0 else __s8yZigV26lPAvEmbOWzMbnjE.__1iBjWxIGtvWf0yGsmF7yzBIR
		rounds[offset + 1] = amount

		if str(target["kind"]).begins_with("S"): side = rounds;side_changed = true
		else: main = rounds;main_changed = true
	if main_changed: candidate.__ZCQBCv36ysTHU0iBaYX6GvwS = main
	if side_changed: candidate.__nQdkAoXs7wyREcSJQ0Beyel6 = side
	return candidate

func meti_ammo_cost(kind: String, index: int, shell_row: int, count: int) -> int:
	var total = 0
	for target: Dictionary in meti_ammo_targets(__YJgAymCaLB78BrFx7OQpn545, kind, index, shell_row):
		total += __ydCl5L2QyDKE2SDpVsMZ5fEb(str(target["kind"]), int(target["index"]), shell_row, maxi(0, count))
	return total

func meti_main_market_role() -> int:
	return __2ZIL9u7_cM4KOmaAUAdneX5d.meti_catalog_main_seat(App.__PtNURh2PaYHMgsPlkLtni90Y(), __YJgAymCaLB78BrFx7OQpn545.__WeB9Hi0OxaFBUuwm2WU2qKEH, int(__MRgAcPuNvSjtNvNirEW1YRMP.get("index", 0)))

func meti_main_market_count() -> int:
	var catalog = App.__PtNURh2PaYHMgsPlkLtni90Y()
	var role = meti_main_market_role()
	var count = 0
	for i in __YJgAymCaLB78BrFx7OQpn545.__dOsDavODOasdfPxqce2DEBC3.size():
		if __2ZIL9u7_cM4KOmaAUAdneX5d.meti_catalog_main_seat(catalog, __YJgAymCaLB78BrFx7OQpn545.__WeB9Hi0OxaFBUuwm2WU2qKEH, i) == role: count += 1
	return count
