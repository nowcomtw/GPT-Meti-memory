class_name __21NGacAISHpzjaKmV3CZK2Y6
extends ScrollContainer
func __iJ22aV_vLfYyZHWX7zT82AbF(__tCaLWioCT96Br1L3_P9K1qQz: __cBjn_l7I8v2A2mo4oxWc1Hx5, name: String, color: Color) -> GridContainer:
	var h: = HBoxContainer.new()
	h.add_theme_constant_override("separation", 8)
	__L1UMAAcFIKEso9SLg2_9KDiK.add_child(h)
	var __Ncg8fmMhtpD68i0A3R1uI7X5: = Control.new()
	__Ncg8fmMhtpD68i0A3R1uI7X5.custom_minimum_size = Vector2(__jwCj43xPfUp2_WSTPQsaE8_6, __jwCj43xPfUp2_WSTPQsaE8_6)
	__Ncg8fmMhtpD68i0A3R1uI7X5.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
	__Ncg8fmMhtpD68i0A3R1uI7X5.mouse_filter = Control.MOUSE_FILTER_IGNORE
	h.add_child(__Ncg8fmMhtpD68i0A3R1uI7X5)
	if __tCaLWioCT96Br1L3_P9K1qQz != null:
		var __q94V10FjElFzosvBe_iYKEFj: = __3CVc7kD6yGCHSiBfO0OphMVd.new()
		__q94V10FjElFzosvBe_iYKEFj.__5SRgdq4kqUc88lslGOc_6RxY = __tCaLWioCT96Br1L3_P9K1qQz
		__q94V10FjElFzosvBe_iYKEFj.scale = Vector2(__4YMWnF_4gndXeXDd5kY15ORS, __4YMWnF_4gndXeXDd5kY15ORS)
		__q94V10FjElFzosvBe_iYKEFj.position = (Vector2(__jwCj43xPfUp2_WSTPQsaE8_6, __jwCj43xPfUp2_WSTPQsaE8_6) - Vector2(__tCaLWioCT96Br1L3_P9K1qQz.size) * __4YMWnF_4gndXeXDd5kY15ORS) / 2.0
		__Ncg8fmMhtpD68i0A3R1uI7X5.add_child(__q94V10FjElFzosvBe_iYKEFj)
	var right: = VBoxContainer.new()
	right.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	right.add_theme_constant_override("separation", 1)
	h.add_child(right)
	var __qev8Is5eHV2TulyqTtqhOJiv: = __mnbm3NNtKsR5RlBj8W9IIgBZ(name, color, 13)
	__qev8Is5eHV2TulyqTtqhOJiv.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	right.add_child(__qev8Is5eHV2TulyqTtqhOJiv)
	var g: = GridContainer.new()
	g.columns = 2
	g.add_theme_constant_override("h_separation", 10)
	g.add_theme_constant_override("v_separation", 1)
	right.add_child(g)
	return g
func __NXMt00d4Tq3aehd2TbhbE1Ch(g: GridContainer, __1F1XW59CvOypEoeT4PhFDzwT: String, value: String, color: Color = __eBt5HIxcCIYFCRhcyd21idU2.__pCUi6LToFPukNiGDrBwJ7It8) -> void :
	var __MZGopKoB5nMO2JRTPumud0Jl: = __mnbm3NNtKsR5RlBj8W9IIgBZ(__1F1XW59CvOypEoeT4PhFDzwT, __eBt5HIxcCIYFCRhcyd21idU2.__kVYXi_NVoyPvuzc3ek8hOGFd, 13)
	g.add_child(__MZGopKoB5nMO2JRTPumud0Jl)
	var v: = __mnbm3NNtKsR5RlBj8W9IIgBZ(value, color, 13)
	v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	v.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	g.add_child(v)
func __A_tYDYVUzk9vttnCIsCJbYrF(text: String, __fI0TF5C92Kv7puPCq3yAC4qY: String = "") -> void :
	var __b6u9HFs9m7E78oNHfQbTj6_R: = PanelContainer.new()
	__b6u9HFs9m7E78oNHfQbTj6_R.mouse_filter = Control.MOUSE_FILTER_IGNORE
	__b6u9HFs9m7E78oNHfQbTj6_R.add_theme_stylebox_override("panel", __1cRMctAifg483cHgRNgZQKXk(Color(0.03, 0.07, 0.11, 0.55), __KfvMFlFKIRnBwilCncvTp8qX, 1, 4, Vector4(8, 6, 8, 7)))
	__erQkUKaalgRUTQHBd5DsGcXp.add_child(__b6u9HFs9m7E78oNHfQbTj6_R)
	var __PGNNzXcfqlsCzzPf6Tl2gPa9: = VBoxContainer.new()
	__PGNNzXcfqlsCzzPf6Tl2gPa9.add_theme_constant_override("separation", 3)
	__b6u9HFs9m7E78oNHfQbTj6_R.add_child(__PGNNzXcfqlsCzzPf6Tl2gPa9)
	var h: = HBoxContainer.new()
	__PGNNzXcfqlsCzzPf6Tl2gPa9.add_child(h)
	var __3UdKrwzM8oxYRsMIrZKzECqj: = __mnbm3NNtKsR5RlBj8W9IIgBZ(text, __eBt5HIxcCIYFCRhcyd21idU2.GOLD, 14)
	__3UdKrwzM8oxYRsMIrZKzECqj.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	h.add_child(__3UdKrwzM8oxYRsMIrZKzECqj)
	if __fI0TF5C92Kv7puPCq3yAC4qY != "" and __zsjYADbMgGkrOA60WMZ9z8yM:
		var b: = Button.new()
		b.text = tr("UI_SPEC_CHANGE")
		b.tooltip_text = tr("UI_SPEC_CHANGE_TIP_" + __fI0TF5C92Kv7puPCq3yAC4qY.to_upper())
		b.focus_mode = Control.FOCUS_NONE
		b.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
		b.add_theme_font_size_override("font_size", 11)
		b.custom_minimum_size = Vector2(38, 18)
		b.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		for __ikJ37VqPviHldUKEEHOulNhT: Array in [["normal", 0.1], ["hover", 0.22], ["pressed", 0.05]]:
			b.add_theme_stylebox_override(__ikJ37VqPviHldUKEEHOulNhT[0], __1cRMctAifg483cHgRNgZQKXk(Color(0.42, 0.58, 0.74, __ikJ37VqPviHldUKEEHOulNhT[1]), __KfvMFlFKIRnBwilCncvTp8qX, 1, 3, Vector4(6, 0, 6, 1)))
		b.pressed.connect( func() -> void : __GM7CSPJaQDtDRbDnD39g1A8y.emit(__fI0TF5C92Kv7puPCq3yAC4qY))
		h.add_child(b)
	var __Gb1OyrofTFMa0Z9A5efZNIEZ: = ColorRect.new()
	__Gb1OyrofTFMa0Z9A5efZNIEZ.color = Color(__KfvMFlFKIRnBwilCncvTp8qX, 0.35)
	__Gb1OyrofTFMa0Z9A5efZNIEZ.custom_minimum_size = Vector2(0, 1)
	__Gb1OyrofTFMa0Z9A5efZNIEZ.mouse_filter = Control.MOUSE_FILTER_IGNORE
	__PGNNzXcfqlsCzzPf6Tl2gPa9.add_child(__Gb1OyrofTFMa0Z9A5efZNIEZ)
	__L1UMAAcFIKEso9SLg2_9KDiK = __PGNNzXcfqlsCzzPf6Tl2gPa9
func __Zs_NRND2aIHjT0QBiS5yVaRm(__Duapp_t5TwRyPlc3XdhFvu1l: __s8yZigV26lPAvEmbOWzMbnjE, __hmfcLu2X1Z4nlvw0UI1YbuQC: __MxRtF5kMQ2PhDOJRxJ1ej8ie) -> void :
	__L1UMAAcFIKEso9SLg2_9KDiK = __erQkUKaalgRUTQHBd5DsGcXp
	for __i7aaps6hhUqhgc_WqTFZhqN6: Node in __erQkUKaalgRUTQHBd5DsGcXp.get_children():
		__erQkUKaalgRUTQHBd5DsGcXp.remove_child(__i7aaps6hhUqhgc_WqTFZhqN6)
		__i7aaps6hhUqhgc_WqTFZhqN6.queue_free()
	var __dYMkGQWP_F3WHiaAFIiUe8kK: __Se4EsxPBCHX48h1ZS5MexaMl = App.__PtNURh2PaYHMgsPlkLtni90Y()
	var __t6YKulEII0C_Y7N8sKNRHquG: __bzxMmNAcE_RKMny5gklgDglw = App.___qFCN2viGM2bPW1uGV9qys9h()
	var __1CYcrxb0tTuBxlN7HXhkOu6Q: int = __Duapp_t5TwRyPlc3XdhFvu1l.__WeB9Hi0OxaFBUuwm2WU2qKEH
	if not __dYMkGQWP_F3WHiaAFIiUe8kK.__S427rIy8YAPI_7NTPBneiPZH(__1CYcrxb0tTuBxlN7HXhkOu6Q):
		return
	var __sWF_S5SHWyJuoelKZViuHGyv: Dictionary = __dYMkGQWP_F3WHiaAFIiUe8kK.__ofKSCLcCg7jWtqacDa153ehk(__1CYcrxb0tTuBxlN7HXhkOu6Q)
	var __LVLeX0y9kVDevIb63G91yioC: bool = __hmfcLu2X1Z4nlvw0UI1YbuQC != null and __hmfcLu2X1Z4nlvw0UI1YbuQC.__3pHTyYQlMesWCy5zSJELYO80 == __1CYcrxb0tTuBxlN7HXhkOu6Q
	__zsjYADbMgGkrOA60WMZ9z8yM = __LVLeX0y9kVDevIb63G91yioC
	var __uhOib_DXmR5KLxAyYDve8SyR: __s8yZigV26lPAvEmbOWzMbnjE = __hmfcLu2X1Z4nlvw0UI1YbuQC.__nfaBZ_xIiHIPY3GkBUUjEEyF(__Duapp_t5TwRyPlc3XdhFvu1l) if __LVLeX0y9kVDevIb63G91yioC else __Duapp_t5TwRyPlc3XdhFvu1l
	var __MDxJB2sHssOPtHFJ1rbp2AoQ: = {"key": "spec", "frame_row": __1CYcrxb0tTuBxlN7HXhkOu6Q, "gun_rows": Array(__Duapp_t5TwRyPlc3XdhFvu1l.__dOsDavODOasdfPxqce2DEBC3), "side": 0, "player": true, "ai": null, "pos": Vector2i.ZERO, "heading": 0, "crew": __uhOib_DXmR5KLxAyYDve8SyR.__EfJKGcQvIptwi5lKkR8NBpI6(), "gun_ammo": __Ti__RyaVjFAbq0eWKyiulRtX.__RgxkBWnYRjC44wuJnI7BKnV_(__Duapp_t5TwRyPlc3XdhFvu1l), "fcs": __Duapp_t5TwRyPlc3XdhFvu1l.__vwSAcybbCInOpnt2FbN4qz7L, "armor": __Duapp_t5TwRyPlc3XdhFvu1l.__cQ8JInnnrEoGxd_1jglej7pR, "engine": __dYMkGQWP_F3WHiaAFIiUe8kK.__Qw3k08OnVM2mR_e4yUtGgVFs(__Duapp_t5TwRyPlc3XdhFvu1l), "crew_engine": __uhOib_DXmR5KLxAyYDve8SyR.__r9BsTmtwzeYPsGTYxXbgs5gZ, "crew_weight": __uhOib_DXmR5KLxAyYDve8SyR.__RuEf8sDpDtu0ArTJYzf6W0JG, "side_guns": __Ti__RyaVjFAbq0eWKyiulRtX.__PApmoLqPUYMxHjVKJXlCVSNj(__Duapp_t5TwRyPlc3XdhFvu1l), "torps": __Ti__RyaVjFAbq0eWKyiulRtX.__AtK05FiW_JVImRFYAMahs5BX(__Duapp_t5TwRyPlc3XdhFvu1l), "air": __Ti__RyaVjFAbq0eWKyiulRtX.__mgdM7ycmi3DNHzWo0uObSaPX(__Duapp_t5TwRyPlc3XdhFvu1l)}

	var meti_flat: PackedInt32Array = __Ti__RyaVjFAbq0eWKyiulRtX.__RgxkBWnYRjC44wuJnI7BKnV_(__Duapp_t5TwRyPlc3XdhFvu1l)
	var meti_nested: Array = []
	for i in __Duapp_t5TwRyPlc3XdhFvu1l.__dOsDavODOasdfPxqce2DEBC3.size(): meti_nested.append(Array(meti_flat.slice(i * 4, i * 4 + 4)))
	__MDxJB2sHssOPtHFJ1rbp2AoQ["gun_ammo"] = meti_nested
	var meti_mounts: PackedInt32Array = __dYMkGQWP_F3WHiaAFIiUe8kK.__4mBhSAAMIt6DTsibdV0pC19W(__1CYcrxb0tTuBxlN7HXhkOu6Q)
	var meti_rows: PackedInt32Array = __dYMkGQWP_F3WHiaAFIiUe8kK.__PJZemYw0whDwrAt4vbBLpQ7w(__Duapp_t5TwRyPlc3XdhFvu1l)
	var meti_ammo: PackedInt32Array = __dYMkGQWP_F3WHiaAFIiUe8kK.__Xs0yLUqBQ7TVWSHzfx4EiUAr(__Duapp_t5TwRyPlc3XdhFvu1l)
	var meti_side: Array = []
	for i in meti_rows.size():
		if meti_rows[i] >= 0: meti_side.append([meti_mounts[i], meti_rows[i]] + Array(meti_ammo.slice(i * 4, i * 4 + 4)))
	__MDxJB2sHssOPtHFJ1rbp2AoQ["side_guns"] = meti_side
	var __8S6135ZkRczf6rw9xg3vEGuC: __YdhZSn3k6BLtSITi5naOCb7n = __2ZIL9u7_cM4KOmaAUAdneX5d.__CqzDpplM5ETWU2SW2VGKogkg(__t6YKulEII0C_Y7N8sKNRHquG, __MDxJB2sHssOPtHFJ1rbp2AoQ, __NYbIaW78BNqdaS0BgoYwqAci.__O1Urlr6IdUTnFWvioe6wcQrt.new(8, 8), 0)
	var title: = __mnbm3NNtKsR5RlBj8W9IIgBZ(App.__A6XI74bFN3243pFbSLAzzTVt(__1CYcrxb0tTuBxlN7HXhkOu6Q), __eBt5HIxcCIYFCRhcyd21idU2.__pCUi6LToFPukNiGDrBwJ7It8, 17)
	title.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	__L1UMAAcFIKEso9SLg2_9KDiK.add_child(title)
	__L1UMAAcFIKEso9SLg2_9KDiK.add_child(__mnbm3NNtKsR5RlBj8W9IIgBZ("%s　Lv%d　%s" % [tr("UI_SHIPTYPE_%d" % int(__sWF_S5SHWyJuoelKZViuHGyv["kind"])), __dYMkGQWP_F3WHiaAFIiUe8kK.__YYdrcqw869Ksy5fDhyntjB3x(__1CYcrxb0tTuBxlN7HXhkOu6Q), App.__AqRLmDaYMC2aA5Jk6DLdJAGf(str(__sWF_S5SHWyJuoelKZViuHGyv["label"]))], __eBt5HIxcCIYFCRhcyd21idU2.__kVYXi_NVoyPvuzc3ek8hOGFd, 13))
	__A_tYDYVUzk9vttnCIsCJbYrF(tr("UI_SPEC_HULL"))
	var g: = __poyQQ3v0QtcDY0aSCwjsIMSh()
	__NXMt00d4Tq3aehd2TbhbE1Ch(g, tr("UI_SPEC_HP"), "%d / %d" % [__8S6135ZkRczf6rw9xg3vEGuC.__F41ZT8z_0zKKqYDFwqS1WGTs, __8S6135ZkRczf6rw9xg3vEGuC.__EnRnlPve0Y145ZsCmTA3iWUI])
	__wdwmWtKigWF9FpVnmu4AABfx(1.0, Color8(110, 210, 120))
	g = __poyQQ3v0QtcDY0aSCwjsIMSh()
	__NXMt00d4Tq3aehd2TbhbE1Ch(g, tr("UI_SPEC_SIGHT"), "%d" % __dYMkGQWP_F3WHiaAFIiUe8kK.__0ei7_11E4Vsboqiw_nj_V3fO(__1CYcrxb0tTuBxlN7HXhkOu6Q))
	if __dYMkGQWP_F3WHiaAFIiUe8kK.__qYFERErK1LYUL_U6LL8iyJj9(__1CYcrxb0tTuBxlN7HXhkOu6Q) > 0:
		__NXMt00d4Tq3aehd2TbhbE1Ch(g, tr("UI_SPEC_O2"), "%d" % __dYMkGQWP_F3WHiaAFIiUe8kK.__qYFERErK1LYUL_U6LL8iyJj9(__1CYcrxb0tTuBxlN7HXhkOu6Q))
	var d: Vector2i = __dYMkGQWP_F3WHiaAFIiUe8kK.__77YZ0E3pilwCWMSZ5lHzv_es(__Duapp_t5TwRyPlc3XdhFvu1l)
	var __kMlMVRYmB8YkkTCEd8zQjXV8: int = d.x + (__hmfcLu2X1Z4nlvw0UI1YbuQC.__RuEf8sDpDtu0ArTJYzf6W0JG() if __LVLeX0y9kVDevIb63G91yioC else 0)
	var __dPXTIG_UCoOLfFyld_Dq0caB: bool = __kMlMVRYmB8YkkTCEd8zQjXV8 > d.y
	g = __poyQQ3v0QtcDY0aSCwjsIMSh()
	__NXMt00d4Tq3aehd2TbhbE1Ch(g, tr("UI_SPEC_DISP"), tr("UI_SPEC_TONS") % [__kMlMVRYmB8YkkTCEd8zQjXV8 / 1000, d.y / 1000], __eBt5HIxcCIYFCRhcyd21idU2.__PDJ2eYH1RM56AXV47Yaop2B3 if __dPXTIG_UCoOLfFyld_Dq0caB else __eBt5HIxcCIYFCRhcyd21idU2.__pCUi6LToFPukNiGDrBwJ7It8)
	__wdwmWtKigWF9FpVnmu4AABfx(float(__kMlMVRYmB8YkkTCEd8zQjXV8) / maxf(1.0, d.y), __eBt5HIxcCIYFCRhcyd21idU2.__PDJ2eYH1RM56AXV47Yaop2B3 if __dPXTIG_UCoOLfFyld_Dq0caB else Color8(90, 170, 255))
	if __LVLeX0y9kVDevIb63G91yioC:
		g = __poyQQ3v0QtcDY0aSCwjsIMSh()
		__NXMt00d4Tq3aehd2TbhbE1Ch(g, tr("UI_SPEC_DISP_EQUIP"), tr("UI_SPEC_TONS_ONE") % (d.x / 1000), __eBt5HIxcCIYFCRhcyd21idU2.__kVYXi_NVoyPvuzc3ek8hOGFd)
		__NXMt00d4Tq3aehd2TbhbE1Ch(g, tr("UI_SPEC_DISP_CREW"), tr("UI_SPEC_TONS_ONE") % (__hmfcLu2X1Z4nlvw0UI1YbuQC.__RuEf8sDpDtu0ArTJYzf6W0JG() / 1000), __eBt5HIxcCIYFCRhcyd21idU2.__kVYXi_NVoyPvuzc3ek8hOGFd)
	__A_tYDYVUzk9vttnCIsCJbYrF(tr("UI_SPEC_ARMOR"), "armor")
	var __Mr0nGjlm_MZLYhitDOto4uVU: __nZxK7u5JB3kHTF7XC5Hr9MHe.__C9ZAnKztslaadyzGQaCAJD4g = __8S6135ZkRczf6rw9xg3vEGuC.target
	var __gP5Qvc2TziEL9BTDjPChpfgk: = GridContainer.new()
	__gP5Qvc2TziEL9BTDjPChpfgk.columns = 3
	__gP5Qvc2TziEL9BTDjPChpfgk.add_theme_constant_override("h_separation", 10)
	__L1UMAAcFIKEso9SLg2_9KDiK.add_child(__gP5Qvc2TziEL9BTDjPChpfgk)
	for __kh55DOy2_quazpfamMO0EjTH: Array in [["", __eBt5HIxcCIYFCRhcyd21idU2.__kVYXi_NVoyPvuzc3ek8hOGFd], [tr("UI_SPEC_DECK"), __eBt5HIxcCIYFCRhcyd21idU2.__kVYXi_NVoyPvuzc3ek8hOGFd], [tr("UI_SPEC_SIDE"), __eBt5HIxcCIYFCRhcyd21idU2.__kVYXi_NVoyPvuzc3ek8hOGFd], [tr("UI_SPEC_AP"), __eBt5HIxcCIYFCRhcyd21idU2.__kVYXi_NVoyPvuzc3ek8hOGFd], [str(__Mr0nGjlm_MZLYhitDOto4uVU.ap_deck), __eBt5HIxcCIYFCRhcyd21idU2.__pCUi6LToFPukNiGDrBwJ7It8], [str(__Mr0nGjlm_MZLYhitDOto4uVU.ap_side), __eBt5HIxcCIYFCRhcyd21idU2.__pCUi6LToFPukNiGDrBwJ7It8], [tr("UI_SPEC_HE"), __eBt5HIxcCIYFCRhcyd21idU2.__kVYXi_NVoyPvuzc3ek8hOGFd], [str(__Mr0nGjlm_MZLYhitDOto4uVU.he_deck), __eBt5HIxcCIYFCRhcyd21idU2.__pCUi6LToFPukNiGDrBwJ7It8], [str(__Mr0nGjlm_MZLYhitDOto4uVU.he_side), __eBt5HIxcCIYFCRhcyd21idU2.__pCUi6LToFPukNiGDrBwJ7It8]]:
		var __866YQqfKqpomDBlutT8gXl62: = __mnbm3NNtKsR5RlBj8W9IIgBZ(__kh55DOy2_quazpfamMO0EjTH[0], __kh55DOy2_quazpfamMO0EjTH[1], 13)
		__866YQqfKqpomDBlutT8gXl62.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		if __gP5Qvc2TziEL9BTDjPChpfgk.get_child_count() % 3 != 0:
			__866YQqfKqpomDBlutT8gXl62.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
		__gP5Qvc2TziEL9BTDjPChpfgk.add_child(__866YQqfKqpomDBlutT8gXl62)
	g = __poyQQ3v0QtcDY0aSCwjsIMSh()
	__NXMt00d4Tq3aehd2TbhbE1Ch(g, tr("UI_SPEC_SUB"), "%.2f%%" % (__Mr0nGjlm_MZLYhitDOto4uVU.sub / 100.0))
	var __RKprcKYn2a4xgOrT_V7H3Pzd: PackedInt32Array = __Se4EsxPBCHX48h1ZS5MexaMl.__z60ooVwI9Q0G4gXJuZ_QzkIy(__Duapp_t5TwRyPlc3XdhFvu1l.__cQ8JInnnrEoGxd_1jglej7pR)
	__NXMt00d4Tq3aehd2TbhbE1Ch(g, tr("UI_SPEC_THICK"), "%s / %s" % [__cJUQCT0w1JgndX7HvaSfR9Hm(__RKprcKYn2a4xgOrT_V7H3Pzd[1]), __cJUQCT0w1JgndX7HvaSfR9Hm(__RKprcKYn2a4xgOrT_V7H3Pzd[3])])
	if __Mr0nGjlm_MZLYhitDOto4uVU.__tU3LKkiKFkCz9gqPVWopN1ej > 0:
		__NXMt00d4Tq3aehd2TbhbE1Ch(g, tr("UI_SPEC_BULGE"), "%d / %d" % [__Mr0nGjlm_MZLYhitDOto4uVU.__tU3LKkiKFkCz9gqPVWopN1ej, __Mr0nGjlm_MZLYhitDOto4uVU.__Ub5aVTwuCgOWLFhYmM4vLKch])
	__A_tYDYVUzk9vttnCIsCJbYrF(tr("UI_SPEC_FCS"), "fcs")
	if __Duapp_t5TwRyPlc3XdhFvu1l.__vwSAcybbCInOpnt2FbN4qz7L < 0:
		g = __iJ22aV_vLfYyZHWX7zT82AbF(null, tr("UI_SPEC_NOT_FITTED"), __eBt5HIxcCIYFCRhcyd21idU2.__PDJ2eYH1RM56AXV47Yaop2B3)
	else:
		var __o8fHratXQRLR7qTOoW_q_Gbx: Dictionary = __dYMkGQWP_F3WHiaAFIiUe8kK.__vwSAcybbCInOpnt2FbN4qz7L(__Duapp_t5TwRyPlc3XdhFvu1l.__vwSAcybbCInOpnt2FbN4qz7L)
		g = __iJ22aV_vLfYyZHWX7zT82AbF(__LcEmKczmLrorVyOBaMDnHamK("ComponentsFCS", int(__o8fHratXQRLR7qTOoW_q_Gbx.get("art", -10)) + 2), str(__o8fHratXQRLR7qTOoW_q_Gbx.get("name", tr("UI_SPEC_DEFAULT"))), __eBt5HIxcCIYFCRhcyd21idU2.__pCUi6LToFPukNiGDrBwJ7It8)
		__NXMt00d4Tq3aehd2TbhbE1Ch(g, tr("UI_SPEC_TRACK"), str(__t6YKulEII0C_Y7N8sKNRHquG.__Jy2hcMM9emCF3iBBkLMyeUr7("FCS", __Duapp_t5TwRyPlc3XdhFvu1l.__vwSAcybbCInOpnt2FbN4qz7L, 154)))
		__NXMt00d4Tq3aehd2TbhbE1Ch(g, tr("UI_SPEC_HITMOD"), "%+d" % __t6YKulEII0C_Y7N8sKNRHquG.__Jy2hcMM9emCF3iBBkLMyeUr7("FCS", __Duapp_t5TwRyPlc3XdhFvu1l.__vwSAcybbCInOpnt2FbN4qz7L, 152))
		__NXMt00d4Tq3aehd2TbhbE1Ch(g, tr("UI_SPEC_LINE"), str(__8S6135ZkRczf6rw9xg3vEGuC.__dKFYKO52kDsiWE3ajFZXSNS8))
	__A_tYDYVUzk9vttnCIsCJbYrF(tr("UI_SPEC_ENGINE"), "engine")
	var __TthLCH4l_M2l9wZ5Jb_83ma1: int = __dYMkGQWP_F3WHiaAFIiUe8kK.__Qw3k08OnVM2mR_e4yUtGgVFs(__Duapp_t5TwRyPlc3XdhFvu1l)
	var __pqGrY2U_MwX9ZBW91e0X06OB: Dictionary = __dYMkGQWP_F3WHiaAFIiUe8kK.__NELIelBEafKRGQultNqYAbM7(__TthLCH4l_M2l9wZ5Jb_83ma1)
	g = __iJ22aV_vLfYyZHWX7zT82AbF(__LcEmKczmLrorVyOBaMDnHamK("ComponentsEng", int(__pqGrY2U_MwX9ZBW91e0X06OB.get("art", -10)) + 2) if not __pqGrY2U_MwX9ZBW91e0X06OB.is_empty() else null, str(__pqGrY2U_MwX9ZBW91e0X06OB.get("name", tr("UI_SPEC_DEFAULT"))), __eBt5HIxcCIYFCRhcyd21idU2.__pCUi6LToFPukNiGDrBwJ7It8 if not __pqGrY2U_MwX9ZBW91e0X06OB.is_empty() else __eBt5HIxcCIYFCRhcyd21idU2.__kVYXi_NVoyPvuzc3ek8hOGFd)
	if __pqGrY2U_MwX9ZBW91e0X06OB.is_empty():
		__NXMt00d4Tq3aehd2TbhbE1Ch(g, tr("UI_SPEC_HP_POWER"), "—", __eBt5HIxcCIYFCRhcyd21idU2.__kVYXi_NVoyPvuzc3ek8hOGFd)
	else:
		__NXMt00d4Tq3aehd2TbhbE1Ch(g, tr("UI_SPEC_HP_POWER"), str(__pqGrY2U_MwX9ZBW91e0X06OB.get("hp", 0)))
		__NXMt00d4Tq3aehd2TbhbE1Ch(g, tr("UI_SPEC_OD"), "+%d%%" % int(__8S6135ZkRczf6rw9xg3vEGuC.__NELIelBEafKRGQultNqYAbM7["od"]))
		__NXMt00d4Tq3aehd2TbhbE1Ch(g, tr("UI_SPEC_HEAT"), str(int(__8S6135ZkRczf6rw9xg3vEGuC.__NELIelBEafKRGQultNqYAbM7["heat_max"])))
	__NXMt00d4Tq3aehd2TbhbE1Ch(g, tr("UI_SPEC_SPEED"), tr("UI_SPEC_KNOTS") % (int(__8S6135ZkRczf6rw9xg3vEGuC.__NELIelBEafKRGQultNqYAbM7["max_speed"]) / 100))
	var meti_summary = meti_draw_gun_sections(__8S6135ZkRczf6rw9xg3vEGuC, __dYMkGQWP_F3WHiaAFIiUe8kK)
	var __3CdVlMCIeQe_2ugPJut0Gq7O: int = meti_summary["primary_ammo"]
	var __aALmk3WOcRmf99p_WyTW9Jo1: PackedInt32Array = __dYMkGQWP_F3WHiaAFIiUe8kK.__Hmr_a2CPvjknmgXnhmVu1vm9(__1CYcrxb0tTuBxlN7HXhkOu6Q)
	if not __aALmk3WOcRmf99p_WyTW9Jo1.is_empty():
		var __HomPKaShT2ROT1N94EyyKfPz: PackedInt32Array = __dYMkGQWP_F3WHiaAFIiUe8kK.__7uBhyRNBJZP4s1InKu8Lo_y7(__Duapp_t5TwRyPlc3XdhFvu1l)
		var __IwW5qb2bVeACNUvCdj6jV_VG: int = 0
		var __2Mwbb7Irdjwq28abokqr1V5D: int = 0
		for r: int in __HomPKaShT2ROT1N94EyyKfPz:
			if r >= 0:
				__IwW5qb2bVeACNUvCdj6jV_VG += 1
				__2Mwbb7Irdjwq28abokqr1V5D += int(__dYMkGQWP_F3WHiaAFIiUe8kK.__GP_inhBqbirtrHNQn7xXbKG_(r).get("tubes", 0))
		__A_tYDYVUzk9vttnCIsCJbYrF(tr("UI_SPEC_TORP") % [__IwW5qb2bVeACNUvCdj6jV_VG, __aALmk3WOcRmf99p_WyTW9Jo1.size()])
		g = __poyQQ3v0QtcDY0aSCwjsIMSh()
		var __v026e7kBDOepj3TMNXyvCxfC: PackedInt32Array = __dYMkGQWP_F3WHiaAFIiUe8kK.__El7brR86C9a6x0hMgLnIgY3e(__Duapp_t5TwRyPlc3XdhFvu1l)
		for __eZ90fPBa72aorTBYTGmr2suI: int in __aALmk3WOcRmf99p_WyTW9Jo1.size():
			var __eHUi1ZgCCB98H08MDALxOmyr: Dictionary = __dYMkGQWP_F3WHiaAFIiUe8kK.__GP_inhBqbirtrHNQn7xXbKG_(__HomPKaShT2ROT1N94EyyKfPz[__eZ90fPBa72aorTBYTGmr2suI]) if __HomPKaShT2ROT1N94EyyKfPz[__eZ90fPBa72aorTBYTGmr2suI] >= 0 else {}
			__NXMt00d4Tq3aehd2TbhbE1Ch(g, tr("UI_SPEC_TORP_N") % [__eZ90fPBa72aorTBYTGmr2suI + 1, __aALmk3WOcRmf99p_WyTW9Jo1[__eZ90fPBa72aorTBYTGmr2suI]], tr("UI_SPEC_TORP_V") % [int(__eHUi1ZgCCB98H08MDALxOmyr["tubes"]), __eHUi1ZgCCB98H08MDALxOmyr["name"]] if not __eHUi1ZgCCB98H08MDALxOmyr.is_empty() else tr("UI_SS_EMPTY_SLOT"), __eBt5HIxcCIYFCRhcyd21idU2.__pCUi6LToFPukNiGDrBwJ7It8 if not __eHUi1ZgCCB98H08MDALxOmyr.is_empty() else __eBt5HIxcCIYFCRhcyd21idU2.__kVYXi_NVoyPvuzc3ek8hOGFd)
			if not __eHUi1ZgCCB98H08MDALxOmyr.is_empty():
				var __sCGVTnxTJKzaNoDfCChD0ol_: bool = __v026e7kBDOepj3TMNXyvCxfC[2 * __eZ90fPBa72aorTBYTGmr2suI] >= 0 and __v026e7kBDOepj3TMNXyvCxfC[2 * __eZ90fPBa72aorTBYTGmr2suI + 1] > 0
				__NXMt00d4Tq3aehd2TbhbE1Ch(g, "", tr("UI_SPEC_TORP_AMMO") % [__dYMkGQWP_F3WHiaAFIiUe8kK.__zhHTezbt3nPUGWVaU6OaVpvy(__v026e7kBDOepj3TMNXyvCxfC[2 * __eZ90fPBa72aorTBYTGmr2suI]).get("name", "—"), __v026e7kBDOepj3TMNXyvCxfC[2 * __eZ90fPBa72aorTBYTGmr2suI + 1]]
					if __sCGVTnxTJKzaNoDfCChD0ol_ else tr("UI_SS_NO_TORPEDO"), __eBt5HIxcCIYFCRhcyd21idU2.__pCUi6LToFPukNiGDrBwJ7It8 if __sCGVTnxTJKzaNoDfCChD0ol_ else __eBt5HIxcCIYFCRhcyd21idU2.__kVYXi_NVoyPvuzc3ek8hOGFd)
		if __IwW5qb2bVeACNUvCdj6jV_VG > 0:
			g = __poyQQ3v0QtcDY0aSCwjsIMSh()
			__NXMt00d4Tq3aehd2TbhbE1Ch(g, tr("UI_SPEC_TORP_SALVO"), tr("UI_SPEC_TORP_SALVO_V") % __2Mwbb7Irdjwq28abokqr1V5D)
			__NXMt00d4Tq3aehd2TbhbE1Ch(g, tr("UI_SPEC_TORP_SPACE"), "%d / %d" % [__dYMkGQWP_F3WHiaAFIiUe8kK.__1CdXpyU1UJ8cmNMTd_g2_0od(__Duapp_t5TwRyPlc3XdhFvu1l), __dYMkGQWP_F3WHiaAFIiUe8kK.__eO4VHYjMVObwrueIqrahxQOQ(__1CYcrxb0tTuBxlN7HXhkOu6Q)], __eBt5HIxcCIYFCRhcyd21idU2.__PDJ2eYH1RM56AXV47Yaop2B3 if __dYMkGQWP_F3WHiaAFIiUe8kK.__1CdXpyU1UJ8cmNMTd_g2_0od(__Duapp_t5TwRyPlc3XdhFvu1l) > __dYMkGQWP_F3WHiaAFIiUe8kK.__eO4VHYjMVObwrueIqrahxQOQ(__1CYcrxb0tTuBxlN7HXhkOu6Q) else __eBt5HIxcCIYFCRhcyd21idU2.__pCUi6LToFPukNiGDrBwJ7It8)
	__A_tYDYVUzk9vttnCIsCJbYrF(tr("UI_SPEC_AMMO"))
	g = __poyQQ3v0QtcDY0aSCwjsIMSh()
	__NXMt00d4Tq3aehd2TbhbE1Ch(g, tr("UI_SPEC_AMMO_MAIN"), str(__3CdVlMCIeQe_2ugPJut0Gq7O))
	if int(meti_summary["secondary_count"]) > 0: __NXMt00d4Tq3aehd2TbhbE1Ch(g, "副砲彈藥", str(meti_summary["secondary_ammo"]))
	var __ADeejB62g2Lab8_SxRZR7Ilj: String = ""
	if __dYMkGQWP_F3WHiaAFIiUe8kK.__BGxXnVzPsmPLUaUtEL38SXTm(__Duapp_t5TwRyPlc3XdhFvu1l) != __Se4EsxPBCHX48h1ZS5MexaMl.__5CDMR1_ZY_Be5hesPdyczkNt.OK:
		__ADeejB62g2Lab8_SxRZR7Ilj = tr("UI_SS_ERR_%d" % __dYMkGQWP_F3WHiaAFIiUe8kK.__BGxXnVzPsmPLUaUtEL38SXTm(__Duapp_t5TwRyPlc3XdhFvu1l))
	elif __LVLeX0y9kVDevIb63G91yioC:
		var __JqKbBBAICm4sXqiRguYUJOfx: String = __hmfcLu2X1Z4nlvw0UI1YbuQC.__lmpWsWqjW3K_vd5n9ILNvkzw(__Duapp_t5TwRyPlc3XdhFvu1l)
		__ADeejB62g2Lab8_SxRZR7Ilj = tr(__JqKbBBAICm4sXqiRguYUJOfx) if __JqKbBBAICm4sXqiRguYUJOfx != "" else ""
	__L1UMAAcFIKEso9SLg2_9KDiK = __erQkUKaalgRUTQHBd5DsGcXp
	if __ADeejB62g2Lab8_SxRZR7Ilj != "":
		var __6yhKYpFhaca6XWTeL6fLllYg: = __mnbm3NNtKsR5RlBj8W9IIgBZ(__ADeejB62g2Lab8_SxRZR7Ilj, __eBt5HIxcCIYFCRhcyd21idU2.__PDJ2eYH1RM56AXV47Yaop2B3, 13)
		__6yhKYpFhaca6XWTeL6fLllYg.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		__L1UMAAcFIKEso9SLg2_9KDiK.add_child(__6yhKYpFhaca6XWTeL6fLllYg)
func __wdwmWtKigWF9FpVnmu4AABfx(ratio: float, color: Color) -> void :
	var __o7dGFyIn0f1Fn4LANqc6S19b: = ProgressBar.new()
	__o7dGFyIn0f1Fn4LANqc6S19b.show_percentage = false
	__o7dGFyIn0f1Fn4LANqc6S19b.custom_minimum_size = Vector2(0, 5)
	__o7dGFyIn0f1Fn4LANqc6S19b.max_value = 1000
	__o7dGFyIn0f1Fn4LANqc6S19b.value = clampf(ratio, 0.0, 1.0) * 1000
	__o7dGFyIn0f1Fn4LANqc6S19b.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var __3xAjbrYtYu1Yr4Si01iJhePu: = StyleBoxFlat.new()
	__3xAjbrYtYu1Yr4Si01iJhePu.bg_color = Color(0.02, 0.05, 0.08, 1)
	var __SVQ2jy4aTZZlJEImR6ZrbOTR: = StyleBoxFlat.new()
	__SVQ2jy4aTZZlJEImR6ZrbOTR.bg_color = color
	__o7dGFyIn0f1Fn4LANqc6S19b.add_theme_stylebox_override("background", __3xAjbrYtYu1Yr4Si01iJhePu)
	__o7dGFyIn0f1Fn4LANqc6S19b.add_theme_stylebox_override("fill", __SVQ2jy4aTZZlJEImR6ZrbOTR)
	__L1UMAAcFIKEso9SLg2_9KDiK.add_child(__o7dGFyIn0f1Fn4LANqc6S19b)
var __erQkUKaalgRUTQHBd5DsGcXp: VBoxContainer
static func __1cRMctAifg483cHgRNgZQKXk(__LDZbbS8ZdXt6bOhm9inFE2Vs: Color, __5GTYMvuoc9MuYL0D9Z4Nnhja: Color, w: int, r: int, __p3iHFQcC7lqIpKCpUPm4I1nA: Vector4) -> StyleBoxFlat:
	var __65w1iyWtRyo4iHYfOUGClLDJ: = StyleBoxFlat.new()
	__65w1iyWtRyo4iHYfOUGClLDJ.bg_color = __LDZbbS8ZdXt6bOhm9inFE2Vs
	__65w1iyWtRyo4iHYfOUGClLDJ.border_color = __5GTYMvuoc9MuYL0D9Z4Nnhja
	__65w1iyWtRyo4iHYfOUGClLDJ.set_border_width_all(w)
	__65w1iyWtRyo4iHYfOUGClLDJ.set_corner_radius_all(r)
	__65w1iyWtRyo4iHYfOUGClLDJ.content_margin_left = __p3iHFQcC7lqIpKCpUPm4I1nA.x
	__65w1iyWtRyo4iHYfOUGClLDJ.content_margin_top = __p3iHFQcC7lqIpKCpUPm4I1nA.y
	__65w1iyWtRyo4iHYfOUGClLDJ.content_margin_right = __p3iHFQcC7lqIpKCpUPm4I1nA.z
	__65w1iyWtRyo4iHYfOUGClLDJ.content_margin_bottom = __p3iHFQcC7lqIpKCpUPm4I1nA.w
	return __65w1iyWtRyo4iHYfOUGClLDJ
var __zsjYADbMgGkrOA60WMZ9z8yM: bool = false
const __KfvMFlFKIRnBwilCncvTp8qX: = Color(0.42, 0.58, 0.74, 0.55)
var __L1UMAAcFIKEso9SLg2_9KDiK: VBoxContainer
const __jwCj43xPfUp2_WSTPQsaE8_6: = 50.0 * __4YMWnF_4gndXeXDd5kY15ORS
func __mnbm3NNtKsR5RlBj8W9IIgBZ(text: String, color: Color, __HLAkdcg7V64aSbtZxg8asvqK: int) -> Label:
	var __CmYafmU57oHadUPtivrrSluu: = Label.new()
	__CmYafmU57oHadUPtivrrSluu.text = text
	__CmYafmU57oHadUPtivrrSluu.add_theme_font_size_override("font_size", __HLAkdcg7V64aSbtZxg8asvqK)
	__CmYafmU57oHadUPtivrrSluu.add_theme_color_override("font_color", color)
	__CmYafmU57oHadUPtivrrSluu.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return __CmYafmU57oHadUPtivrrSluu
const __4YMWnF_4gndXeXDd5kY15ORS: = 1.3
static func __LcEmKczmLrorVyOBaMDnHamK(pack: String, b: int) -> __cBjn_l7I8v2A2mo4oxWc1Hx5:
	if b < 0 or not Assets.__QiUGArjHDhwcrWbH3BB0K8c5(pack, b):
		return null
	return Assets.__MUCguPydNQwl8ZRXUX2ciJ44(pack, b).frame(0)
signal __GM7CSPJaQDtDRbDnD39g1A8y(__aBMa7lqL757DuGFOKAbcvnBB: String)
static func __cJUQCT0w1JgndX7HvaSfR9Hm(__tzrPw6uqOxyYYDXbc70jqaoN: int) -> String:
	return "%d.%d\"" % [__tzrPw6uqOxyYYDXbc70jqaoN / 10, __tzrPw6uqOxyYYDXbc70jqaoN % 10] if __tzrPw6uqOxyYYDXbc70jqaoN > 0 else "—"
func __poyQQ3v0QtcDY0aSCwjsIMSh() -> GridContainer:
	var g: = GridContainer.new()
	g.columns = 2
	g.add_theme_constant_override("h_separation", 10)
	g.add_theme_constant_override("v_separation", 1)
	__L1UMAAcFIKEso9SLg2_9KDiK.add_child(g)
	return g
func _init() -> void :
	horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	size_flags_vertical = Control.SIZE_EXPAND_FILL
	__erQkUKaalgRUTQHBd5DsGcXp = VBoxContainer.new()
	__erQkUKaalgRUTQHBd5DsGcXp.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	__erQkUKaalgRUTQHBd5DsGcXp.add_theme_constant_override("separation", 6)
	add_child(__erQkUKaalgRUTQHBd5DsGcXp)
	__L1UMAAcFIKEso9SLg2_9KDiK = __erQkUKaalgRUTQHBd5DsGcXp


func meti_draw_gun_sections(ship: Variant, catalog: Variant) -> Dictionary:
	var summary = {"primary_count": 0, "secondary_count": 0, "primary_ammo": 0, "secondary_ammo": 0}
	for seat in 2:
		var guns: Array[Dictionary] = []
		for gun: Dictionary in ship.__BJReFJ4ugditvprP9JFCx5S2:
			if int(gun.get("seat", 0)) == seat: guns.append(gun)
		summary["primary_count" if seat == 0 else "secondary_count"] = guns.size()
		if seat == 1 and guns.is_empty(): continue
		__A_tYDYVUzk9vttnCIsCJbYrF(("主砲（%d 座）" if seat == 0 else "副砲（%d 座）") % guns.size())
		var grid = __poyQQ3v0QtcDY0aSCwjsIMSh()
		var barrels = 0
		for index in guns.size():
			var gun = guns[index]
			var spec: Dictionary = catalog.__Y7oNU_MxqAazQR74RzaCuaOa(int(gun["gunset_row"]))
			barrels += int(gun["barrels"])
			summary["primary_ammo" if seat == 0 else "secondary_ammo"] += int(gun["ammo_a"]) + int(gun["ammo_b"])
			__NXMt00d4Tq3aehd2TbhbE1Ch(grid, tr("UI_SPEC_GUN_N") % [index + 1, int(spec.get("caliber", 0)) / 100.0, int(gun["barrels"])], tr("UI_SPEC_GUN_V") % [int(gun["reload_total"]) / 25.0, int(gun["acc70"])])
		if not guns.is_empty():
			var first = guns[0]
			grid = __poyQQ3v0QtcDY0aSCwjsIMSh()
			__NXMt00d4Tq3aehd2TbhbE1Ch(grid, tr("UI_SPEC_SALVO"), tr("UI_SPEC_SALVO_V") % barrels)
			__NXMt00d4Tq3aehd2TbhbE1Ch(grid, tr("UI_SPEC_ELEV"), "%d°" % (int(first["max_el"]) / 10))
			__NXMt00d4Tq3aehd2TbhbE1Ch(grid, tr("UI_SPEC_V0"), str(first["V0"]))
	set_meta("meti_gun_role_summary", summary.duplicate())
	return summary
