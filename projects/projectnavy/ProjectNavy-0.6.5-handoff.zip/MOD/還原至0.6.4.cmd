@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0manage_mod.ps1" -Action Restore
pause
